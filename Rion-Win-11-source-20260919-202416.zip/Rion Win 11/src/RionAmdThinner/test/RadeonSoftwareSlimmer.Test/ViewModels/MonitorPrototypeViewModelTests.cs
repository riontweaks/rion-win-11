using System;
using NUnit.Framework;
using RadeonSoftwareSlimmer.ViewModels;
using DemoState = RadeonSoftwareSlimmer.ViewModels.MonitorPrototypeViewModel.DemoState;
using StatusKind = RadeonSoftwareSlimmer.ViewModels.MonitorPrototypeViewModel.StatusKind;

namespace RadeonSoftwareSlimmer.Test.ViewModels
{
    public class MonitorPrototypeViewModelTests
    {
        [Test]
        public void New_StartsWaiting_WithQueuedSampleData()
        {
            var vm = new MonitorPrototypeViewModel();
            Assert.Multiple(() =>
            {
                Assert.That(vm.State, Is.EqualTo(DemoState.Waiting));
                Assert.That(vm.Status, Is.EqualTo(StatusKind.Neutral));
                Assert.That(vm.Percent, Is.EqualTo(0));
                Assert.That(vm.Indeterminate, Is.False);
                Assert.That(vm.IsFinished, Is.False);
                Assert.That(vm.ShowPrimaryAction, Is.False);
                Assert.That(vm.PlannedServiceChanges, Is.Not.Empty);
                Assert.That(vm.PlannedGpuTweaks, Is.Not.Empty);
            });
        }

        [TestCaseSource(nameof(AllStates))]
        public void ShowState_AlwaysGivesAPhaseLabelAndDetail(DemoState state)
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(state);

            Assert.Multiple(() =>
            {
                Assert.That(vm.State, Is.EqualTo(state));
                Assert.That(vm.PhaseLabel, Is.Not.Null.And.Not.Empty);
                Assert.That(vm.Detail, Is.Not.Null.And.Not.Empty);
            });
        }

        [Test]
        public void ShowState_Complete_IsFinished_AndOffersFinishAction()
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(DemoState.Complete);

            Assert.Multiple(() =>
            {
                Assert.That(vm.IsFinished, Is.True);
                Assert.That(vm.Status, Is.EqualTo(StatusKind.Success));
                Assert.That(vm.Percent, Is.EqualTo(100));
                Assert.That(vm.ShowPrimaryAction, Is.True);
                Assert.That(vm.PrimaryActionText, Does.Contain("Finish"));
            });
        }

        [TestCase(DemoState.Warning, StatusKind.Caution)]
        [TestCase(DemoState.Error, StatusKind.Danger)]
        public void ShowState_ProblemStates_OfferManualApply(DemoState state, StatusKind kind)
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(state);

            Assert.Multiple(() =>
            {
                Assert.That(vm.Status, Is.EqualTo(kind));
                Assert.That(vm.IsFinished, Is.False);
                Assert.That(vm.ShowPrimaryAction, Is.True);
                Assert.That(vm.PrimaryActionText, Does.Contain("Apply"));
            });
        }

        [TestCase(DemoState.Preparing)]
        [TestCase(DemoState.Verifying)]
        [TestCase(DemoState.ApplyingServiceChanges)]
        [TestCase(DemoState.ApplyingTweaks)]
        public void ShowState_WorkingStates_AreIndeterminateAndActive(DemoState state)
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(state);

            Assert.Multiple(() =>
            {
                Assert.That(vm.Indeterminate, Is.True);
                Assert.That(vm.Status, Is.EqualTo(StatusKind.Active));
            });
        }

        [Test]
        public void ActivityTag_DescribesTheCategory_BlankWhenIdleOrDone()
        {
            var vm = new MonitorPrototypeViewModel();

            vm.ShowState(DemoState.Downloading);
            Assert.That(vm.ActivityTag, Is.EqualTo("Downloading"));

            vm.ShowState(DemoState.ApplyingTweaks);
            Assert.That(vm.ActivityTag, Is.EqualTo("Applying changes"));

            vm.ShowState(DemoState.Waiting);
            Assert.That(vm.ActivityTag, Is.Empty);

            vm.ShowState(DemoState.Complete);
            Assert.That(vm.ActivityTag, Is.Empty);
        }

        [Test]
        public void Monitor_DoesNotExposeExactTimeOrPercentText()
        {
            // the real monitor shows descriptive state, not a precise %/ETA readout
            var t = typeof(MonitorPrototypeViewModel);
            Assert.Multiple(() =>
            {
                Assert.That(t.GetProperty("PercentText"), Is.Null);
                Assert.That(t.GetProperty("ElapsedText"), Is.Null);
                Assert.That(t.GetProperty("RemainingText"), Is.Null);
            });
        }

        [Test]
        public void ComponentComplete_TellsUserToCloseTheInstaller()
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(DemoState.ComponentComplete);

            Assert.Multiple(() =>
            {
                Assert.That(vm.PhaseLabel, Does.Contain("finished installing"));
                Assert.That(vm.Detail, Does.Contain("Close"));
                Assert.That(vm.Status, Is.EqualTo(StatusKind.Success));
            });
        }

        [Test]
        public void SkipTweaks_ClearsTheQueueAndHidesTheAction()
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(DemoState.InstallerOpen);
            Assume.That(vm.ShowSkipTweaks, Is.True);

            vm.SkipTweaks();

            Assert.Multiple(() =>
            {
                Assert.That(vm.PlannedGpuTweaks, Is.Empty);
                Assert.That(vm.ShowSkipTweaks, Is.False);
                Assert.That(vm.Detail, Does.Contain("skipped"));
            });
        }

        [Test]
        public void Reset_ReturnsToWaitingAtZero()
        {
            var vm = new MonitorPrototypeViewModel();
            vm.ShowState(DemoState.Complete);

            vm.Reset();

            Assert.Multiple(() =>
            {
                Assert.That(vm.State, Is.EqualTo(DemoState.Waiting));
                Assert.That(vm.Percent, Is.EqualTo(0));
                Assert.That(vm.IsFinished, Is.False);
                Assert.That(vm.ShowPrimaryAction, Is.False);
            });
        }

        [Test]
        public void ShowState_RaisesPropertyChanged_ForTheKeyVisualProperties()
        {
            var vm = new MonitorPrototypeViewModel();
            bool phase = false, status = false, detail = false;
            vm.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(vm.PhaseLabel)) phase = true;
                if (e.PropertyName == nameof(vm.Status)) status = true;
                if (e.PropertyName == nameof(vm.Detail)) detail = true;
            };

            vm.ShowState(DemoState.InstallingDriver);

            Assert.Multiple(() =>
            {
                Assert.That(phase, Is.True);
                Assert.That(status, Is.True);
                Assert.That(detail, Is.True);
            });
        }

        private static DemoState[] AllStates => (DemoState[])Enum.GetValues(typeof(DemoState));
    }
}
