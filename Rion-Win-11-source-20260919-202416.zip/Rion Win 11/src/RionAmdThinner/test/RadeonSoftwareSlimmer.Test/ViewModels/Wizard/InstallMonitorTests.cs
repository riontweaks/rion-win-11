using NUnit.Framework;
using RadeonSoftwareSlimmer.ViewModels.Wizard;

namespace RadeonSoftwareSlimmer.Test.ViewModels.Wizard
{
    public class InstallMonitorTests
    {
        [Test]
        public void NewMonitor_IsNotStarted()
        {
            var m = new InstallMonitor();
            Assert.Multiple(() =>
            {
                Assert.That(m.Phase, Is.EqualTo(InstallPhase.NotStarted));
                Assert.That(m.IsRunning, Is.False);
                Assert.That(m.IsFinished, Is.False);
            });
        }

        [TestCase(InstallPhase.Starting)]
        [TestCase(InstallPhase.InstallerOpen)]
        [TestCase(InstallPhase.InstallingDriver)]
        [TestCase(InstallPhase.Verifying)]
        [TestCase(InstallPhase.ApplyingGpuTweaks)]
        public void RunningPhases_AreRunning_NotFinished(InstallPhase phase)
        {
            var m = new InstallMonitor();
            m.SetPhase(phase, "x");
            Assert.Multiple(() =>
            {
                Assert.That(m.IsRunning, Is.True);
                Assert.That(m.IsFinished, Is.False);
            });
        }

        [TestCase(InstallPhase.Complete, true)]
        [TestCase(InstallPhase.Failed, true)]
        [TestCase(InstallPhase.NoChangeDetected, false)]
        public void TerminalPhases_AreNotRunning(InstallPhase phase, bool finished)
        {
            var m = new InstallMonitor();
            m.SetPhase(phase, "x");
            Assert.Multiple(() =>
            {
                Assert.That(m.IsRunning, Is.False);
                Assert.That(m.IsFinished, Is.EqualTo(finished));
            });
        }

        [Test]
        public void FreezePlan_SetsPlannedListsAndClearsApplied()
        {
            var m = new InstallMonitor();
            m.RecordApplied("stale");
            m.FreezePlan(new[] { "Disable service: AMDXE" }, new[] { "Disable ULPS" });

            Assert.Multiple(() =>
            {
                Assert.That(m.PlannedServiceChanges, Is.EqualTo(new[] { "Disable service: AMDXE" }));
                Assert.That(m.PlannedGpuTweaks, Is.EqualTo(new[] { "Disable ULPS" }));
                Assert.That(m.AppliedActions, Is.Empty);
            });
        }

        [Test]
        public void RecordApplied_AddsToApplied()
        {
            var m = new InstallMonitor();
            m.RecordApplied("Disable service: AMDXE");
            Assert.That(m.AppliedActions, Has.Count.EqualTo(1));
        }

        [Test]
        public void SetPhase_WithPercent_SetsDeterminateProgress()
        {
            var m = new InstallMonitor();
            m.SetPhase(InstallPhase.Downloading, "downloading", 42);
            Assert.Multiple(() =>
            {
                Assert.That(m.Percent, Is.EqualTo(42));
                Assert.That(m.ProgressIndeterminate, Is.False);
            });
        }

        [Test]
        public void SetPhase_RunningWithoutPercent_IsIndeterminate()
        {
            var m = new InstallMonitor();
            m.SetPhase(InstallPhase.Starting, "starting");
            Assert.That(m.ProgressIndeterminate, Is.True);
        }

        [Test]
        public void SetPhase_Complete_Pins100Percent()
        {
            var m = new InstallMonitor();
            m.SetPhase(InstallPhase.Complete, "done");
            Assert.Multiple(() =>
            {
                Assert.That(m.Percent, Is.EqualTo(100));
                Assert.That(m.ProgressIndeterminate, Is.False);
            });
        }

        [Test]
        public void CanCancelGpuTweaks_TrueWhileRunningWithQueuedTweaks()
        {
            var m = new InstallMonitor();
            m.FreezePlan(new string[0], new[] { "Disable ULPS" });
            m.SetPhase(InstallPhase.InstallingDriver, "installing");
            Assert.That(m.CanCancelGpuTweaks, Is.True);
        }

        [Test]
        public void CanCancelGpuTweaks_FalseOnceApplyingStarts()
        {
            var m = new InstallMonitor();
            m.FreezePlan(new string[0], new[] { "Disable ULPS" });
            m.SetPhase(InstallPhase.ApplyingGpuTweaks, "applying");
            Assert.That(m.CanCancelGpuTweaks, Is.False);
        }

        [Test]
        public void CancelGpuTweaks_ClearsQueueAndSetsFlags()
        {
            var m = new InstallMonitor { ApplyGpuTweaks = true };
            m.FreezePlan(new string[0], new[] { "Disable ULPS", "Disable MPO" });
            m.SetPhase(InstallPhase.InstallingDriver, "installing");

            m.CancelGpuTweaks();

            Assert.Multiple(() =>
            {
                Assert.That(m.GpuTweaksCancelled, Is.True);
                Assert.That(m.ApplyGpuTweaks, Is.False);
                Assert.That(m.PlannedGpuTweaks, Is.Empty);
                Assert.That(m.CanCancelGpuTweaks, Is.False);
            });
        }

        [Test]
        public void FreezePlan_ResetsCancelledFlag()
        {
            var m = new InstallMonitor();
            m.FreezePlan(new string[0], new[] { "Disable ULPS" });
            m.SetPhase(InstallPhase.InstallingDriver, "x");
            m.CancelGpuTweaks();

            m.FreezePlan(new string[0], new[] { "Disable ULPS" });

            Assert.That(m.GpuTweaksCancelled, Is.False);
        }

        [TestCase(InstallPhase.Downloading, "Downloading", MonitorStatus.Active)]
        [TestCase(InstallPhase.InstallingDriver, "Installing", MonitorStatus.Active)]
        [TestCase(InstallPhase.ApplyingGpuTweaks, "Applying changes", MonitorStatus.Active)]
        [TestCase(InstallPhase.Complete, "", MonitorStatus.Success)]
        [TestCase(InstallPhase.NoChangeDetected, "", MonitorStatus.Caution)]
        [TestCase(InstallPhase.Failed, "", MonitorStatus.Danger)]
        public void ActivityTagAndStatus_TrackThePhase(InstallPhase phase, string tag, MonitorStatus status)
        {
            var m = new InstallMonitor();
            m.SetPhase(phase, "x");
            Assert.Multiple(() =>
            {
                Assert.That(m.ActivityTag, Is.EqualTo(tag));
                Assert.That(m.Status, Is.EqualTo(status));
            });
        }

        [Test]
        public void PhaseLabel_IsDescriptive_NotAnExactReadout()
        {
            var m = new InstallMonitor();
            m.SetPhase(InstallPhase.Downloading, "x", 42);
            Assert.That(m.PhaseLabel, Is.EqualTo("Downloading and extracting packages"));
            Assert.That(m.PhaseLabel, Does.Not.Contain("42"));
        }

        [Test]
        public void PhaseChange_RaisesPropertyChangedForPhaseAndFinished()
        {
            var m = new InstallMonitor();
            bool phase = false, finished = false;
            m.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(InstallMonitor.Phase)) phase = true;
                if (e.PropertyName == nameof(InstallMonitor.IsFinished)) finished = true;
            };
            m.SetPhase(InstallPhase.Complete, "done");
            Assert.Multiple(() =>
            {
                Assert.That(phase, Is.True);
                Assert.That(finished, Is.True);
            });
        }
    }
}
