using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using NUnit.Framework;
using RadeonSoftwareSlimmer;
using RadeonSoftwareSlimmer.ViewModels.Wizard;

namespace RadeonSoftwareSlimmer.Test.Views
{
    /// <summary>
    /// Loads the real glass shell (MainWindow) and the Installation Monitor window on an STA thread.
    /// Catches XAML load failures from the app-wide glass migration and exercises the rail navigation
    /// (wizard steps + the Post-Install tool) and the monitor phase -> status path.
    /// </summary>
    [Apartment(ApartmentState.STA)]
    public class ShellSmokeTests
    {
        [OneTimeSetUp]
        public void EnsureWpfApplication()
        {
            try
            {
                Application app = Application.Current ?? new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };

                // let bare pack URIs ("/icon.ico") resolve against the app assembly, not the test host
                if (Application.ResourceAssembly == null)
                    Application.ResourceAssembly = typeof(MainWindow).Assembly;

                // App.xaml isn't run in the test host, so merge the theme the windows depend on.
                bool hasTheme = false;
                foreach (ResourceDictionary d in app.Resources.MergedDictionaries)
                    if (d.Source != null && d.Source.OriginalString.Contains("Dark.xaml"))
                        hasTheme = true;

                if (!hasTheme)
                    app.Resources.MergedDictionaries.Add(new ResourceDictionary
                    {
                        Source = new Uri("pack://application:,,,/AmdDriverManager;component/Themes/Dark.xaml", UriKind.Absolute),
                    });
            }
            catch (Exception ex)
            {
                Assert.Ignore("No WPF/desktop environment available: " + ex.Message);
            }
        }

        [Test]
        public void MainWindow_Loads_RailNavigatesEveryStep_AndThePostInstallTool()
        {
            MainWindow window = null;
            try
            {
                window = new MainWindow
                {
                    ShowInTaskbar = false,
                    ShowActivated = false,
                    WindowStartupLocation = WindowStartupLocation.Manual,
                    Left = -20000,
                    Top = -20000,
                };
                window.Show();
                Pump();

                var vm = (WizardViewModel)window.DataContext;
                Assert.That(vm, Is.Not.Null);

                // every wizard step is reachable straight away
                foreach (WizardStepViewModel step in vm.Steps)
                {
                    Assert.That(step.IsReachable, Is.True, step.Title + " should be reachable");
                    vm.JumpCommand.Execute(step);
                    Pump();
                    Assert.That(vm.Current, Is.SameAs(step));
                    Assert.That(vm.IsOnWizardStep, Is.True);
                }

                // the Post-Install rail tool
                vm.ShowPostInstallToolCommand.Execute(null);
                Pump();
                Assert.Multiple(() =>
                {
                    Assert.That(vm.IsOnWizardStep, Is.False);
                    Assert.That(vm.IsToolActive, Is.True);
                    Assert.That(vm.ActiveContent, Is.SameAs(vm.PostInstallTool));
                    Assert.That(vm.ActiveTitle, Is.EqualTo("Post-Install"));
                    Assert.That(vm.PostInstallRailState, Is.EqualTo("active"));
                });

                // back to a wizard step clears the tool
                vm.JumpCommand.Execute(vm.Steps[0]);
                Pump();
                Assert.That(vm.IsToolActive, Is.False);
            }
            catch (Exception ex) when (IsEnvironmental(ex))
            {
                Assert.Ignore("Windowing not available: " + ex.Message);
            }
            finally
            {
                window?.Close();
                Pump();
            }
        }

        [Test]
        public void InstallMonitorWindow_Loads_AndFollowsEveryPhase()
        {
            RadeonSoftwareSlimmer.Views.InstallMonitorWindow window = null;
            var monitor = new InstallMonitor();
            try
            {
                window = new RadeonSoftwareSlimmer.Views.InstallMonitorWindow(monitor, () => { })
                {
                    ShowInTaskbar = false,
                    ShowActivated = false,
                    WindowStartupLocation = WindowStartupLocation.Manual,
                    Left = -20000,
                    Top = -20000,
                };
                window.Show();
                Pump();

                foreach (InstallPhase phase in Enum.GetValues(typeof(InstallPhase)))
                {
                    monitor.SetPhase(phase, "detail for " + phase, phase == InstallPhase.Downloading ? 44 : (double?)null);
                    Pump();
                    Assert.That(monitor.PhaseLabel, Is.Not.Empty);
                }
            }
            catch (Exception ex) when (IsEnvironmental(ex))
            {
                Assert.Ignore("Windowing not available: " + ex.Message);
            }
            finally
            {
                window?.Close();
                Pump();
            }
        }

        private static bool IsEnvironmental(Exception ex) =>
            ex is System.ComponentModel.Win32Exception ||
            (ex is InvalidOperationException && ex.Message.Contains("Dispatcher"));

        private static void Pump()
        {
            var frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new Action(() => frame.Continue = false));
            Dispatcher.PushFrame(frame);
        }
    }
}
