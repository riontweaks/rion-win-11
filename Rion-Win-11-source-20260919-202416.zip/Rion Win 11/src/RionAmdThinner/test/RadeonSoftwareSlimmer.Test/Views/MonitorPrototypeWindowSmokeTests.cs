using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using NUnit.Framework;
using RadeonSoftwareSlimmer.ViewModels;
using RadeonSoftwareSlimmer.Views;
using DemoState = RadeonSoftwareSlimmer.ViewModels.MonitorPrototypeViewModel.DemoState;

namespace RadeonSoftwareSlimmer.Test.Views
{
    /// <summary>
    /// Loads the actual prototype <see cref="MonitorPrototypeWindow"/> on an STA thread and drives it
    /// through every demo state. Catches XAML load failures (missing resources, bad templates) and any
    /// exception in the vm -> visual update path (progress animation, status dot, hero transition).
    /// </summary>
    [Apartment(ApartmentState.STA)]
    public class MonitorPrototypeWindowSmokeTests
    {
        [OneTimeSetUp]
        public void EnsureWpfApplication()
        {
            try
            {
                if (Application.Current == null)
                    _ = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
            }
            catch (Exception ex)
            {
                Assert.Ignore("No WPF/desktop environment available: " + ex.Message);
            }
        }

        [Test]
        public void Window_Loads_CyclesEveryState_AndCloses()
        {
            MonitorPrototypeWindow window = null;
            try
            {
                window = new MonitorPrototypeWindow
                {
                    ShowInTaskbar = false,
                    ShowActivated = false,
                    WindowStartupLocation = WindowStartupLocation.Manual,
                    Left = -20000,
                    Top = -20000,
                };
                window.Show();          // forces XAML load + OnSourceInitialized (DWM interop)
                Pump();

                var vm = (MonitorPrototypeViewModel)window.DataContext;
                Assert.That(vm, Is.Not.Null);

                foreach (DemoState state in Enum.GetValues(typeof(DemoState)))
                {
                    vm.ShowState(state);
                    Pump();
                }

                vm.SkipTweaks();
                Pump();
                vm.Reset();
                Pump();
            }
            catch (Exception ex) when (ex is System.ComponentModel.Win32Exception ||
                                       ex.GetType().Name == "InvalidOperationException" &&
                                       ex.Message.Contains("Dispatcher"))
            {
                Assert.Ignore("Windowing not available in this environment: " + ex.Message);
            }
            finally
            {
                if (window != null)
                {
                    window.Close();
                    Pump();
                }
            }
        }

        private static void Pump()
        {
            var frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new Action(() => frame.Continue = false));
            Dispatcher.PushFrame(frame);
        }
    }
}
