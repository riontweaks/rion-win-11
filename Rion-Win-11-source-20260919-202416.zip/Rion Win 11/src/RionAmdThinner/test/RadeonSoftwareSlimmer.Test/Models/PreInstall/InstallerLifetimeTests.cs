using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models.PreInstall;

namespace RadeonSoftwareSlimmer.Test.Models.PreInstall
{
    public class InstallerLifetimeTests
    {
        private sealed class Resource : IDisposable
        {
            public int DisposeCount { get; private set; }
            public bool ThrowOnDispose { get; init; }
            public void Dispose()
            {
                DisposeCount++;
                if (ThrowOnDispose) throw new IOException("Injected resource cleanup failure");
            }
        }

        [Test]
        public async Task ResourcesStayOwnedUntilExitCompletes()
        {
            var owner = new Resource();
            var lease = new Resource();
            var exit = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var monitor = InstallerFilesModel.ReleaseAfterExitAsync(owner, lease, () => exit.Task,
                () => throw new InvalidOperationException("Successful wait must not reopen the process"));
            Assert.That(owner.DisposeCount, Is.Zero);
            Assert.That(lease.DisposeCount, Is.Zero);
            exit.SetResult();
            await monitor.WaitAsync(TimeSpan.FromSeconds(5));
            Assert.That(owner.DisposeCount, Is.EqualTo(1));
            Assert.That(lease.DisposeCount, Is.EqualTo(1));
        }

        [TestCase(false)]
        [TestCase(true)]
        public async Task FailedWaitReleasesOnlyWhenExitIsIndependentlyConfirmed(bool exited)
        {
            var owner = new Resource();
            var lease = new Resource();
            await InstallerFilesModel.ReleaseAfterExitAsync(owner, lease,
                () => Task.FromException(new Win32Exception(5)), () => exited);
            Assert.That(owner.DisposeCount, Is.EqualTo(exited ? 1 : 0));
            Assert.That(lease.DisposeCount, Is.EqualTo(exited ? 1 : 0));
        }

        [Test]
        public async Task FailedExitCheckCannotReleaseUnconfirmedResources()
        {
            var owner = new Resource();
            var lease = new Resource();
            await InstallerFilesModel.ReleaseAfterExitAsync(owner, lease,
                () => Task.FromException(new InvalidOperationException("Monitor unavailable")),
                () => throw new Win32Exception(5));
            Assert.That(owner.DisposeCount, Is.Zero);
            Assert.That(lease.DisposeCount, Is.Zero);
        }

        [Test]
        public void UnexpectedMonitorFailureIsNotSwallowedOrTreatedAsExit()
        {
            var owner = new Resource();
            var lease = new Resource();
            Assert.ThrowsAsync<IOException>(async () => await InstallerFilesModel.ReleaseAfterExitAsync(
                owner, lease, () => Task.FromException(new IOException("Unexpected failure")), () => true));
            Assert.That(owner.DisposeCount, Is.Zero);
            Assert.That(lease.DisposeCount, Is.Zero);
        }

        [Test]
        public void ConfirmedExitReleasesLeaseEvenWhenOwnerCleanupFails()
        {
            var owner = new Resource { ThrowOnDispose = true };
            var lease = new Resource();
            Assert.ThrowsAsync<IOException>(async () => await InstallerFilesModel.ReleaseAfterExitAsync(
                owner, lease, () => Task.CompletedTask, () => true));
            Assert.That(owner.DisposeCount, Is.EqualTo(1));
            Assert.That(lease.DisposeCount, Is.EqualTo(1));
        }

        [Test]
        public async Task DisposingCallerWrapperDoesNotUnlockFileBeforeOriginalProcessExits()
        {
            // This launches only the Windows command interpreter as an inert stdin-waiting
            // fixture. It never starts an installer or invokes a Rion tweak.
            string path = Path.Combine(Path.GetTempPath(), "RionLifetime-" + Guid.NewGuid() + ".txt");
            File.WriteAllText(path, "Inert lock fixture");
            var owner = new Process
            {
                StartInfo = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "cmd.exe"))
                {
                    Arguments = "/d /q /c \"echo ready & set /p RionWait= & exit /b 0\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardInput = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };
            FileStream lease = null;
            Task monitor = null;
            try
            {
                Assert.That(owner.Start(), Is.True);
                Assert.That((await owner.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5))).Trim(), Is.EqualTo("ready"));
                lease = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                using (var caller = Process.GetProcessById(owner.Id))
                {
                    _ = caller.SafeHandle;
                    caller.EnableRaisingEvents = true;
                    monitor = InstallerFilesModel.ReleaseAfterExitAsync(owner, lease,
                        () => owner.WaitForExitAsync(), () => owner.HasExited);
                }
                Assert.That(owner.HasExited, Is.False);
                Assert.Throws<IOException>(() => File.WriteAllText(path, "must stay locked"));
                owner.StandardInput.Close();
                await monitor.WaitAsync(TimeSpan.FromSeconds(5));
                File.WriteAllText(path, "Released after confirmed exit");
            }
            finally
            {
                // Only terminate our own inert fixture if an assertion failed before cleanup.
                try { if (!owner.HasExited) { owner.Kill(); owner.WaitForExit(); } }
                catch (InvalidOperationException) { }
                if (monitor != null) await monitor.WaitAsync(TimeSpan.FromSeconds(5));
                owner.Dispose();
                lease?.Dispose();
                File.Delete(path);
            }
        }
    }
}
