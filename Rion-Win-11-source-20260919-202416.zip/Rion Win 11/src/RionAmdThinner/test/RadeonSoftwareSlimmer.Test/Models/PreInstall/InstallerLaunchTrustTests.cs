using System;
using System.IO;
using System.IO.Abstractions;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models.PreInstall;

namespace RadeonSoftwareSlimmer.Test.Models.PreInstall
{
    public class InstallerLaunchTrustTests
    {
        private string root;
        private InstallerFilesModel model;

        [SetUp]
        public void Setup()
        {
            root = Path.Combine(Path.GetTempPath(), "RionInstallerBoundary-" + Guid.NewGuid());
            Directory.CreateDirectory(Path.Combine(root, "package", "Bin64"));
            model = new InstallerFilesModel(new FileSystem())
            {
                InstallerFile = Path.Combine(root, "unsigned-package.exe"),
                ExtractedInstallerDirectory = Path.Combine(root, "package")
            };
            File.WriteAllText(model.InstallerFile, "Inert unsigned fixture. Never execute.");
            File.WriteAllText(Path.Combine(model.ExtractedInstallerDirectory, "Setup.exe"), "Inert unsigned fixture. Never execute.");
            File.WriteAllText(Path.Combine(model.ExtractedInstallerDirectory, "Bin64", "AMDCleanupUtility.exe"), "Inert unsigned fixture. Never execute.");
        }

        [TearDown]
        public void Cleanup()
        {
            if (Directory.Exists(root)) Directory.Delete(root, true);
        }

        [Test]
        public void UnsignedOriginalPackageIsRejectedBeforeExtraction()
        {
            model.ExtractedInstallerDirectory = Path.Combine(root, "must-not-extract");
            Assert.Throws<InvalidDataException>(() => model.ExtractInstallerFiles());
            Assert.That(Directory.Exists(model.ExtractedInstallerDirectory), Is.False);
        }

        [Test]
        public void ExpectedSetupFilenameCannotBypassPublisherVerification()
        {
            Assert.Throws<InvalidDataException>(() => model.StartRadeonSoftwareSetup());
        }

        [Test]
        public void ExpectedCleanupFilenameCannotBypassPublisherVerification()
        {
            Assert.Throws<InvalidDataException>(() => model.RunAmdCleanupUtility());
        }
    }
}
