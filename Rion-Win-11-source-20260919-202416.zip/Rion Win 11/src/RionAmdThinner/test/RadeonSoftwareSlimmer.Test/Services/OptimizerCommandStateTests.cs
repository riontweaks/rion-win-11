using System;
using System.IO;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class OptimizerCommandStateTests
    {
        private string directory;
        [SetUp] public void Setup() { directory = Path.Combine(Path.GetTempPath(), "RionOptimizer-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(directory); }
        [TearDown] public void Cleanup() => Directory.Delete(directory, true);
        private static JObject Row(string identity, bool exists, JToken value) => new JObject { ["Identity"] = identity, ["Exists"] = exists, ["Value"] = value };

        [TestCase("bcd-isolatedcontext")]
        [TestCase("bcd-allowedinmemorysettings")]
        [TestCase("bcd-disableelamdrivers")]
        [TestCase("bcd-vsmlaunchtype")]
        [TestCase("bcd-loadoptions")]
        public void RetiredOperationsRejectBackendApplyBeforeInspectionOrWrites(string id)
        {
            var backend = new FakeBackend(); // No readable state: the retirement guard must run first.
            var operation = new OptimizerCommandState(id, new JValue(true), directory, backend);
            Assert.Throws<InvalidOperationException>(() => operation.Apply());
            Assert.That(backend.Reads, Is.Zero);
            Assert.That(backend.Writes, Is.Zero);
            Assert.That(Directory.GetFiles(directory), Is.Empty);
        }

        [Test]
        public void RetiredBootOperationStillRestoresAnExistingJournal()
        {
            const string id = "bcd-disableelamdrivers";
            var original = new JArray(Row("boot-guid", false, JValue.CreateNull()));
            var requested = new JArray(Row("boot-guid", true, new JValue(true)));
            var journal = new JObject { ["Schema"] = 1, ["Id"] = id, ["Machine"] = Environment.MachineName,
                ["Before"] = original, ["Requested"] = requested, ["Status"] = "Applied" };
            string path = Path.Combine(directory, id + ".json");
            File.WriteAllText(path, journal.ToString());
            var backend = new FakeBackend { Current = (JArray)requested.DeepClone() };
            var operation = new OptimizerCommandState(id, new JValue(true), directory, backend);
            Assert.Throws<InvalidOperationException>(() => operation.Apply());
            Assert.That(File.ReadAllText(path), Is.EqualTo(journal.ToString()));
            Assert.That(operation.Restore(), Is.True);
            Assert.That(JToken.DeepEquals(backend.Current, original), Is.True);
            Assert.That(File.Exists(path), Is.False);
        }

        [Test]
        public void BootElementAbsenceIsRestoredAcrossInstancesAndRepeatedApply()
        {
            var backend = new FakeBackend { Current = new JArray(Row("boot-guid", false, JValue.CreateNull())) };
            var original = backend.Current.DeepClone();
            var operation = new OptimizerCommandState("fixture", new JArray(0L), directory, backend);
            Assert.That(operation.Apply(), Is.True);
            Assert.That(new OptimizerCommandState("fixture", new JArray(0L), directory, backend).Apply(), Is.True);
            Assert.That(backend.Writes, Is.EqualTo(1));
            Assert.That(operation.HasSavedState(), Is.True);
            Assert.That(operation.Restore(), Is.True);
            Assert.That(JToken.DeepEquals(backend.Current, original), Is.True);
            Assert.That(operation.HasSavedState(), Is.False);
        }

        [Test]
        public void FailedPartialAdapterWriteRetainsEveryOriginalAndCanRestore()
        {
            var backend = new FakeBackend { Current = new JArray(Row("a|IPv4|ActiveStore", true, new JValue("off")), Row("b|IPv6|PersistentStore", true, new JValue("on"))), FailAfterFirst = true };
            var before = backend.Current.DeepClone();
            var operation = new OptimizerCommandState("fixture", new JValue("enabled"), directory, backend);
            Assert.Throws<IOException>(() => operation.Apply());
            Assert.That(operation.HasSavedState(), Is.True);
            backend.FailAfterFirst = false;
            Assert.That(operation.Restore(), Is.True);
            Assert.That(JToken.DeepEquals(backend.Current, before), Is.True);
        }

        [Test]
        public void MixedSendAndReceiveAfterPartialFailureCanRestore()
        {
            var before = new JObject { ["Send"] = "Disabled", ["Receive"] = "Disabled" };
            var backend = new FakeBackend { Current = new JArray(Row("adapter", true, before)) };
            var operation = new OptimizerCommandState("fixture", new JObject { ["Send"] = "Enabled", ["Receive"] = "Enabled" }, directory, backend);
            operation.Apply();
            backend.Current[0]["Value"]["Receive"] = "Disabled";
            Assert.That(operation.Restore(), Is.True);
            Assert.That(JToken.DeepEquals(backend.Current[0]["Value"], before), Is.True);
        }

        [Test]
        public void ExternalChangesAndMissingBootIdentityAreNeverOverwritten()
        {
            var backend = new FakeBackend { Current = new JArray(Row("original", true, new JValue("custom"))) };
            var operation = new OptimizerCommandState("fixture", new JValue("target"), directory, backend);
            operation.Apply();
            backend.Current[0]["Value"] = "external";
            Assert.Throws<IOException>(() => operation.Apply());
            Assert.Throws<IOException>(() => operation.Restore());
            backend.Current[0]["Identity"] = "different-boot-entry";
            Assert.Throws<IOException>(() => operation.Restore());
            Assert.That(backend.Writes, Is.EqualTo(1));
            Assert.That(operation.HasSavedState(), Is.True);
        }

        [Test]
        public void BackupFailureAndMissingHistoryCannotWrite()
        {
            var backend = new FakeBackend { Current = new JArray(Row("original", true, new JValue(false))) };
            string blocked = Path.Combine(directory, "file"); File.WriteAllText(blocked, "fixture");
            var operation = new OptimizerCommandState("fixture", new JValue(true), blocked, backend);
            Assert.Throws<IOException>(() => operation.Apply());
            Assert.Throws<IOException>(() => new OptimizerCommandState("fixture", new JValue(true), directory, backend).Restore());
            Assert.That(backend.Writes, Is.Zero);
        }

        [Test]
        public void IgnoredWriteCannotClaimSuccessAndRetainsRecovery()
        {
            var backend = new FakeBackend { Current = new JArray(Row("original", true, new JValue(false))), IgnoreWrites = true };
            var operation = new OptimizerCommandState("fixture", new JValue(true), directory, backend);
            Assert.Throws<IOException>(() => operation.Apply());
            Assert.That(operation.HasSavedState(), Is.True);
            Assert.That(operation.Inspect(), Is.False);
        }

        [Test]
        public void DuplicateOrEmptySnapshotCannotWrite()
        {
            var backend = new FakeBackend { Current = new JArray() };
            var operation = new OptimizerCommandState("fixture", new JValue(true), directory, backend);
            Assert.Throws<IOException>(() => operation.Apply());
            backend.Current = new JArray(Row("same", true, new JValue(false)), Row("same", true, new JValue(false)));
            Assert.Throws<IOException>(() => operation.Apply());
            Assert.That(backend.Writes, Is.Zero);
        }

        [Test]
        public void UnrelatedNewAdapterIsNotIncludedInSavedRestoreTargets()
        {
            var backend = new FakeBackend { Current = new JArray(Row("original", true, new JValue(false))) };
            var operation = new OptimizerCommandState("fixture", new JValue(true), directory, backend);
            operation.Apply();
            backend.Current.Add(Row("new-adapter", true, new JValue(true)));
            operation.Restore();
            Assert.That((bool)backend.Current[1]["Value"], Is.True);
        }

        private sealed class FakeBackend : IOptimizerCommandBackend
        {
            public JArray Current;
            public int Writes;
            public int Reads;
            public bool FailAfterFirst;
            public bool IgnoreWrites;
            public JArray Read(string id) { Reads++; return (JArray)Current.DeepClone(); }
            public void Write(string id, JArray state)
            {
                Writes++;
                if (IgnoreWrites) return;
                foreach (var row in state)
                {
                    for (int i = 0; i < Current.Count; i++)
                        if ((string)Current[i]["Identity"] == (string)row["Identity"]) Current[i] = row.DeepClone();
                    if (FailAfterFirst) throw new IOException("Injected partial write.");
                }
            }
        }
    }
}
