using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    [TestFixture]
    public sealed class CustomTweakRecoveryTests
    {
        private string directory;

        [SetUp]
        public void Setup()
        {
            directory = Path.Combine(Path.GetTempPath(), "RionCustomRecovery-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
        }

        [TearDown]
        public void Cleanup() => Directory.Delete(directory, true);

        [Test]
        public void VbsRestoresMixedPresenceAndExactTypesWithoutChangingLocks()
        {
            var registry = new MemoryRegistry();
            registry.Seed(VbsTweak.DeviceGuardKey, "EnableVirtualizationBasedSecurity", 2L, RegistryValueKind.QWord);
            registry.Seed(VbsTweak.HvciKey, "Locked", 0, RegistryValueKind.DWord);

            SeedHistoricalVbsChange(registry);
            int writes = registry.Writes;
            Assert.Throws<InvalidOperationException>(() => VbsTweak.Apply());
            Assert.That(registry.Writes, Is.EqualTo(writes), "retired apply must preserve historical recovery state");
            Assert.That(VbsTweak.Revert(registry, directory), Is.True);
            Assert.That(registry.Read(VbsTweak.DeviceGuardKey, "EnableVirtualizationBasedSecurity"), Is.EqualTo((2L, RegistryValueKind.QWord)));
            Assert.That(registry.Read(VbsTweak.HvciKey, "Enabled"), Is.Null);
            Assert.That(registry.Read(VbsTweak.HvciKey, "Locked"), Is.EqualTo((0, RegistryValueKind.DWord)));
        }

        [Test]
        public void VbsMissingHistoryNeverEnablesAssumedDefaults()
        {
            var registry = new MemoryRegistry();
            Assert.Throws<InvalidOperationException>(() => VbsTweak.Revert(registry, directory));
            Assert.That(registry.Writes, Is.Zero);
            Assert.That(VbsTweak.IsDisabled(registry), Is.False, "missing settings do not establish the running protection state");
        }

        [Test]
        public void VbsExternalChangeSurvivesRestoreAndCannotBecomeANewBaseline()
        {
            var registry = new MemoryRegistry();
            registry.Seed(VbsTweak.DeviceGuardKey, "EnableVirtualizationBasedSecurity", 1, RegistryValueKind.DWord);
            SeedHistoricalVbsChange(registry);
            registry.Seed(VbsTweak.DeviceGuardKey, "EnableVirtualizationBasedSecurity", 9, RegistryValueKind.DWord);
            int writes = registry.Writes;
            Assert.Throws<InvalidOperationException>(() => VbsTweak.Apply());
            Assert.That(registry.Writes, Is.EqualTo(writes));
            Assert.Throws<IOException>(() => VbsTweak.Revert(registry, directory));
            Assert.That(registry.Read(VbsTweak.DeviceGuardKey, "EnableVirtualizationBasedSecurity"), Is.EqualTo((9, RegistryValueKind.DWord)));
            Assert.That(registry.Read(VbsTweak.HvciKey, "Enabled"), Is.Null, "independent recoverable entries still restore");
        }

        // Reconstruct a pre-retirement journal using only the in-memory test registry.
        // The production assembly no longer contains an implementation that disables VBS.
        private void SeedHistoricalVbsChange(MemoryRegistry registry)
        {
            var backup = new BackupSession(directory) { Description = "VBS and memory integrity configuration" };
            foreach (var setting in new[] { (VbsTweak.DeviceGuardKey, "EnableVirtualizationBasedSecurity"), (VbsTweak.HvciKey, "Enabled") })
            {
                using var key = registry.LocalMachine.OpenSubKey(setting.Item1, true) ?? registry.LocalMachine.CreateSubKey(setting.Item1);
                backup.WriteRegistry(key, "HKLM\\" + setting.Item1, setting.Item2, true, 0, RegistryValueKind.DWord);
            }
        }

        [Test]
        public void PowerPlanRestoresExactOriginalAcrossInstancesAndRepeatApply()
        {
            var commands = new FakePowerCommands();
            Guid original = commands.Active;
            var activation = new PowerPlanActivation(commands, directory);
            activation.Apply();
            Assert.That(commands.Active, Is.Not.EqualTo(original));
            new PowerPlanActivation(commands, directory).Apply();
            Assert.That(commands.Imports, Is.EqualTo(1));
            Assert.That(commands.Activations, Is.EqualTo(1));
            new PowerPlanActivation(commands, directory).Revert();
            Assert.That(commands.Active, Is.EqualTo(original));
            Assert.That(File.Exists(Path.Combine(directory, "activation.json")), Is.False);
        }

        [Test]
        public void PowerPlanJournalFailurePreventsImportAndActivation()
        {
            var commands = new FakePowerCommands();
            string blocked = Path.Combine(directory, "not-a-directory");
            File.WriteAllText(blocked, "fixture");
            Assert.Throws<IOException>(() => new PowerPlanActivation(commands, blocked).Apply());
            Assert.That(commands.Imports, Is.Zero);
            Assert.That(commands.Activations, Is.Zero);
        }

        [Test]
        public void PowerPlanMissingOrCorruptHistoryNeverSelectsBalanced()
        {
            var commands = new FakePowerCommands();
            var activation = new PowerPlanActivation(commands, directory);
            Assert.Throws<InvalidOperationException>(() => activation.Revert());
            File.WriteAllText(Path.Combine(directory, "activation.json"), "{}");
            Assert.Throws<InvalidDataException>(() => activation.Revert());
            Assert.That(commands.Activations, Is.Zero);
        }

        [Test]
        public void PowerPlanPreservesExternalSelectionAndHistory()
        {
            var commands = new FakePowerCommands();
            var activation = new PowerPlanActivation(commands, directory);
            activation.Apply();
            Guid external = Guid.NewGuid();
            commands.Schemes.Add(new PowerScheme(external, "External choice"));
            commands.Active = external;
            int activations = commands.Activations;
            Assert.Throws<InvalidOperationException>(() => activation.Revert());
            Assert.Throws<InvalidOperationException>(() => activation.Apply());
            Assert.That(commands.Activations, Is.EqualTo(activations));
            Assert.That(commands.Active, Is.EqualTo(external));
            Assert.That(File.Exists(Path.Combine(directory, "activation.json")), Is.True);
        }

        [Test]
        public void PowerPlanFailedReadbackKeepsRecoveryForRetry()
        {
            var commands = new FakePowerCommands { IgnoreActivation = true };
            var activation = new PowerPlanActivation(commands, directory);
            Guid original = commands.Active;
            Assert.Throws<IOException>(() => activation.Apply());
            Assert.That(File.Exists(Path.Combine(directory, "activation.json")), Is.True);
            commands.IgnoreActivation = false;
            activation.Apply();
            activation.Revert();
            Assert.That(commands.Active, Is.EqualTo(original));
        }

        [Test]
        public void PowerPlanImportFailureKeepsPriorSchemeAndDurableRecovery()
        {
            var commands = new FakePowerCommands { FailImport = true };
            Guid original = commands.Active;
            var activation = new PowerPlanActivation(commands, directory);
            Assert.Throws<IOException>(() => activation.Apply());
            Assert.That(File.Exists(Path.Combine(directory, "activation.json")), Is.True);
            Assert.That(commands.Activations, Is.Zero);
            activation.Revert();
            Assert.That(commands.Active, Is.EqualTo(original));
        }

        [Test]
        public void PowerPlanLegacyMigrationRequiresMatchingActivePlan()
        {
            var commands = new FakePowerCommands();
            Guid original = commands.Active;
            Guid rion = Guid.NewGuid();
            commands.Schemes.Add(new PowerScheme(rion, RionPowerPlanTweak.PlanDisplayName));
            File.WriteAllText(Path.Combine(directory, "previous-scheme.guid"), original.ToString());
            var activation = new PowerPlanActivation(commands, directory);
            Assert.Throws<InvalidDataException>(() => activation.Revert());
            Assert.That(commands.Activations, Is.Zero);
            commands.Active = rion;
            activation.Revert();
            Assert.That(commands.Active, Is.EqualTo(original));
            Assert.That(File.Exists(Path.Combine(directory, "previous-scheme.guid")), Is.False);
        }

        [Test]
        public void PowerPlanMissingOriginalCannotBeReplacedWithADefault()
        {
            var commands = new FakePowerCommands();
            Guid original = commands.Active;
            var activation = new PowerPlanActivation(commands, directory);
            activation.Apply();
            commands.Schemes.RemoveAll(s => s.Id == original);
            int writes = commands.Activations;
            Assert.Throws<InvalidOperationException>(() => activation.Revert());
            Assert.That(commands.Activations, Is.EqualTo(writes));
        }

        [Test]
        public void PowerSchemeParsingDoesNotDependOnEnglishOrSimpleNames()
        {
            Guid id = Guid.NewGuid();
            var schemes = WindowsPowerSchemeCommands.ParseSchemes("GUID du mode de gestion : " + id + "  (Custom (AC)) *\r\n");
            Assert.That(schemes.Single(), Is.EqualTo(new PowerScheme(id, "Custom (AC)")));
        }

        [Test]
        public void PowerPlanIncompleteImportNeverActivatesAnUnverifiedPlanOnRetry()
        {
            var commands = new FakePowerCommands { WrongImportName = true };
            var activation = new PowerPlanActivation(commands, directory);
            Assert.Throws<IOException>(() => activation.Apply());
            Assert.Throws<IOException>(() => activation.Apply());
            Assert.That(commands.Activations, Is.Zero);
            Assert.That(commands.Imports, Is.EqualTo(1));
            Assert.That(File.Exists(Path.Combine(directory, "activation.json")), Is.True);
        }

        private sealed class FakePowerCommands : IPowerSchemeCommands
        {
            public Guid Active = Guid.NewGuid();
            public List<PowerScheme> Schemes { get; } = new();
            public int Imports;
            public int Activations;
            public bool IgnoreActivation;
            public bool FailImport;
            public bool WrongImportName;
            public FakePowerCommands() => Schemes.Add(new PowerScheme(Active, "Custom original"));
            public IReadOnlyList<PowerScheme> List() => Schemes.ToArray();
            public Guid GetActive() => Active;
            public void Import(Guid id)
            {
                Imports++;
                if (FailImport) throw new IOException("injected import failure");
                Schemes.Add(new PowerScheme(id, WrongImportName ? "Unverified import" : RionPowerPlanTweak.PlanDisplayName));
            }
            public void SetActive(Guid id)
            {
                Activations++;
                if (!IgnoreActivation) Active = id;
            }
        }

        private sealed class MemoryRegistry : IRegistry
        {
            private readonly Dictionary<string, MemoryKey> keys = new(StringComparer.OrdinalIgnoreCase);
            public int Writes;
            public IRegistryKey LocalMachine { get; }
            public IRegistryKey CurrentUser => LocalMachine;
            public MemoryRegistry() => LocalMachine = new MemoryKey(this, "");
            public void Seed(string path, string name, object value, RegistryValueKind kind)
            {
                var key = (MemoryKey)LocalMachine.CreateSubKey(path);
                key.Values[name] = (value, kind);
            }
            public (object, RegistryValueKind)? Read(string path, string name) =>
                keys.TryGetValue(path, out var key) && key.Values.TryGetValue(name, out var value) ? value : null;

            private sealed class MemoryKey : IRegistryKey
            {
                private readonly MemoryRegistry registry;
                public string Name { get; }
                public readonly Dictionary<string, (object Value, RegistryValueKind Kind)> Values = new(StringComparer.OrdinalIgnoreCase);
                public MemoryKey(MemoryRegistry registry, string name) { this.registry = registry; Name = name; }
                public IRegistryKey OpenSubKey(string name, bool writable) => registry.keys.GetValueOrDefault(name);
                public IRegistryKey CreateSubKey(string name)
                {
                    if (!registry.keys.ContainsKey(name)) registry.keys[name] = new MemoryKey(registry, name);
                    return registry.keys[name];
                }
                public string[] GetSubKeyNames() => Array.Empty<string>();
                public string[] GetValueNames() => Values.Keys.ToArray();
                public object GetValue(string name) => GetValue(name, null);
                public object GetValue(string name, object fallback) => Values.TryGetValue(name, out var value) ? value.Value : fallback;
                public RegistryValueKind GetValueKind(string name) => Values[name].Kind;
                public void SetValue(string name, object value, RegistryValueKind kind) { registry.Writes++; Values[name] = (value, kind); }
                public void DeleteValue(string name, bool throwing) { registry.Writes++; Values.Remove(name); }
                public void Dispose() { }
            }
        }
    }
}
