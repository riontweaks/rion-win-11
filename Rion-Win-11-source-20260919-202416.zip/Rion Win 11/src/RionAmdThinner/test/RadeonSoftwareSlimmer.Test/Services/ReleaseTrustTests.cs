using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class ReleaseTrustTests
    {
        [TestCase("7z.exe")]
        [TestCase("7z.dll")]
        public void ModifiedCachedComponentsAreRejectedOnSubsequentRequests(string name)
        {
            string directory = Path.Combine(Path.GetTempPath(), "Rion7zTrust-" + Guid.NewGuid());
            try
            {
                string exe = SevenZip.Prepare(directory);
                Assert.That(File.Exists(exe), Is.True);
                Assert.That(SevenZip.Prepare(directory), Is.EqualTo(exe));
                string file = Path.Combine(directory, name);
                byte[] bytes = File.ReadAllBytes(file);
                bytes[bytes.Length - 1] ^= 1; // Same-length substitution defeated the former nonempty-file check.
                File.WriteAllBytes(file, bytes);
                Assert.Throws<InvalidDataException>(() => SevenZip.Acquire(directory));
            }
            finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        }

        [Test]
        public async Task ExecutionLeasePreventsReplacementAndStillExtractsAnInertArchive()
        {
            string root = Path.Combine(Path.GetTempPath(), "Rion7zLease-" + Guid.NewGuid());
            string directory = Path.Combine(root, "cache");
            Directory.CreateDirectory(root);
            try
            {
                string archive = Path.Combine(root, "fixture.zip");
                using (var zip = ZipFile.Open(archive, ZipArchiveMode.Create))
                using (var writer = new StreamWriter(zip.CreateEntry("fixture.txt").Open()))
                    writer.Write("Benign extraction fixture");
                var lease = SevenZip.Acquire(directory);
                using (lease)
                {
                    using var concurrent = SevenZip.Acquire(directory);
                    foreach (string name in new[] { "7z.exe", "7z.dll" })
                    {
                        string path = Path.Combine(directory, name);
                        Assert.Throws<IOException>(() => { using var writer = File.Open(path, FileMode.Open, FileAccess.Write, FileShare.ReadWrite); });
                        Assert.Throws<IOException>(() => File.Delete(path));
                        Assert.Throws<IOException>(() => File.Move(path, path + ".replaced"));
                    }
                    Assert.Throws<IOException>(() => Directory.Move(directory, directory + ".replaced"));
                    Assert.Throws<IOException>(() => Directory.Move(root, root + ".replaced"));
                    var result = await ShellRunner.RunAsync(lease.ExecutablePath,
                        $"x \"{archive}\" -o\"{Path.Combine(root, "output")}\" -y", null, 30000);
                    Assert.That(result.ExitCode, Is.Zero, result.Output);
                    Assert.That(File.ReadAllText(Path.Combine(root, "output", "fixture.txt")), Is.EqualTo("Benign extraction fixture"));
                }
                Assert.Throws<ObjectDisposedException>(() => { _ = lease.ExecutablePath; });
                // Disposing the lease releases every handle, including ancestor directories.
                File.Delete(Path.Combine(directory, "7z.exe"));
                Directory.Move(directory, directory + ".released");
            }
            finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
        }

        [Test]
        public void RetiredBootControlsRejectDirectApplyAndRetainRecovery()
        {
            var retired = OptimizerImportCatalog.All.Where(t => t.Id.StartsWith("bcd-") && t.Id != "bcd-bootmenupolicy").ToArray();
            Assert.That(retired, Has.Length.EqualTo(5));
            foreach (var tweak in retired)
            {
                Assert.That(tweak.ApplyBlockedReason, Is.Not.Empty);
                Assert.Throws<InvalidOperationException>(() => tweak.CustomApply());
                Assert.That(tweak.CustomRevert, Is.Not.Null);
                Assert.That(tweak.HasSavedState, Is.Not.Null);
            }
            Assert.Throws<InvalidOperationException>(() => VbsTweak.Apply());
        }
    }
}
