using System.Linq;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class RecommendedTweakTests
    {
        [Test] public void ReviewedImportsExcludeProtectionWeakeningRegistryPolicies()
        {
            Assert.That(OptimizerImportCatalog.All, Has.Count.EqualTo(14));
            Assert.That(OptimizerImportCatalog.All.Count(t => t.IsCustom), Is.EqualTo(9));
            Assert.That(OptimizerImportCatalog.All.Count(t => t.DeleteRegistryValue), Is.Zero);
            Assert.That(OptimizerImportCatalog.All.Where(t => !t.IsCustom).Any(t =>
                t.Category == TweakCategory.Security || t.SecuritySensitive), Is.False);
            Assert.That(OptimizerImportCatalog.All.All(t => t.ManualOnly && !GeneralTweakCatalog.IsRecommended(t)), Is.True);
            Assert.That(OptimizerImportCatalog.All.All(t => !string.IsNullOrWhiteSpace(t.Group) && !string.IsNullOrWhiteSpace(t.SourceCommand)), Is.True);
            Assert.That(OptimizerImportCatalog.All.Any(t => t.SourceCommand.Contains("MsSense.exe")), Is.False);
            Assert.That(OptimizerImportCatalog.All.Where(t => t.IsCustom).All(t => t.CustomRevert != null && t.HasSavedState != null), Is.True);
        }
        [Test] public void BulkRecommendationsAreSharedObjectsFromTheVisibleCatalog()
        {
            Assert.That(GeneralTweakCatalog.Recommended, Is.Not.Empty);
            foreach (var tweak in GeneralTweakCatalog.Recommended)
                Assert.That(GeneralTweakCatalog.All.Contains(tweak), Is.True);
            Assert.That(GeneralTweakCatalog.All.Select(t => t.Id).Distinct().Count(), Is.EqualTo(GeneralTweakCatalog.All.Count));
        }
        [TestCase("vbs-hvci-off")]
        [TestCase("dynamic-tick-off")]
        [TestCase("tdr-delay")]
        [TestCase("core-parking-off")]
        [TestCase("svchost-split-threshold")]
        [TestCase("edge-background-mode-off")]
        public void IndividualAndProcessPresetChoicesAreNotSilentlyAppliedByRecommendedTweaks(string id)
        {
            // Defined, not All: a tweak another card owns is still defined and still applied,
            // it just has no card of its own in the grid.
            Assert.That(GeneralTweakCatalog.IsRecommended(GeneralTweakCatalog.Defined.Single(t => t.Id == id)), Is.False);
        }

        [Test] public void CombinedVisibleCatalogHasOneOwnerPerRegistryValue()
        {
            var visible = GeneralTweakCatalog.All.Concat(NetworkTweakCatalog.All).Concat(ResearchedTweakCatalog.Network).ToList();
            var registry = visible.Where(t => !t.IsCustom && !t.IsCommandBased && t.DynamicKeyPath == null);
            var duplicates = registry.GroupBy(t => (t.Hive + "\\" + t.KeyPath + "\\" + t.ValueName).ToUpperInvariant()).Where(g => g.Count() > 1);
            Assert.That(duplicates.Select(g => g.Key), Is.Empty);
            Assert.That(visible.Count(t => t.ValueName == "NetworkThrottlingIndex"), Is.EqualTo(1));
        }
        [TestCase("vbs-hvci-off")]
        [TestCase("dynamic-tick-off")]
        [TestCase("net-max-user-port")]
        [TestCase("core-parking-off")]
        [TestCase("tdr-delay")]
        public void RetiredSettingsRemainInspectableButCannotBeApplied(string id)
        {
            var tweak = GeneralTweakCatalog.Defined.Concat(NetworkTweakCatalog.All).Single(t => t.Id == id);
            Assert.That(tweak.ApplyBlockedReason, Is.Not.Empty);
            Assert.That(GeneralTweakCatalog.IsRecommended(tweak), Is.False);
        }

        [Test] public void ProcessReductionOwnsServiceHostGroupingInsteadOfASecondCard()
        {
            // The definition must survive — ProcessReductionRunner looks it up by id and would
            // throw if it were deleted outright rather than hidden.
            Assert.That(TweakCatalog.All.Any(t => t.Id == "svchost-split-threshold"), Is.True);
            Assert.That(GeneralTweakCatalog.All.Any(t => t.Id == "svchost-split-threshold"), Is.False);
        }
    }
}
