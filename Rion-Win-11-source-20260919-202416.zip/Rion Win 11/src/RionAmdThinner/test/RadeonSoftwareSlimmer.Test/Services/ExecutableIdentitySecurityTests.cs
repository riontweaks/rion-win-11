using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class ExecutableIdentitySecurityTests
    {
        [Test]
        public void MissingKnownExecutableFailsWithoutSearchPathFallback()
        {
            string path = Path.Combine(Path.GetTempPath(), "RionMissing-" + Guid.NewGuid(), "powershell.exe");
            var error = Assert.Throws<FileNotFoundException>(() => ShellRunner.RequireExecutable(path, "Repair Windows PowerShell."));
            Assert.That(error.FileName, Is.EqualTo(path));
            Assert.That(error.Message, Does.Contain("Repair Windows PowerShell"));
            Assert.Throws<FileNotFoundException>(() => ShellRunner.RequireExecutable("powershell.exe", "Absolute path required."));
        }

        [TestCase(SignatureStatus.ValidButNotAmd, "Microsoft Corporation", "Microsoft Corporation", true)]
        [TestCase(SignatureStatus.ValidButNotAmd, "microsoft corporation", "Microsoft Corporation", true)]
        [TestCase(SignatureStatus.ValidButNotAmd, "Unrelated Trusted Publisher", "Microsoft Corporation", false)]
        [TestCase(SignatureStatus.ValidButNotAmd, "Microsoft Corporation Extra", "Microsoft Corporation", false)]
        [TestCase(SignatureStatus.ValidButNotAmd, "O&O Software GmbH", "O&O Software GmbH", true)]
        [TestCase(SignatureStatus.Invalid, "Microsoft Corporation", "Microsoft Corporation", false)]
        [TestCase(SignatureStatus.Unsigned, "Microsoft Corporation", "Microsoft Corporation", false)]
        [TestCase(SignatureStatus.Error, "Microsoft Corporation", "Microsoft Corporation", false)]
        [TestCase(SignatureStatus.ValidButNotAmd, "Microsoft Corporation", "", false)]
        public void ExpectedPublisherRequiresExactIdentityAndTrustedSignature(SignatureStatus status, string actual, string expected, bool accepted)
        {
            Assert.That(PortableToolDownloader.IsAcceptedPublisher(status, actual, expected), Is.EqualTo(accepted));
        }

        [Test]
        public void EveryUnpinnedDirectToolDeclaresPublisher()
        {
            foreach (var tool in UtilityToolCatalog.All.Where(t => t.Mechanism == UtilityMechanism.DirectDownload && t.Sha256 == null))
                Assert.That(tool.ExpectedPublisher, Is.Not.Null.And.Not.Empty, tool.Name);
            Assert.That(UtilityToolCatalog.All.Single(t => t.Name == "Autoruns").ExpectedPublisher, Is.EqualTo("Microsoft Corporation"));
            Assert.That(UtilityToolCatalog.All.Single(t => t.Name == "O&O ShutUp10").ExpectedPublisher, Is.EqualTo("O&O Software GmbH"));
        }

        [Test]
        public void EveryLaunchableUtilityRequiresCatalogIdentityIncludingWinget()
        {
            foreach (var tool in UtilityToolCatalog.All)
                Assert.That(tool.Sha256 != null || !string.IsNullOrWhiteSpace(tool.ExpectedPublisher), Is.True, tool.Name);
            Assert.That(UtilityToolCatalog.All.Single(t => t.Source == "Wagnardsoft.DisplayDriverUninstaller").ExpectedPublisher, Is.EqualTo("Wagnardsoft"));
        }

        [Test]
        public void DiscoveredUnsignedToolWithWrongPinnedBytesIsRejectedBeforeLaunch()
        {
            string directory = Path.Combine(Path.GetTempPath(), "RionFallback-" + Guid.NewGuid());
            Directory.CreateDirectory(directory);
            try
            {
                string path = Path.Combine(directory, "nvidiaProfileInspector.exe");
                File.WriteAllText(path, "Inert substituted utility fixture. Never execute.");
                var entry = UtilityToolCatalog.All.Single(t => t.Name == "NVIDIA Profile Inspector");
                Assert.Throws<InvalidDataException>(() => PortableToolDownloader.LaunchDownloaded(path, entry.Sha256, entry.ExpectedPublisher));
                File.Delete(path); // Rejection released the guard.
            }
            finally { Directory.Delete(directory, true); }
        }

        private sealed class DownloadHandler : HttpMessageHandler
        {
            private readonly byte[] bytes;
            public DownloadHandler(byte[] bytes) => this.bytes = bytes;
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct) =>
                Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { RequestMessage = request, Content = new ByteArrayContent(bytes) });
        }

        [Test]
        public void WrongPublisherSignedDownloadPreservesCacheAndRemovesPartial()
        {
            string source = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "dotnet.exe");
            if (!File.Exists(source)) Assert.Ignore("A signed .NET host fixture is unavailable.");
            Assert.That(PortableToolDownloader.IsTrustedExecutable(source), Is.True);
            string directory = Path.Combine(Path.GetTempPath(), "RionPublisher-" + Guid.NewGuid());
            Directory.CreateDirectory(directory);
            try
            {
                string target = Path.Combine(directory, "tool.exe");
                File.WriteAllText(target, "existing cache");
                using var client = new HttpClient(new DownloadHandler(File.ReadAllBytes(source)));
                Assert.ThrowsAsync<InvalidDataException>(() => PortableToolDownloader.DownloadFileAsync(client, "https://example.com/tool.exe", target, null, 1024, CancellationToken.None, expectedPublisher: "O&O Software GmbH"));
                Assert.That(File.ReadAllText(target), Is.EqualTo("existing cache"));
                Assert.That(Directory.GetFiles(directory, "*.partial"), Is.Empty);
                Assert.That(PortableToolDownloader.IsAcceptedExecutable(source, expectedPublisher: "O&O Software GmbH"), Is.False);
            }
            finally { Directory.Delete(directory, true); }
        }
    }
}
