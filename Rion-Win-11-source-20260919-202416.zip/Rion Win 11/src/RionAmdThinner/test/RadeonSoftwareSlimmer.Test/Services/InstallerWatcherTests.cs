using System.Linq;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class InstallerWatcherTests
    {
        [Test]
        public void DriverChanged_AfterNull_ReturnsFalse()
        {
            var before = new HardwareInfo { DriverVersion = "31.0.1" };
            Assert.That(InstallerWatcher.DriverChanged(before, null), Is.False);
        }

        [Test]
        public void DriverChanged_SameEverything_ReturnsFalse()
        {
            var before = new HardwareInfo { DriverVersion = "32.0.1", DriverDate = "2026-08-17", AmdSoftwareVersion = "26.10", AmdSoftwareDetected = true };
            var after = new HardwareInfo { DriverVersion = "32.0.1", DriverDate = "2026-08-17", AmdSoftwareVersion = "26.10", AmdSoftwareDetected = true };
            Assert.That(InstallerWatcher.DriverChanged(before, after), Is.False);
        }

        [Test]
        public void DriverChanged_NewVersion_ReturnsTrue()
        {
            var before = new HardwareInfo { DriverVersion = "32.0.1" };
            var after = new HardwareInfo { DriverVersion = "32.0.2" };
            Assert.That(InstallerWatcher.DriverChanged(before, after), Is.True);
        }

        [Test]
        public void DriverChanged_NewDriverDate_ReturnsTrue()
        {
            var before = new HardwareInfo { DriverVersion = "32.0.1", DriverDate = "2026-08-17" };
            var after = new HardwareInfo { DriverVersion = "32.0.1", DriverDate = "2026-09-01" };
            Assert.That(InstallerWatcher.DriverChanged(before, after), Is.True);
        }

        [Test]
        public void DriverChanged_AmdSoftwareNewlyDetected_ReturnsTrue()
        {
            var before = new HardwareInfo { AmdSoftwareDetected = false };
            var after = new HardwareInfo { AmdSoftwareDetected = true };
            Assert.That(InstallerWatcher.DriverChanged(before, after), Is.True);
        }

        [Test]
        public void DriverChanged_AmdSoftwareVersionBump_ReturnsTrue()
        {
            var before = new HardwareInfo { AmdSoftwareVersion = "26.10", AmdSoftwareDetected = true };
            var after = new HardwareInfo { AmdSoftwareVersion = "26.11", AmdSoftwareDetected = true };
            Assert.That(InstallerWatcher.DriverChanged(before, after), Is.True);
        }

        // ---- Classify: installer window text/percent -> phase ----

        [Test]
        public void Classify_InstallingText_WithHiddenExpressLabel_IsInstalling_NotChooser()
        {
            // the exact real-world case: AMD shows "Installing AMD Software: Adrenalin Edition" at 39%,
            // but a hidden wizard page still has an "Express Installation" label in the UI tree.
            var r = InstallerWatcher.Classify("Installing AMD Software: Adrenalin Edition", 39, false);
            Assert.Multiple(() =>
            {
                Assert.That(r.Phase, Is.EqualTo(WatchPhase.InstallingDriver));
                Assert.That(r.RealInstall, Is.True);
                Assert.That(r.Percent, Is.EqualTo(39));
            });
        }

        [Test]
        public void Classify_LiveProgressWithNoUsefulText_IsInstalling()
        {
            // reader grabbed a stale "Express Installation" line, but the bar is moving at 55%
            var r = InstallerWatcher.Classify("Express Installation", 55, false);
            Assert.That(r.Phase, Is.EqualTo(WatchPhase.InstallingDriver));
            Assert.That(r.RealInstall, Is.True);
        }

        [Test]
        public void Classify_ChooserScreen_NoProgress_IsInstallerOpen_NotRealInstall()
        {
            var r = InstallerWatcher.Classify("Express Installation   Recommended", null, false);
            Assert.Multiple(() =>
            {
                Assert.That(r.Phase, Is.EqualTo(WatchPhase.InstallerOpen));
                Assert.That(r.RealInstall, Is.False);
                Assert.That(r.Percent, Is.Null);
            });
        }

        [Test]
        public void Classify_EulaScreen_IsInstallerOpen()
        {
            var r = InstallerWatcher.Classify("End User License Agreement", null, false);
            Assert.That(r.Phase, Is.EqualTo(WatchPhase.InstallerOpen));
            Assert.That(r.RealInstall, Is.False);
        }

        [Test]
        public void Classify_DownloadingWithPercent_IsDownloading()
        {
            var r = InstallerWatcher.Classify("Downloading package 3 of 12", 20, false);
            Assert.Multiple(() =>
            {
                Assert.That(r.Phase, Is.EqualTo(WatchPhase.Downloading));
                Assert.That(r.RealInstall, Is.True);
            });
        }

        [Test]
        public void Classify_PreparingText_IsStarting_NotRealInstall()
        {
            var r = InstallerWatcher.Classify("Preparing installation", 0, false);
            Assert.That(r.Phase, Is.EqualTo(WatchPhase.Starting));
            Assert.That(r.RealInstall, Is.False);
        }

        [Test]
        public void Classify_DriverStageProcess_IsInstalling_EvenWithNoText()
        {
            var r = InstallerWatcher.Classify(null, null, driverStage: true);
            Assert.That(r.Phase, Is.EqualTo(WatchPhase.InstallingDriver));
            Assert.That(r.RealInstall, Is.True);
        }

        [TestCase("Installation completed successfully")]
        [TestCase("Welcome to the AMD Software experience")]
        public void Classify_SuccessText_IsConfirmed(string text)
        {
            var r = InstallerWatcher.Classify(text, 100, false);
            Assert.That(r.Confirmed, Is.True);
            Assert.That(r.Phase, Is.EqualTo(WatchPhase.Finishing));
        }

        [Test]
        public void Classify_RestartText_IsConfirmed()
        {
            var r = InstallerWatcher.Classify("A restart is required to complete setup", null, false);
            Assert.That(r.Confirmed, Is.True);
        }

        [Test]
        public void Classify_HundredPercent_IsNotTreatedAsLiveProgress()
        {
            // 100% with a stale chooser label should not read as "installing"
            var r = InstallerWatcher.Classify("Express Installation", 100, false);
            Assert.That(r.Phase, Is.EqualTo(WatchPhase.InstallerOpen));
        }

        // ---- force-close AMD installer + Adrenalin before applying tweaks ----
        // NOTE: ForceCloseAmdPostInstall() is deliberately NOT exercised here - it really does
        // terminate the user's running AMD Software. Only the read-only checks are tested.

        [Test]
        public void RunningChecks_DoNotThrow()
        {
            Assert.DoesNotThrow(() => _ = InstallerWatcher.AmdInstallerStillRunning());
            Assert.DoesNotThrow(() => _ = InstallerWatcher.AdrenalinRunning());
        }

        [Test]
        public void ProcessNeedles_NeverTargetTheDriverOrEventsClient()
        {
            var t = typeof(InstallerWatcher);
            string[] Needles(string field) =>
                (string[])t.GetField(field, System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static).GetValue(null);

            string[] installer = Needles("InstallerNeedles");
            string[] adrenalin = Needles("AdrenalinNeedles");

            Assert.Multiple(() =>
            {
                // drvinst.exe (the OS driver installer) and atieclxx.exe (the driver's events client)
                // must never be in a set we force-kill.
                foreach (string n in installer.Concat(adrenalin))
                {
                    Assert.That("drvinst".Contains(n), Is.False, "installer/adrenalin needle would match drvinst: " + n);
                    Assert.That("atieclxx".Contains(n), Is.False, "installer/adrenalin needle would match atieclxx: " + n);
                }
                // the two sets are distinct concepts - no needle appears in both
                Assert.That(installer.Intersect(adrenalin), Is.Empty);
            });
        }
    }
}
