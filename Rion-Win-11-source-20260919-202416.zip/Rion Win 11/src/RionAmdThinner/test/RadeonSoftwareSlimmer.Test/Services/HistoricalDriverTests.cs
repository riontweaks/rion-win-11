using System;
using System.IO;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class HistoricalDriverTests
    {
        private const string AmdUrl = "https://drivers.amd.com/drivers/whql-amd-software-adrenalin-edition-26.6.4-win11-b.exe";
        [Test] public void AmdMatchesExactVersionAndOs()
        {
            string row = "<article><p>Adrenalin 26.6.4 (WHQL Recommended)</p><a href='" + AmdUrl + "'>Download</a></article>";
            string html = "<button>Windows 11 - 64-Bit Edition</button>" + row + "<h2 class='accordion-header'><button>Windows 10 - 64-Bit Edition</button>";
            Assert.That(HistoricalDriverInstaller.ParseAmd(html, "26.6.4", true), Is.EqualTo(AmdUrl));
            Assert.That(HistoricalDriverInstaller.ParseAmd(html, "26.6.4", false), Is.Null);
            Assert.That(HistoricalDriverInstaller.ParseAmd(html, "26.6", true), Is.Null);
            Assert.That(HistoricalDriverInstaller.ParseAmd(html, "26.3.1", true), Is.Null);
        }
        [Test] public void NvidiaKeepsUrlAttachedToItsVersion()
        {
            string json = "{\"IDS\":[{\"downloadInfo\":{\"Version\":\"616.56\",\"DownloadURL\":\"https://us.download.nvidia.com/Windows/616.56/616.56-desktop-win10-win11-64bit.exe\"}},{\"downloadInfo\":{\"Version\":\"591.86\",\"DownloadURL\":\"https://us.download.nvidia.com/Windows/591.86/591.86-desktop-win10-win11-64bit.exe\"}}]}";
            Assert.That(HistoricalDriverInstaller.ParseNvidia(json, "591.86"), Does.Contain("/591.86/591.86-"));
            Assert.That(HistoricalDriverInstaller.ParseNvidia(json, "999.99"), Is.Null);
        }
        [TestCase("https://drivers.amd.com.evil.test/26.6.4.exe")]
        [TestCase("http://drivers.amd.com/26.6.4.exe")]
        [TestCase("https://user@drivers.amd.com/26.6.4.exe")]
        [TestCase("https://drivers.amd.com:444/26.6.4.exe")]
        [TestCase("https://drivers.amd.com/26.6.4-minimalsetup.exe")]
        [TestCase("https://drivers.amd.com/26.6.40.exe")]
        public void RejectsUnexpectedPackageIdentity(string url) => Assert.That(HistoricalDriverInstaller.IsPackageUrl("AMD", url, "26.6.4"), Is.False);
        [Test] public void TrustRequiresSignatureAndExactVendor()
        {
            var info = new DriverInstallerInfo { SignatureStatus = SignatureStatus.ValidButNotAmd, Publisher = "NVIDIA Corporation" };
            Assert.That(HistoricalDriverInstaller.Trusted("NVIDIA", info), Is.True);
            Assert.That(HistoricalDriverInstaller.Trusted("AMD", info), Is.False);
            info.Publisher = "NVIDIA Corporation impostor";
            Assert.That(HistoricalDriverInstaller.Trusted("NVIDIA", info), Is.False);
            info.Publisher = "NVIDIA Corporation"; info.SignatureStatus = SignatureStatus.Invalid;
            Assert.That(HistoricalDriverInstaller.Trusted("NVIDIA", info), Is.False);
        }
        [Test] public void UnmatchedGpuCannotFallBackToGenericPackage()
        {
            var service = new HistoricalDriverInstaller((_, _) => Task.FromResult("<root/>"));
            Assert.ThrowsAsync<InvalidOperationException>(async () => await service.ResolveAsync(DriverRecommendationCatalog.ForVendor("AMD")[0], "Unknown GPU", true, default));
        }
    }
}
