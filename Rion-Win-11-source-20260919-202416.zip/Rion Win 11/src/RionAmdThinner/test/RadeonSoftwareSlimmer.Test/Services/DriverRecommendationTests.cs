using System;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class DriverRecommendationTests
    {
        [TestCase("AMD", 4)]
        [TestCase("NVIDIA", 3)]
        public void CatalogHasDatedScopedEvidence(string vendor, int count)
        {
            var rows = DriverRecommendationCatalog.ForVendor(vendor);
            Assert.That(rows.Count, Is.EqualTo(count));
            Assert.That(rows.Select(r => r.Version).Distinct().Count(), Is.EqualTo(count));
            Assert.That(rows.Count(r => r.IsOptimal), Is.EqualTo(1));
            Assert.That(rows.Single(r => r.IsOptimal).Label, Does.Contain(" · Optimal"));
            Assert.That(rows.Where(r => !r.IsOptimal).All(r => !r.Label.Contains("Optimal")), Is.True);
            foreach (var row in rows)
            {
                Assert.That(row.Vendor, Is.EqualTo(vendor));
                Assert.That(row.Released, Is.LessThanOrEqualTo(DriverRecommendationCatalog.ReviewedOn));
                Assert.That(DriverReleaseService.IsOfficial(vendor, new Uri(row.OfficialUrl)), Is.True);
                Assert.That(DriverRecommendationCatalog.IsEvidenceUrl(vendor, row.EvidenceUrl), Is.True);
                Assert.That(row.UseCase, Is.Not.Empty);
                Assert.That(row.Caveat, Is.Not.Empty);
            }
        }
        [Test] public async Task SelectionDoesNotPrepareInstallerOrChangeLiveState()
        {
            int preparations = 0;
            var vm = new DriverReleaseCardViewModel("AMD", "RX 7900 XTX",
                service: new DriverReleaseService((_, _) => throw new InvalidOperationException("offline")),
                prepareInstaller: () => { preparations++; return Task.CompletedTask; });
            vm.SelectedRecommendation = vm.Recommendations.Last();
            Assert.That(vm.SelectedRecommendation.Version, Is.EqualTo("26.3.1"));
            vm.SelectedRecommendation = DriverRecommendationCatalog.ForVendor("NVIDIA")[0];
            Assert.That(vm.SelectedRecommendation.Version, Is.EqualTo("26.3.1"));
            await vm.RefreshAsync(true);
            Assert.That(vm.RecommendationsReviewed, Is.EqualTo("Last reviewed: September 8, 2026"));
            Assert.That(vm.SelectedRecommendation.Version, Is.EqualTo("26.3.1"));
            Assert.That(vm.Version, Is.EqualTo("—"));
            Assert.That(preparations, Is.Zero);
        }
        [TestCase("https://www.reddit.com/other")]
        [TestCase("file:///C:/test.exe")]
        [TestCase("https://www.reddit.com.evil.example/")]
        public void OnlyCatalogEvidenceLinksAreAllowed(string url) =>
            Assert.That(DriverRecommendationCatalog.IsEvidenceUrl("AMD", url), Is.False);
    }
}
