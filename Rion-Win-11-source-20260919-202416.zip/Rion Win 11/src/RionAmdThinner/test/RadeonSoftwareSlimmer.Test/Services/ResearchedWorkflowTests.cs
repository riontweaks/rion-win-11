using System;
using System.IO;
using Microsoft.Win32;
using NUnit.Framework;
using NvidiaDriverTool.Services;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Test.TestDoubles;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class ResearchedWorkflowTests
    {
        [Test]
        public void ParseRealNvidiaPackageWithoutExecutingIt()
        {
            string root = Environment.GetEnvironmentVariable("RION_NVIDIA_FIXTURE");
            if (string.IsNullOrEmpty(root)) Assert.Ignore("Set RION_NVIDIA_FIXTURE to an extracted official package.");
            var components = NvidiaComponentManifest.Parse(root);
            Assert.That(components, Has.Some.Matches<NvidiaComponentManifest.NvidiaComponent>(c => c.Services.Count > 0));
            Assert.That(components, Has.Some.Matches<NvidiaComponentManifest.NvidiaComponent>(c => c.Tasks.Count > 0));
            Assert.That(NvidiaInstallPlan.Arguments(components, Array.Empty<string>()), Is.EqualTo("-s -n"));
        }
        [TestCase(null)]
        [TestCase(7)]
        public void PolicyRestoresOriginalAfterRepeatedApplyAndReload(int? original)
        {
            var root = new FakeRegistryKey();
            var key = root.CreateSubKey("policy");
            if (original.HasValue) key.SetValue("value", original.Value, RegistryValueKind.DWord);
            string backup = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".json");
            var policy = new ReversibleDword(root, "policy", "value", 0, backup);
            Assert.That(policy.Apply(), Is.True);
            Assert.That(policy.Apply(), Is.False);
            Assert.That(policy.Inspect(), Is.True);
            Assert.That(new ReversibleDword(root, "policy", "value", 0, backup).Revert(), Is.True);
            Assert.That(key.GetValue("value"), Is.EqualTo(original));
            Assert.That(File.Exists(backup), Is.False);
        }
        [Test]
        public void PolicyRefusesExternalChangesAndUnownedRevert()
        {
            var root = new FakeRegistryKey();
            string backup = Path.Combine(TestContext.CurrentContext.WorkDirectory, Guid.NewGuid() + ".json");
            var policy = new ReversibleDword(root, "policy", "value", 0, backup);
            Assert.Throws<InvalidOperationException>(() => policy.Revert());
            policy.Apply();
            root.OpenSubKey("policy", true).SetValue("value", 9, RegistryValueKind.DWord);
            Assert.Throws<InvalidOperationException>(() => policy.Revert());
            Assert.Throws<InvalidOperationException>(() => policy.Apply());
            Assert.That(root.OpenSubKey("policy", false).GetValue("value"), Is.EqualTo(9));
            File.Delete(backup);
        }
        [Test]
        public void NvidiaRejectsRequiredUnknownAndConflictingSelections()
        {
            var driver = new NvidiaComponentManifest.NvidiaComponent { Name = "Display.Driver", Disposition = "critical" };
            var app = new NvidiaComponentManifest.NvidiaComponent { Name = "Display.NvApp" };
            app.Requires.Add("NvContainer");
            var container = new NvidiaComponentManifest.NvidiaComponent { Name = "NvContainer" };
            var components = new[] { driver, app, container };
            Assert.Throws<InvalidOperationException>(() => NvidiaInstallPlan.Arguments(components, new[] { "Display.Driver" }));
            Assert.Throws<InvalidOperationException>(() => NvidiaInstallPlan.Arguments(components, new[] { "NvContainer" }));
            Assert.Throws<InvalidOperationException>(() => NvidiaInstallPlan.Arguments(components, new[] { "unknown" }));
            Assert.That(NvidiaInstallPlan.Arguments(components, new[] { "Display.NvApp", "NvContainer" }),
                Is.EqualTo("-s -n -deselect:Display.NvApp -deselect:NvContainer"));
        }
    }
}
