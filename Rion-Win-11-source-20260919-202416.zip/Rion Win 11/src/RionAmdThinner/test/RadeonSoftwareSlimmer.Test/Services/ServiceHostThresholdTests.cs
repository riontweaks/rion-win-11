using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class ServiceHostThresholdTests
    {
        // Published table: capacity GB -> SvcHostSplitThresholdInKB.
        [TestCase(4, 0x400000)]
        [TestCase(6, 0x600000)]
        [TestCase(8, 0x800000)]
        [TestCase(12, 0xC00000)]
        [TestCase(16, 0x1000000)]
        [TestCase(24, 0x1800000)]
        [TestCase(32, 0x2000000)]
        [TestCase(64, 0x4000000)]
        // Off-table capacities take the nearest listed capacity's threshold.
        [TestCase(15, 0x1000000)]
        [TestCase(31, 0x2000000)]
        [TestCase(17, 0x1000000)]
        [TestCase(33, 0x2000000)]
        [TestCase(14, 0x1000000)]
        [TestCase(13.99, 0xC00000)]
        [TestCase(2, 0x400000)]
        [TestCase(128, 0x8000000)]
        [TestCase(256, 0x10000000)]
        // Unreadable capacity falls back to the Windows default.
        [TestCase(0, 0x380000)]
        [TestCase(-1, 0x380000)]
        public void SelectsNearestTableValue(double detectedGb, long expected)
        {
            Assert.That(SystemInfo.ServiceHostSplitThresholdKb((long)(detectedGb * 1024 * 1024)),
                Is.EqualTo(expected));
        }
    }
}
