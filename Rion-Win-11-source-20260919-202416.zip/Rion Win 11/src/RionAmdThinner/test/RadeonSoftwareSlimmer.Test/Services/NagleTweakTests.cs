using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using Newtonsoft.Json;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class NagleTweakTests
    {
        private string directory;
        private string legacyFile;
        private MemoryRegistry registry;

        [SetUp]
        public void Setup()
        {
            directory = Path.Combine(Path.GetTempPath(), "RionNagle-" + Guid.NewGuid());
            Directory.CreateDirectory(directory);
            legacyFile = Path.Combine(directory, "nagle-touched-adapters.txt");
            registry = new MemoryRegistry();
        }

        [TearDown] public void Cleanup() => Directory.Delete(directory, true);

        private bool Apply() => NagleTweak.Apply(registry, directory, legacyFile);
        private bool Revert() => NagleTweak.Revert(registry, directory, legacyFile);

        [Test]
        public void ExistingTypedValuesAndAbsenceAreRestoredAcrossAdapters()
        {
            var first = registry.AddAdapter("{first}");
            var second = registry.AddAdapter("{second}");
            first.Values["TcpAckFrequency"] = (8, RegistryValueKind.DWord);
            first.Values["TCPNoDelay"] = ("original", RegistryValueKind.String);
            second.Values["TcpAckFrequency"] = (new byte[] { 0, 255 }, RegistryValueKind.Binary);
            Assert.That(Apply(), Is.True);
            Assert.That(NagleTweak.IsDisabled(registry), Is.True);
            Assert.That(RegistryChangeHistory.ListEntries(directory), Has.Count.EqualTo(4));
            Assert.That(Revert(), Is.True);
            Assert.That(first.Values["TcpAckFrequency"], Is.EqualTo((8, RegistryValueKind.DWord)));
            Assert.That(first.Values["TCPNoDelay"], Is.EqualTo(("original", RegistryValueKind.String)));
            Assert.That(second.Values["TcpAckFrequency"].Value, Is.EqualTo(new byte[] { 0, 255 }));
            Assert.That(second.Values["TcpAckFrequency"].Kind, Is.EqualTo(RegistryValueKind.Binary));
            Assert.That(second.Values.ContainsKey("TCPNoDelay"), Is.False);
        }

        [Test]
        public void RepeatedApplyAndNewAdaptersPreserveFirstOriginals()
        {
            var first = registry.AddAdapter("{first}");
            first.Values["TcpAckFrequency"] = (8, RegistryValueKind.DWord);
            Apply();
            int writes = registry.Writes;
            Apply();
            Assert.That(registry.Writes, Is.EqualTo(writes));
            var second = registry.AddAdapter("{second}");
            Apply();
            Assert.That(RegistryChangeHistory.ListEntries(directory), Has.Count.EqualTo(4));
            Revert();
            Assert.That(first.Values["TcpAckFrequency"].Value, Is.EqualTo(8));
            Assert.That(first.Values.ContainsKey("TCPNoDelay"), Is.False);
            Assert.That(second.Values, Is.Empty);
        }

        [Test]
        public void NumericallyEqualWrongRegistryTypeIsReplacedAndRecoverable()
        {
            var adapter = registry.AddAdapter("{first}");
            adapter.Values["TcpAckFrequency"] = (1L, RegistryValueKind.QWord);
            adapter.Values["TCPNoDelay"] = (1, RegistryValueKind.DWord);
            Assert.That(NagleTweak.IsDisabled(registry), Is.False);
            Apply();
            Assert.That(registry.Writes, Is.EqualTo(1));
            Revert();
            Assert.That(adapter.Values["TcpAckFrequency"], Is.EqualTo((1L, RegistryValueKind.QWord)));
            Assert.That(adapter.Values["TCPNoDelay"], Is.EqualTo((1, RegistryValueKind.DWord)));
        }

        [Test]
        public void EachWriteHasADurableJournalAndPersistenceFailurePreventsWrites()
        {
            registry.AddAdapter("{first}");
            registry.BeforeWrite = () => Assert.That(RegistryChangeHistory.ListEntries(directory), Is.Not.Empty);
            Apply();
            Assert.That(registry.Writes, Is.EqualTo(2));

            var other = new MemoryRegistry(); other.AddAdapter("{other}");
            string fileAsDirectory = Path.Combine(directory, "blocked");
            File.WriteAllText(fileAsDirectory, "file");
            Assert.Throws<IOException>(() => NagleTweak.Apply(other, fileAsDirectory, legacyFile));
            Assert.That(other.Writes, Is.Zero);
        }

        [Test]
        public void PartialWriteFailureRetainsHistoryAndRestoresCompletedWrites()
        {
            var adapter = registry.AddAdapter("{first}");
            adapter.Values["TcpAckFrequency"] = (8, RegistryValueKind.DWord);
            registry.FailWriteName = "TCPNoDelay";
            Assert.Throws<IOException>(() => Apply());
            Assert.That(adapter.Values["TcpAckFrequency"].Value, Is.EqualTo(1));
            Assert.That(RegistryChangeHistory.ListEntries(directory), Has.Count.EqualTo(2));
            registry.FailWriteName = null;
            Assert.Throws<IOException>(() => Revert());
            Assert.That(adapter.Values["TcpAckFrequency"].Value, Is.EqualTo(8));
            Assert.That(adapter.Values.ContainsKey("TCPNoDelay"), Is.False);
            Assert.That(RegistryChangeHistory.ListEntries(directory).Count(e => e.Status == "Restored"), Is.EqualTo(1));
        }

        [Test]
        public void IgnoredWriteDoesNotReportSuccess()
        {
            registry.AddAdapter("{first}"); registry.IgnoreWrites = true;
            Assert.Throws<IOException>(() => Apply());
            Assert.That(RegistryChangeHistory.ListEntries(directory).Single().Status, Is.EqualTo("Failed"));
        }

        [Test]
        public void ExternalChangeBlocksReapplyAndIsPreservedDuringPartialRestore()
        {
            var adapter = registry.AddAdapter("{first}");
            Apply();
            adapter.Values["TcpAckFrequency"] = (9, RegistryValueKind.DWord);
            int writes = registry.Writes;
            Assert.Throws<IOException>(() => Apply());
            Assert.That(registry.Writes, Is.EqualTo(writes));
            Assert.Throws<IOException>(() => Revert());
            Assert.That(adapter.Values["TcpAckFrequency"].Value, Is.EqualTo(9));
            Assert.That(adapter.Values.ContainsKey("TCPNoDelay"), Is.False);
            Assert.That(RegistryChangeHistory.ListEntries(directory).Any(e => e.Status == "Conflict"), Is.True);
        }

        [Test]
        public void MissingHistoryDoesNotClaimRestoreOrDeleteExistingValues()
        {
            var adapter = registry.AddAdapter("{first}");
            adapter.Values["TcpAckFrequency"] = (1, RegistryValueKind.DWord);
            adapter.Values["TCPNoDelay"] = (1, RegistryValueKind.DWord);
            var error = Assert.Throws<InvalidOperationException>(() => Revert());
            Assert.That(error.Message, Does.Contain("No saved TCP settings"));
            Assert.That(registry.Writes, Is.Zero);
        }

        [TestCase("Pending")]
        [TestCase("Failed")]
        public void UnconfirmedPriorWriteCannotBeReplacedWithANewOriginal(string status)
        {
            var adapter = registry.AddAdapter("{first}");
            adapter.Values["TcpAckFrequency"] = (8, RegistryValueKind.DWord);
            Apply();
            string path = Directory.GetFiles(directory, "*.json").Single();
            var document = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(path));
            var entry = document.Entries.Single(e => e.Detail == "TcpAckFrequency");
            entry.Verified = null; entry.HistoryStatus = status;
            File.WriteAllText(path, JsonConvert.SerializeObject(document));
            adapter.Values["TcpAckFrequency"] = (9, RegistryValueKind.DWord);
            int writes = registry.Writes;
            Assert.Throws<IOException>(() => Apply());
            Assert.That(registry.Writes, Is.EqualTo(writes));
            var saved = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(path));
            Assert.That(saved.Entries.Single(e => e.Detail == "TcpAckFrequency").Before.Data, Is.EqualTo("8"));
            Assert.That(Directory.GetFiles(directory, "*.json"), Has.Length.EqualTo(1));
        }

        [Test]
        public void IncompleteLegacyRecordIsPreservedWithoutInventingOriginals()
        {
            registry.AddAdapter("{first}");
            string original = "{first}\tAck\n";
            File.WriteAllText(legacyFile, original);
            Assert.Throws<InvalidOperationException>(() => Apply());
            var error = Assert.Throws<InvalidOperationException>(() => Revert());
            Assert.That(error.Message, Does.Contain("did not save existing values"));
            Assert.That(File.ReadAllText(legacyFile), Is.EqualTo(original));
            Assert.That(registry.Writes, Is.Zero);
            Assert.That(Directory.GetFiles(directory, "*.json"), Is.Empty);
        }

        [Test]
        public void NoAdaptersIsUnknownAndCannotBeReportedAsApplied()
        {
            Assert.That(NagleTweak.IsDisabled(registry), Is.Null);
            Assert.Throws<IOException>(() => Apply());
            Assert.That(registry.Writes, Is.Zero);
        }

        private sealed class MemoryRegistry : IRegistry
        {
            internal readonly Dictionary<string, MemoryKey> Keys = new(StringComparer.OrdinalIgnoreCase);
            public IRegistryKey CurrentUser => Keys[""];
            public IRegistryKey LocalMachine => Keys[""];
            internal int Writes;
            internal bool IgnoreWrites;
            internal string FailWriteName;
            internal Action BeforeWrite;

            internal MemoryRegistry()
            {
                Keys[""] = new MemoryKey(this, "");
                Keys[NagleTweak.InterfacesKey] = new MemoryKey(this, NagleTweak.InterfacesKey);
            }
            internal MemoryKey AddAdapter(string name)
            {
                string path = NagleTweak.InterfacesKey + "\\" + name;
                var key = new MemoryKey(this, path); Keys.Add(path, key); return key;
            }

            internal sealed class MemoryKey : IRegistryKey
            {
                private readonly MemoryRegistry owner;
                public string Name { get; }
                internal readonly Dictionary<string, (object Value, RegistryValueKind Kind)> Values = new(StringComparer.OrdinalIgnoreCase);
                internal MemoryKey(MemoryRegistry owner, string name) { this.owner = owner; Name = name; }
                private string PathOf(string name) => Name.Length == 0 ? name : Name + "\\" + name;
                public IRegistryKey OpenSubKey(string name, bool writable) => owner.Keys.TryGetValue(PathOf(name), out var key) ? key : null;
                public IRegistryKey CreateSubKey(string name)
                {
                    string path = PathOf(name);
                    if (!owner.Keys.TryGetValue(path, out var key)) owner.Keys[path] = key = new MemoryKey(owner, path);
                    return key;
                }
                public string[] GetSubKeyNames() => owner.Keys.Keys.Where(k => k.StartsWith(Name + "\\", StringComparison.OrdinalIgnoreCase))
                    .Select(k => k.Substring(Name.Length + 1)).Where(k => !k.Contains('\\')).ToArray();
                public string[] GetValueNames() => Values.Keys.ToArray();
                public object GetValue(string name) => GetValue(name, null);
                public object GetValue(string name, object fallback) => Values.TryGetValue(name, out var value) ? value.Value : fallback;
                public RegistryValueKind GetValueKind(string name) => Values[name].Kind;
                public void SetValue(string name, object value, RegistryValueKind kind)
                {
                    owner.BeforeWrite?.Invoke();
                    if (owner.FailWriteName == name) throw new IOException("Injected write failure");
                    owner.Writes++; if (!owner.IgnoreWrites) Values[name] = (value, kind);
                }
                public void DeleteValue(string name, bool throwOnMissingValue)
                { owner.BeforeWrite?.Invoke(); owner.Writes++; if (!owner.IgnoreWrites) Values.Remove(name); }
                public void Dispose() { }
            }
        }
    }
}
