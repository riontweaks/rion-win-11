using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services;

public class InstallerPublisherPolicyTests
{
    [TestCase("Advanced Micro Devices", true)]
    [TestCase("Advanced Micro Devices, Inc.", true)]
    [TestCase("Advanced Micro Devices Inc.", true)]
    [TestCase("advanced micro devices", true)]
    [TestCase("ATI Technologies Inc.", true)]
    [TestCase("Advanced Micro Devices Unrelated Company", false)]
    [TestCase("Not Advanced Micro Devices", false)]
    [TestCase("ATI Technologies Impersonator", false)]
    [TestCase("AMD", false)]
    [TestCase("NVIDIA Corporation", false)]
    [TestCase("", false)]
    [TestCase(null, false)]
    public void InspectionPreparationAndDisplayUseTheSameExactPublisherPolicy(string publisher, bool expected)
    {
        bool recognized = InstallerValidator.IsAmdPublisher(publisher);
        var info = new DriverInstallerInfo { Publisher = publisher,
            SignatureStatus = recognized ? SignatureStatus.Valid : SignatureStatus.ValidButNotAmd };
        Assert.That(recognized, Is.EqualTo(expected));
        Assert.That(HistoricalDriverInstaller.Trusted("AMD", info), Is.EqualTo(expected));
        Assert.That(info.LooksTrusted, Is.EqualTo(expected));
    }

    [TestCase(SignatureStatus.NotChecked)]
    [TestCase(SignatureStatus.Unsigned)]
    [TestCase(SignatureStatus.Invalid)]
    [TestCase(SignatureStatus.Error)]
    public void KnownNameAndOfficialSourceNeverBypassSignatureVerification(SignatureStatus status)
    {
        var info = new DriverInstallerInfo { Publisher = "Advanced Micro Devices",
            SignatureStatus = status, IsOfficialAmdSource = true };
        Assert.That(HistoricalDriverInstaller.Trusted("AMD", info), Is.False);
        Assert.That(info.LooksTrusted, Is.False);
    }
}
