using System;
using System.IO;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public sealed class TweakInspectionTests
    {
        [Test]
        public void InspectionFailureReachesTheCardAndApplyResultWithoutWriting()
        {
            int writes = 0;
            var tweak = new SystemTweak {
                Id = "fixture-bcd", Title = "Fixture boot setting",
                InspectCommandState = () => throw new IOException("The system BCD store could not be opened."),
                CustomApply = () => { writes++; return true; }
            };
            var service = new TweakService(null, () => true);
            Assert.That(service.InspectWithError(tweak, out _, out var error), Is.EqualTo(TweakState.Unreadable));
            Assert.That(error, Does.Contain("BCD store"));
            var result = service.ApplyDetailed(tweak, new BackupSession());
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.Unavailable));
            Assert.That(result.Message, Does.Contain("BCD store").And.Contain("No change was attempted"));
            Assert.That(writes, Is.Zero);
        }

        [Test]
        public void APlatformRejectedWriteIsReportedAsFailure()
        {
            var tweak = new SystemTweak {
                Id = "fixture-rejected", Title = "Fixture boot setting", InspectCommandState = () => false,
                CustomApply = () => throw new InvalidOperationException("Secure Boot rejected this setting.")
            };
            var result = new TweakService(null, () => true).ApplyDetailed(tweak, new BackupSession());
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.Failed));
            Assert.That(result.Message, Does.Contain("Secure Boot rejected"));
        }

        [Test]
        public void ImportedCommandCardsInspectAutomatically()
        {
            foreach (var tweak in OptimizerImportCatalog.All)
                if (tweak.Id.StartsWith("bcd-", StringComparison.Ordinal))
                    Assert.That(tweak.InspectOnLoad && tweak.DeferInitialInspection, Is.True, tweak.Id);
        }
    }
}
