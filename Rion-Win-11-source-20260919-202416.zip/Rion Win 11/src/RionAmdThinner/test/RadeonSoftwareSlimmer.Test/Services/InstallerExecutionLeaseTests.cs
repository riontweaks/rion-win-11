using System;
using System.IO;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class InstallerExecutionLeaseTests
    {
        private string root;
        private string directory;
        private string executable;
        [SetUp] public void Setup()
        {
            root = Path.Combine(Path.GetTempPath(), "RionInstallerLease-" + Guid.NewGuid());
            directory = Path.Combine(root, "package");
            Directory.CreateDirectory(directory);
            executable = Path.Combine(directory, "setup.exe");
            File.WriteAllText(executable, "Inert trust fixture. Never execute.");
        }
        [TearDown] public void Cleanup() { if (Directory.Exists(root)) Directory.Delete(root, true); }

        [TestCase("Advanced Micro Devices")]
        [TestCase("Advanced Micro Devices, Inc.")]
        public void ExecutableAndAncestorsStayLockedDuringValidationAndUntilDisposal(string publisher)
        {
            bool inspected = false;
            var lease = InstallerExecutionLease.Acquire(executable, "AMD", path =>
            {
                Assert.That(path, Is.EqualTo(executable));
                Assert.Throws<IOException>(() => File.WriteAllText(path, "changed"));
                Assert.Throws<IOException>(() => Directory.Move(root, root + ".moved"));
                inspected = true;
                return new DriverInstallerInfo { SignatureStatus = SignatureStatus.Valid, Publisher = publisher };
            });
            using (lease)
            {
                Assert.That(inspected, Is.True);
                Assert.That(lease.ExecutablePath, Is.EqualTo(executable));
                Assert.Throws<IOException>(() => File.Delete(executable));
                Assert.Throws<IOException>(() => File.Move(executable, executable + ".moved"));
                Assert.Throws<IOException>(() => Directory.Move(directory, directory + ".moved"));
                Assert.That(File.ReadAllText(executable), Does.StartWith("Inert trust fixture"));
            }
            Assert.Throws<ObjectDisposedException>(() => { _ = lease.ExecutablePath; });
            File.WriteAllText(executable, "Released");
            Directory.Move(directory, directory + ".released");
        }

        [TestCase(SignatureStatus.Unsigned, "Advanced Micro Devices, Inc.")]
        [TestCase(SignatureStatus.Invalid, "Advanced Micro Devices, Inc.")]
        [TestCase(SignatureStatus.Error, "Advanced Micro Devices, Inc.")]
        [TestCase(SignatureStatus.ValidButNotAmd, "Unrelated trusted publisher")]
        public void RejectedIdentityReleasesEveryHandle(SignatureStatus status, string publisher)
        {
            Assert.Throws<InvalidDataException>(() => InstallerExecutionLease.Acquire(executable, "AMD", _ =>
                new DriverInstallerInfo { SignatureStatus = status, Publisher = publisher }));
            File.Delete(executable);
            Directory.Move(directory, directory + ".released");
        }

        [Test]
        public void PublicEntryPointRejectsRealUnsignedBytesWithoutLaunching()
        {
            Assert.Throws<InvalidDataException>(() => InstallerExecutionLease.Acquire(executable, "NVIDIA"));
            File.Delete(executable);
        }

        [Test]
        public void InspectorFailureReleasesEveryHandle()
        {
            Assert.Throws<InvalidOperationException>(() => InstallerExecutionLease.Acquire(executable, "AMD", _ => throw new InvalidOperationException("Injected verification error")));
            File.Delete(executable);
            Directory.Move(directory, directory + ".released");
        }

        [Test]
        public void RelativePathAndUnknownVendorAreRejected()
        {
            Assert.Throws<ArgumentException>(() => InstallerExecutionLease.Acquire("setup.exe", "AMD"));
            Assert.Throws<ArgumentException>(() => InstallerExecutionLease.Acquire(executable, "Unknown"));
        }
    }
}
