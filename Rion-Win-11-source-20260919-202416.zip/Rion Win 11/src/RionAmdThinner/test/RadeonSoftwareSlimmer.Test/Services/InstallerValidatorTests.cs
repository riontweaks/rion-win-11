using System;
using System.IO;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services;

public class InstallerValidatorTests
{
    [TestCase("https://amd.com/en/support", true)]
    [TestCase("https://drivers.amd.com/package.exe", true)]
    [TestCase("https://DRIVERS.AMD.COM/package.exe", true)]
    [TestCase("https://amd.com.evil.example/package.exe", false)]
    [TestCase("https://notamd.com/package.exe", false)]
    [TestCase("https://evil.example/amd.com/package.exe", false)]
    [TestCase("https://amd.com@evil.example/package.exe", false)]
    [TestCase("https://user@amd.com/package.exe", false)]
    [TestCase("http://drivers.amd.com/package.exe", false)]
    [TestCase("file:///C:/amd.com/package.exe", false)]
    [TestCase(null, false)]
    public void OfficialSourceRequiresHttpsAndAnActualAmdHost(string source, bool expected)
        => Assert.That(InstallerValidator.IsOfficialAmdUrl(source), Is.EqualTo(expected));

    [Test]
    public void RepeatedSignedFileChecksPreserveTrustResult()
    {
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "dotnet.exe");
        Assert.That(File.Exists(path), Is.True, "This Windows integration test requires the installed .NET host.");
        var validator = new InstallerValidator();
        for (int i = 0; i < 20; i++)
        {
            var result = validator.Inspect(path);
            Assert.That(result.SignatureStatus, Is.EqualTo(SignatureStatus.ValidButNotAmd));
            Assert.That(result.LooksTrusted, Is.False);
        }
    }

    [Test]
    public void OfficialUrlDoesNotMakeUnsignedBytesTrusted()
    {
        string path = Path.Combine(Path.GetTempPath(), "RionUnsigned-" + Guid.NewGuid() + ".exe");
        try
        {
            File.WriteAllBytes(path, new byte[2048]);
            var result = new InstallerValidator().Inspect(path, "https://drivers.amd.com/package.exe");
            Assert.That(result.IsOfficialAmdSource, Is.True);
            Assert.That(result.LooksTrusted, Is.False);
        }
        finally { File.Delete(path); }
    }
}
