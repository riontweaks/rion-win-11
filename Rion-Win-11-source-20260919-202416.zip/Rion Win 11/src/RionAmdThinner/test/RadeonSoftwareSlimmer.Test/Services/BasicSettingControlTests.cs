using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;

namespace RadeonSoftwareSlimmer.Test.Services
{
    [TestFixture]
    public sealed class BasicSettingControlTests
    {
        private string directory;
        private FakeProvider provider;
        private BasicSettingControl Control => new BasicSettingControl(provider, directory);

        [SetUp]
        public void Setup()
        {
            directory = Path.Combine(Path.GetTempPath(), "RionBasicFixture-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            provider = new FakeProvider();
        }

        [TearDown]
        public void Cleanup()
        {
            string resolved = Path.GetFullPath(directory);
            Assert.That(resolved.StartsWith(Path.GetFullPath(Path.GetTempPath()), StringComparison.OrdinalIgnoreCase)
                && Path.GetFileName(resolved).StartsWith("RionBasicFixture-", StringComparison.Ordinal), Is.True);
            Directory.Delete(resolved, true);
        }

        [TestCase(BasicSetting.MemoryCompression)]
        [TestCase(BasicSetting.TcpAutoTuning)]
        [TestCase(BasicSetting.TcpCongestion)]
        public void RestartAndRepeatedApplyPreserveExactBaseline(BasicSetting setting)
        {
            string before = provider.Values[setting];
            Control.Apply(setting);
            Assert.That(provider.Values[setting], Is.EqualTo(BasicSettingControl.Target(setting)));
            int writes = provider.Writes;
            Control.Apply(setting);
            Assert.That(provider.Writes, Is.EqualTo(writes));
            Control.Restore(setting);
            Assert.That(provider.Values[setting], Is.EqualTo(before));
            Assert.That(Control.HasSavedState(setting), Is.False);
        }

        [Test]
        public void AlreadyConfiguredDoesNotInventRecovery()
        {
            provider.Values[BasicSetting.TcpCongestion] = "cubic";
            Control.Apply(BasicSetting.TcpCongestion);
            Assert.That(provider.Writes, Is.Zero);
            Assert.That(Control.HasSavedState(BasicSetting.TcpCongestion), Is.False);
            Assert.Throws<InvalidOperationException>(() => Control.Restore(BasicSetting.TcpCongestion));
        }

        [Test]
        public void ExternalChangeBlocksApplyAndRestoreWithoutOverwriting()
        {
            Control.Apply(BasicSetting.TcpAutoTuning);
            provider.Values[BasicSetting.TcpAutoTuning] = "experimental";
            int writes = provider.Writes;
            Assert.Throws<InvalidOperationException>(() => Control.Restore(BasicSetting.TcpAutoTuning));
            Assert.Throws<InvalidOperationException>(() => Control.Apply(BasicSetting.TcpAutoTuning));
            Assert.That(provider.Writes, Is.EqualTo(writes));
            Assert.That(Control.HasSavedState(BasicSetting.TcpAutoTuning), Is.True);
        }

        [Test]
        public void UnavailableOrPolicyManagedStatePreventsWrites()
        {
            provider.Unavailable = "Managed by policy";
            Assert.Throws<InvalidOperationException>(() => Control.Apply(BasicSetting.TcpAutoTuning));
            Assert.That(provider.Writes, Is.Zero);
            Assert.That(Control.HasSavedState(BasicSetting.TcpAutoTuning), Is.False);
        }

        [Test]
        public void JournalFailurePreventsMutation()
        {
            string blocked = Path.Combine(directory, "file");
            File.WriteAllText(blocked, "fixture");
            Assert.Throws<IOException>(() => new BasicSettingControl(provider, blocked).Apply(BasicSetting.MemoryCompression));
            Assert.That(provider.Writes, Is.Zero);
        }

        [Test]
        public void SetterFailureKeepsRecoveryAndOriginalCanBeRetiredWithoutAWrite()
        {
            provider.FailWrite = true;
            Assert.Throws<IOException>(() => Control.Apply(BasicSetting.MemoryCompression));
            Assert.That(Control.HasSavedState(BasicSetting.MemoryCompression), Is.True);
            provider.FailWrite = false;
            int writes = provider.Writes;
            Control.Restore(BasicSetting.MemoryCompression);
            Assert.That(provider.Writes, Is.EqualTo(writes));
            Assert.That(Control.HasSavedState(BasicSetting.MemoryCompression), Is.False);
        }

        [Test]
        public void ReadbackFailureRetainsRecoveryForRetry()
        {
            provider.IgnoreWrite = true;
            Assert.Throws<IOException>(() => Control.Apply(BasicSetting.MemoryCompression));
            Assert.That(Control.HasSavedState(BasicSetting.MemoryCompression), Is.True);
            provider.IgnoreWrite = false;
            Control.Apply(BasicSetting.MemoryCompression);
            provider.IgnoreWrite = true;
            Assert.Throws<IOException>(() => Control.Restore(BasicSetting.MemoryCompression));
            Assert.That(Control.HasSavedState(BasicSetting.MemoryCompression), Is.True);
            provider.IgnoreWrite = false;
            Control.Restore(BasicSetting.MemoryCompression);
            Assert.That(provider.Values[BasicSetting.MemoryCompression], Is.EqualTo("enabled"));
        }

        [TestCase("{}")]
        [TestCase("broken JSON")]
        public void InvalidRecoveryIsPreservedAndNeverReplaced(string content)
        {
            File.WriteAllText(Path.Combine(directory, "MemoryCompression.json"), content);
            Assert.Throws<InvalidDataException>(() => Control.Apply(BasicSetting.MemoryCompression));
            Assert.Throws<InvalidDataException>(() => Control.Restore(BasicSetting.MemoryCompression));
            Assert.That(provider.Writes, Is.Zero);
            Assert.That(File.ReadAllText(Path.Combine(directory, "MemoryCompression.json")), Is.EqualTo(content));
        }

        [Test]
        public void RecoveryFromAnotherMachineIsRejected()
        {
            Control.Apply(BasicSetting.MemoryCompression);
            string file = Path.Combine(directory, "MemoryCompression.json");
            File.WriteAllText(file, File.ReadAllText(file).Replace(Environment.MachineName, "different-machine"));
            int writes = provider.Writes;
            Assert.Throws<InvalidDataException>(() => Control.Restore(BasicSetting.MemoryCompression));
            Assert.That(provider.Writes, Is.EqualTo(writes));
        }

        [Test]
        public void StateChangedDuringPreparationIsNotWritten()
        {
            provider.OnRead = count => { if (count == 2) provider.Values[BasicSetting.TcpAutoTuning] = "experimental"; };
            Assert.Throws<InvalidOperationException>(() => Control.Apply(BasicSetting.TcpAutoTuning));
            Assert.That(provider.Writes, Is.Zero);
            Assert.That(Control.HasSavedState(BasicSetting.TcpAutoTuning), Is.True);
        }

        [Test]
        public void JournalExistsBeforeFirstSetterCall()
        {
            provider.OnWrite = () => Assert.That(Control.HasSavedState(BasicSetting.MemoryCompression), Is.True);
            Control.Apply(BasicSetting.MemoryCompression);
        }

        [Test]
        public void WriteCommandsRejectUnknownOrInjectedPersistedValues()
        {
            Assert.Throws<ArgumentException>(() => WindowsBasicSettingProvider.WriteScript(BasicSetting.TcpCongestion, "cubic; whoami"));
            Assert.Throws<ArgumentException>(() => WindowsBasicSettingProvider.WriteScript(BasicSetting.MemoryCompression, "false"));
            Assert.That(WindowsBasicSettingProvider.WriteScript(BasicSetting.TcpAutoTuning, "normal"), Does.Contain("-SettingName Internet"));
            Assert.That(WindowsBasicSettingProvider.WriteScript(BasicSetting.TcpCongestion, "cubic"), Does.Contain("template=internet"));
        }

        [Test]
        public void DiagnosticRegistryControlIsOptionalAndUnique()
        {
            var item = BasicTweakCatalog.All.Single(t => t.Id == "verbose-status");
            Assert.That(item.Id, Is.EqualTo("verbose-status"));
            Assert.That(item.ValueName, Is.EqualTo("VerboseStatus"));
            Assert.That(item.ManualOnly && item.IndividualApplyOnly, Is.True);
            Assert.That(GeneralTweakCatalog.All.Count(t => t.Id == item.Id), Is.EqualTo(1));
            Assert.That(GeneralTweakCatalog.IsRecommended(item), Is.False);
        }

        [Test]
        public void StandardToggleCardsInspectApplyAndRestoreTheirSavedState()
        {
            var cards = BasicTweakCatalog.Create(Control).Where(t => t.IsCustom).ToList();
            Assert.That(cards.Count, Is.EqualTo(3));
            foreach (var card in cards)
            {
                Assert.That(card.IsAdjustable, Is.False);
                Assert.That(card.ManualOnly && card.IndividualApplyOnly && card.DeferInitialInspection && card.InspectOnLoad, Is.True);
                Assert.That(card.InspectCommandState(), Is.False);
                Assert.That(card.CustomApply(), Is.True);
                Assert.That(card.InspectCommandState(), Is.True);
                Assert.That(card.HasSavedState(), Is.True);
                Assert.That(card.CustomRevert(), Is.True);
                Assert.That(card.InspectCommandState(), Is.False);
                Assert.That(card.HasSavedState(), Is.False);
            }
        }

        private sealed class FakeProvider : IBasicSettingProvider
        {
            internal readonly Dictionary<BasicSetting, string> Values = new()
            {
                [BasicSetting.MemoryCompression] = "enabled", [BasicSetting.TcpAutoTuning] = "restricted",
                [BasicSetting.TcpCongestion] = "ctcp"
            };
            internal int Writes;
            internal bool FailWrite;
            internal bool IgnoreWrite;
            internal string Unavailable;
            internal Action<int> OnRead;
            internal Action OnWrite;
            private int reads;
            public BasicSettingState Read(BasicSetting setting) { OnRead?.Invoke(++reads); return new(Values[setting], Unavailable); }
            public void Write(BasicSetting setting, string value)
            {
                OnWrite?.Invoke();
                Writes++;
                if (FailWrite) throw new IOException("Injected setter failure");
                if (!IgnoreWrite) Values[setting] = value;
            }
        }
    }
}
