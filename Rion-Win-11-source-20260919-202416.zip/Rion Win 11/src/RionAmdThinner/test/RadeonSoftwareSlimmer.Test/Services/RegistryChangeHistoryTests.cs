using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using Newtonsoft.Json;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class RegistryChangeHistoryTests
    {
        private string directory;
        [SetUp] public void Setup() { directory = Path.Combine(Path.GetTempPath(), "RionHistory-" + Guid.NewGuid()); Directory.CreateDirectory(directory); }
        [TearDown] public void Cleanup() => Directory.Delete(directory, true);

        private static SystemTweak Fixture() => new SystemTweak { Id = "fixture", Title = "Fixture", KeyPath = "TestOnly", ValueName = "x", TargetValue = 23 };

        [Test] public void QualityOfLifeRoundTripsAbsentAndNonDefaultValues()
        {
            foreach (var tweak in QualityOfLifeCatalog.Create("Professional", 26200, 5000))
            foreach (bool absent in new[] { true, false })
            {
                var registry = new MemoryRegistry();
                if (!absent) registry.Values[tweak.ValueName] = (new byte[] { 19, 8, 3 }, RegistryValueKind.Binary);
                var service = new TweakService(registry, () => true);
                string history = Path.Combine(directory, tweak.Id + absent);
                Assert.That(service.ApplyDetailed(tweak, new BackupSession(history)).Success, Is.True, tweak.Id);
                string root = tweak.Hive == TweakHive.CurrentUser ? "HKCU" : "HKLM";
                Assert.That(RegistryChangeHistory.RestoreLatest(root + "\\" + tweak.KeyPath + "\\" + tweak.ValueName, registry, history).Success, Is.True, tweak.Id);
                Assert.That(registry.Values.ContainsKey(tweak.ValueName), Is.EqualTo(!absent), tweak.Id);
                if (!absent) { Assert.That(registry.Values[tweak.ValueName].kind, Is.EqualTo(RegistryValueKind.Binary)); Assert.That(registry.Values[tweak.ValueName].value, Is.EqualTo(new byte[] { 19, 8, 3 })); }
            }
        }
        [Test] public void QualityOfLifeGatesUnsupportedPoliciesAndPreservesSnippingTool()
        {
            var home = QualityOfLifeCatalog.Create("Core", 26100, 4000);
            Assert.That(home.Single(t => t.Id == "qol-onedrive").ApplyBlockedReason, Is.Not.Null);
            Assert.That(home.Single(t => t.Id == "qol-search-hidden").ApplyBlockedReason, Is.Null);
            Assert.That(QualityOfLifeCatalog.Create("Professional", 26100, 3900).Single(t => t.Id == "qol-recall").ApplyBlockedReason, Is.Not.Null);
            Assert.That(QualityOfLifeCatalog.Create("Professional", 26100, 3915).Single(t => t.Id == "qol-recall").IndividualApplyOnly, Is.True);
            Assert.That(home.All(t => !t.IsCustom && !t.IsCommandBased && !t.KeyPath.Contains("ScreenSketch")), Is.True);
            Assert.That(TweakBundleCatalog.MissingIds, Is.Empty);
            Assert.That(TweakBundleCatalog.Unassigned, Is.Empty);
        }

        [Test] public void GroupCompletesBothValuesAndPreservesAlreadyAppliedMembers()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = (23, RegistryValueKind.DWord);
            var second = Fixture(); second.Id = "second"; second.ValueName = "y";
            var result = new TweakService(registry, () => true).RunGroup(new[] { Fixture(), second }, true, directory);
            Assert.That(result.All(r => r.Success), Is.True);
            Assert.That(registry.Values["x"].value, Is.EqualTo(23));
            Assert.That(registry.Values["y"].value, Is.EqualTo(23));
            Assert.That(registry.Writes, Is.EqualTo(1));
        }

        [Test] public void GroupFailureRestoresEarlierWriteToExactOriginalType()
        {
            var registry = new MemoryRegistry { FailValue = "y" };
            registry.Values["x"] = (new byte[] { 4, 9 }, RegistryValueKind.Binary);
            var second = Fixture(); second.Id = "second"; second.ValueName = "y";
            var result = new TweakService(registry, () => true).RunGroup(new[] { Fixture(), second }, true, directory);
            Assert.That(result.Any(r => !r.Success), Is.True);
            Assert.That(registry.Values["x"].value, Is.EqualTo(new byte[] { 4, 9 }));
            Assert.That(registry.Values["x"].kind, Is.EqualTo(RegistryValueKind.Binary));
            Assert.That(registry.Values.ContainsKey("y"), Is.False);
        }

        [Test] public void GroupPreflightFailureMakesNoWrites()
        {
            var registry = new MemoryRegistry();
            var second = Fixture(); second.Id = "second"; second.ApplyBlockedReason = "Unsupported fixture";
            var result = new TweakService(registry, () => true).RunGroup(new[] { Fixture(), second }, true, directory);
            Assert.That(result.All(r => !r.Success), Is.True);
            Assert.That(registry.Writes, Is.Zero);
        }

        [Test]
        public void EveryImportedRegistryOperationRoundTripsExactOriginalTypes()
        {
            foreach (var tweak in OptimizerImportCatalog.All.Where(t => !t.IsCustom))
            {
                var registry = new MemoryRegistry();
                registry.Values[tweak.ValueName] = (new byte[] { 0, 255, 17 }, RegistryValueKind.Binary);
                var service = new TweakService(registry, () => true);
                string history = Path.Combine(directory, tweak.Id);
                var historical = new SystemTweak { Id = tweak.Id, Title = tweak.Title,
                    Hive = tweak.Hive, KeyPath = tweak.KeyPath, ValueName = tweak.ValueName,
                    ValueKind = tweak.ValueKind, TargetValue = tweak.TargetValue };
                if (!string.IsNullOrEmpty(tweak.ApplyBlockedReason))
                {
                    Assert.That(service.ApplyDetailed(tweak, new BackupSession(history)).Status,
                        Is.EqualTo(TweakOperationStatus.Unsupported), tweak.Id);
                    Assert.That(registry.Writes, Is.Zero, "Retired preset must not write");
                }
                // Seed a historical version's record through the fake registry, then verify exact recovery.
                var first = service.ApplyDetailed(historical, new BackupSession(history));
                Assert.That(first.Status, Is.EqualTo(TweakOperationStatus.Applied), tweak.Id + ": " + first.Message);
                Assert.That(service.Inspect(tweak, out _), Is.EqualTo(TweakState.AtTarget), tweak.Id);
                Assert.That(service.ApplyDetailed(historical, new BackupSession(history)).Status, Is.EqualTo(TweakOperationStatus.AlreadyConfigured), tweak.Id);
                Assert.That(registry.Writes, Is.EqualTo(1), tweak.Id);
                Assert.That(RegistryChangeHistory.RestoreLatest("HKLM\\" + tweak.KeyPath + "\\" + tweak.ValueName, registry, history).Success, Is.True, tweak.Id);
                Assert.That(registry.Values[tweak.ValueName].kind, Is.EqualTo(RegistryValueKind.Binary), tweak.Id);
                Assert.That(registry.Values[tweak.ValueName].value, Is.EqualTo(new byte[] { 0, 255, 17 }), tweak.Id);
            }
        }

        [Test]
        public void DeletingAnAbsentOverrideIsAnHonestNoOp()
        {
            var registry = new MemoryRegistry();
            var tweak = Fixture();
            tweak.DeleteRegistryValue = true;
            var result = new TweakService(registry, () => true).ApplyDetailed(tweak, new BackupSession(directory));
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.AlreadyConfigured));
            Assert.That(registry.Writes, Is.Zero);
            Assert.That(RegistryChangeHistory.ListEntries(directory), Is.Empty);
        }

        [Test] public void ApplyResultsDistinguishChangesFromNoOpsAndPreserveOriginal()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = (17, RegistryValueKind.DWord);
            var service = new TweakService(registry, () => true);
            var changed = service.ApplyDetailed(Fixture(), new BackupSession(directory));
            var unchanged = service.ApplyDetailed(Fixture(), new BackupSession(directory));
            Assert.That(changed.Status, Is.EqualTo(TweakOperationStatus.Applied));
            Assert.That(changed.PreviousValue, Is.EqualTo("17"));
            Assert.That(unchanged.Status, Is.EqualTo(TweakOperationStatus.AlreadyConfigured));
            Assert.That(registry.Writes, Is.EqualTo(1));
            Assert.That(RegistryChangeHistory.ListEntries(directory), Has.Count.EqualTo(1));
            Assert.That(RegistryChangeHistory.RestoreLatest(@"HKLM\TestOnly\x", registry, directory).Success, Is.True);
            Assert.That(registry.Values["x"].value, Is.EqualTo(17));
        }

        [Test] public void ApplyResultsNeverCountDeniedOrRetiredOperationsAsChanges()
        {
            var registry = new MemoryRegistry();
            var denied = new TweakService(registry, () => false).ApplyDetailed(Fixture(), new BackupSession(directory));
            var retired = Fixture(); retired.ApplyBlockedReason = "Retired";
            var blocked = new TweakService(registry, () => true).ApplyDetailed(retired, new BackupSession(directory));
            Assert.That(denied.Status, Is.EqualTo(TweakOperationStatus.Unavailable));
            Assert.That(blocked.Status, Is.EqualTo(TweakOperationStatus.Unsupported));
            Assert.That(registry.Writes, Is.Zero);
            Assert.That(TweakOperationResult.Summarize(new[] { denied, blocked }), Does.Contain("0 changed"));
        }

        [Test] public void ThrowingInspectionIsUnavailableAndCannotCallCustomApply()
        {
            var tweak = Fixture(); int calls = 0;
            tweak.CustomApply = () => { calls++; return true; };
            tweak.InspectCommandState = () => throw new IOException("probe failed");
            var result = new TweakService(new MemoryRegistry(), () => true).ApplyDetailed(tweak, new BackupSession(directory));
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.Unavailable));
            Assert.That(calls, Is.Zero);
        }

        [Test] public void FailedReadbackIsNotReportedAsApplied()
        {
            var registry = new MemoryRegistry { IgnoreWrites = true };
            var result = new TweakService(registry, () => true).ApplyDetailed(Fixture(), new BackupSession(directory));
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.Failed));
            Assert.That(RegistryChangeHistory.ListEntries(directory), Has.Count.EqualTo(1));
            Assert.That(TweakOperationResult.Summarize(new[] { result }), Does.Contain("1 failed"));
        }

        [Test] public void AdjustedPresetCannotReportSuccessWithoutPrivilege()
        {
            var registry = new MemoryRegistry();
            Assert.Throws<InvalidOperationException>(() => new TweakService(registry, () => false).ApplyValue(Fixture(), 7, new BackupSession(directory)));
            Assert.That(registry.Writes, Is.Zero);
        }

        [Test] public void AdjustedPresetVerifiesItsOwnValueAndHighDwords()
        {
            var registry = new MemoryRegistry(); var service = new TweakService(registry, () => true);
            Assert.That(service.ApplyValue(Fixture(), 0xFFFFFFFF, new BackupSession(directory)), Is.True);
            Assert.That(service.ApplyValue(Fixture(), 0xFFFFFFFF, new BackupSession(directory)), Is.False);
            Assert.That(registry.Values["x"].value, Is.EqualTo(-1));
            Assert.That(registry.Writes, Is.EqualTo(1));
        }

        [Test] public void MissingHistoryNeverSubstitutesDefaultAndConflictNeverOverwrites()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = (17, RegistryValueKind.DWord);
            Assert.That(RegistryChangeHistory.RestoreLatest(@"HKLM\TestOnly\x", registry, directory).Success, Is.False);
            Assert.That(registry.Writes, Is.Zero);
            new BackupSession(directory).WriteRegistry(registry, @"HKLM\TestOnly", "x", true, 23, RegistryValueKind.DWord);
            registry.Values["x"] = (99, RegistryValueKind.DWord);
            int writes = registry.Writes;
            Assert.That(RegistryChangeHistory.RestoreLatest(@"HKLM\TestOnly\x", registry, directory).Success, Is.False);
            Assert.That(registry.Writes, Is.EqualTo(writes));
            Assert.That(registry.Values["x"].value, Is.EqualTo(99));
        }

        [TestCase(RegistryValueKind.String)]
        [TestCase(RegistryValueKind.QWord)]
        public void NumericMatchWithWrongTypeIsCorrectedAndOriginalTypeCanBeRestored(RegistryValueKind kind)
        {
            var registry = new MemoryRegistry();
            object original = kind == RegistryValueKind.String ? "23" : (object)23L;
            registry.Values["x"] = (original, kind);
            var service = new TweakService(registry, () => true);
            Assert.That(service.Inspect(Fixture(), out var current), Is.EqualTo(TweakState.NeedsApply));
            Assert.That(current, Is.EqualTo(23));
            var result = service.ApplyDetailed(Fixture(), new BackupSession(directory));
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.Applied));
            Assert.That(registry.Values["x"], Is.EqualTo(((object)23, RegistryValueKind.DWord)));
            Assert.That(service.Inspect(Fixture(), out _), Is.EqualTo(TweakState.AtTarget));
            Assert.That(RegistryChangeHistory.RestoreLatest(@"HKLM\TestOnly\x", registry, directory).Success, Is.True);
            Assert.That(registry.Values["x"], Is.EqualTo((original, kind)));
        }

        [Test]
        public void AdjustableTargetCorrectsWrongTypeAndThenSkipsTheSameTypedValue()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = ("7", RegistryValueKind.String);
            var service = new TweakService(registry, () => true);
            Assert.That(service.ApplyValue(Fixture(), 7, new BackupSession(directory)), Is.True);
            Assert.That(service.ApplyValue(Fixture(), 7, new BackupSession(directory)), Is.False);
            Assert.That(registry.Writes, Is.EqualTo(1));
            Assert.That(registry.Values["x"], Is.EqualTo(((object)7, RegistryValueKind.DWord)));
        }

        [Test]
        public void ReadbackWithRequestedNumberButWrongTypeIsAFailure()
        {
            var registry = new MemoryRegistry { WrittenKind = RegistryValueKind.QWord };
            var result = new TweakService(registry, () => true).ApplyDetailed(Fixture(), new BackupSession(directory));
            Assert.That(result.Status, Is.EqualTo(TweakOperationStatus.Failed));
            Assert.That(RegistryChangeHistory.ListEntries(directory).Single().Status, Is.EqualTo("Failed"));
        }

        private sealed class MemoryRegistry : IRegistry, IRegistryKey
        {
            public IRegistryKey CurrentUser => this;
            public IRegistryKey LocalMachine => this;
            public string Name => "TestOnly";
            public readonly Dictionary<string, (object value, RegistryValueKind kind)> Values = new();
            public int Writes;
            public bool ThrowWrites;
            public bool IgnoreWrites;
            public string FailValue;
            public RegistryValueKind? WrittenKind;
            public Action BeforeRead;
            public IRegistryKey OpenSubKey(string name, bool writable) => this;
            public IRegistryKey CreateSubKey(string name) => this;
            public string[] GetSubKeyNames() => Array.Empty<string>();
            public string[] GetValueNames() { BeforeRead?.Invoke(); return Values.Keys.ToArray(); }
            public object GetValue(string name) => GetValue(name, null);
            public object GetValue(string name, object fallback) => Values.TryGetValue(name, out var entry) ? entry.value : fallback;
            public RegistryValueKind GetValueKind(string name) => Values[name].kind;
            public void SetValue(string name, object value, RegistryValueKind kind) { if (ThrowWrites || name == FailValue) throw new IOException("injected write failure"); Writes++; if (!IgnoreWrites) Values[name] = (value, WrittenKind ?? kind); }
            public void DeleteValue(string name, bool throwing) { if (ThrowWrites) throw new IOException("injected write failure"); Writes++; if (!IgnoreWrites) Values.Remove(name); }
            public void Dispose() { }
        }

        [Test]
        public void ExactTypedOriginalsSurviveDiskAndRestore()
        {
            var fixtures = new (object value, RegistryValueKind kind)[] {
                (-1, RegistryValueKind.DWord), (long.MinValue, RegistryValueKind.QWord),
                (new byte[] { 0, 255, 1 }, RegistryValueKind.Binary), (new byte[] { 3, 4 }, RegistryValueKind.None),
                (new[] { "one", "", "two" }, RegistryValueKind.MultiString), ("", RegistryValueKind.String),
                (@"%USERPROFILE%\raw", RegistryValueKind.ExpandString)
            };
            var registry = new MemoryRegistry();
            var backup = new BackupSession(directory) { Description = "typed fixture" };
            for (int i = 0; i < fixtures.Length; i++)
            {
                string name = "v" + i;
                registry.Values[name] = fixtures[i];
                backup.WriteRegistry(registry, @"HKCU\TestOnly", name, true, 7, RegistryValueKind.DWord);
            }
            foreach (var entry in RegistryChangeHistory.ListEntries(directory))
            {
                Assert.That(entry.CanRestore, Is.True);
                Assert.That(RegistryChangeHistory.Restore(entry.Id, registry, directory).Success, Is.True);
            }
            for (int i = 0; i < fixtures.Length; i++)
            {
                Assert.That(registry.Values["v" + i].kind, Is.EqualTo(fixtures[i].kind));
                Assert.That(registry.Values["v" + i].value, Is.EqualTo(fixtures[i].value));
            }
            Assert.That(RegistryChangeHistory.ListEntries(directory).All(e => e.Status == "Restored" && !e.CanRestore), Is.True);
        }

        [Test]
        public void RepeatedWritePreservesOriginalBaselineAndAbsence()
        {
            var registry = new MemoryRegistry(); var backup = new BackupSession(directory);
            backup.WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 10, RegistryValueKind.DWord);
            backup.WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 20, RegistryValueKind.DWord);
            var entry = RegistryChangeHistory.ListEntries(directory).Single();
            Assert.That(entry.PreviousValue, Is.EqualTo("(absent)"));
            Assert.That(entry.RequestedValue, Does.Contain("20"));
            Assert.That(RegistryChangeHistory.Restore(entry.Id, registry, directory).Success, Is.True);
            Assert.That(registry.Values.ContainsKey("x"), Is.False);
        }

        [Test]
        public void ExternalChangeIsNotOverwrittenAndConflictIsDurable()
        {
            var registry = new MemoryRegistry(); var backup = new BackupSession(directory);
            registry.Values["x"] = (17, RegistryValueKind.DWord);
            backup.WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord);
            registry.Values["x"] = (23L, RegistryValueKind.QWord); // same number, different exact type
            int writes = registry.Writes;
            var entry = RegistryChangeHistory.ListEntries(directory).Single();
            Assert.That(RegistryChangeHistory.Restore(entry.Id, registry, directory).Success, Is.False);
            Assert.That(registry.Writes, Is.EqualTo(writes));
            Assert.That(RegistryChangeHistory.ListEntries(directory).Single().Status, Is.EqualTo("Conflict"));
        }

        [Test]
        public void FailedWriteAndFailedReadbackRemainVisible()
        {
            foreach (bool throwWrites in new[] { true, false })
            {
                var registry = new MemoryRegistry { ThrowWrites = throwWrites, IgnoreWrites = !throwWrites };
                var backup = new BackupSession(directory);
                Assert.Throws<IOException>(() => backup.WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord));
            }
            Assert.That(RegistryChangeHistory.ListEntries(directory).All(e => e.Status == "Failed" && !e.CanRestore && !string.IsNullOrEmpty(e.Error)), Is.True);
        }

        [Test]
        public void ExternalChangeDuringPreparationBlocksWrite()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = (17, RegistryValueKind.DWord);
            int reads = 0;
            registry.BeforeRead = () => { if (++reads == 2) registry.Values["x"] = (99, RegistryValueKind.DWord); };
            Assert.Throws<IOException>(() => new BackupSession(directory).WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord));
            Assert.That(registry.Writes, Is.Zero);
            Assert.That(registry.Values["x"].value, Is.EqualTo(99));
            Assert.That(RegistryChangeHistory.ListEntries(directory).Single().Status, Is.EqualTo("Failed"));
        }
        [Test]
        public void PersistenceFailureBlocksMutation()
        {
            string blocked = Path.Combine(directory, "file"); File.WriteAllText(blocked, "blocked");
            var registry = new MemoryRegistry();
            Assert.Throws<IOException>(() => new BackupSession(blocked).WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord));
            Assert.That(registry.Writes, Is.Zero);
        }

        [Test]
        public void LegacyAndCorruptDocumentsRemainVisibleWithoutRestore()
        {
            File.WriteAllText(Path.Combine(directory, "legacy.json"), JsonConvert.SerializeObject(new BackupDocument {
                Entries = new List<BackupEntry> { new BackupEntry { Kind = BackupEntryKind.Registry, Target = @"HKCU\TestOnly", Detail = "x", PreviousData = "17" } }
            }));
            File.WriteAllText(Path.Combine(directory, "corrupt.json"), "{broken");
            var entries = RegistryChangeHistory.ListEntries(directory);
            Assert.That(entries.Count, Is.EqualTo(2));
            Assert.That(entries.All(e => !e.CanRestore), Is.True);
            var registry = new MemoryRegistry();
            Assert.That(RegistryChangeHistory.Restore("legacy.json:0", registry, directory).Success, Is.False);
            Assert.That(RegistryChangeHistory.Restore("../legacy.json:0", registry, directory).Success, Is.False);
            Assert.That(registry.Writes, Is.Zero);
        }

        [Test]
        public void ExistingLegacyRestoreRetainsSupportedValuesWhileHistoryStaysInspectOnly()
        {
            var doc = new BackupDocument { Entries = new List<BackupEntry> {
                new BackupEntry { Kind = BackupEntryKind.Registry, Target = @"HKCU\TestOnly", Detail = "dword", Existed = true, PreviousValueKind = (int)RegistryValueKind.DWord, PreviousData = "4294967295" },
                new BackupEntry { Kind = BackupEntryKind.Registry, Target = @"HKCU\TestOnly", Detail = "text", Existed = true, PreviousValueKind = (int)RegistryValueKind.ExpandString, PreviousData = @"%USERPROFILE%\original" },
                new BackupEntry { Kind = BackupEntryKind.Registry, Target = @"HKCU\TestOnly", Detail = "bytes", Existed = true, PreviousValueKind = (int)RegistryValueKind.Binary, PreviousData = "base64:AP8=" },
                new BackupEntry { Kind = BackupEntryKind.Registry, Target = @"HKCU\TestOnly", Detail = "missing", Existed = false }
            }};
            File.WriteAllText(Path.Combine(directory, "legacy.json"), JsonConvert.SerializeObject(doc));
            var registry = new MemoryRegistry(); registry.Values["missing"] = (1, RegistryValueKind.DWord);
            Assert.That(RegistryChangeHistory.ListEntries(directory, registry).All(e => !e.CanRestore), Is.True);
            Assert.That(BackupStore.RevertLatestRegistry(registry, directory), Is.EqualTo(4));
            Assert.That(registry.Values["dword"].value, Is.EqualTo(-1));
            Assert.That(registry.Values["text"].value, Is.EqualTo(@"%USERPROFILE%\original"));
            Assert.That(registry.Values["bytes"].value, Is.EqualTo(new byte[] { 0, 255 }));
            Assert.That(registry.Values.ContainsKey("missing"), Is.False);
        }
        [Test]
        public void WrongScopeCannotRestore()
        {
            var registry = new MemoryRegistry(); var backup = new BackupSession(directory);
            backup.WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord);
            string path = Directory.GetFiles(directory, "*.json").Single();
            var doc = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(path)); doc.Machine = "another-machine";
            File.WriteAllText(path, JsonConvert.SerializeObject(doc));
            var entry = RegistryChangeHistory.ListEntries(directory).Single();
            Assert.That(entry.CanRestore, Is.False);
            Assert.That(RegistryChangeHistory.Restore(entry.Id, registry, directory).Success, Is.False);
        }

        [Test]
        public void RestartAfterWriteBeforeOutcomePersistCanRecoverRequestedState()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = (17, RegistryValueKind.DWord);
            new BackupSession(directory).WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord);
            string path = Directory.GetFiles(directory, "*.json").Single();
            var doc = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(path));
            doc.Entries[0].HistoryStatus = "Pending"; doc.Entries[0].Verified = null;
            File.WriteAllText(path, JsonConvert.SerializeObject(doc));
            var entry = RegistryChangeHistory.ListEntries(directory, registry).Single();
            Assert.That(entry.CanRestore, Is.True);
            Assert.That(entry.Status, Is.EqualTo("Recovery available — interrupted/unconfirmed"));
            Assert.That(RegistryChangeHistory.Restore(entry.Id, registry, directory).Success, Is.True);
            Assert.That(registry.Values["x"].value, Is.EqualTo(17));
        }
        [Test]
        public void InterruptedRestoreCanBeVerifiedWithoutWritingAgain()
        {
            var registry = new MemoryRegistry(); registry.Values["x"] = (17, RegistryValueKind.DWord);
            new BackupSession(directory).WriteRegistry(registry, @"HKCU\TestOnly", "x", true, 23, RegistryValueKind.DWord);
            string path = Directory.GetFiles(directory, "*.json").Single();
            var doc = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(path)); doc.Entries[0].HistoryStatus = "Restoring";
            File.WriteAllText(path, JsonConvert.SerializeObject(doc)); registry.Values["x"] = (17, RegistryValueKind.DWord);
            int writes = registry.Writes;
            Assert.That(RegistryChangeHistory.Restore(Path.GetFileName(path) + ":0", registry, directory).Success, Is.True);
            Assert.That(registry.Writes, Is.EqualTo(writes));
            Assert.That(RegistryChangeHistory.ListEntries(directory).Single().Status, Is.EqualTo("Restored"));
        }
    }
}



