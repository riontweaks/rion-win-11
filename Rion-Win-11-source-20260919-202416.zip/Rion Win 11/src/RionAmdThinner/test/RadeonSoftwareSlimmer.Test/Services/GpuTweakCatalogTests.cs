using System.Linq;
using Microsoft.Win32;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class GpuTweakCatalogTests
    {
        [Test]
        public void All_HasEntries()
        {
            Assert.That(GpuTweakCatalog.All, Is.Not.Empty);
        }

        [Test]
        public void All_IdsAreUnique()
        {
            var ids = GpuTweakCatalog.All.Select(t => t.Id).ToList();
            Assert.That(ids, Is.Unique);
        }

        [Test]
        public void All_EveryEntryIsDocumentedAndReversible()
        {
            foreach (GpuTweak tweak in GpuTweakCatalog.All)
            {
                Assert.Multiple(() =>
                {
                    Assert.That(tweak.Id, Is.Not.Null.And.Not.Empty, "Id");
                    Assert.That(tweak.Title, Is.Not.Null.And.Not.Empty, tweak.Id + " Title");
                    Assert.That(tweak.Summary, Is.Not.Null.And.Not.Empty, tweak.Id + " Summary");
                    Assert.That(tweak.TradeOff, Is.Not.Null.And.Not.Empty, tweak.Id + " TradeOff");
                    Assert.That(tweak.SourceNote, Is.Not.Null.And.Not.Empty, tweak.Id + " SourceNote");
                    Assert.That(tweak.ValueName, Is.Not.Null.And.Not.Empty, tweak.Id + " ValueName");
                });
            }
        }

        [Test]
        public void All_ValueKindsAreNumeric()
        {
            foreach (GpuTweak tweak in GpuTweakCatalog.All)
            {
                Assert.That(tweak.ValueKind,
                    Is.EqualTo(RegistryValueKind.DWord).Or.EqualTo(RegistryValueKind.QWord),
                    tweak.Id + " should be a numeric registry value");
            }
        }

        [Test]
        public void All_AreOptIn_NothingRecommendedByDefault()
        {
            // After the OverlayTestMode incident: no GPU registry tweak is auto-checked.
            Assert.That(GpuTweakCatalog.All.Any(t => t.RecommendedDefault), Is.False);
        }

        [Test]
        public void MpoTweak_IsOptInAndCarriesAnArtifactWarning()
        {
            GpuTweak mpo = GpuTweakCatalog.All.FirstOrDefault(t =>
                string.Equals(t.ValueName, "OverlayTestMode", System.StringComparison.OrdinalIgnoreCase));

            Assume.That(mpo, Is.Not.Null, "MPO tweak present");
            Assert.Multiple(() =>
            {
                Assert.That(mpo.RecommendedDefault, Is.False, "MPO must never be auto-checked");
                Assert.That(mpo.TradeOff.ToLowerInvariant(), Does.Contain("artifact").Or.Contain("banding"),
                    "MPO trade-off must warn about display artifacts");
            });
        }

        [Test]
        public void All_HasHagsAndPowerThrottlingAndTelemetry()
        {
            var ids = GpuTweakCatalog.All.Select(t => t.Id).ToList();
            Assert.That(ids, Does.Contain("enable-hags")
                .And.Contains("disable-power-throttling")
                .And.Contains("amd-telemetry-off"));
        }

        [Test]
        public void EvidenceGradeLabel_MatchesGrade()
        {
            var a = new GpuTweak { EvidenceGrade = EvidenceGrade.A_Official };
            var c = new GpuTweak { EvidenceGrade = EvidenceGrade.C_CommunityInformed };
            Assert.Multiple(() =>
            {
                Assert.That(a.EvidenceGradeLabel, Does.StartWith("A"));
                Assert.That(c.EvidenceGradeLabel, Does.StartWith("C"));
            });
        }
    }
}
