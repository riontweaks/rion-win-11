using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.Win32;
using Newtonsoft.Json;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Optimize;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class BackupSessionDurabilityTests
    {
        private string directory;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "RionBackupTests-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
        }

        [TearDown]
        public void TearDown()
        {
            // Only the unique directory created by this test is removed.
            Directory.Delete(directory, recursive: true);
        }

        [Test]
        public void RepeatedCheckpointKeepsOriginalValuesInOneReadableSnapshot()
        {
            var session = new BackupSession(directory) { Description = "test only" };
            session.CaptureRegistry(@"HKCU\TestOnly", "First", true, 17, RegistryValueKind.DWord);
            string firstPath = session.Save();
            var first = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(firstPath));
            Assert.That(first.Entries.Single().PreviousData, Is.EqualTo("17"));

            session.CaptureRegistry(@"HKCU\TestOnly", "Second", false, null, RegistryValueKind.DWord);
            string secondPath = session.Save();
            var second = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(secondPath));
            Assert.That(secondPath, Is.EqualTo(firstPath));
            Assert.That(second.Entries.Count, Is.EqualTo(2));
            Assert.That(second.Entries[0].PreviousData, Is.EqualTo("17"));
            Assert.That(second.Entries[1].Existed, Is.False);
            Assert.That(Directory.GetFiles(directory), Has.Length.EqualTo(1));
        }

        [Test]
        public void FailedReplacementLeavesPreviousSnapshotReadable()
        {
            var session = new BackupSession(directory);
            session.CaptureRegistry(@"HKCU\TestOnly", "First", true, 17, RegistryValueKind.DWord);
            string path = session.Save();
            string original = File.ReadAllText(path);
            session.CaptureRegistry(@"HKCU\TestOnly", "Second", true, 23, RegistryValueKind.DWord);
            using (var locked = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                Assert.That(() => session.Save(), Throws.InstanceOf<IOException>().Or.InstanceOf<UnauthorizedAccessException>());
            Assert.That(File.ReadAllText(path), Is.EqualTo(original));

            Assert.That(session.Save(), Is.EqualTo(path));
            var recovered = JsonConvert.DeserializeObject<BackupDocument>(File.ReadAllText(path));
            Assert.That(recovered.Entries.Count, Is.EqualTo(2));
            Assert.That(File.Exists(path + ".tmp"), Is.False);
        }

        [Test]
        public void EmptyCheckpointDoesNotCreateASnapshot()
        {
            Assert.That(new BackupSession(directory).Save(), Is.Null);
            Assert.That(Directory.GetFiles(directory), Is.Empty);
        }

        [Test]
        public void TweakMutationIsBlockedWhenBackupDirectoryCannotBeCreated()
        {
            string blockedPath = Path.Combine(directory, "a-file-not-a-directory");
            File.WriteAllText(blockedPath, "test");
            var registry = new FakeRegistry();
            var service = new TweakService(registry);
            var tweak = new SystemTweak { Id = "test", KeyPath = "TestOnly", ValueName = "Value", ValueKind = RegistryValueKind.DWord };
            // Call the mutation core to avoid the OS elevation guard; only this in-memory
            // registry is supplied. Failure occurs before logging or any platform calls.
            var method = typeof(TweakService).GetMethod("ApplyOne", BindingFlags.NonPublic | BindingFlags.Instance);
            Assert.That(method, Is.Not.Null);
            var failure = Assert.Throws<TargetInvocationException>(() => method.Invoke(service,
                new object[] { tweak, 23L, new BackupSession(blockedPath) }));
            Assert.That(failure.InnerException, Is.InstanceOf<IOException>());
            Assert.That(registry.Key.Writes, Is.Zero);
            Assert.That(registry.Key.GetValue("Value"), Is.EqualTo(17));
        }

        private sealed class FakeRegistry : IRegistry
        {
            public FakeKey Key { get; } = new FakeKey();
            public IRegistryKey CurrentUser => Key;
            public IRegistryKey LocalMachine => Key;
        }

        private sealed class FakeKey : IRegistryKey
        {
            public int Writes { get; private set; }
            public string Name => "TestOnly";
            public IRegistryKey OpenSubKey(string name, bool writable) => this;
            public IRegistryKey CreateSubKey(string name) => this;
            public string[] GetSubKeyNames() => Array.Empty<string>();
            public string[] GetValueNames() => new[] { "Value" };
            public object GetValue(string name) => 17;
            public object GetValue(string name, object defaultValue) => 17;
            public RegistryValueKind GetValueKind(string name) => RegistryValueKind.DWord;
            public void SetValue(string name, object value, RegistryValueKind valueKind) => Writes++;
            public void DeleteValue(string name, bool throwOnMissingValue) => Writes++;
            public void Dispose() { }
        }
    }
}
