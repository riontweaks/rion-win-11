using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class DriverReleaseTests
    {
        private const string Source = DriverReleaseService.AmdReference;
        private static string AmdRow(string version, string tag, string date, string notes = "/en/resources/support-articles/release-notes/example.html") =>
            $"<article><h4>AMD Software: Adrenalin Edition</h4><strong>Revision Number</strong><p>Adrenalin {version} ({tag})</p><strong>File Size</strong><p>900 MB</p><strong>Release Date</strong><p>{date}</p><a href='{notes}'>Release notes</a></article>";
        private static string AmdPage => "<h2 class='accordion-header'><button>Windows 11 - 64-Bit Edition</button></h2>" +
            AmdRow("26.8.1", "WHQL Recommended", "2026-08-20") + AmdRow("26.9.1", "WHQL Optional", "2026-09-03") +
            "<h2 class='accordion-header'><button>Windows 10</button></h2>" + AmdRow("99.1.1", "WHQL Recommended", "2099-01-01");
        private static string NvidiaRow(string name, string version, string date, string link = "//www.nvidia.com/download/driverResults.aspx/123/en-us") =>
            $"<tr id='driverList'><td>icon</td><td><a href='{link}'>{name}</a> WHQL</td><td>{version}</td><td>{date}</td></tr>";

        [Test] public void AmdKeepsDatesAndCertificationWithTheirOwnWindows11Release()
        {
            var rows = DriverReleaseService.ParseAmd(AmdPage, Source);
            Assert.That(rows, Has.Count.EqualTo(2));
            Assert.That(rows.Single(r => r.Version == "26.9.1").Channel, Is.EqualTo("Optional"));
            Assert.That(rows.Single(r => r.Version == "26.8.1").ReleaseDate, Is.EqualTo(new DateTime(2026, 8, 20)));
        }
        [Test] public async Task LatestAndRecommendedAreIndependentOfPageOrder()
        {
            var service = new DriverReleaseService((_, _) => Task.FromResult(AmdPage));
            var result = await service.ReadAsync("AMD", null, default);
            Assert.That(result.Latest.Version, Is.EqualTo("26.9.1"));
            Assert.That(result.Alternative.Version, Is.EqualTo("26.8.1"));
            Assert.That(result.Scope, Does.Contain("reference listing"));
        }
        [Test] public void AmdMissingOsSectionDoesNotGuess()
        { Assert.Throws<InvalidDataException>(() => DriverReleaseService.ParseAmd(AmdRow("26.9.1", "WHQL", "2026-09-03"), Source)); }
        [Test] public void NvidiaSeparatesChannelsAndExcludesProfessionalPackages()
        {
            var rows = DriverReleaseService.ParseNvidia(NvidiaRow("GeForce Game Ready Driver", "616.64", "September 3, 2026") +
                NvidiaRow("NVIDIA Studio Driver", "615.26", "August 25, 2026") + NvidiaRow("NVIDIA RTX Driver", "999.99", "September 4, 2026"));
            Assert.That(rows.Select(r => r.Channel), Is.EqualTo(new[] { "Game Ready", "Studio" }));
        }
        [Test] public void NvidiaDuplicateNotebookRowsDoNotDuplicateTheRelease()
        {
            var row = NvidiaRow("GeForce Game Ready Driver", "616.64", "September 3, 2026");
            Assert.That(DriverReleaseService.ParseNvidia(row + row), Has.Count.EqualTo(1));
        }
        [Test] public void MalformedDateIsNotReplacedWithTodaysDate()
        { Assert.That(DriverReleaseService.ParseNvidia(NvidiaRow("GeForce Game Ready Driver", "616.64", "Unknown")), Is.Empty); }
        [TestCase("https://www.nvidia.com.attacker.test/download")]
        [TestCase("http://www.nvidia.com/download")]
        [TestCase("https://www.nvidia.com:444/download")]
        [TestCase("https://user@www.nvidia.com/download")]
        public void UnsafeVendorLinksAreRejected(string link)
        {
            Assert.That(DriverReleaseService.IsOfficial("NVIDIA", new Uri(link)), Is.False);
            Assert.Throws<InvalidDataException>(() => DriverReleaseService.ParseNvidia(NvidiaRow("GeForce Game Ready Driver", "616.64", "September 3, 2026", link)));
        }
        [Test] public void AmdRejectsForeignNotesLinks()
        {
            string page = "<button>Windows 11</button>" + AmdRow("26.9.1", "Optional", "2026-09-03", "https://other.test/release-notes/test.html");
            Assert.Throws<InvalidDataException>(() => DriverReleaseService.ParseAmd(page, Source));
        }
        [Test] public async Task UnknownPageIsUnavailableRatherThanAFabricatedVersion()
        {
            var vm = new DriverReleaseCardViewModel("AMD", null, service: new((_, _) => Task.FromResult("<html>Access denied</html>")));
            await vm.RefreshAsync();
            Assert.That(vm.Freshness, Is.EqualTo("Unavailable"));
            Assert.That(vm.Version, Is.EqualTo("—"));
            Assert.That(vm.OpenNotesCommand.CanExecute(null), Is.False);
        }
        [Test] public async Task FailedRefreshKeepsLastGoodReleaseButMarksItStale()
        {
            int calls = 0;
            var vm = new DriverReleaseCardViewModel("AMD", null, service: new((_, _) => ++calls == 1 ? Task.FromResult(AmdPage) : throw new IOException("offline")));
            await vm.RefreshAsync();
            string checkedAt = vm.CheckedAt;
            await vm.RefreshAsync();
            Assert.That(calls, Is.EqualTo(1), "Re-entry inside the interval should not duplicate requests");
            await vm.RefreshAsync(true);
            Assert.That(vm.Version, Is.EqualTo("26.9.1"));
            Assert.That(vm.Freshness, Does.Contain("refresh failed"));
            Assert.That(vm.CheckedAt, Is.EqualTo(checkedAt));
            Assert.That(vm.Signature, Does.Contain("not verified"));
        }
        [Test] public async Task ConcurrentRefreshIsCoalescedAndTimeoutIsReported()
        {
            int calls = 0;
            var completion = new TaskCompletionSource<string>();
            var vm = new DriverReleaseCardViewModel("AMD", null, service: new((_, _) => { calls++; return completion.Task; }));
            var first = vm.RefreshAsync(true);
            await vm.RefreshAsync(true);
            Assert.That(calls, Is.EqualTo(1));
            completion.SetException(new OperationCanceledException());
            await first;
            Assert.That(vm.Status, Does.Contain("timed out"));
            Assert.That(vm.IsBusy, Is.False);
        }
        [Test] public async Task AmdProductMatchingRequiresExactIdentity()
        {
            string index = "{&#34;url&#34;:&#34;" + Source + "&#34;}";
            var service = new DriverReleaseService((uri, _) => Task.FromResult(uri.AbsoluteUri == DriverReleaseService.AmdIndex ? index : AmdPage));
            var exact = await service.ReadAsync("AMD", "AMD Radeon RX 9070 XT", default);
            var partial = await service.ReadAsync("AMD", "AMD Radeon RX 9070", default);
            Assert.That(exact.Scope, Does.Contain("product listing"));
            Assert.That(partial.Scope, Does.Contain("not matched"));
        }
        [Test] public void LocalSignatureDoesNotCertifyTheOnlineRelease()
        {
            var vm = new DriverReleaseCardViewModel("NVIDIA", null, () => new RadeonSoftwareSlimmer.Models.DriverInstallerInfo
            { FilePath = @"C:\fixture\older-driver.exe", SignatureStatus = RadeonSoftwareSlimmer.Models.SignatureStatus.ValidButNotAmd, Publisher = "NVIDIA Corporation", OriginalHashSha256 = "fixture-hash" });
            Assert.That(vm.SelectedPackage, Does.Contain("older-driver.exe").And.Contain("NVIDIA Corporation").And.Contain("may differ from the online release"));
            Assert.That(vm.Signature, Does.Contain("not verified"));
            Assert.That(DriverReleaseService.IsOfficial("Unknown", new Uri("https://www.nvidia.com/")), Is.False);
        }
    }
}
