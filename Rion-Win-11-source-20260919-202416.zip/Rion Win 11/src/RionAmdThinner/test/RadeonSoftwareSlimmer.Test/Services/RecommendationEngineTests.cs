using NUnit.Framework;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Test.Services
{
    /// <summary>
    /// Covers the policy the post-install auto-apply relies on: which live services / tasks
    /// get turned off automatically after a verified install. Assumes the built-in seed rule
    /// set (no %LOCALAPPDATA%\AmdDriverManager\recommendations.json override present).
    /// </summary>
    public class RecommendationEngineTests
    {
        private RecommendationEngine _engine;

        [SetUp]
        public void SetUp()
        {
            _engine = new RecommendationEngine();
            Assume.That(_engine.RulesVersion, Is.EqualTo("seed-2026.09"),
                "A local recommendations.json override is present; skipping seed-rule tests.");
        }

        [Test]
        public void ShouldAutoDisable_Null_ReturnsFalse()
        {
            Assert.That(_engine.ShouldAutoDisable(null), Is.False);
        }

        [Test]
        public void ShouldAutoDisable_Empty_ReturnsFalse()
        {
            Assert.That(_engine.ShouldAutoDisable(""), Is.False);
        }

        [Test]
        public void ShouldAutoDisable_UnmatchedIdentifier_ReturnsFalse()
        {
            Assert.That(_engine.ShouldAutoDisable("Some Unrelated Third Party Service"), Is.False);
        }

        [TestCase("Radeon Software")]     // core-display -> Required
        [TestCase("amdkmdag")]            // core-display -> Required
        public void ShouldAutoDisable_RequiredComponent_ReturnsFalse(string identifier)
        {
            Assert.That(_engine.ShouldAutoDisable(identifier), Is.False);
        }

        [TestCase("AMD External Events Utility")]   // external-events -> KeepByDefault
        [TestCase("AtiHDAudioService")]             // hd-audio -> KeepByDefault
        [TestCase("AMD Crash Defender")]            // crash-defender -> KeepByDefault
        public void ShouldAutoDisable_KeepByDefaultComponent_ReturnsFalse(string identifier)
        {
            Assert.That(_engine.ShouldAutoDisable(identifier), Is.False);
        }

        [TestCase("AMD Link")]        // amd-link -> Optional
        [TestCase("AMDXE")]           // amd-link -> Optional
        [TestCase("AUEPLauncher")]    // uxp -> Optional
        [TestCase("DVRAnalytics")]    // uxp -> Optional
        [TestCase("ReLive")]          // relive-recording -> Optional
        public void ShouldAutoDisable_OptionalComponent_ReturnsTrue(string identifier)
        {
            Assert.That(_engine.ShouldAutoDisable(identifier), Is.True);
        }

        [TestCase("StartCN")]     // install-manager-task -> Optional but DefaultAction = ReviewAfterInstall
        [TestCase("StartCNBM")]
        public void ShouldAutoDisable_ReviewAfterInstallComponent_ReturnsFalse(string identifier)
        {
            RecommendationRecord rec = _engine.Match(identifier);
            Assume.That(rec, Is.Not.Null);
            Assume.That(rec.DefaultAction, Is.EqualTo(ComponentAction.ReviewAfterInstall));

            Assert.That(_engine.ShouldAutoDisable(identifier), Is.False);
        }

        [Test]
        public void Classify_UnmatchedIdentifier_ReturnsUnknown()
        {
            Assert.That(_engine.Classify("Nothing Matches This"), Is.EqualTo(Classification.Unknown));
        }

        [Test]
        public void Match_KnownIdentifier_ReturnsRecordWithThatId()
        {
            Assert.That(_engine.Match("AMD Link")?.Id, Is.EqualTo("amd-link"));
        }
    }
}
