using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.Optimize;
using System.Linq;

namespace RadeonSoftwareSlimmer.Test.Services
{
    public class PortableToolSecurityTests
    {
        private string directory;
        [SetUp] public void Setup() { directory = Path.Combine(Path.GetTempPath(), "RionToolTests-" + Guid.NewGuid()); Directory.CreateDirectory(directory); }
        [TearDown] public void Cleanup() { Directory.Delete(directory, true); }
        private sealed class Handler : HttpMessageHandler
        {
            public byte[] Bytes = new byte[2048];
            public long? Length;
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var response = new HttpResponseMessage(HttpStatusCode.OK) { RequestMessage = request, Content = new ByteArrayContent(Bytes) };
                response.Content.Headers.ContentLength = Length ?? Bytes.Length;
                return Task.FromResult(response);
            }
        }
        [TestCase(false)] [TestCase(true)]
        public void RejectsUnsignedOrTruncatedDownloadWithoutReplacingCache(bool truncated)
        {
            string destination = Path.Combine(directory, "tool.exe");
            File.WriteAllText(destination, "existing cache");
            using var client = new HttpClient(new Handler { Length = truncated ? 4096 : 2048 });
            Assert.ThrowsAsync<InvalidDataException>(() => PortableToolDownloader.DownloadFileAsync(client, "https://example.com/tool.exe", destination, null, 1024, CancellationToken.None));
            Assert.That(File.ReadAllText(destination), Is.EqualTo("existing cache"));
            Assert.That(Directory.GetFiles(directory, "*.partial"), Is.Empty);
        }
        [Test]
        public async Task SignedDownloadIsPromotedWithoutLaunching()
        {
            string source = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "dotnet.exe");
            Assert.That(PortableToolDownloader.IsTrustedExecutable(source), Is.True);
            byte[] bytes = File.ReadAllBytes(source);
            using var client = new HttpClient(new Handler { Bytes = bytes });
            string destination = Path.Combine(directory, "tool.exe");
            await PortableToolDownloader.DownloadFileAsync(client, "https://example.com/tool.exe", destination, null, 1024, CancellationToken.None);
            Assert.That(File.ReadAllBytes(destination), Is.EqualTo(bytes));
            Assert.That(Directory.GetFiles(directory, "*.partial"), Is.Empty);
        }
        [Test]
        public void RejectsHttpBeforeSaving()
        {
            using var client = new HttpClient(new Handler());
            Assert.ThrowsAsync<InvalidOperationException>(() => PortableToolDownloader.DownloadFileAsync(client, "http://example.com/tool.exe", Path.Combine(directory, "tool.exe"), null, 1, CancellationToken.None));
            Assert.That(Directory.GetFiles(directory), Is.Empty);
        }
        [Test]
        public void RejectsUnsignedCachedFile()
        {
            string path = Path.Combine(directory, "tool.exe"); File.WriteAllBytes(path, new byte[2048]);
            Assert.That(PortableToolDownloader.IsTrustedExecutable(path), Is.False);
        }
        [Test]
        public async Task PinnedUnsignedDownloadIsAcceptedButChangedBytesAreRejected()
        {
            byte[] bytes = new byte[2048];
            string hash = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes));
            string path = Path.Combine(directory, "curated.exe");
            using var client = new HttpClient(new Handler { Bytes = bytes });
            await PortableToolDownloader.DownloadFileAsync(client, "https://example.com/tool.exe", path, null, 1024, CancellationToken.None, hash);
            Assert.That(PortableToolDownloader.IsAcceptedExecutable(path, hash), Is.True);
            bytes[0] = 1;
            using var changed = new HttpClient(new Handler { Bytes = bytes });
            Assert.ThrowsAsync<InvalidDataException>(() => PortableToolDownloader.DownloadFileAsync(changed, "https://example.com/tool.exe", path, null, 1024, CancellationToken.None, hash));
            Assert.That(File.ReadAllBytes(path)[0], Is.Zero);
            Assert.That(Directory.GetFiles(directory, "*.partial"), Is.Empty);
        }
        [Test]
        public void SignedFileCannotBypassAPin()
        {
            string source = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "dotnet", "dotnet.exe");
            Assert.That(PortableToolDownloader.IsAcceptedExecutable(source, new string('0', 64)), Is.False);
        }
        [Test]
        public async Task DownloadedCuratedFixturesPassTheProductionVerificationPath()
        {
            string root = Environment.GetEnvironmentVariable("RION_UTILITY_FIXTURES");
            if (string.IsNullOrEmpty(root)) Assert.Ignore("Set RION_UTILITY_FIXTURES to the downloaded curated files.");
            foreach (var entry in UtilityToolCatalog.All.Where(t => t.Sha256 != null))
            {
                string source = Path.Combine(root, Path.GetFileName(new Uri(entry.Source).AbsolutePath));
                using var client = new HttpClient(new Handler { Bytes = File.ReadAllBytes(source) });
                string destination = Path.Combine(directory, entry.FileName);
                await PortableToolDownloader.DownloadFileAsync(client, entry.Source, destination, null, 1024, CancellationToken.None, entry.Sha256);
                Assert.That(PortableToolDownloader.IsAcceptedExecutable(destination, entry.Sha256), Is.True, entry.Name);
            }
        }
        [Test]
        public void AlreadyInstalledIsSuccessAndActualFailurePreservesDiagnostics()
        {
            Assert.That(WingetInstallService.InterpretInstallResult(new ShellRunner.Result { ExitCode = unchecked((int)0x8A15002B) }), Is.True);
            var error = Assert.Throws<InvalidOperationException>(() => WingetInstallService.InterpretInstallResult(new ShellRunner.Result { ExitCode = 5, Output = "Access denied" }));
            Assert.That(error.Message, Does.Contain("Access denied").And.Contain("0x00000005"));
            Assert.Throws<TimeoutException>(() => WingetInstallService.InterpretInstallResult(new ShellRunner.Result { ExitCode = 0, TimedOut = true }));
        }
        [Test]
        public void NoDefenderDisablingUtilityRemains()
        {
            Assert.That(UtilityToolCatalog.All.Any(t => t.Name.Equals("dControl", StringComparison.OrdinalIgnoreCase)), Is.False);
            Assert.That(WindowsHealthCatalog.All.Any(t => t.Id == "defender-off"), Is.False);
        }
        [Test]
        public void RejectsFileNameTraversal()
        {
            Assert.ThrowsAsync<ArgumentException>(() => PortableToolDownloader.DownloadAndLaunchAsync("https://example.com/tool.exe", "../outside.exe"));
        }
    }
}
