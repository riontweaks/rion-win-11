using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Optimize
{
    public sealed record DesktopDebloatApp(string Name, string Publisher, RegistryHive Hive, RegistryView View,
        string KeyPath, string ProductCode, bool Msi, string QuietCommand);

    public static class DesktopDebloatCatalog
    {
        // Exact product and publisher pairs. Shared runtimes, drivers and system components
        // are never inferred to be unwanted from a broad name fragment.
        public static bool IsCandidate(string name, string publisher, bool component = false) => !component &&
            ((new[] { "Microsoft Teams", "Microsoft Teams classic", "Teams Machine-Wide Installer",
                "Microsoft Power Automate Desktop", "Microsoft OneDrive", "Cortana", "Clipchamp" }.Contains(name, StringComparer.OrdinalIgnoreCase)
                && string.Equals(publisher, "Microsoft Corporation", StringComparison.OrdinalIgnoreCase))
             || (string.Equals(name, "Skype", StringComparison.OrdinalIgnoreCase)
                && new[] { "Skype Technologies S.A.", "Microsoft Corporation" }.Contains(publisher, StringComparer.OrdinalIgnoreCase)));

        public static IReadOnlyList<DesktopDebloatApp> Scan(Action<string> warning = null)
        {
            var apps = new List<DesktopDebloatApp>();
            foreach (var hive in new[] { RegistryHive.LocalMachine, RegistryHive.CurrentUser })
            foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using var root = RegistryKey.OpenBaseKey(hive, view);
                    const string path = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
                    using var uninstall = root.OpenSubKey(path);
                    if (uninstall == null) continue;
                    foreach (var id in uninstall.GetSubKeyNames())
                    {
                        using var key = uninstall.OpenSubKey(id);
                        if (key == null) continue;
                        string Text(string n) => key.GetValue(n)?.ToString() ?? "";
                        string name = Text("DisplayName"), publisher = Text("Publisher");
                        if (!IsCandidate(name, publisher, Text("SystemComponent") == "1" || Text("ParentKeyName").Length > 0)) continue;
                        string command = Text("QuietUninstallString");
                        if (command.Length == 0 && name.Equals("Microsoft OneDrive", StringComparison.OrdinalIgnoreCase)) command = Text("UninstallString");
                        apps.Add(new(name, publisher, hive, view, path + "\\" + id, id, Text("WindowsInstaller") == "1", command));
                    }
                }
                catch (Exception ex) { warning?.Invoke($"Desktop scan {hive}/{view}: {ex.Message}"); }
            }
            return apps;
        }

        public static bool TryGetCommand(DesktopDebloatApp app, out string executable, out string arguments)
        {
            executable = arguments = "";
            if (app.Msi && Guid.TryParse(app.ProductCode, out var product))
            {
                executable = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "msiexec.exe");
                arguments = $"/x {product:B} /quiet /norestart REBOOT=ReallySuppress";
                return true;
            }
            string command = app.QuietCommand?.Trim() ?? "";
            if (command.StartsWith('"'))
            {
                int end = command.IndexOf('"', 1);
                if (end < 2) return false;
                executable = command.Substring(1, end - 1);
                arguments = command.Substring(end + 1).Trim();
            }
            else
            {
                int end = command.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
                if (end < 0) return false;
                executable = command.Substring(0, end + 4);
                arguments = command.Substring(end + 4).Trim();
            }
            if (app.Name.Equals("Microsoft OneDrive", StringComparison.OrdinalIgnoreCase)
                && (!Path.GetFileName(executable).Equals("OneDriveSetup.exe", StringComparison.OrdinalIgnoreCase)
                    || !arguments.Split(' ', StringSplitOptions.RemoveEmptyEntries).Contains("/uninstall", StringComparer.OrdinalIgnoreCase)
                    || arguments.Split(' ', StringSplitOptions.RemoveEmptyEntries).Any(a => !new[] { "/uninstall", "/allusers" }.Contains(a, StringComparer.OrdinalIgnoreCase)))) return false;
            return Path.IsPathFullyQualified(executable) && Path.GetExtension(executable).Equals(".exe", StringComparison.OrdinalIgnoreCase)
                && !new[] { "cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe", "rundll32.exe", "mshta.exe" }
                    .Contains(Path.GetFileName(executable), StringComparer.OrdinalIgnoreCase);
        }

        public static bool IsSelectedForRemoval(DesktopDebloatApp app, IReadOnlyCollection<string> keep, IReadOnlyCollection<string> reviewedNames) =>
            IsCandidate(app.Name, app.Publisher) && (keep == null || !keep.Contains(app.Name, StringComparer.OrdinalIgnoreCase))
            && (reviewedNames == null || reviewedNames.Contains(app.Name, StringComparer.OrdinalIgnoreCase));

        public static async Task<(List<string> removed, List<string> failed)> RunAsync(Action<string> log, CancellationToken ct,
            IReadOnlyCollection<string> keep = null, IReadOnlyCollection<string> reviewedNames = null)
        {
            var removed = new List<string>();
            var failed = new List<string>();
            var apps = Scan(warning => { failed.Add(warning); log?.Invoke(warning); });
            // The same MSI may be registered twice. Execute its product code once.
            foreach (var group in apps.Where(a => IsSelectedForRemoval(a, keep, reviewedNames))
                .GroupBy(a => a.Msi ? "MSI|" + a.ProductCode : a.Hive + "|" + a.QuietCommand + "|" + a.Name, StringComparer.OrdinalIgnoreCase))
            {
                ct.ThrowIfCancellationRequested();
                var app = group.First();
                try
                {
                    if (!TryGetCommand(app, out var exe, out var args) || !File.Exists(exe))
                        throw new InvalidOperationException("No supported unattended uninstaller. Use Desktop apps to uninstall manually.");
                    var signature = new InstallerValidator().Inspect(exe);
                    if (signature.SignatureStatus is not (Models.SignatureStatus.Valid or Models.SignatureStatus.ValidButNotAmd)
                        || !(new[] { "Microsoft Corporation", "Skype Technologies S.A." }.Contains(signature.Publisher, StringComparer.OrdinalIgnoreCase)
                             || app.Msi && string.Equals(signature.Publisher, "Microsoft Windows", StringComparison.OrdinalIgnoreCase)))
                        throw new InvalidOperationException("The uninstaller's trusted publisher could not be verified. Use Windows Installed apps to review it.");
                    if (app.Name.Equals("Microsoft OneDrive", StringComparison.OrdinalIgnoreCase))
                        log?.Invoke("OneDrive removal stops sync and folder backup. Cloud-only files are not downloaded by this operation; the OneDrive data folder is not deleted.");
                    log?.Invoke("Removing desktop app: " + app.Name);
                    var result = await ShellRunner.RunAsync(exe, args, log, timeoutMs: 300000, ct: ct).ConfigureAwait(false);
                    ct.ThrowIfCancellationRequested();
                    if (result.TimedOut || result.ExitCode is not (0 or 3010 or 1641))
                        throw new InvalidOperationException("Uninstaller did not complete successfully (exit " + result.ExitCode + ").");
                    foreach (var entry in group)
                    {
                        using var root = RegistryKey.OpenBaseKey(entry.Hive, entry.View);
                        using var key = root.OpenSubKey(entry.KeyPath);
                        if (key?.GetValue("DisplayName") != null)
                            throw new InvalidOperationException("Still registered after uninstall; restart or review Desktop apps.");
                    }
                    removed.Add(app.Name + " (desktop)");
                    if (result.ExitCode is 3010 or 1641) log?.Invoke("Restart required for " + app.Name);
                    AuditLog.Action("Auto Debloat", "UninstallDesktop", app.Name, newValue: "removed", result: "OK", reversible: false);
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex) { failed.Add(app.Name + ": " + ex.Message); log?.Invoke(failed.Last()); }
            }
            return (removed, failed);
        }
    }
}
