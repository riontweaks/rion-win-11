using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Newtonsoft.Json;

namespace RadeonSoftwareSlimmer.Optimize
{
    public enum BasicSetting { MemoryCompression, TcpAutoTuning, TcpCongestion }

    public sealed record BasicSettingState(string Value, string UnavailableReason = null);

    public interface IBasicSettingProvider
    {
        BasicSettingState Read(BasicSetting setting);
        void Write(BasicSetting setting, string value);
    }

    /// <summary>One setting per durable journal; recovery never substitutes a default.</summary>
    public sealed class BasicSettingControl
    {
        private readonly IBasicSettingProvider provider;
        private readonly string directory;
        public BasicSettingControl(IBasicSettingProvider provider, string directory)
        {
            this.provider = provider;
            this.directory = Path.GetFullPath(directory);
        }

        public static BasicSettingControl CreateWindows() => new BasicSettingControl(new WindowsBasicSettingProvider(),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "BasicSettings"));

        public static string Target(BasicSetting setting) => setting switch
        {
            BasicSetting.MemoryCompression => "disabled",
            BasicSetting.TcpAutoTuning => "normal",
            BasicSetting.TcpCongestion => "cubic",
            _ => throw new ArgumentOutOfRangeException(nameof(setting))
        };

        internal static bool IsValid(BasicSetting setting, string value) => (setting switch
        {
            BasicSetting.MemoryCompression => new[] { "enabled", "disabled" },
            BasicSetting.TcpAutoTuning => new[] { "disabled", "highlyrestricted", "restricted", "normal", "experimental" },
            BasicSetting.TcpCongestion => new[] { "none", "ctcp", "dctcp", "cubic", "bbr2", "default" },
            _ => Array.Empty<string>()
        }).Contains(value, StringComparer.Ordinal);

        public BasicSettingState Inspect(BasicSetting setting) => provider.Read(setting);
        public bool HasSavedState(BasicSetting setting) => File.Exists(JournalPath(setting));

        public string Apply(BasicSetting setting) => WithLock(() =>
        {
            string current = ReadSupported(setting);
            var journal = Load(setting);
            if (journal != null) RequireUnchanged(current, journal);
            if (current == Target(setting)) return "Already configured; no change was made.";
            if (journal == null)
            {
                journal = new Journal { Version = 1, Machine = Environment.MachineName, Setting = setting,
                    Before = current, Target = Target(setting) };
                Save(setting, journal); // Flush and publish the complete record BEFORE mutation.
            }
            if (ReadSupported(setting) != current) throw new InvalidOperationException("The setting changed while preparing this action. Refresh and review it.");
            provider.Write(setting, journal.Target);
            if (ReadSupported(setting) != journal.Target)
                throw new IOException("The requested value was not verified. Saved recovery is available for retry or restore.");
            return "Configured value verified. The previous value is saved for Restore.";
        });

        public string Restore(BasicSetting setting) => WithLock(() =>
        {
            var journal = Load(setting) ?? throw new InvalidOperationException("No previous value was saved by Rion. No default was substituted.");
            string current = ReadSupported(setting);
            RequireUnchanged(current, journal);
            if (current != journal.Before)
            {
                if (ReadSupported(setting) != current) throw new InvalidOperationException("The setting changed while preparing recovery. Refresh and review it.");
                provider.Write(setting, journal.Before);
            }
            if (ReadSupported(setting) != journal.Before)
                throw new IOException("The saved value was not verified. Recovery was retained for retry.");
            File.Delete(JournalPath(setting));
            return "The exact previous configured value was restored and verified.";
        });

        private string ReadSupported(BasicSetting setting)
        {
            var state = provider.Read(setting);
            if (!string.IsNullOrEmpty(state.UnavailableReason)) throw new InvalidOperationException(state.UnavailableReason);
            if (!IsValid(setting, state.Value)) throw new InvalidOperationException("Windows returned an unsupported value. No change was made.");
            return state.Value;
        }

        private static void RequireUnchanged(string current, Journal journal)
        {
            if (current != journal.Before && current != journal.Target)
                throw new InvalidOperationException("This setting changed outside Rion. The external value and saved recovery were preserved.");
        }

        private string JournalPath(BasicSetting setting)
        {
            _ = Target(setting);
            return Path.Combine(directory, setting + ".json");
        }

        private Journal Load(BasicSetting setting)
        {
            string path = JournalPath(setting);
            if (!File.Exists(path)) return null;
            Journal journal;
            try { journal = JsonConvert.DeserializeObject<Journal>(File.ReadAllText(path)); }
            catch (JsonException ex) { throw new InvalidDataException("Saved recovery is unreadable. It was preserved; no change was made.", ex); }
            if (journal == null || journal.Version != 1 || journal.Machine != Environment.MachineName
                || journal.Setting != setting || journal.Target != Target(setting)
                || !IsValid(setting, journal.Before) || journal.Before == journal.Target)
                throw new InvalidDataException("Saved recovery is invalid or belongs to another PC. It was preserved; no change was made.");
            return journal;
        }

        private void Save(BasicSetting setting, Journal journal)
        {
            Directory.CreateDirectory(directory);
            string path = JournalPath(setting);
            string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                byte[] bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(journal, Formatting.Indented));
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Flush(true);
                }
                File.Move(temporary, path); // Never overwrite an existing baseline.
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }

        private string WithLock(Func<string> operation)
        {
            string hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(directory.ToUpperInvariant())));
            using var mutex = new Mutex(false, @"Local\RionBasicSettings-" + hash);
            bool acquired = false;
            try
            {
                try { acquired = mutex.WaitOne(TimeSpan.FromSeconds(5)); }
                catch (AbandonedMutexException) { acquired = true; }
                if (!acquired) throw new IOException("Another Rion operation is using these settings. Try again when it finishes.");
                return operation();
            }
            finally { if (acquired) mutex.ReleaseMutex(); }
        }

        private sealed class Journal
        {
            public int Version { get; set; }
            public string Machine { get; set; }
            public BasicSetting Setting { get; set; }
            public string Before { get; set; }
            public string Target { get; set; }
        }
    }
}
