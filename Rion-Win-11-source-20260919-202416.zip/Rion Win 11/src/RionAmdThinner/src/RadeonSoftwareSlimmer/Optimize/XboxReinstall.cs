using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Optimize;

public static class XboxReinstall
{
    public const string VerifyScript = """
        $ErrorActionPreference = 'Stop'
        $app = @(Get-AppxPackage -Name Microsoft.GamingApp -ErrorAction Stop | Where-Object { $_.Name -eq 'Microsoft.GamingApp' -and $_.Status -eq 'Ok' })
        if (-not $app.Count) { throw 'Xbox is not registered with healthy status for the current user.' }
        Write-Output 'XBOX-VERIFIED'
        """;

    public static async Task<FixResult> RunAsync(IRegistry registry, Action<string> log,
        Action<int, int> progress, CancellationToken ct)
    {
        var backup = new BackupSession { Description = "Xbox reinstall — service startup" };
        // Only repair existing disabled services. Keep existing Automatic/Manual choices and
        // leave Gaming Services to its Store installer instead of inventing service keys.
        string[] services = { "XblAuthManager", "XblGameSave", "XboxNetApiSvc", "XboxGipSvc", "AppXSvc", "ClipSVC", "InstallService" };
        foreach (var name in services)
        {
            ct.ThrowIfCancellationRequested();
            int? current = ServiceTrimCatalog.GetCurrentStart(registry, name);
            if (current == 4 && (!ServiceTrimCatalog.SetStart(registry, name, 3, backup, "Xbox Reinstall")
                || ServiceTrimCatalog.GetCurrentStart(registry, name) != 3))
                return FixResult.Fail("Could not restore " + name + " to Manual. Review permissions and service history, then retry.");
        }
        backup.Save();
        log?.Invoke("Installing or repairing Xbox from Microsoft Store. Game Bar is a separate optional app in Windows Apps.");
        bool installed = await AppxRepairService.ReinstallAsync("Microsoft.GamingApp_8wekyb3d8bbwe", "9MV0B5HZVK9Z", "Xbox", log, ct).ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        if (!installed) return FixResult.Fail("Xbox installation did not complete. Check Microsoft Store and the log, then retry.");
        var verify = await ShellRunner.PowerShellAsync(VerifyScript, log, timeoutMs: 60000, ct: ct).ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        return verify.ExitCode == 0 && !verify.TimedOut && (verify.Output ?? "").Split('\n').Any(l => l.Trim() == "XBOX-VERIFIED")
            ? FixResult.Ok("Xbox is installed for this user. Open Xbox to finish sign-in and any Gaming Services setup. Restart if repaired services are still unavailable.")
            : FixResult.Fail("The installer finished, but Xbox registration could not be verified. Check Microsoft Store and the log; installation is not confirmed.");
    }
}
