using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>One-shot network repair/quick-switch actions for the Tools > Network tab. Thin
    /// wrappers over the existing <see cref="ShellRunner"/> — no new shelling mechanism introduced.
    /// The stack-level resets are NOT revertible and need a restart; the UI must gate those behind
    /// an explicit confirmation, not a bare button.</summary>
    public static class NetworkToolsRunner
    {
        public sealed class RecommendedProfileSnapshot
        {
            public string AdapterName { get; set; } = "";
            public string? GlobalReceiveSideScaling { get; set; }
            public bool? AdapterRssEnabled { get; set; }
            public DateTimeOffset Created { get; set; } = DateTimeOffset.Now;
        }

        private static string ProfileDirectory => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "NetworkProfiles");

        private static string ProfilePath(string adapterName) => Path.Combine(ProfileDirectory,
            Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(adapterName))) + ".json");

        private static string Quote(string value) => value.Replace("'", "''");

        // PowerShell sometimes emits CLIXML diagnostics on stderr. ShellRunner deliberately
        // combines both streams for the visible log, so read the final one-line JSON payload.
        private static string JsonPayload(string output)
        {
            string[] lines = output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            for (int index = lines.Length - 1; index >= 0; index--)
            {
                string candidate = lines[index].Trim();
                if (candidate.StartsWith("{") || candidate.StartsWith("[") || candidate.StartsWith("\""))
                    return candidate;
            }
            return output.Trim();
        }

        private static Task<ShellRunner.Result> ProfilePowerShellAsync(string script, Action<string> onLine, CancellationToken ct)
        {
            // Keep state JSON internal and emit readable errors, not PowerShell CLIXML.
            string wrapped = "$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; try { "
                + script + " } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }";
            return ShellRunner.PowerShellAsync(wrapped, onLine, ct: ct);
        }
        public static bool HasRecommendedProfileSnapshot(string adapterName) =>
            !string.IsNullOrWhiteSpace(adapterName) && File.Exists(ProfilePath(adapterName));

        /// <summary>Applies the safe, documented subset of the supplied script's Apply All flow:
        /// Windows RSS plus selected-adapter RSS. Queue counts, CPU affinity, RSC/offloads, power
        /// properties and raw NIC registry values are intentionally not given a universal target.</summary>
        public static async Task<ShellRunner.Result> ApplyRecommendedProfileAsync(string adapterName,
            Action<string> onLine, CancellationToken ct = default)
        {
            string name = Quote(adapterName);
            string read = "$ErrorActionPreference='Stop'; $a=Get-NetAdapter -Name '" + name + "'; " +
                "if($a.Status -ne 'Up'){throw 'Selected adapter is not connected.'}; " +
                "$g=Get-NetOffloadGlobalSetting; $r=Get-NetAdapterRss -Name $a.Name -ErrorAction SilentlyContinue; " +
                "$json=[pscustomobject]@{GlobalReceiveSideScaling=[string]$g.ReceiveSideScaling; AdapterRssEnabled=if($null -eq $r){$null}else{[bool]$r.Enabled}} | ConvertTo-Json -Compress; " +
                "[Console]::Out.Write($json)";
            ShellRunner.Result before = await ProfilePowerShellAsync(read, null, ct).ConfigureAwait(false);
            if (before.ExitCode != 0) return before;

            RecommendedProfileSnapshot snapshot;
            try
            {
                snapshot = JsonSerializer.Deserialize<RecommendedProfileSnapshot>(JsonPayload(before.Output))
                    ?? throw new InvalidDataException("Windows did not return RSS state.");
                snapshot.AdapterName = adapterName;
            }
            catch (Exception ex)
            {
                return new ShellRunner.Result { ExitCode = -1, Output = "Could not read the current RSS state: " + ex.Message };
            }

            Directory.CreateDirectory(ProfileDirectory);
            if (snapshot.GlobalReceiveSideScaling is not ("Enabled" or "Disabled"))
                return new ShellRunner.Result { ExitCode = -1, Output = "Windows returned an unknown global RSS state; no changes were made." };
            if (!File.Exists(ProfilePath(adapterName)))
                File.WriteAllText(ProfilePath(adapterName), JsonSerializer.Serialize(snapshot));
            string apply = "$g=Get-NetOffloadGlobalSetting; " +
                "if([string]$g.ReceiveSideScaling -eq 'Enabled'){'Windows RSS: already enabled'}else{Set-NetOffloadGlobalSetting -ReceiveSideScaling Enabled; if([string](Get-NetOffloadGlobalSetting).ReceiveSideScaling -ne 'Enabled'){throw 'Windows RSS could not be verified'}; 'Windows RSS: enabled'}; " +
                "$r=Get-NetAdapterRss -Name '" + name + "' -ErrorAction SilentlyContinue; " +
                "if($null -eq $r){'Adapter RSS: unavailable; unchanged'}elseif($r.Enabled){'Adapter RSS: already enabled'}else{Set-NetAdapterRss -Name '" + name + "' -Enabled $true; if(-not (Get-NetAdapterRss -Name '" + name + "').Enabled){throw 'Adapter RSS could not be verified'}; 'Adapter RSS: enabled'}; 'Original RSS settings: saved for Restore'";            return await ProfilePowerShellAsync(apply, onLine, ct).ConfigureAwait(false);
        }

        public static async Task<ShellRunner.Result> RestoreRecommendedProfileAsync(string adapterName,
            Action<string> onLine, CancellationToken ct = default)
        {
            string path = ProfilePath(adapterName);
            if (!File.Exists(path)) return new ShellRunner.Result { ExitCode = -1, Output = "No saved recommended-profile state exists for this adapter." };
            RecommendedProfileSnapshot? snapshot;
            try { snapshot = JsonSerializer.Deserialize<RecommendedProfileSnapshot>(File.ReadAllText(path)); }
            catch (Exception ex) { return new ShellRunner.Result { ExitCode = -1, Output = "Saved profile state is unreadable: " + ex.Message }; }
            if (snapshot == null || snapshot.AdapterName != adapterName)
                return new ShellRunner.Result { ExitCode = -1, Output = "Saved profile state does not match this adapter." };

            string name = Quote(adapterName);
            if (snapshot.GlobalReceiveSideScaling is not ("Enabled" or "Disabled"))
                return new ShellRunner.Result { ExitCode = -1, Output = "Saved RSS state is invalid; no changes were made." };
            string global = snapshot.GlobalReceiveSideScaling;
            string restore = "$ErrorActionPreference='Stop'; Set-NetOffloadGlobalSetting -ReceiveSideScaling " + global + "; " +
                (snapshot.AdapterRssEnabled.HasValue
                    ? "Set-NetAdapterRss -Name '" + name + "' -Enabled $" + snapshot.AdapterRssEnabled.Value.ToString().ToLowerInvariant() + "; "
                    : "") + "if([string](Get-NetOffloadGlobalSetting).ReceiveSideScaling -ne '" + global + "'){throw 'Restored global RSS state could not be verified'}; "
                + (snapshot.AdapterRssEnabled.HasValue ? "$actual=Get-NetAdapterRss -Name '" + name + "'; if($null -eq $actual -or [bool]$actual.Enabled -ne $" + snapshot.AdapterRssEnabled.Value.ToString().ToLowerInvariant() + "){throw 'Restored adapter RSS state could not be verified'}; " : "")
                + "'Restored saved RSS state; readback verified.'";
            ShellRunner.Result result = await ProfilePowerShellAsync(restore, onLine, ct).ConfigureAwait(false);
            if (result.ExitCode == 0 && !result.TimedOut) File.Delete(path);
            return result;
        }
        public static Task<ShellRunner.Result> FlushDnsAsync(Action<string> onLine, CancellationToken ct = default)
            => ShellRunner.RunAsync("ipconfig.exe", "/flushdns", onLine, ct: ct);

        public static async Task<ShellRunner.Result> ReleaseRenewAsync(Action<string> onLine, CancellationToken ct = default)
        {
            var release = await ShellRunner.RunAsync("ipconfig.exe", "/release", onLine, ct: ct).ConfigureAwait(false);
            if (release.ExitCode != 0 || ct.IsCancellationRequested) return release;
            return await ShellRunner.RunAsync("ipconfig.exe", "/renew", onLine, ct: ct).ConfigureAwait(false);
        }

        /// <summary>Not revertible; requires a restart. Gate behind a confirmation dialog.</summary>
        public static Task<ShellRunner.Result> ResetWinsockAsync(Action<string> onLine, CancellationToken ct = default)
            => ShellRunner.RunAsync("netsh.exe", "winsock reset", onLine, ct: ct);

        /// <summary>Not revertible; requires a restart. Gate behind a confirmation dialog.</summary>
        public static Task<ShellRunner.Result> ResetTcpIpStackAsync(Action<string> onLine, CancellationToken ct = default)
            => ShellRunner.RunAsync("netsh.exe", "int ip reset", onLine, ct: ct);

        /// <summary>Friendly names of active, non-loopback/non-tunnel network adapters — the set a
        /// DNS quick-switch should offer.</summary>
        public static IReadOnlyList<string> GetActiveAdapterNames()
        {
            try
            {
                // NetworkInterface reports virtual host adapters as Ethernet. Windows' Physical
                // property is the authoritative distinction for this adapter-scoped control.
                ShellRunner.Result result = ShellRunner.PowerShellAsync(
                    "$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; $names=@(Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' -and $_.HardwareInterface -and -not $_.Virtual } | Sort-Object @{Expression={if($_.Status -eq 'Up'){0}else{1}}},Name | Select-Object -ExpandProperty Name); " +
                    "$json=ConvertTo-Json -InputObject @($names) -Compress; [Console]::Out.WriteLine($json)",
                    null, timeoutMs: 10_000).GetAwaiter().GetResult();
                if (result.ExitCode != 0) return Array.Empty<string>();
                string json = JsonPayload(result.Output);
                using JsonDocument document = JsonDocument.Parse(json);
                return document.RootElement.ValueKind == JsonValueKind.Array
                    ? document.RootElement.EnumerateArray().Select(e => e.GetString()).Where(name => !string.IsNullOrWhiteSpace(name)).Select(name => name!).ToList()
                    : document.RootElement.ValueKind == JsonValueKind.String && !string.IsNullOrWhiteSpace(document.RootElement.GetString())
                        ? new[] { document.RootElement.GetString()! }
                        : Array.Empty<string>();
            }
            catch
            {
                return Array.Empty<string>();
            }
        }

        public static readonly (string Label, string Primary, string Secondary)[] DnsPresets =
        {
            ("Cloudflare", "1.1.1.1", "1.0.0.1"),
            ("Google", "8.8.8.8", "8.8.4.4"),
        };

        public static async Task<ShellRunner.Result> SetDnsAsync(string adapterName, string primary, string secondary,
            Action<string> onLine, CancellationToken ct = default)
        {
            var r1 = await ShellRunner.RunAsync("netsh.exe",
                $"interface ip set dns name=\"{adapterName}\" source=static addr={primary} register=primary",
                onLine, ct: ct).ConfigureAwait(false);
            if (r1.ExitCode != 0 || string.IsNullOrEmpty(secondary) || ct.IsCancellationRequested) return r1;

            return await ShellRunner.RunAsync("netsh.exe",
                $"interface ip add dns name=\"{adapterName}\" addr={secondary} index=2",
                onLine, ct: ct).ConfigureAwait(false);
        }

        public static Task<ShellRunner.Result> SetDnsAutomaticAsync(string adapterName, Action<string> onLine,
            CancellationToken ct = default)
            => ShellRunner.RunAsync("netsh.exe", $"interface ip set dns name=\"{adapterName}\" source=dhcp", onLine, ct: ct);
    }
}



