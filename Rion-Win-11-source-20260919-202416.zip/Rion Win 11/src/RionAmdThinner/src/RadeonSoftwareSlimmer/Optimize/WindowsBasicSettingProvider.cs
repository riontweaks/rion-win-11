using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace RadeonSoftwareSlimmer.Optimize
{
    public sealed class WindowsBasicSettingProvider : IBasicSettingProvider
    {
        private const string Marker = "RIONBASIC:";

        public BasicSettingState Read(BasicSetting setting)
        {
            try
            {
                string output = Run(ReadScript(setting));
                string line = output.Split('\n').Select(s => s.Trim()).Single(s => s.StartsWith(Marker, StringComparison.Ordinal));
                var state = JsonConvert.DeserializeObject<BasicSettingState>(line.Substring(Marker.Length));
                if (state == null) throw new IOException("Windows returned no setting state.");
                string value = state.Value?.ToLowerInvariant();
                return BasicSettingControl.IsValid(setting, value) ? state with { Value = value }
                    : new BasicSettingState(value, state.UnavailableReason ?? "This Windows version returned an unsupported value.");
            }
            catch (Exception ex) { return new BasicSettingState(null, "Unavailable: " + ex.Message); }
        }

        public void Write(BasicSetting setting, string value) => Run(WriteScript(setting, value));

        internal static string ReadScript(BasicSetting setting)
        {
            string body = setting switch
            {
                BasicSetting.MemoryCompression => @"
Get-Command Enable-MMAgent,Disable-MMAgent -ErrorAction Stop | Out-Null
$m=Get-MMAgent -ErrorAction Stop
if($null -eq $m.MemoryCompression){throw 'Memory compression state is not exposed.'}
$value=if($m.MemoryCompression){'enabled'}else{'disabled'}",
                BasicSetting.TcpAutoTuning => @"
$p=(Get-Command Set-NetTCPSetting -ErrorAction Stop).Parameters['AutoTuningLevelLocal']
if(!$p){throw 'The TCP auto-tuning setter is unavailable.'}
$t=@(Get-NetTCPSetting -SettingName Internet -ErrorAction Stop | Where-Object SettingName -eq 'Internet')
if($t.Count -ne 1){throw 'The Internet TCP template is unavailable.'}
$value=[string]$t[0].AutoTuningLevelLocal
if([string]$t[0].AutoTuningLevelGroupPolicy -ne 'NotConfigured'){$reason='TCP auto-tuning is managed by policy or its policy state is unavailable.'}",
                BasicSetting.TcpCongestion => @"
$t=@(Get-NetTCPSetting -SettingName Internet -ErrorAction Stop | Where-Object SettingName -eq 'Internet')
if($t.Count -ne 1){throw 'The Internet TCP template is unavailable.'}
$value=([string]$t[0].CongestionProvider).ToLowerInvariant()
$netsh=Join-Path ([Environment]::GetFolderPath('System')) 'netsh.exe'
$help=(& $netsh interface tcp set supplemental '?' 2>&1 | Out-String)
if($help -notmatch '\bcubic\b' -or $help -notmatch ('\b'+[regex]::Escape($value)+'\b')){$reason='This Windows version does not advertise CUBIC and the current provider for exact recovery.'}",
                _ => throw new ArgumentOutOfRangeException(nameof(setting))
            };
            return "$reason=$null\n" + body + "\n[Console]::Out.WriteLine('" + Marker + "'+(ConvertTo-Json -Compress -InputObject @{Value=$value;UnavailableReason=$reason}))";
        }

        internal static string WriteScript(BasicSetting setting, string value)
        {
            // Persisted values are never interpolated until validated against a closed enum.
            if (!BasicSettingControl.IsValid(setting, value)) throw new ArgumentException("Unsupported setting value.", nameof(value));
            return setting switch
            {
                BasicSetting.MemoryCompression => (value == "enabled" ? "Enable" : "Disable") + "-MMAgent -MemoryCompression -ErrorAction Stop",
                BasicSetting.TcpAutoTuning => "Set-NetTCPSetting -SettingName Internet -AutoTuningLevelLocal " + value + " -ErrorAction Stop",
                BasicSetting.TcpCongestion => "$netsh=Join-Path ([Environment]::GetFolderPath('System')) 'netsh.exe'\n& $netsh interface tcp set supplemental template=internet congestionprovider=" + value
                    + "\nif($LASTEXITCODE -ne 0){throw ('netsh rejected the provider (exit '+$LASTEXITCODE+').')}",
                _ => throw new ArgumentOutOfRangeException(nameof(setting))
            };
        }

        private static string Run(string script)
        {
            var result = ShellRunner.PowerShellAsync("$ErrorActionPreference='Stop'\ntry {\n" + script
                + "\n} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }", null, 30000).GetAwaiter().GetResult();
            if (result.ExitCode != 0 || result.TimedOut) throw new IOException(result.Output.Trim());
            return result.Output;
        }
    }
}
