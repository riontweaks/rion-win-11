using System;
using System.Collections.Generic;
using System.Linq;

namespace RadeonSoftwareSlimmer.Optimize;

public static class TweakBundleCatalog
{
	private sealed class Definition
	{
		public string Id { get; }

		public string Title { get; }

		public string Description { get; }

		public string Section { get; }

		public string Filter { get; }

		public string[] Members { get; }

		public bool Featured { get; set; }

		public Definition(string id, string title, string description, string section, string filter, params string[] members)
		{
			Id = id;
			Title = title;
			Description = description;
			Section = section;
			Filter = filter;
			Members = members;
		}
	}

	private sealed class Built
	{
		public List<TweakBundle> Bundles { get; } = new List<TweakBundle>();

		public List<SystemTweak> Unassigned { get; } = new List<SystemTweak>();

		public List<string> MissingIds { get; } = new List<string>();
	}

	public const string MmcssSection = "MMCSS";

	public const string PerformanceSection = "Performance & power";

	public const string GraphicsSection = "Graphics & gaming";

	public const string NetworkSection = "Network & internet";

	public const string SystemSection = "Boot & system";

	public const string PrivacySection = "Privacy & background apps";

	public const string SecuritySection = "Security & protection";

	private static readonly Definition[] Definitions = new Definition[]
	{
		new Definition("bundle-power-plan", "Rion Power Plan", "Imports and activates the tuned power scheme, then puts your previous plan back on revert.", "Performance & power", "Performance", "rion-power-plan")
		{
			Featured = true
		},
		new Definition("bundle-priority-separation", "Win32 Separation Control", "Choose foreground time slices or background scheduling. Adjust shows each value; Restore recovers your original state.", "Performance & power", "Performance", "priority-separation"),
		new Definition("bundle-cpu-power", "Background power throttling", "Disables background power throttling. Power consumption and heat can increase.", "Performance & power", "Performance", "power-throttling-off"),
        new Definition("bundle-qol", "Quality of life", "Simplify Windows appearance, Start and taskbar; control syncing and supported AI features. Snipping Tool stays available.", "Quality of life", "Quality of life", "menu-show-delay", "min-animate-off", "qol-taskbar-animations", "qol-dark-apps", "qol-dark-windows", "qol-transparency", "qol-search-hidden", "qol-task-view", "qol-start-recommendations", "qol-start-recent-apps", "qol-onedrive", "qol-recall", "qol-copilot-legacy", "qol-disablecocreator", "qol-disableimagecreator", "qol-disablegenerativefill", "widgets-off", "search-highlights-off"),
		new Definition("bundle-verbose-status", "Detailed startup messages", "Shows diagnostic messages during startup and shutdown.", "Boot & system", "System", "verbose-status"),
		new Definition("bundle-usb-memory", "USB power & memory compression", "Stops Windows suspending idle USB devices and turns off in-memory page compression.", "Performance & power", "Performance", "usb-selective-suspend-off", "basic-memory-compression-off"),
		new Definition("bundle-hags", "Hardware-accelerated GPU scheduling", "Requests GPU hardware scheduling. Availability and results depend on the GPU, driver and game.", "Graphics & gaming", "Graphics", "hags-on"),
		new Definition("bundle-game-capture", "Game recording & capture", "Turns off background Game DVR recording, the capture policy and app capture.", "Graphics & gaming", "Graphics", "gamedvr-store-off", "gamedvr-policy-off", "appcapture-off"),
		new Definition("bundle-tdr", "GPU recovery timeout (TDR)", "Restores timeout overrides saved by older Rion versions. New overrides are disabled.", "Graphics & gaming", "Graphics", "tdr-delay"),
		new Definition("bundle-tcp-autotuning", "TCP receive-window auto-tuning", "Returns receive-window auto-tuning to normal and enables Winsock send auto-tuning.", "Network & internet", "Network", "basic-tcp-autotuning-normal", "net-winsock-autotuning"),
		new Definition("bundle-tcp-cubic", "CUBIC congestion control", "Sets CUBIC as the TCP congestion provider. Alternative to BBR2 — only one can be active.", "Network & internet", "Network", "basic-tcp-cubic"),
		new Definition("bundle-tcp-bbr2", "BBR2 congestion control", "Sets BBR2 as the TCP congestion provider. Alternative to CUBIC — only one can be active.", "Network & internet", "Network", "net-bbr2"),
		new Definition("bundle-socket-limits", "TCP socket reuse", "Shortens TIME_WAIT for diagnosed TCP port exhaustion. Does not reduce UDP game ping.", "Network & internet", "Network", "net-timed-wait-delay"),
		new Definition("bundle-net-throttling", "Throttling & acknowledgment delay", "Restores saved legacy network overrides. These are not supported gaming-latency presets.", "Network & internet", "Network", "network-throttling-off", "nagle-off"),
		new Definition("bundle-net-addressing", "IPv4 preference", "Prefers IPv4 for diagnosed routing problems while leaving IPv6 enabled.", "Network & internet", "Network", "net-prefer-ipv4"),
		new Definition("bundle-delivery-optimization", "Windows Update peer transfers", "Stops Windows Update uploading and downloading updates through other PCs.", "Network & internet", "Network", "delivery-optimization-no-peers"),
		new Definition("bundle-vbs-recovery", "Virtualisation security recovery", "Reads Core Isolation configuration changed by older tweak scripts.", "Boot & system", "System", "vbs-hvci-off"),
		new Definition("bundle-scheduling-recovery", "Legacy scheduling recovery", "Inspect and restore the older core-parking shortcut. Use Power Settings for supported parking controls.", "Performance & power", "Performance", "core-parking-off"),
		new Definition("bundle-network-recovery", "Legacy network recovery", "Inspect and restore saved port-ceiling and weak-host overrides.", "Network & internet", "Network", "net-max-user-port", "net-weak-host"),
		new Definition("bundle-edge-graphics", "Edge graphics acceleration", "Turns off Edge graphics acceleration for a diagnosed rendering problem; CPU use may increase.", "Boot & system", "System", "edge-hardware-acceleration-off"),
		new Definition("bundle-edge", "Microsoft Edge behaviour", "Controls idle tabs, startup boost, background apps and browsing personalisation.", "Boot & system", "System", "edge-sleeping-tabs", "edge-startup-boost-off", "edge-background-mode-off", "edge-personalization-off"),
		new Definition("bundle-spotlight", "Windows Spotlight & suggested content", "Stops Settings suggestions, suggestion notifications and the welcome tour after feature updates.", "Boot & system", "System", "spotlight-settings-off", "spotlight-notifications-off", "spotlight-welcome-off"),
		new Definition("bundle-sync-paths", "Settings sync & long paths", "Stops syncing Windows settings across devices and lifts the 260-character file path limit.", "Boot & system", "System", "cloud-sync-off", "win32-long-paths"),
		new Definition("bundle-diagnostic-data", "Diagnostic data", "Sets diagnostic data to the lowest level Windows accepts and stops error reports being sent.", "Privacy & background apps", "Security", "telemetry-min", "error-reporting-off"),
		new Definition("bundle-ceip", "Customer Experience Improvement Program", "Disables Windows CEIP reporting.", "Privacy & background apps", "System", "ceip-off"),
		new Definition("bundle-legacy-app-policies", "Legacy application policy recovery", "Restores saved App-V, Internet Explorer, Messenger and MSDeploy overrides.", "Privacy & background apps", "System", "appv-ceip-off", "melody-disablecustomerimprovementprogram", "melody-ceip", "melody-enabletelemetry"),
		new Definition("bundle-appcompat", "Application compatibility telemetry", "Turns off Application Impact Telemetry and the AppCompat inventory collector.", "Privacy & background apps", "Security", "appcompat-ait-off", "appcompat-inventory-off"),
		new Definition("bundle-ads", "Personalised ads & tailored experiences", "Clears the per-user advertising ID and stops Windows tailoring content from your diagnostic data.", "Privacy & background apps", "Security", "advertising-id-off", "tailored-experiences-off"),
		new Definition("bundle-telemetry-hardening", "Telemetry hardening", "Stops feedback prompts, keeps the device name out of diagnostic uploads and blocks OneSettings downloads.", "Security & protection", "Security", "telemetry-feedback-off", "telemetry-devicename-off", "telemetry-onesettings-off"),
		new Definition("bundle-promoted-apps", "Promoted apps & silent installs", "Stops Windows adding sponsored apps and installing suggested ones in the background.", "Security & protection", "Security", "consumer-features-off", "cdm-silent-apps-off"),
		new Definition("bundle-suggestions", "Start menu & lock screen suggestions", "Hides Start recommendations, lock-screen tips, soft-landing prompts and account-based ads.", "Security & protection", "Security", "cdm-start-suggestions-off", "cdm-tips-off", "cloudcontent-soft-landing-off", "cloudcontent-account-state-off"),
		new Definition("bundle-launch-tracking", "App launch tracking", "Stops Explorer recording which apps you open to rank Start and search results.", "Security & protection", "Security", "start-track-progs-off"),
		new Definition("bundle-amd-telemetry", "AMD driver telemetry", "Restores saved AMD telemetry overrides. Their effect in current drivers is unverified.", "Security & protection", "Security", "amd-telemetry-off", "amd-collectgi-off")
	};

	private static readonly Lazy<Built> Result = new Lazy<Built>(Build);

	public static IReadOnlyList<string> Sections { get; } = new string[] { "Quality of life", "Performance & power", "MMCSS", "Graphics & gaming", "Network & internet", "Boot & system", "Privacy & background apps", "Security & protection" };

	public static IReadOnlyList<SystemTweak> Source { get; } = (from g in GeneralTweakCatalog.All.Concat(NetworkTweakCatalog.All).Concat(ResearchedTweakCatalog.Network).GroupBy<SystemTweak, string>((SystemTweak t) => t.Id, StringComparer.Ordinal)
		select g.First()).ToList();

	public static IReadOnlyList<TweakBundle> All => Result.Value.Bundles;

	public static IReadOnlyList<SystemTweak> Unassigned => Result.Value.Unassigned;

	public static IReadOnlyList<string> MissingIds => Result.Value.MissingIds;

	public static int TweakCount => All.Sum((TweakBundle b) => b.Count);

	private static Built Build()
	{
		Built built = new Built();
		Dictionary<string, SystemTweak> dictionary = Source.ToDictionary<SystemTweak, string>((SystemTweak t) => t.Id, StringComparer.Ordinal);
		HashSet<string> claimed = new HashSet<string>(StringComparer.Ordinal);
		Definition[] definitions = Definitions;
		string[] members;
		foreach (Definition definition in definitions)
		{
			List<SystemTweak> list = new List<SystemTweak>();
			members = definition.Members;
			foreach (string text in members)
			{
				if (!dictionary.TryGetValue(text, out var value))
				{
					built.MissingIds.Add(text);
				}
				else if (claimed.Add(text))
				{
					list.Add(value);
				}
			}
			if (list.Count != 0)
			{
				built.Bundles.Add(new TweakBundle(definition.Id, definition.Title, definition.Description, definition.Section, definition.Filter, list)
				{
					IsFeatured = definition.Featured
				});
			}
		}
		foreach (string taskName in MultimediaTweakCatalog.TaskNames)
		{
			string prefix = "mmcss-" + MultimediaTweakCatalog.TaskId(taskName) + "-";
			List<SystemTweak> list2 = Source.Where((SystemTweak t) => t.Id.StartsWith(prefix, StringComparison.Ordinal)).ToList();
			foreach (SystemTweak item in list2)
			{
				claimed.Add(item.Id);
			}
			built.Bundles.Add(new TweakBundle("bundle-" + prefix.TrimEnd('-'), "MMCSS · " + taskName, "Adjust scheduling only for threads that explicitly register with the " + taskName + " task.", "MMCSS", "MMCSS", list2));
		}
		members = new string[2] { "system-responsiveness", "graphics-mpo-off" };
		foreach (string text2 in members)
		{
			SystemTweak systemTweak = dictionary[text2];
			claimed.Add(text2);
			built.Bundles.Add(new TweakBundle("bundle-" + text2, systemTweak.Title, systemTweak.Summary, (systemTweak.Category == TweakCategory.Graphics) ? "Graphics & gaming" : "MMCSS", (systemTweak.Category == TweakCategory.Graphics) ? "Graphics" : "MMCSS", new SystemTweak[1] { systemTweak }));
		}
		foreach (SystemTweak item2 in Source.Where((SystemTweak t) => !claimed.Contains(t.Id)))
		{
			built.Unassigned.Add(item2);
			built.Bundles.Add(new TweakBundle("bundle-single-" + item2.Id, item2.Title, item2.Summary, SectionFallback(item2), item2.Group == QualityOfLifeCatalog.Section ? QualityOfLifeCatalog.Section : item2.Category.ToString(), new SystemTweak[1] { item2 }));
		}
		return built;
	}

	private static string SectionFallback(SystemTweak tweak)
	{
		if (tweak.Group == QualityOfLifeCatalog.Section) return QualityOfLifeCatalog.Section;
		string text = TweakSections.For(tweak);
		if (!Sections.Contains(text))
		{
			return "Boot & system";
		}
		return text;
	}

	public static IEnumerable<TweakBundle> InSection(string section)
	{
		return All.Where((TweakBundle b) => b.Section == section);
	}
}
