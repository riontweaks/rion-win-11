using System;
using System.Threading;
using System.Threading.Tasks;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>
    /// Clears "allow the computer to turn off this device to save power" for HID devices (keyboards,
    /// mice, game controllers), USB hubs and USB input devices, and disables the USB selective-suspend
    /// setting in the active power plan. The global services\USB\DisableSelectiveSuspend switch is
    /// handled by the tweak catalog; this covers the per-device flags Windows also honours.
    /// </summary>
    public static class UsbPowerRunner
    {
        public static async Task<(int devicesChanged, bool planChanged, string note)> RunAsync(
            Action<string> onLine, CancellationToken ct)
        {
            int changed = 0;
            bool planChanged = false;

            // 1. Per-device: MSPower_DeviceEnable (root\wmi) toggled off = "don't power-manage this device".
            string script = @"
$targets = @('USB','HIDClass','Mouse','Keyboard','Bluetooth')
$count = 0
try {
  $pdo  = Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceEnable -ErrorAction Stop
  $wpdo = Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceWakeEnable -ErrorAction SilentlyContinue
} catch { $pdo = @() }

foreach ($d in $pdo) {
  try {
    $inst = $d.InstanceName
    $pnp  = Get-PnpDevice -InstanceId ($inst -replace '_0$','') -ErrorAction SilentlyContinue | Select-Object -First 1
    $cls  = $pnp.Class
    if (-not $cls) { if ($inst -notmatch 'USB\\|HID\\') { continue } }
    elseif ($targets -notcontains $cls) { continue }
    if ($d.Enable -eq $true) {
      $d | Set-CimInstance -Property @{ Enable = $false } -ErrorAction Stop
      $count++
      Write-Output ""OFF`t$inst""
    }
  } catch { Write-Output ""ERR`t$($d.InstanceName)`t$($_.Exception.Message)"" }
}
Write-Output ""COUNT`t$count""
";
            var res = await ShellRunner.PowerShellAsync(script, line =>
            {
                string[] p = line.Split('\t');
                if (p.Length >= 1 && p[0] == "OFF") { changed++; onLine?.Invoke("USB power management off for " + (p.Length > 1 ? p[1] : "a device")); }
                else if (p.Length >= 1 && p[0] == "COUNT") { onLine?.Invoke("Cleared USB power management on " + (p.Length > 1 ? p[1] : "0") + " device(s)"); }
            }, timeoutMs: 3 * 60 * 1000, ct: ct).ConfigureAwait(false);

            // 2. Active power plan: USB selective suspend = Disabled (AC + DC).
            try
            {
                const string sub = "2a737441-1930-4402-8d77-b2bebba308a3"; // USB settings
                const string setting = "48e6b7a6-50f5-4782-a5d4-53bb8f07e226"; // USB selective suspend
                await ShellRunner.RunAsync("powercfg", $"/setacvalueindex SCHEME_CURRENT {sub} {setting} 0", _ => { }, 20000, ct).ConfigureAwait(false);
                await ShellRunner.RunAsync("powercfg", $"/setdcvalueindex SCHEME_CURRENT {sub} {setting} 0", _ => { }, 20000, ct).ConfigureAwait(false);
                var apply = await ShellRunner.RunAsync("powercfg", "/setactive SCHEME_CURRENT", _ => { }, 20000, ct).ConfigureAwait(false);
                planChanged = apply.ExitCode == 0;
                if (planChanged) onLine?.Invoke("Power plan: USB selective suspend disabled.");
            }
            catch (Exception ex) { onLine?.Invoke("Could not update the power plan USB setting: " + ex.Message); }

            string note = $"{changed} device(s), power plan " + (planChanged ? "updated" : "unchanged");
            return (changed, planChanged, note);
        }
    }
}
