using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Runs SFC then DISM RestoreHealth, streaming their output. Long-running.</summary>
    public static class SystemHealthRunner
    {
        public sealed class Outcome
        {
            public System.Collections.Generic.List<string> Failures { get; } = new();
            public bool SfcFoundIssues { get; set; }
            public bool SfcRepaired { get; set; }
            public bool DismRepaired { get; set; }
            public bool NeedsReboot { get; set; }
            public string Summary { get; set; }
        }

        public static async Task<Outcome> RunAsync(Action<string> onLine, CancellationToken ct)
        {
            var outcome = new Outcome();
            string sysDir = Environment.GetFolderPath(Environment.SpecialFolder.System);

            onLine?.Invoke("Running SFC /scannow (this can take several minutes)…");
            var sfc = await ShellRunner.RunAsync(Path.Combine(sysDir, "sfc.exe"), "/scannow",
                l => onLine?.Invoke(l), timeoutMs: 30 * 60 * 1000, ct: ct).ConfigureAwait(false);

            string sfcOut = sfc.Output ?? "";
            ct.ThrowIfCancellationRequested();
            if (sfc.TimedOut || sfc.ExitCode != 0) outcome.Failures.Add("SFC did not complete successfully (exit " + sfc.ExitCode + ").");
            if (sfcOut.IndexOf("did not find any integrity violations", StringComparison.OrdinalIgnoreCase) >= 0)
                onLine?.Invoke("SFC: no integrity violations.");
            else if (sfcOut.IndexOf("successfully repaired", StringComparison.OrdinalIgnoreCase) >= 0)
            { outcome.SfcFoundIssues = outcome.SfcRepaired = outcome.NeedsReboot = true; onLine?.Invoke("SFC: repaired corrupted files — a restart is recommended."); }
            else if (sfcOut.IndexOf("unable to fix", StringComparison.OrdinalIgnoreCase) >= 0)
            { outcome.SfcFoundIssues = true; onLine?.Invoke("SFC: found issues it could not fix — DISM will try next."); }
            else outcome.Failures.Add("SFC result could not be classified. Review its output; no clean-state claim was made.");

            onLine?.Invoke("Running DISM /Online /Cleanup-Image /RestoreHealth…");
            var dism = await ShellRunner.RunAsync(Path.Combine(sysDir, "Dism.exe"),
                "/Online /Cleanup-Image /RestoreHealth",
                l => onLine?.Invoke(l), timeoutMs: 40 * 60 * 1000, ct: ct).ConfigureAwait(false);

            string dismOut = dism.Output ?? "";
            ct.ThrowIfCancellationRequested();
            if (dism.TimedOut || dism.ExitCode is not (0 or 3010)) outcome.Failures.Add("DISM did not complete successfully (exit " + dism.ExitCode + ").");
            if (dism.ExitCode == 3010) outcome.NeedsReboot = true;
            if (dismOut.IndexOf("The restore operation completed successfully", StringComparison.OrdinalIgnoreCase) >= 0
                || dismOut.IndexOf("completed successfully", StringComparison.OrdinalIgnoreCase) >= 0)
                onLine?.Invoke("DISM: component store is healthy / repaired.");
            else if (dism.ExitCode != 0)
                onLine?.Invoke("DISM exited with code " + dism.ExitCode + " — see the log.");

            if (outcome.SfcFoundIssues && outcome.SfcRepaired == false)
            {
                onLine?.Invoke("Re-running SFC after DISM…");
                var sfc2 = await ShellRunner.RunAsync(Path.Combine(sysDir, "sfc.exe"), "/scannow",
                    l => onLine?.Invoke(l), timeoutMs: 30 * 60 * 1000, ct: ct).ConfigureAwait(false);
                ct.ThrowIfCancellationRequested();
                if (sfc2.TimedOut || sfc2.ExitCode != 0) outcome.Failures.Add("SFC recheck did not complete.");
                if ((sfc2.Output ?? "").IndexOf("successfully repaired", StringComparison.OrdinalIgnoreCase) >= 0)
                { outcome.SfcRepaired = outcome.DismRepaired = outcome.NeedsReboot = true; }
                else if ((sfc2.Output ?? "").IndexOf("did not find any integrity violations", StringComparison.OrdinalIgnoreCase) >= 0)
                    outcome.SfcFoundIssues = false;
            }

            if (outcome.SfcFoundIssues && !outcome.SfcRepaired) outcome.Failures.Add("SFC reported issues that were not confirmed repaired.");
            outcome.Summary = outcome.Failures.Count > 0 ? "Windows checks need attention; review the results."
                : outcome.SfcRepaired || outcome.DismRepaired
                ? "Repaired corrupted system files — restart recommended."
                : outcome.SfcFoundIssues
                    ? "Found issues; check the CBS log if problems persist."
                    : "No system-file corruption found.";
            return outcome;
        }
    }
}
