using System;
using System.Collections.Generic;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Reviewed imports, excluding protection-weakening registry policies.
    /// Existing targets retain their original catalog identity; source text is never executed.</summary>
    public static class OptimizerImportCatalog
    {
        public static IReadOnlyList<SystemTweak> All { get; } = new[]
        {
            new SystemTweak
            {
                Id = "appv-ceip-off",
                ApplyBlockedReason = "This legacy component policy has no validated Windows 11 optimization benefit. New writes are disabled; saved values can still be restored.",
                Title = "Disable App-V customer experience reporting",
                Group = "Telemetry",
                Category = TweakCategory.System,
                Summary = "Disables customer experience reporting for an installed App-V client. The stored configuration is inspected; running behavior may differ.",
                TradeOff = "Only applies when App-V is installed. Does not turn off Windows diagnostic data or promise lower background load.",
                Grade = TweakGrade.A,
                Source = "https://github.com/SheMelody/win11-basic-optimizer/blob/main/win11_basic_optimizer_v8.bat",
                SourceCommand = "reg add \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\AppV\\CEIP\" /v \"CEIPEnable\" /t REG_DWORD /d 0 /f",
                ManualOnly = true,
                SecuritySensitive = false,
                KeyPath = "SOFTWARE\\Policies\\Microsoft\\AppV\\CEIP",
                ValueName = "CEIPEnable",
                VerificationNote = "Stored configuration verified; this does not prove an effective security or performance change.",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 0,
            },
            new SystemTweak
            {
                Id = "melody-disablecustomerimprovementprogram",
                ApplyBlockedReason = "This legacy component policy has no validated Windows 11 optimization benefit. New writes are disabled; saved values can still be restored.",
                Title = "Internet Explorer CEIP policy",
                Group = "Telemetry",
                Category = TweakCategory.System,
                Summary = "Writes DisableCustomerImprovementProgram=0 exactly as supplied in Melody's v8 script. The stored configuration is inspected; running behavior may differ.",
                TradeOff = "A component-specific privacy policy. Legacy components may ignore it or be absent. The source's asserted inverted value meanings are unverified; the exact requested number is shown.",
                Grade = TweakGrade.C,
                Source = "https://github.com/SheMelody/win11-basic-optimizer/blob/main/win11_basic_optimizer_v8.bat",
                SourceCommand = "reg add \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Internet Explorer\\SQM\" /v \"DisableCustomerImprovementProgram\" /t REG_DWORD /d 0 /f",
                ManualOnly = true,
                SecuritySensitive = false,
                KeyPath = "SOFTWARE\\Policies\\Microsoft\\Internet Explorer\\SQM",
                ValueName = "DisableCustomerImprovementProgram",
                VerificationNote = "Stored configuration verified; this does not prove an effective security or performance change.",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 0,
            },
            new SystemTweak
            {
                Id = "melody-ceip",
                ApplyBlockedReason = "This legacy component policy has no validated Windows 11 optimization benefit. New writes are disabled; saved values can still be restored.",
                Title = "Messenger CEIP policy",
                Group = "Telemetry",
                Category = TweakCategory.System,
                Summary = "Writes CEIP=2 exactly as supplied in Melody's v8 script. The stored configuration is inspected; running behavior may differ.",
                TradeOff = "A component-specific privacy policy. Legacy components may ignore it or be absent. The source's asserted inverted value meanings are unverified; the exact requested number is shown.",
                Grade = TweakGrade.C,
                Source = "https://github.com/SheMelody/win11-basic-optimizer/blob/main/win11_basic_optimizer_v8.bat",
                SourceCommand = "reg add \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Messenger\\Client\" /v \"CEIP\" /t REG_DWORD /d 2 /f",
                ManualOnly = true,
                SecuritySensitive = false,
                KeyPath = "SOFTWARE\\Policies\\Microsoft\\Messenger\\Client",
                ValueName = "CEIP",
                VerificationNote = "Stored configuration verified; this does not prove an effective security or performance change.",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 2,
            },
            new SystemTweak
            {
                Id = "melody-enabletelemetry",
                ApplyBlockedReason = "This legacy component policy has no validated Windows 11 optimization benefit. New writes are disabled; saved values can still be restored.",
                Title = "MSDeploy telemetry policy",
                Group = "Telemetry",
                Category = TweakCategory.System,
                Summary = "Writes EnableTelemetry=1 exactly as supplied in Melody's v8 script. The stored configuration is inspected; running behavior may differ.",
                TradeOff = "A component-specific privacy policy. Legacy components may ignore it or be absent. The source's asserted inverted value meanings are unverified; the exact requested number is shown.",
                Grade = TweakGrade.C,
                Source = "https://github.com/SheMelody/win11-basic-optimizer/blob/main/win11_basic_optimizer_v8.bat",
                SourceCommand = "reg add \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MSDeploy\\3\" /v \"EnableTelemetry\" /t REG_DWORD /d 1 /f",
                ManualOnly = true,
                SecuritySensitive = false,
                KeyPath = "SOFTWARE\\Policies\\Microsoft\\MSDeploy\\3",
                ValueName = "EnableTelemetry",
                VerificationNote = "Stored configuration verified; this does not prove an effective security or performance change.",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 1,
            },
            new SystemTweak
            {
                Id = "error-reporting-off",
                Title = "Disable Windows Error Reporting",
                Group = "Telemetry",
                Category = TweakCategory.System,
                Summary = "Disables Windows Error Reporting through its machine policy. The stored configuration is inspected; running behavior may differ.",
                TradeOff = "Crash reporting and suggested solutions become unavailable; troubleshooting loses diagnostic information.",
                Grade = TweakGrade.A,
                Source = "https://github.com/SheMelody/win11-basic-optimizer/blob/main/win11_basic_optimizer_v8.bat",
                SourceCommand = "reg add \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting\" /v \"Disabled\" /t REG_DWORD /d 1 /f",
                ManualOnly = true,
                SecuritySensitive = false,
                KeyPath = "SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting",
                ValueName = "Disabled",
                VerificationNote = "Stored configuration verified; this does not prove an effective security or performance change.",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 1,
            },
            Command("net-bbr2", "Use BBR2 TCP congestion control", "TCP Congestion Control", "Changes the Internet TCP template to BBR2 when Windows accepts that provider.", "Build-dependent and experimental for some workloads. Does not directly reduce UDP game ping. The original provider is captured and restored.", "netsh int tcp set supplemental internet congestionprovider=bbr2", new JValue("bbr2")),
            Command("net-weak-host", "Enable weak host send and receive on all adapters", "Weak Host Model", "Enables the weak host model for existing adapters, including hidden adapters, in IPv4 and IPv6.", "Changes interface isolation and routing behavior; may affect VPNs and connectivity. Each adapter GUID, address family and policy store is captured. Unlike the source script, errors are reported.", "powershell \"Get-NetAdapter -IncludeHidden | Set-NetIPInterface -WeakHostSend Enabled -WeakHostReceive Enabled -ErrorAction SilentlyContinue\"", new JObject { ["Send"] = "Enabled", ["Receive"] = "Enabled" }),
            Command("net-winsock-autotuning", "Enable Winsock send autotuning", "Winsock Autotuning", "Enables dynamic Winsock send buffering.", "A throughput-related setting, separate from TCP receive-window autotuning. Exact inspection must succeed before changing it; no game-latency improvement is promised.", "netsh winsock set autotuning on", new JValue("on")),
        };

        private static SystemTweak Command(string id, string title, string group, string summary, string cost, string sourceCommand, JToken target)
        {
            var state = new OptimizerCommandState(id, target);
            return new SystemTweak
            {
                Id = id, Title = title, Group = group, Summary = summary, TradeOff = cost,
                Category = id.StartsWith("net-", StringComparison.Ordinal) ? TweakCategory.Performance : TweakCategory.Security,
                Grade = TweakGrade.C, ManualOnly = true, SecuritySensitive = id != "net-winsock-autotuning",
                RebootRequired = false, DeferInitialInspection = true, InspectOnLoad = true,
                Source = "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh",
                ApplyBlockedReason = id == "net-weak-host" ? "Enabling weak-host routing on every adapter is not a general optimization and can change interface isolation. Only saved-state restoration is available." : state.IsRetired
                    ? "Retired security/boot override. Only inspection and restoration of saved state are available." : null,
                SourceCommand = sourceCommand,
                CustomApply = state.Apply,
                CustomRevert = state.Restore,
                InspectCommandState = state.Inspect, HasSavedState = state.HasSavedState,
            };
        }

        public static string GroupFor(SystemTweak tweak)
        {
            if (!string.IsNullOrEmpty(tweak.Group)) return tweak.Group;
            switch (tweak.Id)
            {
                case "ceip-off": return "Telemetry";
                case "appcompat-ait-off": return "Telemetry";
                case "appcompat-inventory-off": return "Telemetry";
                case "telemetry-min": return "Telemetry";
                case "hags-on": return "Hardware-Accelerated Scheduling";
                default: return tweak.Category.ToString();
            }
        }
    }
}
