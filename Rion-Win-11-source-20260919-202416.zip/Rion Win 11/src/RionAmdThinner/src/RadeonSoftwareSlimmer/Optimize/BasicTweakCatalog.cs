using System.Collections.Generic;

namespace RadeonSoftwareSlimmer.Optimize
{
    public static class BasicTweakCatalog
    {
        public static IReadOnlyList<SystemTweak> All { get; } = Create(BasicSettingControl.CreateWindows());

        internal static IReadOnlyList<SystemTweak> Create(BasicSettingControl control) => new[]
        {
            Command(control, BasicSetting.MemoryCompression, "basic-memory-compression-off", "Disable memory compression", "Memory",
                "Disables Windows memory compression. Switch off to restore the configuration saved before applying this tweak.",
                "Optional troubleshooting choice. Can increase RAM use and paging; no general performance gain is established. Restart Windows after changing.",
                "https://learn.microsoft.com/en-us/powershell/module/mmagent/disable-mmagent", true),
            Command(control, BasicSetting.TcpAutoTuning, "basic-tcp-autotuning-normal", "Normal TCP receive-window auto-tuning", "Network",
                "Sets receive-window auto-tuning to Normal for the Internet TCP template. Can recover throughput after restrictive overrides.",
                "Does not promise lower gaming latency. Respects organization policy. Switch off to restore the exact previous configured level.",
                "https://learn.microsoft.com/en-us/powershell/module/nettcpip/set-nettcpsetting", false),
            Command(control, BasicSetting.TcpCongestion, "basic-tcp-cubic", "CUBIC TCP congestion control", "Network",
                "Selects CUBIC for the Internet TCP template using the supported Windows command. Switch off to restore the previous provider.",
                "Throughput depends on the network path. No effect on UDP game traffic. Reconnect applications after changing; other TCP templates are unchanged.",
                "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-interface", false),
            new SystemTweak
            {
                Id = "verbose-status", Title = "Detailed startup and shutdown messages",
                Summary = "Shows more detailed status messages during startup, shutdown, sign-in and sign-out. Useful for diagnosing a slow step.",
                TradeOff = "Diagnostic display only; it does not make Windows faster. The DisableStatusMessages policy can prevent these messages from appearing.",
                Category = TweakCategory.System, Group = "Diagnostics", Grade = TweakGrade.A,
                ManualOnly = true, IndividualApplyOnly = true,
                KeyPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                ValueName = "VerboseStatus", TargetValue = 1, DefaultValue = null,
                Source = "https://learn.microsoft.com/en-us/troubleshoot/windows-server/user-profiles-and-logon/enable-verbose-startup-shutdown-logon-logoff-status-messages"
            }
        };

        private static SystemTweak Command(BasicSettingControl control, BasicSetting setting, string id, string title,
            string group, string summary, string tradeOff, string source, bool reboot) => new SystemTweak
        {
            Id = id, Title = title, Group = group, Summary = summary, TradeOff = tradeOff, Source = source,
            Category = setting == BasicSetting.MemoryCompression ? TweakCategory.Performance : TweakCategory.System,
            Grade = TweakGrade.A, ManualOnly = true, IndividualApplyOnly = true, RebootRequired = reboot,
            DeferInitialInspection = true, InspectOnLoad = true,
            HasSavedState = () => control.HasSavedState(setting),
            CheckApplySupport = _ => control.Inspect(setting).UnavailableReason,
            InspectCommandState = () =>
            {
                var state = control.Inspect(setting);
                return string.IsNullOrEmpty(state.UnavailableReason) ? state.Value == BasicSettingControl.Target(setting) : (bool?)null;
            },
            CustomApply = () => { control.Apply(setting); return true; },
            CustomRevert = () => { control.Restore(setting); return true; }
        };
    }
}
