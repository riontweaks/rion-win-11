using System;
using System.Collections.Generic;
using System.Linq;

namespace RadeonSoftwareSlimmer.Optimize
{
    public sealed class SectionReport
    {
        public OptimizeSection Section { get; set; }
        public string Title { get; set; }
        public SectionState Outcome { get; set; } = SectionState.Skipped;
        public string Summary { get; set; }

        public List<string> Applied { get; } = new List<string>();
        public List<string> AlreadyOptimal { get; } = new List<string>();
        public List<string> Failed { get; } = new List<string>();
    }

    public sealed class OptimizeReport
    {
        public DateTime StartedLocal { get; } = DateTime.Now;
        public bool RestorePointCreated { get; set; }
        public string SnapshotPath { get; set; }
        public bool NeedsReboot { get; set; }
        public bool Cancelled { get; set; }

        public List<SectionReport> Sections { get; } = new List<SectionReport>();
        public List<RegistrySnapshot.DiffRow> TweakerFindings { get; } = new List<RegistrySnapshot.DiffRow>();

        public int TotalApplied => Sections.Sum(s => s.Applied.Count);
        public int TotalAlreadyOptimal => Sections.Sum(s => s.AlreadyOptimal.Count);
        public int TotalFailed => Sections.Sum(s => s.Failed.Count);

        public string Headline =>
            Cancelled ? "Cancelled — partial changes were applied and logged"
            : $"{TotalApplied} change(s) applied · {TotalAlreadyOptimal} already optimal"
              + (TotalFailed > 0 ? $" · {TotalFailed} failed" : "");
    }
}
