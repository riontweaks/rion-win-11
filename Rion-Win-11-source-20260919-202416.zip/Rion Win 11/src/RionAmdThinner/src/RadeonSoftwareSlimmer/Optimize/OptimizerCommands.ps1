$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$operationId = [string]$request.Id
$writing = $null -ne $request.State
$states = @($request.State)
$bcdTypes = @{
    'bcd-isolatedcontext' = @{ Type = [uint32]0x16000060; Property = 'Boolean'; Method = 'SetBooleanElement' }
    'bcd-allowedinmemorysettings' = @{ Type = [uint32]0x17000077; Property = 'Integers'; Method = 'SetIntegerListElement' }
    'bcd-disableelamdrivers' = @{ Type = [uint32]0x260000e1; Property = 'Boolean'; Method = 'SetBooleanElement' }
    'bcd-vsmlaunchtype' = @{ Type = [uint32]0x25000142; Property = 'Integer'; Method = 'SetIntegerElement' }
    'bcd-bootmenupolicy' = @{ Type = [uint32]0x250000c2; Property = 'Integer'; Method = 'SetIntegerElement' }
    'bcd-loadoptions' = @{ Type = [uint32]0x12000030; Property = 'String'; Method = 'SetStringElement' }
}
function Native([string]$executable, [string[]]$arguments) {
    $result = & (Join-Path $env:SystemRoot ('System32\' + $executable)) @arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw ($result -join "`n") }
    return ($result -join "`n")
}
function State([string]$identity, [bool]$exists, $value) {
    [pscustomobject]@{ Identity = $identity; Exists = $exists; Value = $value }
}
function BindBootWmi([string]$path, [bool]$isClass = $false) {
    $bound = if ($isClass) { [wmiclass]$path } else { [wmi]$path }
    $bound.PSBase.Scope.Options.EnablePrivileges = $true
    return $bound
}
function OpenBootObject {
    $bcdClass = BindBootWmi 'root\WMI:BcdStore' $true
    $opened = $bcdClass.OpenStore('')
    if (!$opened.ReturnValue) { throw 'The system BCD store could not be opened.' }
    # OpenStore/OpenObject return embedded objects without __PATH on current Windows.
    # Bind the documented key properties instead of casting an empty path.
    $store = BindBootWmi 'root\WMI:BcdStore.FilePath=""'
    # GUID_CURRENT_BOOT_ENTRY from Microsoft's BCD sample. The friendly {current}
    # alias belongs to bcdedit; WMI OpenObject requires a GUID.
    $objectResult = $store.OpenObject('{fa926493-6f1c-4193-a414-58f0b2456d1e}')
    if (!$objectResult.ReturnValue) { throw 'The current boot entry could not be resolved.' }
    $resolvedId = [guid]::Empty
    if (![guid]::TryParse([string]$objectResult.Object.Id, [ref]$resolvedId) -or $resolvedId -eq [guid]::Empty -or
        [string]$objectResult.Object.StoreFilePath -ne '') { throw 'The current system boot entry identity is invalid.' }
    $bootObject = BindBootWmi ('root\WMI:BcdObject.Id="' + $resolvedId.ToString('B') + '",StoreFilePath=""')
    return $bootObject
}
function BcdState($boot, $definition) {
    $elements = $boot.EnumerateElements()
    if (!$elements.ReturnValue) { throw 'The current boot elements could not be enumerated.' }
    $found = @($elements.Elements | Where-Object { [uint32]$_.Type -eq $definition.Type })
    if ($found.Count -gt 1) { throw 'The boot element is ambiguous.' }
    $value = $null
    if ($found.Count -eq 1) {
        $value = $found[0].($definition.Property)
        if ($definition.Property -eq 'Integers') { $value = @($value | ForEach-Object { [uint64]$_ }) }
    }
    State ([string]$boot.Id) ($found.Count -eq 1) $value
}
function ReadWeakHost {
    foreach ($adapter in @(Get-NetAdapter -IncludeHidden -ErrorAction Stop)) {
        foreach ($store in @('ActiveStore', 'PersistentStore')) {
            # Enumerating the store avoids interpreting an absent family as an access error.
            foreach ($entry in @(Get-NetIPInterface -PolicyStore $store -ErrorAction Stop | Where-Object { $_.InterfaceIndex -eq $adapter.ifIndex })) {
                $identity = ([guid]$adapter.InterfaceGuid).ToString() + '|' + [string]$entry.AddressFamily + '|' + $store
                State $identity $true ([pscustomobject]@{ Send = [string]$entry.WeakHostSend; Receive = [string]$entry.WeakHostReceive })
            }
        }
    }
}
try {
    $result = @()
    if ($bcdTypes.ContainsKey($operationId)) {
        $definition = $bcdTypes[$operationId]
        $boot = OpenBootObject
        if ($writing) {
            if ($states.Count -ne 1 -or [string]$states[0].Identity -ne [string]$boot.Id) { throw 'The current boot entry differs from the saved entry.' }
            $saved = $states[0]
            if (!$saved.Exists) {
                $now = BcdState $boot $definition
                if ($now.Exists) { $response = $boot.DeleteElement($definition.Type); if (!$response.ReturnValue) { throw 'BCD refused to remove the saved element.' } }
            } else {
                switch ($definition.Property) {
                    Boolean { $response = $boot.SetBooleanElement($definition.Type, [bool]$saved.Value) }
                    Integer { $response = $boot.SetIntegerElement($definition.Type, [uint64]$saved.Value) }
                    Integers { $response = $boot.SetIntegerListElement($definition.Type, [uint64[]]$saved.Value) }
                    String { $response = $boot.SetStringElement($definition.Type, [string]$saved.Value) }
                }
                if (!$response.ReturnValue) { throw 'Windows rejected the BCD setting. Secure Boot or platform restrictions may prevent this operation.' }
            }
        }
        $result = @(BcdState $boot $definition)
    } elseif ($operationId -eq 'net-winsock-autotuning') {
        if ($writing) {
            if ($states.Count -ne 1 -or $states[0].Identity -ne 'winsock' -or !$states[0].Exists -or $states[0].Value -notin @('on','off')) { throw 'Invalid saved Winsock state.' }
            $null = Native 'netsh.exe' @('winsock','set','autotuning',[string]$states[0].Value)
        }
        $dump = Native 'netsh.exe' @('winsock','dump')
        $autoMatches = [regex]::Matches($dump, '(?im)^\s*(?:winsock\s+)?set\s+autotuning\s+(on|off)\s*$')
        if ($autoMatches.Count -ne 1) { throw 'Winsock dump did not expose one unambiguous autotuning setting. No default was assumed.' }
        $result = @(State 'winsock' $true $autoMatches[0].Groups[1].Value.ToLowerInvariant())
    } elseif ($operationId -eq 'net-bbr2') {
        if ($writing) {
            if ($states.Count -ne 1 -or $states[0].Identity -ne 'Internet' -or !$states[0].Exists -or [string]$states[0].Value -notmatch '^[a-zA-Z0-9]+$') { throw 'Invalid saved TCP provider.' }
            $null = Native 'netsh.exe' @('int','tcp','set','supplemental','internet',('congestionprovider=' + [string]$states[0].Value))
        }
        $template = @(Get-NetTCPSetting -SettingName Internet -ErrorAction Stop)
        if ($template.Count -ne 1 -or !$template[0].CongestionProvider) { throw 'The Internet TCP template could not be captured.' }
        $result = @(State 'Internet' $true ([string]$template[0].CongestionProvider).ToLowerInvariant())
    } elseif ($operationId -eq 'net-weak-host') {
        if ($writing) {
            $adapters = @(Get-NetAdapter -IncludeHidden -ErrorAction Stop)
            # Validate every identity and value before the first write.
            foreach ($saved in $states) {
                $parts = ([string]$saved.Identity).Split('|')
                if ($parts.Count -ne 3 -or $parts[1] -notin @('IPv4','IPv6') -or $parts[2] -notin @('ActiveStore','PersistentStore') -or !$saved.Exists -or
                    $saved.Value.Send -notin @('Enabled','Disabled') -or $saved.Value.Receive -notin @('Enabled','Disabled')) { throw 'Invalid saved interface state.' }
                $found = @($adapters | Where-Object { ([guid]$_.InterfaceGuid).ToString() -eq $parts[0] })
                if ($found.Count -ne 1) { throw 'A saved adapter is missing or ambiguous.' }
            }
            foreach ($saved in @($states | Sort-Object { if ([string]$_.Identity -like '*|PersistentStore') { 0 } else { 1 } })) {
                # Persistent writes may also affect active state. Restore persistent first.
                $parts = ([string]$saved.Identity).Split('|')
                $adapter = $adapters | Where-Object { ([guid]$_.InterfaceGuid).ToString() -eq $parts[0] }
                Set-NetIPInterface -InterfaceIndex $adapter.ifIndex -AddressFamily $parts[1] -PolicyStore $parts[2] -WeakHostSend $saved.Value.Send -WeakHostReceive $saved.Value.Receive -ErrorAction Stop
            }
        }
        $result = @(ReadWeakHost)
    } else { throw 'Unknown optimizer operation.' }
    Write-Output ('RION_STATE:' + (ConvertTo-Json -InputObject @($result) -Depth 10 -Compress))
} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }
