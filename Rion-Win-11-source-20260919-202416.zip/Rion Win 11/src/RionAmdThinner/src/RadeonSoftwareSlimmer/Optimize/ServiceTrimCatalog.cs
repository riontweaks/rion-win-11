using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.Win32;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    public sealed class TrimmableService
    {
        public string Name { get; set; }
        public string Note { get; set; }
        /// <summary>2 = Automatic, 3 = Manual, 4 = Disabled.</summary>
        public int TargetStart { get; set; } = 3;
    }

    /// <summary>
    /// Curated optional Windows services set to Manual to reduce automatic startup
    /// activity when applicable. Applied by writing the service's <c>Start</c> value under
    /// HKLM\SYSTEM\CurrentControlSet\Services, captured to the backup store so it is reversible.
    /// Protected services are excluded. Manual services can still start on demand; no fixed process reduction is promised.
    /// </summary>
    public static class ServiceTrimCatalog
    {
        public static IReadOnlyList<TrimmableService> All { get; } = new List<TrimmableService>
        {
            new TrimmableService { Name = "DiagTrack",         TargetStart = 3, Note = "Connected User Experiences and Telemetry" },
            new TrimmableService { Name = "dmwappushservice",  TargetStart = 3, Note = "Device-management WAP Push message routing" },
            new TrimmableService { Name = "diagnosticshub.standardcollector.service", TargetStart = 3, Note = "Diagnostics Hub collector" },
            new TrimmableService { Name = "RetailDemo",        TargetStart = 3, Note = "Retail demo mode" },
            new TrimmableService { Name = "MapsBroker",        TargetStart = 3, Note = "Downloaded Maps Manager" },
            new TrimmableService { Name = "Fax",               TargetStart = 3, Note = "Fax" },
            new TrimmableService { Name = "RemoteRegistry",    TargetStart = 3, Note = "Remote Registry (already disabled by default; kept in case)" },
            new TrimmableService { Name = "WMPNetworkSvc",     TargetStart = 3, Note = "Windows Media Player network sharing" },
            new TrimmableService { Name = "WalletService",     TargetStart = 3, Note = "Wallet" },
            new TrimmableService { Name = "PhoneSvc",          TargetStart = 3, Note = "Phone telephony (VOIP on this PC)" },
            new TrimmableService { Name = "MessagingService",  TargetStart = 3, Note = "Text messaging" },
            new TrimmableService { Name = "SEMgrSvc",          TargetStart = 3, Note = "Payments and NFC/SE Manager" },
            new TrimmableService { Name = "XblGameSave",       TargetStart = 3, Note = "Xbox Live game save on demand" },
            new TrimmableService { Name = "XboxNetApiSvc",     TargetStart = 3, Note = "Xbox Live networking" },
            new TrimmableService { Name = "PcaSvc",            TargetStart = 3, Note = "Program Compatibility Assistant" },
            new TrimmableService { Name = "WbioSrvc",          TargetStart = 3, Note = "Windows Biometric (only if you don't use fingerprint/face sign-in)" },
            new TrimmableService { Name = "WerSvc",            TargetStart = 3, Note = "Windows Error Reporting" },
            new TrimmableService { Name = "wisvc",             TargetStart = 3, Note = "Windows Insider Program (not on Insider builds)" },
            new TrimmableService { Name = "lfsvc",             TargetStart = 3, Note = "Geolocation (apps requesting location start it on demand)" },
            new TrimmableService { Name = "TrkWks",            TargetStart = 3, Note = "Distributed Link Tracking Client" },
            new TrimmableService { Name = "PimIndexMaintenanceSvc", TargetStart = 3, Note = "Contact data indexing" },
            new TrimmableService { Name = "OneSyncSvc",        TargetStart = 3, Note = "Sync host for Mail / Calendar / People (starts on demand)" },
            new TrimmableService { Name = "CDPUserSvc",        TargetStart = 3, Note = "Connected Devices Platform (per user)" },
            new TrimmableService { Name = "DsSvc",             TargetStart = 3, Note = "Data Sharing Service" },
            new TrimmableService { Name = "WpcMonSvc",         TargetStart = 3, Note = "Parental Controls" },
            new TrimmableService { Name = "AJRouter",          TargetStart = 3, Note = "AllJoyn Router" },
            new TrimmableService { Name = "SCardSvr",          TargetStart = 3, Note = "Smart Card" },
            new TrimmableService { Name = "ScDeviceEnum",      TargetStart = 3, Note = "Smart Card Device Enumeration" },
            new TrimmableService { Name = "stisvc",            TargetStart = 3, Note = "Windows Image Acquisition (scanners / some cameras)" },
            new TrimmableService { Name = "TapiSrv",           TargetStart = 3, Note = "Telephony" },
            new TrimmableService { Name = "SharedRealitySvc",  TargetStart = 3, Note = "Spatial Data Service (Mixed Reality)" },
            new TrimmableService { Name = "SysMain",           TargetStart = 3, Note = "SysMain / Superfetch (minimal benefit on an SSD)" },

            // discovery / UPnP / peer networking — start on demand when something actually needs them
            new TrimmableService { Name = "SSDPSRV",           TargetStart = 3, Note = "SSDP Discovery (UPnP)" },
            new TrimmableService { Name = "upnphost",          TargetStart = 3, Note = "UPnP Device Host" },
            new TrimmableService { Name = "fdPHost",           TargetStart = 3, Note = "Function Discovery Provider Host" },
            new TrimmableService { Name = "FDResPub",          TargetStart = 3, Note = "Function Discovery Resource Publication" },
            new TrimmableService { Name = "lltdsvc",           TargetStart = 3, Note = "Link-Layer Topology Discovery (network map)" },
            new TrimmableService { Name = "p2psvc",            TargetStart = 3, Note = "Peer Networking Grouping" },
            new TrimmableService { Name = "p2pimsvc",          TargetStart = 3, Note = "Peer Networking Identity Manager" },
            new TrimmableService { Name = "PNRPsvc",           TargetStart = 3, Note = "Peer Name Resolution Protocol" },
            new TrimmableService { Name = "PNRPAutoReg",       TargetStart = 3, Note = "PNRP Machine Name Publication" },
            new TrimmableService { Name = "WFDSConMgrSvc",     TargetStart = 3, Note = "Wi-Fi Direct Services Connection Manager" },
            new TrimmableService { Name = "icssvc",            TargetStart = 3, Note = "Windows Mobile Hotspot Service" },
            new TrimmableService { Name = "SharedAccess",      TargetStart = 3, Note = "Internet Connection Sharing (ICS)" },

            // remote access / management — leave Manual so RDP still works if you turn it on
            new TrimmableService { Name = "TermService",       TargetStart = 3, Note = "Remote Desktop Services" },
            new TrimmableService { Name = "SessionEnv",        TargetStart = 3, Note = "Remote Desktop Configuration" },
            new TrimmableService { Name = "UmRdpService",      TargetStart = 3, Note = "Remote Desktop Services UserMode Port Redirector" },
            new TrimmableService { Name = "WinRM",             TargetStart = 3, Note = "Windows Remote Management" },
            new TrimmableService { Name = "RemoteAccess",      TargetStart = 3, Note = "Routing and Remote Access" },

            // diagnostics / legacy / enterprise
            new TrimmableService { Name = "DPS",               TargetStart = 3, Note = "Diagnostic Policy Service" },
            new TrimmableService { Name = "WdiServiceHost",    TargetStart = 3, Note = "Diagnostic Service Host" },
            new TrimmableService { Name = "WdiSystemHost",     TargetStart = 3, Note = "Diagnostic System Host" },
            new TrimmableService { Name = "wercplsupport",     TargetStart = 3, Note = "Problem Reports control panel support" },
            new TrimmableService { Name = "dot3svc",           TargetStart = 3, Note = "Wired AutoConfig (802.1X)" },
            new TrimmableService { Name = "AxInstSV",          TargetStart = 3, Note = "ActiveX Installer" },
            new TrimmableService { Name = "wcncsvc",           TargetStart = 3, Note = "Windows Connect Now" },
            new TrimmableService { Name = "SNMPTRAP",          TargetStart = 3, Note = "SNMP Trap" },
            new TrimmableService { Name = "PrintNotify",       TargetStart = 3, Note = "Printer Extensions and Notifications" },
            new TrimmableService { Name = "CscService",        TargetStart = 3, Note = "Offline Files" },
            new TrimmableService { Name = "SDRSVC",            TargetStart = 3, Note = "Windows Backup" },
            new TrimmableService { Name = "PushToInstall",     TargetStart = 3, Note = "Windows PushToInstall (remote Store installs)" },
            new TrimmableService { Name = "EntAppSvc",         TargetStart = 3, Note = "Enterprise App Management" },
            new TrimmableService { Name = "AppVClient",        TargetStart = 3, Note = "Microsoft App-V Client (enterprise)" },
            new TrimmableService { Name = "UevAgentService",   TargetStart = 3, Note = "User Experience Virtualization (enterprise)" },
            new TrimmableService { Name = "shpamsvc",          TargetStart = 3, Note = "Shared PC Account Manager" },
            new TrimmableService { Name = "MixedRealityOpenXRSvc", TargetStart = 3, Note = "Mixed Reality OpenXR" },
            new TrimmableService { Name = "spectrum",          TargetStart = 3, Note = "Windows Perception Service (Mixed Reality)" },
            new TrimmableService { Name = "autotimesvc",       TargetStart = 3, Note = "Cellular Time" },
            new TrimmableService { Name = "LxpSvc",            TargetStart = 3, Note = "Language Experience Service" },
            new TrimmableService { Name = "XblAuthManager", TargetStart = 3, Note = "Xbox sign-in on demand" },
            new TrimmableService { Name = "XboxGipSvc", TargetStart = 3, Note = "Xbox accessories on demand" },
            new TrimmableService { Name = "CaptureService", TargetStart = 3, Note = "Screen capture on demand" },
            new TrimmableService { Name = "BcastDVRUserService", TargetStart = 3, Note = "Game recording and broadcasting on demand" },
        };

        /// <summary>Match known templates and hexadecimal per-user suffixes, never arbitrary prefixes.</summary>
        public static IReadOnlyList<TrimmableService> MatchInstalled(IEnumerable<string> installedNames) =>
            installedNames.Distinct(StringComparer.OrdinalIgnoreCase).Select(name =>
            {
                var rule = All.FirstOrDefault(r => name.Equals(r.Name, StringComparison.OrdinalIgnoreCase)
                    || new[] { "MessagingService", "PimIndexMaintenanceSvc", "OneSyncSvc", "CDPUserSvc", "CaptureService", "BcastDVRUserService" }.Contains(r.Name)
                        && name.StartsWith(r.Name + "_", StringComparison.OrdinalIgnoreCase)
                        && name.Length > r.Name.Length + 1 && name.Substring(r.Name.Length + 1).All(Uri.IsHexDigit));
                return rule == null || ServiceProtection.Reason(name) != null ? null
                    : new TrimmableService { Name = name, Note = rule.Note, TargetStart = 3 };
            }).Where(r => r != null).ToArray();

        public static IReadOnlyList<TrimmableService> Detect(IRegistry registry)
        {
            using var key = registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services", false);
            if (key == null) throw new InvalidOperationException("Service inventory unavailable.");
            return MatchInstalled(key.GetSubKeyNames());
        }

        private const string ServicesKey = @"SYSTEM\CurrentControlSet\Services\";

        /// <summary>Human label for a Start value (2/3/4). Anything else reads back as "Unknown".</summary>
        public static string StartLabel(int start)
        {
            switch (start)
            {
                case 2: return "Automatic";
                case 3: return "Manual";
                case 4: return "Disabled";
                default: return "Unknown";
            }
        }

        /// <summary>Current Start value (2/3/4) for one service, or null if the service key/value
        /// is absent on this edition.</summary>
        public static int? GetCurrentStart(IRegistry registry, string serviceName)
        {
            try
            {
                using (IRegistryKey key = registry.LocalMachine.OpenSubKey(ServicesKey + serviceName, false))
                {
                    object v = key?.GetValue("Start", null);
                    return v == null ? (int?)null : Convert.ToInt32(v, CultureInfo.InvariantCulture);
                }
            }
            catch (Exception ex)
            {
                StaticViewModel.AddDebugMessage(ex, "Could not read Start for service " + serviceName);
                return null;
            }
        }

        /// <summary>
        /// Writes one service's Start value — the single-service unit the bulk <see cref="Apply"/>
        /// loop and the granular Services Manager UI both call. Skips (returns false) if the
        /// service is absent on this edition or already at <paramref name="newStart"/>; otherwise
        /// backs up the previous value and audit-logs the change.
        /// </summary>
        public static bool SetStart(IRegistry registry, string serviceName, int newStart, BackupSession backup, string source = "Services Manager")
        {
            if (newStart < 2 || newStart > 4 || string.IsNullOrWhiteSpace(serviceName)
                || serviceName.IndexOfAny(new[] { '\\', '/', '\0' }) >= 0) return false;
            if (!Elevation.IsElevated) return false;

            string path = ServicesKey + serviceName;
            try
            {
                using (IRegistryKey key = registry.LocalMachine.OpenSubKey(path, true))
                {
                    if (key == null) return false;

                    object cur = key.GetValue("Start", null);
                    if (cur == null) return false;

                    long current = Convert.ToInt64(cur, CultureInfo.InvariantCulture);
                    if (current < 2 || current > 4) return false; // never rewrite boot/system driver start types
                    if (current == newStart) return false;
                    // Bulk/manual trimming cannot weaken protected services. Dedicated repair
                    // and explicit feature toggles retain their own existing behavior.
                    bool trimming = source == "Auto-Optimize" || source == "Services Manager";
                    if (trimming && newStart > current && ServiceProtection.Reason(serviceName) != null) return false;
                    int serviceType = Convert.ToInt32(key.GetValue("Type", 0), CultureInfo.InvariantCulture);
                    if (trimming && (serviceType & 48) == 0) return false; // not a Win32 service
                    bool userTemplate = (serviceType & 64) != 0 && (serviceType & 128) == 0;
                    if (trimming && newStart > current && !userTemplate)
                    {
                        using (var controller = new System.ServiceProcess.ServiceController(serviceName))
                        {
                            var dependents = controller.DependentServices;
                            try { if (dependents.Length > 0) return false; }
                            finally { foreach (var dependent in dependents) dependent.Dispose(); }
                        }
                    }

                    RegistryChangeHistory.Write(backup, key, "HKLM\\" + path, "Start", true, newStart, RegistryValueKind.DWord);

                    AuditLog.Action(source, "ServiceStart", serviceName,
                        oldValue: current.ToString(CultureInfo.InvariantCulture),
                        newValue: newStart.ToString(CultureInfo.InvariantCulture),
                        result: "OK", reversible: true);
                    StaticViewModel.AddLogMessage($"Service {serviceName} → {StartLabel(newStart)}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                StaticViewModel.AddDebugMessage(ex, "Could not set Start for service " + serviceName);
                return false;
            }
        }

        /// <summary>
        /// Applies the trim set. Returns (applied service notes, already-at-target notes). Every
        /// change writes the prior <c>Start</c> value to <paramref name="backup"/>.
        /// </summary>
        public static (List<string> applied, List<string> already, List<string> failed) Apply(
            IRegistry registry, BackupSession backup, IReadOnlyCollection<string> selectedServices = null)
        {
            var applied = new List<string>();
            var already = new List<string>();
            var failed = new List<string>();

            if (!Elevation.IsElevated)
            {
                failed.Add("administrator rights required");
                return (applied, already, failed);
            }

            IReadOnlyList<TrimmableService> detected;
            try { detected = Detect(registry); }
            catch (Exception ex) { failed.Add("Service inventory: " + ex.Message); return (applied, already, failed); }
            foreach (TrimmableService svc in detected)
            {
                if (selectedServices != null && !selectedServices.Contains(svc.Name, StringComparer.OrdinalIgnoreCase)) continue;
                if (ServiceProtection.Reason(svc.Name) != null) continue;
                int? current = GetCurrentStart(registry, svc.Name);
                if (current == null) continue; // service not present on this edition, or unreadable

                if (current == svc.TargetStart || current == 4 && svc.TargetStart == 3)
                {
                    already.Add(svc.Name + (current == 4 ? " (already disabled; preserved)" : " (Manual)"));
                    continue;
                }

                if (SetStart(registry, svc.Name, svc.TargetStart, backup, "Auto-Optimize"))
                    applied.Add(svc.Name + " → Manual (restart may be required)");
                else
                    failed.Add(svc.Name);
            }

            return (applied, already, failed);
        }
    }
}


