using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Activates the embedded plan and records the previously active scheme before changing it.</summary>
    internal static class RionPowerPlanTweak
    {
        public const string PlanDisplayName = "Rion Power Plan";
        internal static bool IsRionName(string name) => name == PlanDisplayName || name == "Rion Pro Power Plan";
        private static readonly object Sync = new object();
        private static string StateDirectory => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionAmdThinner", "PowerPlans");

        public static bool? IsActive()
        {
            try
            {
                var commands = new WindowsPowerSchemeCommands(StateDirectory);
                Guid active = commands.GetActive();
                return commands.List().Any(s => s.Id == active && IsRionName(s.Name));
            }
            catch { return null; }
        }

        public static bool Apply()
        {
            lock (Sync)
                return new PowerPlanActivation(new WindowsPowerSchemeCommands(StateDirectory), StateDirectory).Apply();
        }

        public static bool Revert()
        {
            lock (Sync)
                return new PowerPlanActivation(new WindowsPowerSchemeCommands(StateDirectory), StateDirectory).Revert();
        }
    }

    internal sealed record PowerScheme(Guid Id, string Name);

    internal interface IPowerSchemeCommands
    {
        IReadOnlyList<PowerScheme> List();
        Guid GetActive();
        void Import(Guid id);
        void SetActive(Guid id);
    }

    internal sealed class PowerPlanActivation
    {
        private readonly IPowerSchemeCommands commands;
        private readonly string stateDirectory;
        private string JournalPath => Path.Combine(stateDirectory, "activation.json");
        private string LegacyPath => Path.Combine(stateDirectory, "previous-scheme.guid");

        internal PowerPlanActivation(IPowerSchemeCommands commands, string stateDirectory)
        {
            this.commands = commands;
            this.stateDirectory = stateDirectory;
        }

        internal bool Apply()
        {
            var schemes = commands.List();
            Guid active = commands.GetActive();
            RequireScheme(schemes, active, "The active power scheme could not be identified.");
            var journal = ReadJournal(schemes, active);
            if (journal == null)
            {
                var existing = schemes.FirstOrDefault(s => RionPowerPlanTweak.IsRionName(s.Name));
                if (existing?.Id == active) return true;
                journal = CreateJournal(active, existing?.Id ?? Guid.NewGuid());
            }
            else if (active != journal.Previous && active != journal.Target)
            {
                throw new InvalidOperationException("The active power plan changed outside Rion. Review the saved activation before applying again.");
            }

            RequireScheme(schemes, journal.Previous, "The saved previous power plan no longer exists. No plan was activated.");
            Save(journal); // Recovery must be durable before import or activation.
            if (!schemes.Any(s => s.Id == journal.Target))
                commands.Import(journal.Target);
            var prepared = commands.List();
            RequireScheme(prepared, journal.Target, "The imported power plan could not be verified.");
            if (!prepared.Any(s => s.Id == journal.Target && RionPowerPlanTweak.IsRionName(s.Name)))
                throw new IOException("The imported power plan name was not verified. No activation was attempted; the recovery record was kept.");
            if (commands.GetActive() != active)
                throw new InvalidOperationException("The active power plan changed while preparing this action. No activation was attempted.");

            if (active != journal.Target) commands.SetActive(journal.Target);
            if (commands.GetActive() != journal.Target)
                throw new IOException("Power plan activation was not verified. The previous plan remains recorded for recovery.");
            return true;
        }

        internal bool Revert()
        {
            var schemes = commands.List();
            Guid active = commands.GetActive();
            var journal = ReadJournal(schemes, active);
            if (journal == null)
                throw new InvalidOperationException("No saved previous power plan is available. Choose a plan in Windows power settings; no default was substituted.");
            RequireScheme(schemes, journal.Previous, "The saved previous power plan no longer exists. No default was substituted.");
            if (active != journal.Target && active != journal.Previous)
                throw new InvalidOperationException("The active power plan changed outside Rion. No plan was overwritten; the recovery record was kept.");

            // Also persists legacy migration before a possible activation.
            Save(journal);
            if (commands.GetActive() != active)
                throw new InvalidOperationException("The active power plan changed while preparing recovery. No plan was activated.");
            if (active != journal.Previous) commands.SetActive(journal.Previous);
            if (commands.GetActive() != journal.Previous)
                throw new IOException("The previous power plan was not verified. The recovery record was kept.");

            // Clear the old marker first so an interrupted cleanup cannot replay a stale baseline.
            if (File.Exists(LegacyPath)) File.Delete(LegacyPath);
            File.Delete(JournalPath);
            return true;
        }

        private ActivationJournal ReadJournal(IReadOnlyList<PowerScheme> schemes, Guid active)
        {
            if (File.Exists(JournalPath))
            {
                var journal = JsonConvert.DeserializeObject<ActivationJournal>(File.ReadAllText(JournalPath));
                if (journal == null || journal.SchemaVersion != 1 || journal.Previous == Guid.Empty
                    || journal.Target == Guid.Empty || journal.Previous == journal.Target
                    || journal.Machine != Environment.MachineName)
                    throw new InvalidDataException("The saved power plan activation is invalid or belongs to another PC. It was preserved; no plan was changed.");
                return journal;
            }
            if (!File.Exists(LegacyPath)) return null;
            if (!Guid.TryParse(File.ReadAllText(LegacyPath).Trim(), out Guid previous) || previous == Guid.Empty)
                throw new InvalidDataException("The older power plan recovery record is unreadable. No default was substituted.");
            var target = schemes.SingleOrDefault(s => s.Id == active && RionPowerPlanTweak.IsRionName(s.Name));
            if (target == null || previous == target.Id)
                throw new InvalidDataException("The older recovery record cannot be matched to the active Rion plan. It was preserved for review.");
            return CreateJournal(previous, target.Id);
        }

        private static ActivationJournal CreateJournal(Guid previous, Guid target) => new ActivationJournal
        {
            SchemaVersion = 1,
            Machine = Environment.MachineName,
            Previous = previous,
            Target = target,
        };

        private void Save(ActivationJournal journal)
        {
            Directory.CreateDirectory(stateDirectory);
            string temp = JournalPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    using (var writer = new StreamWriter(stream, Encoding.UTF8, 1024, true))
                    {
                        writer.Write(JsonConvert.SerializeObject(journal, Formatting.Indented));
                        writer.Flush();
                    }
                    stream.Flush(true);
                }
                File.Move(temp, JournalPath, true);
            }
            finally
            {
                if (File.Exists(temp)) File.Delete(temp);
            }
        }

        private static void RequireScheme(IReadOnlyList<PowerScheme> schemes, Guid id, string message)
        {
            if (id == Guid.Empty || !schemes.Any(s => s.Id == id)) throw new InvalidOperationException(message);
        }

        private sealed class ActivationJournal
        {
            public int SchemaVersion { get; set; }
            public string Machine { get; set; }
            public Guid Previous { get; set; }
            public Guid Target { get; set; }
        }
    }

    internal sealed class WindowsPowerSchemeCommands : IPowerSchemeCommands
    {
        private static readonly Regex GuidPattern = new Regex(
            @"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", RegexOptions.Compiled);
        private readonly string stateDirectory;

        internal WindowsPowerSchemeCommands(string stateDirectory) => this.stateDirectory = stateDirectory;

        public IReadOnlyList<PowerScheme> List() => ParseSchemes(Run("/list"));

        internal static IReadOnlyList<PowerScheme> ParseSchemes(string output)
        {
            var schemes = new List<PowerScheme>();
            foreach (string line in output.Split('\n'))
            {
                var match = GuidPattern.Match(line);
                if (!match.Success) continue;
                string suffix = line.Substring(match.Index + match.Length).Trim().TrimEnd('*').Trim();
                if (suffix.Length < 2 || suffix[0] != '(' || suffix[suffix.Length - 1] != ')') continue;
                schemes.Add(new PowerScheme(Guid.Parse(match.Value), suffix.Substring(1, suffix.Length - 2)));
            }
            if (schemes.Count == 0) throw new IOException("Windows did not return any readable power schemes.");
            return schemes;
        }

        public Guid GetActive()
        {
            var match = GuidPattern.Match(Run("/getactivescheme"));
            if (!match.Success) throw new IOException("Windows did not return the active power scheme.");
            return Guid.Parse(match.Value);
        }

        public void Import(Guid id)
        {
            Directory.CreateDirectory(stateDirectory);
            string path = Path.Combine(stateDirectory, "RionProPowerPlan.pow");
            // Refresh from the embedded resource; the writable cache is not the source of truth.
            using (var source = typeof(RionPowerPlanTweak).Assembly.GetManifestResourceStream("RionProPowerPlan.pow"))
            {
                if (source == null) throw new FileNotFoundException("The embedded Rion power plan is missing.");
                using (var destination = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    source.CopyTo(destination);
                    destination.Flush(true);
                }
            }
            Run("/import \"" + path + "\" " + id.ToString("D"));
            Run("/changename " + id.ToString("D") + " \"" + RionPowerPlanTweak.PlanDisplayName + "\" \"Imported by Rion Win 11\"");
        }

        public void SetActive(Guid id) => Run("/setactive " + id.ToString("D"));

        private static string Run(string arguments)
        {
            string executable = ShellRunner.RequireExecutable(Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System), "powercfg.exe"),
                "Windows powercfg.exe is unavailable.");
            var result = ShellRunner.RunAsync(executable, arguments, null, 15000).GetAwaiter().GetResult();
            if (result.ExitCode != 0)
                throw new IOException("Power plan command failed" + (result.TimedOut ? " (timed out)" : "")
                    + ": " + result.Output.Trim());
            return result.Output;
        }
    }
}
