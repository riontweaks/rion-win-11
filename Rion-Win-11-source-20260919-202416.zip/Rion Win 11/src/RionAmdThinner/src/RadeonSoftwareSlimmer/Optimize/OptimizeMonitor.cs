using System;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    public enum SectionState { Pending, Running, Done, Failed, Skipped }

    public sealed class SectionProgress : ObservableObject
    {
        public SectionProgress(OptimizeSection section, string title)
        {
            Section = section;
            Title = title;
        }

        public OptimizeSection Section { get; }
        public string Title { get; }

        private SectionState _state = SectionState.Pending;
        public SectionState State { get => _state; set { Set(ref _state, value); Raise(nameof(IsRunning)); } }

        public bool IsRunning => _state == SectionState.Running;

        private string _detail = "";
        public string Detail { get => _detail; set => Set(ref _detail, value); }
    }

    /// <summary>
    /// Observable state for a running Auto-Optimize pass — the section list with per-section
    /// state, an overall progress value, and a live log. Collection edits are marshalled to the
    /// dispatcher so the service can drive it from a background thread.
    /// </summary>
    public sealed class OptimizeMonitor : ObservableObject
    {
        private readonly Dispatcher _ui = Dispatcher.CurrentDispatcher;

        public ObservableCollection<SectionProgress> Sections { get; } = new ObservableCollection<SectionProgress>();
        public ObservableCollection<string> LogLines { get; } = new ObservableCollection<string>();

        private double _overall;
        public double OverallPercent { get => _overall; private set => Set(ref _overall, value); }

        private string _current = "Preparing…";
        public string CurrentTitle { get => _current; private set => Set(ref _current, value); }

        private bool _running;
        public bool IsRunning { get => _running; private set => Set(ref _running, value); }

        public void Reset(System.Collections.Generic.IEnumerable<OptimizeSectionInfo> sections)
        {
            OnUi(() =>
            {
                Sections.Clear();
                LogLines.Clear();
                foreach (OptimizeSectionInfo s in sections)
                    Sections.Add(new SectionProgress(s.Section, s.Title));
                OverallPercent = 0;
                CurrentTitle = "Preparing…";
                IsRunning = true;
            });
        }

        public void Log(string line)
        {
            OnUi(() =>
            {
                LogLines.Add($"{DateTime.Now:HH:mm:ss}  {line}");
                while (LogLines.Count > 400) LogLines.RemoveAt(0);
            });
        }

        public void Begin(OptimizeSection section, string detail = null)
        {
            OnUi(() =>
            {
                foreach (SectionProgress p in Sections)
                    if (p.Section == section) { p.State = SectionState.Running; if (detail != null) p.Detail = detail; CurrentTitle = p.Title; }
            });
        }

        public void End(OptimizeSection section, SectionState state, string detail = null)
        {
            OnUi(() =>
            {
                int idx = 0, total = Sections.Count;
                for (int i = 0; i < Sections.Count; i++)
                {
                    if (Sections[i].Section == section)
                    {
                        Sections[i].State = state;
                        if (detail != null) Sections[i].Detail = detail;
                        idx = i + 1;
                    }
                }
                OverallPercent = total == 0 ? 100 : (idx * 100.0 / total);
            });
        }

        public void Finish()
        {
            OnUi(() => { OverallPercent = 100; CurrentTitle = "Finished"; IsRunning = false; });
        }

        private void OnUi(Action a)
        {
            if (_ui.CheckAccess()) a();
            else _ui.BeginInvoke(a);
        }
    }
}
