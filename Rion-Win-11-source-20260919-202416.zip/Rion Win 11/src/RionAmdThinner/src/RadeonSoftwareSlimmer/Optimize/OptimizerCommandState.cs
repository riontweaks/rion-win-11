using System;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RadeonSoftwareSlimmer.Optimize
{
    internal interface IOptimizerCommandBackend
    {
        JArray Read(string id);
        void Write(string id, JArray state);
    }

    /// <summary>Exact prior-state journal for the finite set of imported BCD/network operations.</summary>
    internal sealed class OptimizerCommandState
    {
        private static readonly object Sync = new object();
        private readonly string id;
        private readonly string path;
        private readonly IOptimizerCommandBackend backend;
        private readonly JToken value;

        public OptimizerCommandState(string id, JToken value, string directory = null, IOptimizerCommandBackend backend = null)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(id, @"^[a-z0-9-]+$")) throw new ArgumentException("Invalid operation ID.");
            this.id = id;
            this.value = value;
            this.backend = backend ?? new OptimizerCommandBackend();
            path = Path.Combine(directory ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "RionAmdThinner", "OptimizerCommandHistory"), id + ".json");
        }

        public bool HasSavedState() => File.Exists(path);
        internal bool IsRetired => id.StartsWith("bcd-", StringComparison.Ordinal) && id != "bcd-bootmenupolicy";
        public bool? Inspect()
        {
            var current = backend.Read(id);
            Validate(current);
            return current.All(row => (bool)row["Exists"] && JToken.DeepEquals(row["Value"], value));
        }

        public bool Apply()
        {
            if (IsRetired)
                throw new InvalidOperationException("This security/boot override is retired. Only restoration of saved state is available.");
            lock (Sync)
            {
                var before = backend.Read(id);
                Validate(before);
                if (File.Exists(path))
                {
                    var previous = Load();
                    if (Matches(before, (JArray)previous["Requested"])) return true;
                    throw new IOException("This operation already has saved recovery state. Restore it before applying again; the original baseline was preserved.");
                }
                var target = (JArray)before.DeepClone();
                foreach (JObject row in target) { row["Exists"] = true; row["Value"] = value.DeepClone(); }
                if (Matches(before, target)) return true;
                var journal = new JObject { ["Schema"] = 1, ["Id"] = id, ["Machine"] = Environment.MachineName,
                    ["Before"] = before, ["Requested"] = target, ["Status"] = "Pending" };
                Save(journal); // Capture every adapter/boot element before the first mutation.
                if (!Matches(backend.Read(id), before)) throw new IOException("Configuration changed during capture. No operation was attempted; review the saved state.");
                try
                {
                    backend.Write(id, target);
                    if (!Matches(backend.Read(id), target)) throw new IOException("Requested configuration was not verified.");
                    journal["Status"] = "Applied";
                    Save(journal);
                    return true;
                }
                catch (Exception ex)
                {
                    journal["Status"] = "Failed"; journal["Error"] = ex.Message;
                    try { Save(journal); } catch { /* The durable pending record still contains the baseline. */ }
                    throw new IOException(ex.Message + " Saved state remains available with Restore saved state; a partial change may remain.", ex);
                }
            }
        }

        public bool Restore()
        {
            lock (Sync)
            {
                var journal = Load();
                var before = (JArray)journal["Before"];
                var requested = (JArray)journal["Requested"];
                var current = backend.Read(id);
                Validate(current);
                foreach (JObject original in before)
                {
                    var now = Find(current, (string)original["Identity"]);
                    var expected = Find(requested, (string)original["Identity"]);
                    if (now == null || !Recoverable(now, original, expected))
                        throw new IOException("A saved target is missing or changed outside Rion. Restore stopped without overwriting it. Recovery records were retained.");
                }
                backend.Write(id, before);
                if (!Matches(backend.Read(id), before)) throw new IOException("Restore was not verified. Keep the recovery record and retry after reviewing the configuration.");
                File.Delete(path); // Only the verified operation's own journal.
                return true;
            }
        }

        private JObject Load()
        {
            if (!File.Exists(path)) throw new IOException("No saved state exists. No default was substituted.");
            var doc = JObject.Parse(File.ReadAllText(path));
            if ((int?)doc["Schema"] != 1 || (string)doc["Id"] != id || (string)doc["Machine"] != Environment.MachineName)
                throw new IOException("Recovery identity does not match this operation and machine.");
            Validate(doc["Before"] as JArray); Validate(doc["Requested"] as JArray);
            var before = (JArray)doc["Before"]; var target = (JArray)doc["Requested"];
            if (before.Count != target.Count || before.Any(row => Find(target, (string)row["Identity"]) == null))
                throw new IOException("Recovery targets do not match.");
            return doc;
        }

        private void Save(JObject doc)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            byte[] bytes = Encoding.UTF8.GetBytes(doc.ToString(Formatting.Indented));
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
            { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
            if (File.Exists(path)) File.Replace(temporary, path, null);
            else File.Move(temporary, path);
        }

        internal static bool Matches(JArray actual, JArray expected)
        {
            Validate(actual); Validate(expected);
            return expected.All(row => JToken.DeepEquals(Find(actual, (string)row["Identity"]), row));
        }
        private static JToken Find(JArray rows, string identity) => rows.SingleOrDefault(row => (string)row["Identity"] == identity);
        private static bool Recoverable(JToken current, JToken before, JToken requested)
        {
            if (JToken.DeepEquals(current, before) || JToken.DeepEquals(current, requested)) return true;
            if (current["Value"] is not JObject actual || before["Value"] is not JObject original || requested["Value"] is not JObject target
                || !JToken.DeepEquals(current["Exists"], before["Exists"]) || !JToken.DeepEquals(current["Exists"], requested["Exists"])) return false;
            return actual.Count == original.Count && actual.Count == target.Count && actual.Properties().All(property =>
                original.ContainsKey(property.Name) && target.ContainsKey(property.Name)
                && (JToken.DeepEquals(property.Value, original[property.Name]) || JToken.DeepEquals(property.Value, target[property.Name])));
        }
        private static void Validate(JArray rows)
        {
            if (rows == null || rows.Count == 0 || rows.Any(row => row is not JObject || string.IsNullOrWhiteSpace((string)row["Identity"])
                || row["Exists"]?.Type != JTokenType.Boolean || row["Value"] == null)
                || rows.Select(row => (string)row["Identity"]).Distinct().Count() != rows.Count)
                throw new IOException("The current configuration could not be captured unambiguously. No guessed values will be used.");
        }
    }

    internal sealed class OptimizerCommandBackend : IOptimizerCommandBackend
    {
        public JArray Read(string id) => JArray.Parse(Run(id, null));
        public void Write(string id, JArray state) => Run(id, state);

        private static string Run(string id, JArray state)
        {
            using var resource = typeof(OptimizerCommandBackend).Assembly.GetManifestResourceStream("Rion.OptimizerCommands.ps1")
                ?? throw new IOException("The optimizer command resource is missing.");
            using var reader = new StreamReader(resource);
            var request = new JObject { ["Id"] = id, ["State"] = state };
            string payload = Convert.ToBase64String(Encoding.UTF8.GetBytes(request.ToString(Formatting.None)));
            string script = "$request = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + payload + "')) | ConvertFrom-Json\n" + reader.ReadToEnd();
            var result = ShellRunner.PowerShellAsync(script, null, 60000).GetAwaiter().GetResult();
            if (result.ExitCode != 0 || result.TimedOut) throw new IOException(result.Output.Trim());
            string marker = result.Output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .LastOrDefault(line => line.StartsWith("RION_STATE:", StringComparison.Ordinal));
            if (marker == null) throw new IOException("The command returned no verified configuration.");
            return marker.Substring("RION_STATE:".Length);
        }
    }
}
