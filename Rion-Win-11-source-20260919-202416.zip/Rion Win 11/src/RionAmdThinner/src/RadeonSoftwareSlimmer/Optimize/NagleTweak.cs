using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Inspects adapter registry settings and journals each change before writing it.
    /// Matching values confirm configuration, not TCP behavior or a latency gain.</summary>
    internal static class NagleTweak
    {
        internal const string InterfacesKey = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces";
        private const string HistoryDescription = "Network: TCP acknowledgment settings";
        private static readonly string[] ValueNames = { "TcpAckFrequency", "TCPNoDelay" };

        private static string LegacyStateFile => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "RionAmdThinner", "NetworkTweaks", "nagle-touched-adapters.txt");

        public static bool? IsDisabled() => IsDisabled(new WindowsRegistry());

        internal static bool? IsDisabled(IRegistry registry)
        {
            try
            {
                using (var root = registry.LocalMachine.OpenSubKey(InterfacesKey, false))
                {
                    if (root == null) return null;
                    string[] adapters = root.GetSubKeyNames();
                    if (adapters.Length == 0) return null;
                    bool configured = true;
                    foreach (string adapter in adapters)
                    {
                        using (var key = root.OpenSubKey(adapter, false))
                        {
                            if (key == null) return null;
                            foreach (string name in ValueNames)
                                configured &= IsTarget(RegistryValueSnapshot.Read(key, name));
                        }
                    }
                    return configured;
                }
            }
            catch (Exception ex)
            {
                StaticViewModel.AddDebugMessage(ex, "Could not read TCP acknowledgment settings");
                return null;
            }
        }

        public static bool Apply() => Apply(new WindowsRegistry(), BackupStore.BackupDirectory, LegacyStateFile);

        internal static bool Apply(IRegistry registry, string backupDirectory, string legacyStateFile)
        {
            lock (RegistryChangeHistory.Sync)
            {
                CheckLegacyRecord(legacyStateFile);
                var pending = PendingHistory(registry, backupDirectory)
                    .ToDictionary(e => e.Target, StringComparer.OrdinalIgnoreCase);
                var backup = new BackupSession(backupDirectory) { Description = HistoryDescription };
                using (var root = registry.LocalMachine.OpenSubKey(InterfacesKey, true))
                {
                    if (root == null) throw new IOException("Network adapter settings are unavailable; no change was attempted.");
                    string[] adapters = root.GetSubKeyNames();
                    if (adapters.Length == 0) throw new IOException("No network adapter settings were found.");
                    foreach (string adapter in adapters)
                    {
                        using (var key = root.OpenSubKey(adapter, true))
                        {
                            if (key == null) throw new IOException("An adapter became unavailable. Review the setting’s Revert changes action for any completed changes.");
                            string target = @"HKLM\" + InterfacesKey + "\\" + adapter;
                            foreach (string name in ValueNames)
                            {
                                var current = RegistryValueSnapshot.Read(key, name);
                                if (IsTarget(current)) continue;
                                if (pending.ContainsKey(target + "\\" + name))
                                    throw new IOException("A previously changed TCP setting now differs from its saved state. Review the setting’s Revert changes action before applying again.");
                                backup.WriteRegistry(key, target, name, true, 1, RegistryValueKind.DWord);
                            }
                        }
                    }
                }
                StaticViewModel.AddLogMessage("TCP acknowledgment registry settings verified. Previous values are saved in the setting’s Revert changes action; traffic behavior was not measured.");
                return true;
            }
        }

        public static bool Revert() => Revert(new WindowsRegistry(), BackupStore.BackupDirectory, LegacyStateFile);

        internal static bool Revert(IRegistry registry, string backupDirectory, string legacyStateFile)
        {
            lock (RegistryChangeHistory.Sync)
            {
                CheckLegacyRecord(legacyStateFile);
                var pending = PendingHistory(registry, backupDirectory);
                if (pending.Count == 0)
                    throw new InvalidOperationException("No saved TCP settings are available to restore. No default values were substituted.");

                var failures = new List<string>();
                foreach (var entry in pending)
                {
                    var result = RegistryChangeHistory.Restore(entry.Id, registry, backupDirectory);
                    if (!result.Success) failures.Add(entry.Target + ": " + result.Message);
                }
                if (failures.Count > 0)
                    throw new IOException("Some TCP settings could not be restored. Successful restores were retained; review the setting’s Revert changes action. " + string.Join(" ", failures));

                StaticViewModel.AddLogMessage("Restored and verified the saved TCP acknowledgment registry settings.");
                return true;
            }
        }

        private static bool IsTarget(RegistryValueSnapshot value) =>
            value.Exists && value.Kind == RegistryValueKind.DWord && value.Data == "1";

        private static List<RegistryHistoryEntry> PendingHistory(IRegistry registry, string directory) =>
            RegistryChangeHistory.ListEntries(directory, registry)
                .Where(e => e.Description == HistoryDescription &&
                    e.Target.StartsWith(@"HKLM\" + InterfacesKey + "\\", StringComparison.OrdinalIgnoreCase))
                .GroupBy(e => e.Target, StringComparer.OrdinalIgnoreCase)
                .Select(group => group.First())
                .Where(e => e.Status != "Restored")
                .ToList();

        private static void CheckLegacyRecord(string path)
        {
            if (File.Exists(path))
                throw new InvalidOperationException("An older TCP tweak record remains at " + path +
                    ". That version did not save existing values, so exact recovery cannot be reconstructed. The record was preserved and no TCP setting was changed; review it before applying or restoring this tweak.");
        }
    }
}
