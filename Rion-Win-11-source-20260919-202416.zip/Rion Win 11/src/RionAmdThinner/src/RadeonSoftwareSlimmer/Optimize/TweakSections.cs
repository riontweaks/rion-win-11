using System;
using System.Linq;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Browsing labels only; never changes catalog membership or apply behavior.</summary>
    public static class TweakSections
    {
        public static string For(SystemTweak tweak, string group = null)
        {
            group = group ?? OptimizerImportCatalog.GroupFor(tweak);
            if (tweak.Id.StartsWith("net-", StringComparison.Ordinal) || tweak.Id.StartsWith("network-", StringComparison.Ordinal)
                || tweak.Id.StartsWith("basic-tcp-", StringComparison.Ordinal) || group == "Network"
                || NetworkTweakCatalog.All.Any(t => t.Id == tweak.Id) || ResearchedTweakCatalog.Network.Any(t => t.Id == tweak.Id)
                || group == "TCP Congestion Control" || group == "Weak Host Model" || group == "Winsock Autotuning")
                return "Network & internet";
            if (group.StartsWith("Boot", StringComparison.OrdinalIgnoreCase) || tweak.Id.StartsWith("bcd-", StringComparison.Ordinal))
                return "Boot & system";
            if (group == "Telemetry" || tweak.Id.Contains("background") || tweak.Id.Contains("advertising"))
                return "Privacy & background apps";
            if (tweak.Category == TweakCategory.Graphics) return "Graphics & gaming";
            if (tweak.Category == TweakCategory.Security) return "Security & protection";
            if (tweak.Category == TweakCategory.Performance) return "Performance & power";
            return "Boot & system";
        }
    }
}
