using System;
using System.Collections.Generic;
using System.Linq;

namespace RadeonSoftwareSlimmer.Optimize;

/// <summary>One inventory/removal mechanism across Windows builds. No versioned names or wildcard removals.</summary>
public static class DebloatPackageRemoval
{
    public const string WidgetsPackage = "MicrosoftWindows.Client.WebExperience";

    public static string CreateScript(IReadOnlyCollection<string> keep = null,
        bool removeWidgets = false, IReadOnlyCollection<string> reviewedNames = null)
    {
        var names = removeWidgets ? DebloatCatalog.Remove.Append(WidgetsPackage) : DebloatCatalog.Remove;
        names = names.Where(n => (keep == null || !keep.Contains(n, StringComparer.OrdinalIgnoreCase))
            && (reviewedNames == null || reviewedNames.Contains(n, StringComparer.OrdinalIgnoreCase)));
        static string ArrayText(IEnumerable<string> values) => string.Join(",", values.Distinct(StringComparer.OrdinalIgnoreCase).Select(n => "'" + n.Replace("'", "''") + "'"));
        return "$remove = @(" + ArrayText(names) + ")\n$keep = @(" + ArrayText(DebloatCatalog.KeepAlways)
            + ")\n$removeWidgets = " + (removeWidgets ? "$true" : "$false") + "\n" + Body;
    }

    private const string Body = """
        $ErrorActionPreference = 'Stop'
        function Protected($n) {
          if ($removeWidgets -and $n -eq 'MicrosoftWindows.Client.WebExperience') { return $false }
          foreach ($k in $keep) { if ($n -like "*$k*") { return $true } }
          return $false
        }
        # Both inventories must succeed before removal. A failed scan is not an empty scan.
        try {
          $installed = @(Get-AppxPackage -AllUsers -PackageTypeFilter Main,Bundle,Framework,Resource -ErrorAction Stop)
          $provisioned = @(Get-AppxProvisionedPackage -Online -ErrorAction Stop)
        } catch { Write-Output "FAIL`tInventory`t$($_.Exception.Message)"; return }
        Write-Output "INFO`tDetected $($installed.Count) installed package records and $($provisioned.Count) provisioned records"
        $i = 0
        foreach ($name in $remove) {
          $i++
          Write-Output "PROGRESS`t$i`t$($remove.Count)"
          $pkgs = @($installed | Where-Object Name -eq $name)
          $prov = @($provisioned | Where-Object DisplayName -eq $name)
          if (-not $pkgs -and -not $prov) { Write-Output "MISS`t$name"; continue }
          if ((Protected $name) -or @($pkgs | Where-Object { $_.IsFramework -or $_.NonRemovable }).Count) {
            Write-Output "FAIL`t$name`tRetained: protected package or shared framework on this Windows build."
            continue
          }
          # Remove provisioning, then bundle parents. Never forcibly delete WindowsApps files.
          foreach ($pp in $prov) {
            try {
              Remove-AppxProvisionedPackage -Online -PackageName $pp.PackageName -ErrorAction Stop | Out-Null
              if (@(Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object PackageName -eq $pp.PackageName).Count) { throw 'Provisioned package still present after removal.' }
              Write-Output "PROV`t$name"
            } catch { Write-Output "FAIL`t$name`tProvisioning: $($_.Exception.Message)" }
          }
          foreach ($p in @($pkgs | Where-Object { -not $_.IsResourcePackage } | Sort-Object -Property @{Expression='IsBundle';Descending=$true},PackageFullName -Unique)) {
            try {
              # Bundle removal can already have removed this main package.
              if (-not @(Get-AppxPackage -AllUsers -Name $name -PackageTypeFilter Main,Bundle -ErrorAction Stop | Where-Object PackageFullName -eq $p.PackageFullName).Count) { continue }
              Remove-AppxPackage -Package $p.PackageFullName -AllUsers -ErrorAction Stop
            } catch { Write-Output "FAIL`t$name`t$($_.Exception.Message)" }
          }
          try {
            $remaining = @(Get-AppxPackage -AllUsers -Name $name -PackageTypeFilter Main,Bundle,Resource -ErrorAction Stop | Where-Object Name -eq $name)
            $remainingProv = @(Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object DisplayName -eq $name)
            if ($remaining.Count -or $remainingProv.Count) {
              Write-Output "FAIL`t$name`tStill present: $($remaining.Count) installed / $($remainingProv.Count) provisioned. Close the app or restart and rescan."
            } elseif ($pkgs.Count) { Write-Output "GONE`t$name" }
          } catch { Write-Output "FAIL`t$name`tFinal verification: $($_.Exception.Message)" }
        }
        Write-Output 'DONE'
        """;
}
