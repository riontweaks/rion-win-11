using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Clears safe temp locations before the rest of the run. Best-effort — locked files are skipped.</summary>
    public static class DiskCleanupRunner
    {
        public static Task<(long bytesFreed, int filesDeleted, List<string> notes)> RunAsync(
            Action<string> onLine, CancellationToken ct)
        {
            return Task.Run(() =>
            {
                long freed = 0;
                int files = 0;
                var notes = new List<string>();

                string windir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                var targets = new (string path, bool cacheDbOnly)[]
                {
                    (Path.GetTempPath(), false),
                    (Path.Combine(windir, "Temp"), false),
                    (Path.Combine(windir, "SoftwareDistribution", "Download"), false),
                    (Path.Combine(windir, "Prefetch"), false),
                    (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "Microsoft", "Windows", "Explorer"), true), // thumbnail/icon cache DBs
                    (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "CrashDumps"), false),
                    (Path.Combine(windir, "LiveKernelReports"), false),
                };

                foreach ((string path, bool cacheDbOnly) in targets)
                {
                    if (ct.IsCancellationRequested) break;
                    try
                    {
                        if (!Directory.Exists(path)) continue;
                        onLine?.Invoke("Cleaning " + path);
                        (long f, int n) = ClearDir(path, cacheDbOnly, ct, notes);
                        freed += f;
                        files += n;
                    }
                    catch (Exception ex)
                    {
                        StaticViewModel.AddDebugMessage(ex, "Cleanup skipped " + path);
                        notes.Add("skipped " + path);
                    }
                }

                onLine?.Invoke($"Freed {freed / 1024 / 1024} MB across {files} files");
                return (freed, files, notes);
            }, ct);
        }

        internal static (long bytesFreed, int filesDeleted) ClearDir(string dir, bool cacheDbOnly,
            CancellationToken ct, List<string> notes)
        {
            string root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(dir));
            if (root.Equals(Path.TrimEndingDirectorySeparator(Path.GetPathRoot(root) ?? string.Empty), StringComparison.OrdinalIgnoreCase))
                throw new IOException("A drive root is not a cleanup directory.");

            long freed = 0;
            int count = 0;
            ClearContents(new DirectoryInfo(root), cacheDbOnly);
            return (freed, count);

            void ClearContents(DirectoryInfo directory, bool onlyCacheFiles)
            {
                if (ct.IsCancellationRequested) return;
                try
                {
                    EnsureRegularPath(directory.FullName);
                    // Materialize one directory at a time so an inaccessible child does
                    // not abort its siblings. Recursive enumeration would follow links.
                    foreach (FileSystemInfo entry in directory.GetFileSystemInfos())
                    {
                        if (ct.IsCancellationRequested) return;
                        try
                        {
                            EnsureRegularPath(entry.FullName);
                            if (entry is DirectoryInfo child)
                            {
                                if (onlyCacheFiles) continue;
                                ClearContents(child, false);
                                if (ct.IsCancellationRequested) return;
                                EnsureRegularPath(child.FullName);
                                // Only remove a directory we have emptied ourselves. A
                                // skipped/locked file or link keeps its directory intact.
                                if (child.GetFileSystemInfos().Length == 0) child.Delete(false);
                            }
                            else if (entry is FileInfo file)
                            {
                                if (onlyCacheFiles && (!file.Name.Contains("cache", StringComparison.OrdinalIgnoreCase)
                                    || !file.Extension.Equals(".db", StringComparison.OrdinalIgnoreCase))) continue;
                                long length = file.Length;
                                file.Delete();
                                freed += length;
                                count++;
                            }
                        }
                        catch (IOException ex) { notes.Add("Skipped " + entry.FullName + ": " + ex.Message); }
                        catch (UnauthorizedAccessException ex) { notes.Add("Skipped " + entry.FullName + ": " + ex.Message); }
                    }
                }
                catch (IOException ex) { notes.Add("Skipped " + directory.FullName + ": " + ex.Message); }
                catch (UnauthorizedAccessException ex) { notes.Add("Skipped " + directory.FullName + ": " + ex.Message); }
            }

            void EnsureRegularPath(string path)
            {
                string fullPath = Path.GetFullPath(path);
                if (!fullPath.Equals(root, StringComparison.OrdinalIgnoreCase)
                    && !fullPath.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                    throw new IOException("The entry is outside the selected cleanup directory.");

                // Check ancestors too: a cleanup root or an enumerated parent can
                // itself be a junction even when the final entry is a regular file.
                string current = fullPath;
                while (!string.IsNullOrEmpty(current))
                {
                    if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                        throw new IOException("Linked files and directories are excluded from cleanup.");
                    current = Path.GetDirectoryName(current) ?? string.Empty;
                }
            }
        }
    }
}
