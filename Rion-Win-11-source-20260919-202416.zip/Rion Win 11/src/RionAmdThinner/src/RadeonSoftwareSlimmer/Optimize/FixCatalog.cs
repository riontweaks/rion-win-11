using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Optimize
{
    public sealed class FixResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public static FixResult Ok(string message) => new FixResult { Success = true, Message = message };
        public static FixResult Fail(string message) => new FixResult { Success = false, Message = message };
    }

    /// <summary>One named one-click repair. Unlike <see cref="SystemTweak"/> these aren't a single
    /// registry value toggle — each is its own small script of service/registry/appx fixes — so
    /// they're modeled as a plain async action rather than forced into the tweak shape.</summary>
    public sealed class FixDefinition
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        /// <summary>Segoe MDL2 glyph, or "nvidia" as a sentinel meaning "use the NVIDIA icon asset"
        /// instead of a glyph (see FixesView's icon template).</summary>
        public string Glyph { get; set; }

        /// <summary>onProgress reports (current, total) step counts for fixes with a statically
        /// known step count (WiFi, Bluetooth, Windows Update, Defender); the two PowerShell-driven
        /// fixes (Store, NVIDIA Control Panel) never call it — their package count isn't known
        /// ahead of time, so the caller shows an indeterminate progress bar instead of a fake total.</summary>
        public Func<IRegistry, Action<string>, Action<int, int>, CancellationToken, Task<FixResult>> Run { get; set; }
    }

    public static class FixCatalog
    {
        public static readonly FixDefinition[] All =
        {
            new FixDefinition
            {
                Id = "xbox-reinstall",
                Title = "Xbox Reinstall",
                Description = "Reinstalls Xbox from Microsoft Store after debloating, verifies installation, and restores disabled Xbox/Store services to Manual. Game Bar is available separately in Windows Apps.",
                Glyph = "\uE7FC",
                Run = XboxReinstall.RunAsync,
            },
            new FixDefinition
            {
                Id = "wifi-fix",
                Title = "WiFi Fix",
                Description = "Fixes common WiFi connection problems.",
                Glyph = "",
                Run = (registry, onLine, onProgress, ct) => Task.Run(() =>
                {
                    var backup = new BackupSession { Description = "WiFi Fix" };
                    onProgress?.Invoke(0, 2);
                    bool a = ServiceTrimCatalog.SetStart(registry, "WlanSvc", 2, backup, "Fixes");
                    onProgress?.Invoke(1, 2);
                    bool b = ServiceTrimCatalog.SetStart(registry, "WinHttpAutoProxySvc", 2, backup, "Fixes");
                    onProgress?.Invoke(2, 2);
                    backup.Save();
                    onLine?.Invoke("WLAN AutoConfig and WinHTTP Auto Proxy set to Automatic.");
                    return FixResult.Ok(a || b
                        ? "WiFi services reset to Automatic startup."
                        : "WiFi services were already set correctly.");
                }, ct),
            },
            new FixDefinition
            {
                Id = "bluetooth-fix",
                Title = "Bluetooth Fix",
                Description = "Fixes common Bluetooth pairing and connection problems.",
                Glyph = "",
                Run = (registry, onLine, onProgress, ct) => Task.Run(() =>
                {
                    var backup = new BackupSession { Description = "Bluetooth Fix" };
                    bool any = false;
                    string[] svcs = { "bthserv", "BTAGService", "BthAvctpSvc", "BthHFSrv" };
                    for (int i = 0; i < svcs.Length; i++)
                    {
                        onProgress?.Invoke(i, svcs.Length);
                        if (ServiceTrimCatalog.SetStart(registry, svcs[i], 3, backup, "Fixes")) any = true;
                        onLine?.Invoke(svcs[i] + " → Manual");
                    }
                    onProgress?.Invoke(svcs.Length, svcs.Length);
                    backup.Save();
                    return FixResult.Ok(any
                        ? "Bluetooth services reset to their correct startup type."
                        : "Bluetooth services were already set correctly.");
                }, ct),
            },
            new FixDefinition
            {
                Id = "store-fix",
                Title = "Microsoft Store Fix",
                Description = "Fixes the Store when apps won't download or install.",
                Glyph = "",
                Run = async (registry, onLine, onProgress, ct) =>
                {
                    var backup = new BackupSession { Description = "Microsoft Store Fix" };
                    foreach (var (svc, start) in new[] { ("bits", 2), ("cryptsvc", 2), ("appxsvc", 3), ("wuauserv", 3) })
                        ServiceTrimCatalog.SetStart(registry, svc, start, backup, "Fixes");
                    backup.Save();
                    // Package count isn't known ahead of time — leave onProgress uncalled so the
                    // caller shows an indeterminate bar instead of a fake total.

                    const string script = @"
Get-AppxPackage -AllUsers Microsoft.WindowsStore | ForEach-Object {
    try { Add-AppxPackage -DisableDevelopmentMode -Register ""$($_.InstallLocation)\AppXManifest.xml"" -ErrorAction Stop; Write-Output ""OK`t$($_.PackageFullName)"" }
    catch { Write-Output ""FAIL`t$($_.PackageFullName)`t$($_.Exception.Message)"" }
}
Start-Process -FilePath wsreset.exe -WindowStyle Hidden -Wait
Write-Output ""DONE""
";
                    var res = await ShellRunner.PowerShellAsync(script, onLine, timeoutMs: 3 * 60 * 1000, ct: ct).ConfigureAwait(false);
                    return res.ExitCode == 0
                        ? FixResult.Ok("Microsoft Store re-registered and its services reset.")
                        : FixResult.Fail("Store fix finished with errors — see the log above.");
                },
            },
            new FixDefinition
            {
                Id = "windows-update-fix",
                Title = "Re-Enable Windows Update Fix",
                Description = "Turns Windows Update back on if it's been disabled.",
                Glyph = "",
                Run = (registry, onLine, onProgress, ct) => Task.Run(() =>
                {
                    var backup = new BackupSession { Description = "Re-Enable Windows Update" };
                    bool any = false;
                    var svcs = new[] { ("wuauserv", 3), ("BITS", 3), ("UsoSvc", 3) };
                    for (int i = 0; i < svcs.Length; i++)
                    {
                        onProgress?.Invoke(i, svcs.Length);
                        var (svc, start) = svcs[i];
                        if (ServiceTrimCatalog.SetStart(registry, svc, start, backup, "Fixes")) any = true;
                        onLine?.Invoke(svc + " → " + ServiceTrimCatalog.StartLabel(start));
                    }
                    onProgress?.Invoke(svcs.Length, svcs.Length);
                    backup.Save();
                    return FixResult.Ok(any
                        ? "Windows Update services restored to their default startup type."
                        : "Windows Update services were already set correctly.");
                }, ct),
            },
            new FixDefinition
            {
                Id = "defender-fix",
                Title = "Re-Enable Defender Fix",
                Description = "Turns Windows Defender back on if it's been disabled.",
                Glyph = "",
                Run = (registry, onLine, onProgress, ct) => Task.Run(() =>
                {
                    var backup = new BackupSession { Description = "Re-Enable Defender" };
                    bool any = false;
                    const int totalSteps = 5; // 2 policy values + 3 services
                    int step = 0;

                    const string policyPath = @"SOFTWARE\Policies\Microsoft\Windows Defender";
                    using (IRegistryKey key = registry.LocalMachine.OpenSubKey(policyPath, true))
                    {
                        if (key != null)
                        {
                            foreach (string value in new[] { "DisableAntiSpyware", "DisableAntiVirus" })
                            {
                                onProgress?.Invoke(step++, totalSteps);
                                object cur = key.GetValue(value, null);
                                if (cur == null) continue;
                                RegistryChangeHistory.Write(backup, key, "HKLM\\" + policyPath, value, false, null, Microsoft.Win32.RegistryValueKind.DWord);
                                onLine?.Invoke("Cleared policy: " + value);
                                any = true;
                            }
                        }
                    }

                    foreach (var (svc, start) in new[] { ("WinDefend", 2), ("wscsvc", 2), ("SecurityHealthService", 3) })
                    {
                        onProgress?.Invoke(step++, totalSteps);
                        if (ServiceTrimCatalog.SetStart(registry, svc, start, backup, "Fixes")) any = true;
                        onLine?.Invoke(svc + " → " + ServiceTrimCatalog.StartLabel(start));
                    }
                    onProgress?.Invoke(totalSteps, totalSteps);

                    backup.Save();
                    return FixResult.Ok(any
                        ? "Defender policies cleared and its services restored."
                        : "Defender was already set up correctly.");
                }, ct),
            },
            new FixDefinition
            {
                Id = "nvidia-control-panel-fix",
                Title = "NVIDIA Control Panel (No Microsoft Store)",
                Description = "Installs NVIDIA Control Panel without needing the Microsoft Store.",
                Glyph = "nvidia",
                Run = async (registry, onLine, onProgress, ct) =>
                {
                    // Indeterminate — no known step count, onProgress is deliberately never called.
                    string bundle = FindNvidiaControlPanelBundle();
                    if (bundle == null)
                        return FixResult.Fail(
                            "Couldn't find an NVIDIA Control Panel package bundled with the installed driver. "
                            + "Try reinstalling/repairing the NVIDIA driver first, then run this fix again.");

                    onLine?.Invoke("Found: " + bundle);
                    string script = "Add-AppxPackage -Path \"" + bundle.Replace("\"", "`\"") + "\" -ErrorAction Stop";
                    var res = await ShellRunner.PowerShellAsync(script, onLine, ct: ct).ConfigureAwait(false);
                    return res.ExitCode == 0
                        ? FixResult.Ok("NVIDIA Control Panel registered — it should now appear in Start.")
                        : FixResult.Fail("Could not register the package — see the log above.");
                },
            },
        };

        /// <summary>Modern NVIDIA drivers drop the Control Panel's appx/msix bundle on disk as part
        /// of the driver package even when Windows fails to auto-register it. Search the common
        /// install locations rather than shipping a copy of NVIDIA's package in this app.</summary>
        private static string FindNvidiaControlPanelBundle()
        {
            string[] roots =
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\NVIDIA Corporation",
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + @"\NVIDIA Corporation",
                Environment.GetEnvironmentVariable("SystemRoot") + @"\System32\DriverStore\FileRepository",
            };

            foreach (string root in roots)
            {
                if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
                try
                {
                    var hit = Directory.EnumerateFiles(root, "*ControlPanel*.appx*", SearchOption.AllDirectories)
                        .Concat(Directory.EnumerateFiles(root, "*ControlPanel*.msix*", SearchOption.AllDirectories))
                        .FirstOrDefault();
                    if (hit != null) return hit;
                }
                catch { /* inaccessible subtree — keep looking */ }
            }
            return null;
        }
    }
}

