using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using Newtonsoft.Json;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    public sealed class SnapshotEntry
    {
        public string Hive { get; set; }
        public string Key { get; set; }
        public string ValueName { get; set; }
        public bool Existed { get; set; }
        public string Data { get; set; }
        public int Kind { get; set; }
        public string Note { get; set; }
    }

    public sealed class RegistrySnapshotDocument
    {
        public DateTime TimestampUtc { get; set; }
        public List<SnapshotEntry> Entries { get; set; } = new List<SnapshotEntry>();
    }

    /// <summary>
    /// A targeted (not full-hive) snapshot of every registry value Auto-Optimize touches plus
    /// the <see cref="TweakerWatchlist"/> values. Written to
    /// %LOCALAPPDATA%\RionWin11\snapshots\&lt;timestamp&gt;.json before a run so the run can be
    /// audited / hand-reverted, and diffed against the Windows defaults to spot values a previous
    /// tweaker already changed.
    /// </summary>
    public static class RegistrySnapshot
    {
        public static string Directory =>
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "RionWin11", "snapshots");

        public sealed class DiffRow
        {
            public string KeyPath { get; set; }
            public string ValueName { get; set; }
            public string Current { get; set; }
            public string WindowsDefault { get; set; }
            public string Note { get; set; }
        }

        /// <summary>Captures the current state of every catalog + watchlist value; returns the file path.</summary>
        public static string Capture(IRegistry registry, out RegistrySnapshotDocument doc)
        {
            doc = new RegistrySnapshotDocument { TimestampUtc = DateTime.UtcNow };

            foreach ((TweakHive hive, string key, string valueName, string note) in Targets())
            {
                try
                {
                    IRegistryKey root = hive == TweakHive.CurrentUser ? registry.CurrentUser : registry.LocalMachine;
                    using (IRegistryKey k = root.OpenSubKey(key, false))
                    {
                        object v = k?.GetValue(valueName, null);
                        RegistryValueKind kind = RegistryValueKind.None;
                        if (v != null) { try { kind = k.GetValueKind(valueName); } catch { } }
                        doc.Entries.Add(new SnapshotEntry
                        {
                            Hive = hive == TweakHive.CurrentUser ? "HKCU" : "HKLM",
                            Key = key,
                            ValueName = valueName,
                            Existed = v != null,
                            Data = v?.ToString(),
                            Kind = (int)kind,
                            Note = note,
                        });
                    }
                }
                catch (Exception ex)
                {
                    StaticViewModel.AddDebugMessage(ex, "Snapshot could not read " + key + "\\" + valueName);
                }
            }

            string path = null;
            try
            {
                System.IO.Directory.CreateDirectory(Directory);
                path = Path.Combine(Directory,
                    DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + ".json");
                File.WriteAllText(path, JsonConvert.SerializeObject(doc, Formatting.Indented));
                StaticViewModel.AddLogMessage("Registry snapshot saved to " + path);
            }
            catch (Exception ex)
            {
                StaticViewModel.AddLogMessage(ex, "Could not save the registry snapshot");
            }
            return path;
        }

        /// <summary>Watched values whose current state differs from a clean Windows install.</summary>
        public static IReadOnlyList<DiffRow> DiffFromDefault(IRegistry registry)
        {
            var rows = new List<DiffRow>();
            foreach (WatchedValue w in TweakerWatchlist.All)
            {
                try
                {
                    IRegistryKey root = w.Hive == TweakHive.CurrentUser ? registry.CurrentUser : registry.LocalMachine;
                    using (IRegistryKey k = root.OpenSubKey(w.KeyPath, false))
                    {
                        object v = k?.GetValue(w.ValueName, null);
                        long? current = v == null ? (long?)null : SafeLong(v);
                        bool differs = current != w.WindowsDefault;
                        if (differs)
                        {
                            rows.Add(new DiffRow
                            {
                                KeyPath = (w.Hive == TweakHive.CurrentUser ? "HKCU\\" : "HKLM\\") + w.KeyPath,
                                ValueName = w.ValueName,
                                Current = v == null ? "(absent)" : v.ToString(),
                                WindowsDefault = w.WindowsDefault?.ToString(CultureInfo.InvariantCulture) ?? "(absent)",
                                Note = w.Note,
                            });
                        }
                    }
                }
                catch { /* unreadable watch entry — ignore */ }
            }
            return rows;
        }

        private static long? SafeLong(object v)
        {
            try { return Convert.ToInt64(v, CultureInfo.InvariantCulture); }
            catch { return null; }
        }

        private static IEnumerable<(TweakHive hive, string key, string valueName, string note)> Targets()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (SystemTweak t in TweakCatalog.All)
            {
                string key = t.DynamicKeyPath != null ? t.DynamicKeyPath() : t.KeyPath;
                if (string.IsNullOrEmpty(key)) continue;
                string id = t.Hive + "|" + key + "|" + t.ValueName;
                if (seen.Add(id)) yield return (t.Hive, key, t.ValueName, t.Title);
            }
            foreach (WatchedValue w in TweakerWatchlist.All)
            {
                string id = w.Hive + "|" + w.KeyPath + "|" + w.ValueName;
                if (seen.Add(id)) yield return (w.Hive, w.KeyPath, w.ValueName, w.Note);
            }
        }
    }
}
