using System;
using System.Collections.Generic;
using System.IO;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Optimize
{
    public static class ResearchedTweakCatalog
    {
        private static SystemTweak Policy(string id, string title, string summary, string cost,
            string path, string name, int target, string source, bool reboot = false)
        {
            var state = new ReversibleDword(new WindowsRegistry().LocalMachine, path, name, target,
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "RionAmdThinner", "PolicyBackups", id + ".json"));
            bool SupportedEdition()
            {
                if (id != "delivery-optimization-no-peers" && id != "widgets-off" && id != "search-highlights-off") return true;
                using var editionKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
                string edition = editionKey?.GetValue("EditionID") as string ?? "";
                bool editionSupported = edition.StartsWith("Professional", StringComparison.OrdinalIgnoreCase)
                    || edition.StartsWith("Enterprise", StringComparison.OrdinalIgnoreCase)
                    || edition.StartsWith("Education", StringComparison.OrdinalIgnoreCase)
                    || edition.StartsWith("IoTEnterprise", StringComparison.OrdinalIgnoreCase);
                int.TryParse(editionKey?.GetValue("CurrentBuildNumber") as string, out int build);
                return editionSupported && (id == "delivery-optimization-no-peers" || build >= 22621);
            }
            return new SystemTweak { Id = id, Title = title, Summary = summary,
                TradeOff = "Individual choice; excluded from Apply All. " + cost,
                Category = TweakCategory.System, Grade = TweakGrade.A, Source = source,
                RebootRequired = reboot, ManualOnly = true,
                CheckApplySupport = _ => SupportedEdition() ? null : "Requires a supported Windows edition/build; use Windows Settings on this device.",
                CustomApply = () => {
                    if (!SupportedEdition()) throw new InvalidOperationException("This policy requires a supported Windows edition/build. Widgets and Search highlights require Windows 11 22H2 or later, Pro/Enterprise/Education; Home is not documented as supported. Use Windows Settings or review Widgets in Debloat on Home.");
                    return state.Apply();
                }, CustomRevert = state.Revert, InspectCommandState = () => SupportedEdition() ? state.Inspect() : null };
        }
        public static IReadOnlyList<SystemTweak> General { get; } = new[] {
            Policy("widgets-off", "Disable Windows Widgets",
                "Disables the Widgets experience, including taskbar content. Targets Widgets and its web content; does not remove the shared WebView2 runtime. Restart Windows after applying.",
                "Weather, news and the Widgets board become unavailable. Requires Windows 11 22H2 or later on Pro/Enterprise/Education. On Home, review Windows Web Experience Pack in Debloat; hiding the taskbar icon alone does not disable Widgets.",
                @"SOFTWARE\Policies\Microsoft\Dsh", "AllowNewsAndInterests", 0,
                "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-newsandinterests", true),
            Policy("search-highlights-off", "Disable Search highlights",
                "Turns off rotating highlights in Windows Search. File and app search remain available. Does not promise to eliminate SearchHost or its WebView2 processes.",
                "Search loses featured news and highlights. Requires Windows 11 22H2 or later on Pro/Enterprise/Education. On Home, use Settings > Privacy & security > Search permissions > Show search highlights.",
                @"SOFTWARE\Policies\Microsoft\Windows\Windows Search", "EnableDynamicContentInWSB", 0,
                "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-search#allowsearchhighlights", true),
            Policy("edge-sleeping-tabs", "Enable Edge sleeping tabs",
                "Lets Edge put idle background tabs to sleep to reduce resource use. Already enabled by default; useful if previously disabled.",
                "Tabs may pause background work. Policy locks the setting and does not apply to profiles signed into a Microsoft account; availability depends on the Edge profile.",
                @"SOFTWARE\Policies\Microsoft\Edge", "SleepingTabsEnabled", 1,
                "https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/SleepingTabsEnabled"),
            Policy("edge-personalization-off", "Disable Edge browsing personalization",
                "Stops Edge browsing data being used to personalize advertising and Microsoft services. This is a privacy preference, not a speed tweak.",
                "Personalized content is reduced and the preference is locked. Microsoft documents this option as unavailable for child and enterprise accounts.",
                @"SOFTWARE\Policies\Microsoft\Edge", "PersonalizationReportingEnabled", 0,
                "https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/PersonalizationReportingEnabled"),
            Policy("edge-hardware-acceleration-off", "Disable Edge graphics acceleration",
                "Turns off graphics acceleration in Edge. Restart Edge after changing this setting.",
                "Uses software rendering, which can increase CPU usage. This machine policy controls the setting for all users.",
                @"SOFTWARE\Policies\Microsoft\Edge", "HardwareAccelerationModeEnabled", 0,
                "https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/HardwareAccelerationModeEnabled"),
            Policy("edge-startup-boost-off", "Disable Edge Startup Boost",
                "Stops Edge preloading at Windows sign-in. Reduces background activity when Startup Boost was enabled; FPS benefit is unmeasured.",
                "Edge may open more slowly. Machine policy affects all users and locks this setting in Edge.",
                @"SOFTWARE\Policies\Microsoft\Edge", "StartupBoostEnabled", 0,
                "https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/StartupBoostEnabled"),
            Policy("edge-background-mode-off", "Close Edge background apps",
                "Stops Edge apps continuing in the background after the last browser window closes. No benefit when background mode is already off.",
                "Background notifications and app tasks stop. Machine policy affects all users.",
                @"SOFTWARE\Policies\Microsoft\Edge", "BackgroundModeEnabled", 0,
                "https://learn.microsoft.com/en-us/deployedge/microsoft-edge-policies/BackgroundModeEnabled"),
            Policy("win32-long-paths", "Enable long file paths",
                "Allows longPathAware Win32 applications to use paths longer than 260 characters. A compatibility option, with no FPS or latency benefit.",
                "Older applications retain their own path limits. Restart applications or Windows.",
                @"SYSTEM\CurrentControlSet\Control\FileSystem", "LongPathsEnabled", 1,
                "https://learn.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation", true)
        };
        public static IReadOnlyList<SystemTweak> Network { get; } = new[] {
            Policy("delivery-optimization-no-peers", "Stop Windows Update peer transfers",
                "Uses HTTP downloads instead of Delivery Optimization peer sharing. Can avoid peer upload contention; does not improve idle connection latency.",
                "Updates still download. Loses LAN peer caching and may increase Internet downloads. Documented for Pro, Enterprise and Education editions; Home policy support is not established.",
                @"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization", "DODownloadMode", 0,
                "https://learn.microsoft.com/en-us/windows/deployment/do/delivery-optimization-configure")
        };
    }
}

