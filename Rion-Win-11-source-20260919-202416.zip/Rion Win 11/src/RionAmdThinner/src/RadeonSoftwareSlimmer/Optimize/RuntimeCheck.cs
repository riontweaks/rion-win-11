using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>
    /// Detects missing Visual C++ redistributables and the .NET Desktop Runtime, and installs the
    /// missing ones with the Microsoft winget source, including legacy DirectX desktop components.
    /// </summary>
    public static class RuntimeCheck
    {
        private sealed class Runtime
        {
            public string Name;
            public Func<bool> Installed;
            public string WingetId;
            public string Options = "";
        }

        public static async Task<(List<string> installed, List<string> alreadyPresent, List<string> failed)>
            RunAsync(Action<string> onLine, CancellationToken ct)
        {
            var installed = new List<string>();
            var present = new List<string>();
            var failed = new List<string>();

            string winget = await FindWingetAsync(ct).ConfigureAwait(false);
            bool haveWinget = winget != null;
            if (!haveWinget)
                onLine?.Invoke("Windows Package Manager is unavailable. Install or repair Microsoft App Installer, then reopen Rion and retry.");

            var runtimes = new List<Runtime>
            {
                new Runtime { Name = "Visual C++ v14 x64", WingetId = "Microsoft.VCRedist.2015+.x64",
                    Installed = () => V14Installed("x64") },
                new Runtime { Name = "Visual C++ v14 x86", WingetId = "Microsoft.VCRedist.2015+.x86",
                    Installed = () => V14Installed("x86") },
                new Runtime { Name = "Visual C++ 2013 x64", WingetId = "Microsoft.VCRedist.2013.x64",
                    Installed = () => UninstallKeyExists("Microsoft Visual C++ 2013 Redistributable (x64)") },
                new Runtime { Name = "Visual C++ 2013 x86", WingetId = "Microsoft.VCRedist.2013.x86",
                    Installed = () => UninstallKeyExists("Microsoft Visual C++ 2013 Redistributable (x86)") },
                new Runtime { Name = "Visual C++ 2012 x64", WingetId = "Microsoft.VCRedist.2012.x64",
                    Installed = () => UninstallKeyExists("Microsoft Visual C++ 2012 Redistributable (x64)") },
                new Runtime { Name = ".NET Desktop Runtime 8", WingetId = "Microsoft.DotNet.DesktopRuntime.8",
                    Installed = () => DotNetDesktopInstalled(8) },
                new Runtime { Name = "DirectX legacy desktop components", WingetId = "Microsoft.DirectX",
                    Options = " --installer-type exe", Installed = DirectXInstalled },
            };

            foreach (Runtime rt in runtimes)
            {
                ct.ThrowIfCancellationRequested();
                bool ok;
                try { ok = rt.Installed(); } catch { ok = false; }
                if (ok) { present.Add(rt.Name); continue; }

                if (!haveWinget) { failed.Add(rt.Name + " — install or repair Microsoft App Installer and retry"); continue; }

                onLine?.Invoke("Installing " + rt.Name + " …");
                var res = await ShellRunner.RunAsync(winget,
                    $"install --id {rt.WingetId} --exact --source winget{rt.Options} --silent --accept-package-agreements --accept-source-agreements --disable-interactivity",
                    l => onLine?.Invoke(l), timeoutMs: 15 * 60 * 1000, ct: ct).ConfigureAwait(false);

                ct.ThrowIfCancellationRequested();
                bool detected;
                try { detected = rt.Installed(); } catch { detected = false; }
                if (InstallationVerified(res, detected))
                {
                    installed.Add(rt.Name);
                    onLine?.Invoke(rt.Name + " — verified present after installation.");
                }
                else
                {
                    string detail = res.TimedOut ? "timed out after 15 minutes"
                        : $"exit 0x{unchecked((uint)res.ExitCode):X8}; required components not detected";
                    string output = string.Join(" ", (res.Output ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).TakeLast(4));
                    failed.Add(rt.Name + " — " + detail + (output.Length > 0 ? ". " + output : ""));
                    onLine?.Invoke(rt.Name + " — " + detail);
                }
            }

            return (installed, present, failed);
        }

        internal static bool InstallationVerified(ShellRunner.Result result, bool detected) =>
            detected && !result.TimedOut;

        private static async Task<string> FindWingetAsync(CancellationToken ct)
        {
            var candidates = new List<string> {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Microsoft", "WindowsApps", "winget.exe")
            };
            // An elevated process may not inherit the WindowsApps execution-alias PATH.
            var package = await ShellRunner.PowerShellAsync(
                "Get-AppxPackage -Name Microsoft.DesktopAppInstaller | Sort-Object Version -Descending | ForEach-Object { Join-Path $_.InstallLocation 'winget.exe' }",
                null, 15000, ct).ConfigureAwait(false);
            if (package.ExitCode == 0)
                candidates.AddRange((package.Output ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries));
            foreach (string candidate in candidates.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                ct.ThrowIfCancellationRequested();
                if (!Path.IsPathFullyQualified(candidate) || !File.Exists(candidate)) continue;
                var result = await ShellRunner.RunAsync(candidate, "--version", null, 15000, ct).ConfigureAwait(false);
                if (result.ExitCode == 0) return candidate;
            }
            return null;
        }

        private static bool V14Installed(string architecture)
        {
            foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view);
                using var key = root.OpenSubKey(@"SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\" + architecture);
                if (key?.GetValue("Installed") is int installed && installed == 1) return true;
            }
            return false;
        }

        private static bool DirectXInstalled()
        {
            // DirectX 12 in Windows does not replace these optional legacy game libraries.
            var directories = new List<string> { Environment.GetFolderPath(Environment.SpecialFolder.System) };
            if (Environment.Is64BitOperatingSystem)
                directories.Add(Environment.GetFolderPath(Environment.SpecialFolder.SystemX86));
            string[] libraries = { "d3dx9_43.dll", "d3dx10_43.dll", "d3dx11_43.dll",
                "D3DCompiler_43.dll", "xinput1_3.dll", "XAudio2_7.dll", "XAPOFX1_5.dll" };
            return directories.All(dir => !string.IsNullOrEmpty(dir) &&
                libraries.All(file => File.Exists(Path.Combine(dir, file))));
        }

        private static bool UninstallKeyExists(string displayNameContains)
        {
            foreach (string root in new[]
            {
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
            })
            {
                try
                {
                    using (RegistryKey k = Registry.LocalMachine.OpenSubKey(root))
                    {
                        if (k == null) continue;
                        foreach (string sub in k.GetSubKeyNames())
                        {
                            using (RegistryKey s = k.OpenSubKey(sub))
                            {
                                string dn = s?.GetValue("DisplayName") as string;
                                if (!string.IsNullOrEmpty(dn) &&
                                    dn.IndexOf(displayNameContains, StringComparison.OrdinalIgnoreCase) >= 0)
                                    return true;
                            }
                        }
                    }
                }
                catch (Exception ex) { StaticViewModel.AddDebugMessage(ex, "Uninstall-key scan failed"); }
            }
            return false;
        }

        private static bool DotNetDesktopInstalled(int major)
        {
            try
            {
                string dir = Environment.ExpandEnvironmentVariables(
                    @"%ProgramFiles%\dotnet\shared\Microsoft.WindowsDesktop.App");
                if (!System.IO.Directory.Exists(dir)) return false;
                return System.IO.Directory.GetDirectories(dir)
                    .Select(System.IO.Path.GetFileName)
                    .Any(v => v != null && v.StartsWith(major + ".", StringComparison.Ordinal));
            }
            catch { return false; }
        }
    }
}
