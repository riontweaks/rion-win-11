using System;
using System.Collections.Generic;
using Microsoft.Win32;

namespace RadeonSoftwareSlimmer.Optimize;

/// <summary>Documented Cloud Content controls with edition/build gates, using normal registry history.</summary>
public static class WindowsContentTweaks
{
    public static IReadOnlyList<SystemTweak> All { get; } = ReadCatalog();
    private static IReadOnlyList<SystemTweak> ReadCatalog()
    {
        using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        int.TryParse(key?.GetValue("CurrentBuildNumber") as string, out int build);
        return Create(key?.GetValue("EditionID") as string ?? "", build);
    }

    public static IReadOnlyList<SystemTweak> Create(string edition, int build)
    {
        bool supported = build >= 17134 && (edition.StartsWith("Enterprise", StringComparison.OrdinalIgnoreCase)
            || edition.StartsWith("Education", StringComparison.OrdinalIgnoreCase)
            || edition.StartsWith("IoTEnterprise", StringComparison.OrdinalIgnoreCase));
        SystemTweak Entry(string id, string title, string value, string effect, string anchor) => new()
        {
            Id = id, Title = title, Category = TweakCategory.System, Grade = TweakGrade.A,
            Summary = effect + " This reduces promotional content; no FPS gain is established.",
            TradeOff = "Microsoft's suggestions are hidden for this user. Requires Enterprise, Education or IoT Enterprise. On Home/Pro, use Windows Settings notification and suggested-content preferences.",
            Source = "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-experience#" + anchor,
            Hive = TweakHive.CurrentUser, KeyPath = @"Software\Policies\Microsoft\Windows\CloudContent",
            ValueName = value, TargetValue = 1, DefaultValue = null, RebootRequired = false,
            ApplyBlockedReason = supported ? null : "This policy is documented for Enterprise/Education/IoT Enterprise, Windows 10 1803 or newer. Use Windows Settings on this edition.",
        };
        return new[] {
            Entry("spotlight-settings-off", "Hide suggested content in Settings", "DisableWindowsSpotlightOnSettings",
                "Hides Microsoft app and feature suggestions in Settings.", "allowwindowsspotlightonsettings"),
            Entry("spotlight-notifications-off", "Hide Windows suggestion notifications", "DisableWindowsSpotlightOnActionCenter",
                "Stops Windows Spotlight app suggestions in the notification center.", "allowwindowsspotlightonactioncenter"),
            Entry("spotlight-welcome-off", "Skip Windows welcome promotions", "DisableWindowsSpotlightWindowsWelcomeExperience",
                "Stops the promotional welcome experience after Windows updates.", "allowwindowsspotlightwindowswelcomeexperience"),
        };
    }
}
