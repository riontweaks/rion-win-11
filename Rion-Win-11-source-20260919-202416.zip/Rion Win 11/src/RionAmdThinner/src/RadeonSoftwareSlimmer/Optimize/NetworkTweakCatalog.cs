using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>
    /// Curated, machine-wide network tweaks for the Tweaks > Network category. Reuses the same
    /// <see cref="SystemTweak"/>/<see cref="TweakService"/> machinery as <see cref="TweakCatalog"/> —
    /// deliberately no per-adapter (dynamic GUID) entries in this pass, to avoid enumerating
    /// adapter keys for one or two tweaks; those stay candidates for a later pass.
    /// </summary>
    public static class NetworkTweakCatalog
    {
        private const string TcpipParams = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters";

        public static IReadOnlyList<SystemTweak> All { get; } = new List<SystemTweak>
        {
            new SystemTweak
            {
                ApplyBlockedReason = "Legacy preset is not applicable as a modern Windows latency recommendation.",
                ManualOnly = true,
                Id = "net-max-user-port",
                Title = "Legacy Ephemeral Port Override",
                Category = TweakCategory.Performance,
                Summary = "The old MaxUserPort registry preset is retired. Modern Windows manages dynamic port ranges separately; changing this value is not a gaming-latency recommendation. Saved changes can be restored through the setting’s Revert changes action.",
                TradeOff = "Shorter retention can affect connection reuse; use only for diagnosed TCP port exhaustion.",
                Grade = TweakGrade.B,
                Source = "https://learn.microsoft.com/troubleshoot/windows-client/networking/tcp-ip-port-exhaustion-troubleshooting",
                RebootRequired = true,
                Hive = TweakHive.LocalMachine,
                KeyPath = TcpipParams,
                ValueName = "MaxUserPort",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 65534,
                DefaultValue = null,
            },
            new SystemTweak
            {
                ManualOnly = true,
                Id = "net-timed-wait-delay",
                Title = "Faster Socket Reuse (TIME_WAIT)",
                Category = TweakCategory.Performance,
                Summary = "Shortens TCP TIME_WAIT retention to 30 seconds. This is a port-exhaustion troubleshooting choice, not a way to lower UDP game ping.",
                TradeOff = "Shorter retention can affect connection reuse; use only for diagnosed TCP port exhaustion.",
                Grade = TweakGrade.A,
                Source = "Microsoft — Tcpip\\Parameters\\TcpTimedWaitDelay",
                RebootRequired = true,
                Hive = TweakHive.LocalMachine,
                KeyPath = TcpipParams,
                ValueName = "TcpTimedWaitDelay",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 30,
                DefaultValue = 120,
            },
            new SystemTweak
            {
                ManualOnly = true,
                Id = "net-prefer-ipv4",
                Title = "Prefer IPv4 Over IPv6",
                Category = TweakCategory.Performance,
                Summary = "Prefers IPv4 while leaving IPv6 enabled. Consider only for a diagnosed IPv6 connectivity or routing problem; it is not a general latency improvement.",
                TradeOff = "Changes address selection. May bypass a better IPv6 route and affect managed networks or VPNs.",
                Grade = TweakGrade.B,
                Source = "Microsoft KB929852 — DisabledComponents; widely used community network tweak",
                RebootRequired = true,
                Hive = TweakHive.LocalMachine,
                KeyPath = @"SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters",
                ValueName = "DisabledComponents",
                ValueKind = RegistryValueKind.DWord,
                TargetValue = 0x20,
                DefaultValue = 0,
            },
            // One shared identity also used by historical General records.
            TweakCatalog.All.Single(t => t.Id == "network-throttling-off"),
            new SystemTweak
            {
                Id = "nagle-off",
                ApplyBlockedReason = "The per-adapter TCPNoDelay override is unverified on Windows 11. New application is disabled; saved values can still be restored.",
                ManualOnly = true,
                Title = "TCP Acknowledgment Settings",
                Category = TweakCategory.Performance,
                Summary = "Writes TcpAckFrequency=1 and TCPNoDelay=1 to each adapter's registry settings. Microsoft's TcpAckFrequency guidance applies to Windows Server; the per-adapter TCPNoDelay value's effect on Windows 11 is unverified. This does not affect UDP traffic or establish a gaming-latency improvement.",
                TradeOff = "More frequent TCP acknowledgments can increase packet overhead. Microsoft advises studying the environment before changing the default. Exact saved registry values can be restored; older incomplete records require manual review.",
                Grade = TweakGrade.C,
                Source = "https://learn.microsoft.com/en-us/troubleshoot/windows-server/networking/registry-entry-control-tcp-acknowledgment-behavior ; https://learn.microsoft.com/en-us/windows/win32/winsock/ipproto-tcp-socket-options",
                CustomApply = NagleTweak.Apply,
                CustomRevert = NagleTweak.Revert,
                InspectCommandState = NagleTweak.IsDisabled,
            },
        };
    }
}
