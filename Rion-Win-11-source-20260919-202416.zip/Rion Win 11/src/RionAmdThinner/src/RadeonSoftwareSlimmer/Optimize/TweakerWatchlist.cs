using System.Collections.Generic;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>One registry value known to be touched by common third-party tweak tools.</summary>
    public sealed class WatchedValue
    {
        public TweakHive Hive { get; set; }
        public string KeyPath { get; set; }
        public string ValueName { get; set; }
        /// <summary>The value on a clean Windows install (null = the value is absent by default).</summary>
        public long? WindowsDefault { get; set; }
        public string Note { get; set; }
    }

    /// <summary>
    /// Registry values that O&amp;O ShutUp10, Chris Titus WinUtil, Optimizer, W10Privacy and the
    /// Sophia Script are known to change. Auto-Optimize reads these before a run purely to report
    /// "this PC shows signs another tweaker has been here" — the apply logic still just drives
    /// everything in <see cref="TweakCatalog"/> to its target.
    /// </summary>
    public static class TweakerWatchlist
    {
        public static IReadOnlyList<WatchedValue> All { get; } = new List<WatchedValue>
        {
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Policies\Microsoft\Windows\DataCollection", ValueName = "AllowTelemetry", WindowsDefault = null, Note = "Telemetry policy" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Policies\Microsoft\Windows\Windows Search", ValueName = "AllowCortana", WindowsDefault = null, Note = "Cortana policy" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Policies\Microsoft\Windows\CloudContent", ValueName = "DisableWindowsConsumerFeatures", WindowsDefault = null, Note = "Consumer features policy" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Policies\Microsoft\Windows\GameDVR", ValueName = "AllowGameDVR", WindowsDefault = null, Note = "GameDVR policy" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Control\PriorityControl", ValueName = "Win32PrioritySeparation", WindowsDefault = 2, Note = "CPU quantum / foreground boost" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Control", ValueName = "SvcHostSplitThresholdInKB", WindowsDefault = 0x380000, Note = "svchost grouping threshold" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile", ValueName = "SystemResponsiveness", WindowsDefault = 20, Note = "MMCSS reservation" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile", ValueName = "NetworkThrottlingIndex", WindowsDefault = 10, Note = "Network throttling" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", ValueName = "PowerThrottlingOff", WindowsDefault = 0, Note = "Power throttling" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", ValueName = "TdrDelay", WindowsDefault = 2, Note = "GPU TDR delay" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", ValueName = "HwSchMode", WindowsDefault = 1, Note = "Hardware-accelerated GPU scheduling" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Microsoft\Windows\Dwm", ValueName = "OverlayTestMode", WindowsDefault = null, Note = "Multiplane Overlay (MPO)" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate", ValueName = "ExcludeWUDriversInQualityUpdate", WindowsDefault = null, Note = "Windows Update driver exclusion" },
            new WatchedValue { Hive = TweakHive.CurrentUser, KeyPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo", ValueName = "Enabled", WindowsDefault = 1, Note = "Advertising ID" },
            new WatchedValue { Hive = TweakHive.CurrentUser, KeyPath = @"System\GameConfigStore", ValueName = "GameDVR_Enabled", WindowsDefault = 1, Note = "GameDVR (per user)" },
            new WatchedValue { Hive = TweakHive.CurrentUser, KeyPath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager", ValueName = "SilentInstalledAppsEnabled", WindowsDefault = 1, Note = "Silent app suggestions" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Services\DiagTrack", ValueName = "Start", WindowsDefault = 2, Note = "Connected User Experiences and Telemetry service" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SYSTEM\CurrentControlSet\Services\dmwappushservice", ValueName = "Start", WindowsDefault = 3, Note = "WAP Push message routing service" },
            new WatchedValue { Hive = TweakHive.LocalMachine, KeyPath = @"SOFTWARE\Policies\Microsoft\Windows Defender", ValueName = "DisableAntiSpyware", WindowsDefault = null, Note = "Defender policy (a red flag if set)" },
        };
    }
}
