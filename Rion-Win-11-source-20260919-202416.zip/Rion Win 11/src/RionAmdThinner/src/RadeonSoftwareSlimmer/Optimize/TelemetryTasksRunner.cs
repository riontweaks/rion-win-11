using System;
using System.Threading;
using System.Threading.Tasks;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>
    /// Disables the built-in scheduled tasks that drive telemetry / CEIP / the compatibility
    /// appraiser. Reversible — each can be re-enabled from Task Scheduler or with Enable-ScheduledTask.
    /// </summary>
    public static class TelemetryTasksRunner
    {
        private static readonly string[] Tasks =
        {
            // compatibility appraiser / inventory
            @"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
            @"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser Exp",
            @"\Microsoft\Windows\Application Experience\ProgramDataUpdater",
            @"\Microsoft\Windows\Application Experience\StartupAppTask",
            @"\Microsoft\Windows\Application Experience\PcaPatchDbTask",
            @"\Microsoft\Windows\Application Experience\PcaWallpaperAppDetect",
            @"\Microsoft\Windows\Application Experience\AitAgent",
            @"\Microsoft\Windows\Application Experience\MareBackup",
            // CEIP
            @"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
            @"\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
            @"\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask",
            @"\Microsoft\Windows\Customer Experience Improvement Program\BthSQM",
            @"\Microsoft\Windows\PI\Sqm-Tasks",
            // feedback / flighting / OneSettings
            @"\Microsoft\Windows\Feedback\Siuf\DmClient",
            @"\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload",
            @"\Microsoft\Windows\Flighting\FeatureConfig\ReconcileFeatures",
            @"\Microsoft\Windows\Flighting\FeatureConfig\UsageDataFlushing",
            @"\Microsoft\Windows\Flighting\FeatureConfig\UsageDataReporting",
            @"\Microsoft\Windows\Flighting\OneSettings\RefreshCache",
            @"\Microsoft\Windows\CloudExperienceHost\CreateObjectTask",
            // error reporting / diagnostics
            @"\Microsoft\Windows\Windows Error Reporting\QueueReporting",
            @"\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
            @"\Microsoft\Windows\DiskFootprint\Diagnostics",
            @"\Microsoft\Windows\Diagnosis\Scheduled",
            @"\Microsoft\Windows\NetTrace\GatherNetworkInfo",
            @"\Microsoft\Windows\Autochk\Proxy",
            @"\Microsoft\Windows\Maintenance\WinSAT",
            @"\Microsoft\Windows\DUSM\dusmtask",
            // family safety / maps / licence checks
            @"\Microsoft\Windows\Shell\FamilySafetyMonitor",
            @"\Microsoft\Windows\Shell\FamilySafetyRefreshTask",
            @"\Microsoft\Windows\Maps\MapsUpdateTask",
            @"\Microsoft\Windows\Maps\MapsToastTask",
            @"\Microsoft\Windows\Clip\License Validation",
            @"\Microsoft\Windows\Speech\SpeechModelDownloadTask",
        };

        public static async Task<(int disabled, int notPresent)> RunAsync(Action<string> onLine, CancellationToken ct)
        {
            int disabled = 0, missing = 0;

            string joined = string.Join(",", Array.ConvertAll(Tasks, t => "'" + t.Replace("'", "''") + "'"));
            string script = @"
$tasks = @(" + joined + @")
foreach ($t in $tasks) {
  $leaf = Split-Path $t -Leaf
  $path = (Split-Path $t -Parent) + '\'
  $st = Get-ScheduledTask -TaskName $leaf -TaskPath $path -ErrorAction SilentlyContinue
  if (-not $st) { Write-Output ""MISS`t$t""; continue }
  if ($st.State -eq 'Disabled') { Write-Output ""ALREADY`t$t""; continue }
  try { Disable-ScheduledTask -TaskName $leaf -TaskPath $path -ErrorAction Stop | Out-Null; Write-Output ""OFF`t$t"" }
  catch { Write-Output ""ERR`t$t`t$($_.Exception.Message)"" }
}
";
            await ShellRunner.PowerShellAsync(script, line =>
            {
                string[] p = line.Split('\t');
                if (p.Length >= 2 && p[0] == "OFF") { disabled++; onLine?.Invoke("Disabled task " + Trim(p[1])); }
                else if (p.Length >= 2 && p[0] == "MISS") { missing++; }
            }, timeoutMs: 2 * 60 * 1000, ct: ct).ConfigureAwait(false);

            return (disabled, missing);
        }

        private static string Trim(string full)
        {
            int i = full.LastIndexOf('\\');
            return i >= 0 ? full.Substring(i + 1) : full;
        }
    }
}
