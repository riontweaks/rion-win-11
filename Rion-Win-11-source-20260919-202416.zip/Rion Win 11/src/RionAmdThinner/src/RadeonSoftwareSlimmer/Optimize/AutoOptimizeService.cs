using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>
    /// Orchestrates an Auto-Optimize run: System Restore point → targeted registry snapshot →
    /// each selected section in a safe order → an <see cref="OptimizeReport"/>. Every reversible
    /// change is captured to a per-section <see cref="BackupSession"/> saved to
    /// <see cref="BackupStore"/>, so "Revert this run" uses the existing revert path.
    /// </summary>
    public sealed class AutoOptimizeService
    {
        private readonly WindowsRegistry _registry = new WindowsRegistry();
        public Func<SectionReport, OptimizeMonitor, CancellationToken, Task> ProcessReduction { get; set; }
        public IReadOnlyCollection<string> KeepDebloatApps { get; set; } = Array.Empty<string>();

        private static readonly OptimizeSection[] Order =
        {
            OptimizeSection.DiskCleanup,
            OptimizeSection.RegistryTweaks,
            OptimizeSection.BackgroundServices,
            OptimizeSection.ProcessReduction,
            OptimizeSection.Debloat,
            OptimizeSection.Runtimes,
            OptimizeSection.SystemFileCheck,
            OptimizeSection.GpuDriver,
        };

        public async Task<OptimizeReport> RunAsync(
            IReadOnlyCollection<OptimizeSection> selected, OptimizeMonitor monitor, CancellationToken ct)
        {
            var report = new OptimizeReport();
            AuditLog.StartSession("optimize-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture));

            // 1. Restore point
            monitor.Log("Creating a System Restore point…");
            report.RestorePointCreated = await Task.Run(
                () => RestorePoint.TryCreate("Rion Auto-Optimize " + DateTime.Now.ToString("g", CultureInfo.InvariantCulture)))
                .ConfigureAwait(false);
            monitor.Log(report.RestorePointCreated ? "Restore point created." : "Restore point unavailable (System Protection may be off) — continuing.");

            // 2. Snapshot + tweaker scan
            monitor.Log("Snapshotting the registry values this run can touch…");
            report.SnapshotPath = await Task.Run(() => RegistrySnapshot.Capture(_registry, out _)).ConfigureAwait(false);
            report.TweakerFindings.AddRange(await Task.Run(() => RegistrySnapshot.DiffFromDefault(_registry)).ConfigureAwait(false));
            if (report.TweakerFindings.Count > 0)
                monitor.Log($"{report.TweakerFindings.Count} watched value(s) already differ from a clean Windows install.");

            // 3. Sections
            foreach (OptimizeSection section in Order)
            {
                if (!selected.Contains(section)) continue;
                // Process reduction owns service choices when selected; the legacy trim must
                // not override the user's keep-feature selections earlier in the same run.
                if (section == OptimizeSection.BackgroundServices && selected.Contains(OptimizeSection.ProcessReduction))
                {
                    monitor.Begin(section);
                    monitor.End(section, SectionState.Skipped, "Handled by process reduction and its keep-feature choices");
                    continue;
                }
                if (ct.IsCancellationRequested) { report.Cancelled = true; break; }

                var sr = new SectionReport
                {
                    Section = section,
                    Title = OptimizeSectionInfo.All.First(i => i.Section == section).Title,
                };
                report.Sections.Add(sr);
                monitor.Begin(section);

                try
                {
                    switch (section)
                    {
                        case OptimizeSection.DiskCleanup: await RunDiskCleanup(sr, monitor, ct).ConfigureAwait(false); break;
                        case OptimizeSection.RegistryTweaks: await RunTweaksAsync(sr, monitor, ct, report).ConfigureAwait(false); break;
                        case OptimizeSection.BackgroundServices: RunServices(sr, monitor); break;
                        case OptimizeSection.ProcessReduction:
                            if (ProcessReduction == null) throw new InvalidOperationException("Process reduction is available in the main app.");
                            try { await ProcessReduction(sr, monitor, ct).ConfigureAwait(false); }
                            finally { if (sr.Applied.Count > 0) report.NeedsReboot = true; }
                            break;
                        case OptimizeSection.Debloat: await RunDebloat(sr, monitor, ct).ConfigureAwait(false); break;
                        case OptimizeSection.Runtimes: await RunRuntimes(sr, monitor, ct).ConfigureAwait(false); break;
                        case OptimizeSection.SystemFileCheck: await RunHealth(sr, monitor, ct, report).ConfigureAwait(false); break;
                        case OptimizeSection.GpuDriver: RunDriverCheck(sr, monitor, report); break;
                    }
                    sr.Outcome = sr.Failed.Count > 0 ? SectionState.Failed : SectionState.Done;
                }
                catch (OperationCanceledException) { report.Cancelled = true; sr.Outcome = SectionState.Skipped; monitor.End(section, SectionState.Skipped); break; }
                catch (Exception ex)
                {
                    sr.Outcome = SectionState.Failed;
                    sr.Failed.Add(ex.Message);
                    monitor.Log("Section failed: " + ex.Message);
                    StaticViewModel.AddLogMessage(ex, "Auto-Optimize section " + section + " failed");
                }

                monitor.End(section, sr.Outcome, sr.Summary);
            }

            monitor.Finish();
            AuditLog.Action("Auto-Optimize", "Run", "complete",
                newValue: $"{report.TotalApplied} applied / {report.TotalFailed} failed"
                          + (report.Cancelled ? " (cancelled)" : ""),
                result: report.Cancelled ? "Partial" : "OK", reversible: true);
            return report;
        }

        // ---------------------------------------------------------------- sections

        private static async Task RunDiskCleanup(SectionReport sr, OptimizeMonitor m, CancellationToken ct)
        {
            (long bytes, int files, List<string> notes) = await DiskCleanupRunner.RunAsync(m.Log, ct).ConfigureAwait(false);
            sr.Applied.Add($"Freed {bytes / 1024 / 1024} MB ({files} files)");
            foreach (string n in notes) sr.AlreadyOptimal.Add(n);
            sr.Summary = $"{bytes / 1024 / 1024} MB freed";
        }

        private Task RunTweaksAsync(SectionReport sr, OptimizeMonitor m, CancellationToken ct, OptimizeReport report)
        {
            // 1. Registry tweak catalog (idempotent — skip anything already at target).
            var svc = new TweakService(_registry);
            var toApply = new List<SystemTweak>();
            foreach (SystemTweak t in GeneralTweakCatalog.Recommended)
            {
                ct.ThrowIfCancellationRequested();
                switch (svc.Inspect(t, out long? cur))
                {
                    case TweakState.AtTarget: sr.AlreadyOptimal.Add(t.Title); break;
                    case TweakState.Unreadable: sr.Failed.Add(t.Title + " (unreadable)"); break;
                    default:
                        toApply.Add(t);
                        m.Log(cur == null
                            ? $"{t.Title}: not set → {t.EffectiveTarget}"
                            : $"{t.Title}: {cur} → {t.EffectiveTarget}");
                        break;
                }
            }

            var backup = new BackupSession { Description = "Auto-Optimize — performance tweaks" };
            IReadOnlyList<string> written = svc.Apply(toApply, backup, out bool reboot);
            string saved = backup.Save();
            if (saved != null) m.Log("Tweak undo data saved to " + saved);

            foreach (SystemTweak t in toApply)
            {
                if (written.Contains(t.Id)) sr.Applied.Add(t.Title);
                else if (svc.Inspect(t, out _) == TweakState.AtTarget) sr.AlreadyOptimal.Add(t.Title);
                else sr.Failed.Add(t.Title + " (requested state not confirmed)");
            }

            sr.Summary = reboot ? "some tweaks need a restart" : $"{written.Count} tweak(s) applied";
            if (reboot) report.NeedsReboot = true;
            return Task.CompletedTask;
        }

        private void RunServices(SectionReport sr, OptimizeMonitor m)
        {
            var backup = new BackupSession { Description = "Auto-Optimize — background services" };
            (List<string> applied, List<string> already, List<string> failed) = ServiceTrimCatalog.Apply(_registry, backup);
            string saved = backup.Save();
            if (saved != null) m.Log("Service undo data saved to " + saved);

            sr.Applied.AddRange(applied);
            sr.AlreadyOptimal.AddRange(already);
            sr.Failed.AddRange(failed);
            sr.Summary = $"{applied.Count} service(s) trimmed";
        }

        private async Task RunDebloat(SectionReport sr, OptimizeMonitor m, CancellationToken ct)
        {
            (List<string> removed, List<string> notPresent, List<string> failed) =
                await DebloatCatalog.RunAsync(m.Log, null, ct, KeepDebloatApps).ConfigureAwait(false);
            sr.Applied.AddRange(removed.Select(r => "Removed " + r));
            sr.AlreadyOptimal.AddRange(notPresent.Select(n => n + " (not installed)"));
            sr.Failed.AddRange(failed);
            sr.Summary = $"{removed.Count} app(s) removed";
        }

        private static async Task RunRuntimes(SectionReport sr, OptimizeMonitor m, CancellationToken ct)
        {
            (List<string> installed, List<string> present, List<string> failed) =
                await RuntimeCheck.RunAsync(m.Log, ct).ConfigureAwait(false);
            sr.Applied.AddRange(installed.Select(i => "Installed " + i));
            sr.AlreadyOptimal.AddRange(present.Select(p => p + " (present)"));
            sr.Failed.AddRange(failed);
            sr.Summary = $"{installed.Count} runtime(s) installed";
        }

        private static async Task RunHealth(SectionReport sr, OptimizeMonitor m, CancellationToken ct, OptimizeReport report)
        {
            SystemHealthRunner.Outcome o = await SystemHealthRunner.RunAsync(m.Log, ct).ConfigureAwait(false);
            sr.Summary = o.Summary;
            sr.Failed.AddRange(o.Failures);
            if (o.SfcRepaired || o.DismRepaired) sr.Applied.Add(o.Summary);
            else sr.AlreadyOptimal.Add(o.Summary);
            if (o.NeedsReboot) report.NeedsReboot = true;
        }

        private static void RunDriverCheck(SectionReport sr, OptimizeMonitor m, OptimizeReport report)
        {
            HardwareInfo hw = new HardwareInspector().Inspect();
            if (!hw.IsAmdGpu)
            {
                sr.AlreadyOptimal.Add("No AMD GPU — nothing to do.");
                sr.Summary = "not an AMD GPU";
                return;
            }

            DateTime? date = ParseDate(hw.DriverDate);
            if (date == null)
            {
                sr.AlreadyOptimal.Add($"Driver {hw.DriverVersion} (date unknown).");
                sr.Summary = "driver date unknown";
                return;
            }

            int months = (int)((DateTime.Now - date.Value).TotalDays / 30.0);
            if (months >= 6)
            {
                sr.Applied.Add($"Driver is {months} months old ({hw.DriverDate}). Open AMD GPU Manager → Driver Tool to install the current package.");
                sr.Summary = $"{months} months old — update recommended";
                m.Log($"AMD driver dated {hw.DriverDate} is {months} months old.");
            }
            else
            {
                sr.AlreadyOptimal.Add($"Driver is current — dated {hw.DriverDate} ({months} months).");
                sr.Summary = "driver is current";
            }
        }

        private static DateTime? ParseDate(string s)
        {
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime d)) return d;
            return null;
        }
    }
}
