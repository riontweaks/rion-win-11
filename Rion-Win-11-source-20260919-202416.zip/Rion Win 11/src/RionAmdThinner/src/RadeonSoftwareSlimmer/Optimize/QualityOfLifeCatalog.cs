using System;
using System.Collections.Generic;
using Microsoft.Win32;

namespace RadeonSoftwareSlimmer.Optimize;

/// <summary>Personal preferences, using the normal value-kind/presence-aware tweak journal.</summary>
public static class QualityOfLifeCatalog
{
    public const string Section = "Quality of life";
    private const string Personalize = @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";
    private const string Advanced = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
    private const string ExplorerPolicy = @"Software\Policies\Microsoft\Windows\Explorer";
    private const string AiPolicy = @"SOFTWARE\Policies\Microsoft\Windows\WindowsAI";
    private const string SettingsSource = "https://learn.microsoft.com/en-us/windows/apps/develop/settings/settings-common";
    private const string AiSource = "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-windowsai";
    public static IReadOnlyList<SystemTweak> All { get; } = ReadCatalog();
    private static IReadOnlyList<SystemTweak> ReadCatalog()
    {
        using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        int.TryParse(key?.GetValue("CurrentBuildNumber") as string, out int build);
        return Create(key?.GetValue("EditionID") as string ?? "", build, Convert.ToInt32(key?.GetValue("UBR") ?? 0));
    }
    public static IReadOnlyList<SystemTweak> Create(string edition, int build, int revision)
    {
        bool policyEdition = edition.StartsWith("Professional", StringComparison.OrdinalIgnoreCase)
            || edition.StartsWith("Enterprise", StringComparison.OrdinalIgnoreCase)
            || edition.StartsWith("Education", StringComparison.OrdinalIgnoreCase)
            || edition.StartsWith("IoTEnterprise", StringComparison.OrdinalIgnoreCase);
        var list = new List<SystemTweak>();
        SystemTweak Add(string id, string title, string path, string name, long target, string summary,
            string source = SettingsSource, bool machine = false, bool supported = true)
        {
            var item = new SystemTweak { Id = "qol-" + id, Title = title, Category = TweakCategory.System,
                Group = Section, Grade = TweakGrade.A, Summary = summary,
                TradeOff = "Personal preference. Sign out and back in if Windows does not refresh immediately. Restore returns the saved value, including an originally absent value.",
                Source = source, Hive = machine ? TweakHive.LocalMachine : TweakHive.CurrentUser,
                KeyPath = path, ValueName = name, TargetValue = target, DefaultValue = null,
                ApplyBlockedReason = supported ? null : "This Windows edition/build is not documented to support this policy. Use Windows Settings instead." };
            list.Add(item); return item;
        }
        Add("transparency", "Disable transparency", Personalize, "EnableTransparency", 0, "Makes Windows surfaces opaque.");
        Add("dark-apps", "Dark app mode", Personalize, "AppsUseLightTheme", 0, "Uses dark mode in apps that follow the Windows theme.");
        Add("dark-windows", "Dark Windows mode", Personalize, "SystemUsesLightTheme", 0, "Uses dark mode for Start, taskbar and Windows surfaces.");
        Add("task-view", "Hide Task View", Advanced, "ShowTaskViewButton", 0, "Hides the taskbar button. Win+Tab and virtual desktops remain available.", "https://github.com/microsoft/winget-dsc");
        Add("search-hidden", "Hide taskbar Search", @"Software\Microsoft\Windows\CurrentVersion\Search", "SearchboxTaskbarMode", 0,
            "Sets Search to Hidden. You can still search from Start or with Win+S.", "https://github.com/microsoft/winget-dsc");
        Add("taskbar-animations", "Disable taskbar animations", Advanced, "TaskbarAnimations", 0, "Disables taskbar animations; window animations have a separate control.").Grade = TweakGrade.B;
        Add("start-recommendations", "Hide Start recommendations", ExplorerPolicy, "HideRecommendedSection", 1,
            "Hides the Recommended section containing suggested apps and files.", "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-start#hiderecommendedsection", supported: policyEdition && build >= 22621);
        Add("start-recent-apps", "Hide recently added apps", ExplorerPolicy, "HideRecentlyAddedApps", 1,
            "Stops newly installed apps appearing in Start recommendations.", "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-start#hiderecentlyaddedapps", supported: policyEdition && build >= 22000);
        Add("onedrive", "Disable OneDrive file sync", @"Software\Policies\Microsoft\Windows\OneDrive", "DisableFileSyncNGSC", 1,
            "Keeps OneDrive file sync disabled across restarts while this policy remains configured. Does not delete local or cloud files.",
            "https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-system#disableonedrivefilesync", true, policyEdition && build >= 22000)
            .TradeOff = "OneDrive syncing and online-only file access stop. Download required cloud files first. Restore reverts the policy; Windows updates or organization policy can override preferences.";
        var recall = Add("recall", "Disable Recall snapshots", AiPolicy, "DisableAIDataAnalysis", 1,
            "Prevents Recall snapshots. Snipping Tool stays installed and usable.", AiSource + "#disableaidataanalysis", true,
            policyEdition && (build > 26100 || build == 26100 && revision >= 3915));
        recall.ManualOnly = recall.IndividualApplyOnly = true;
        recall.TradeOff = "Windows deletes existing Recall snapshots when this policy is enabled. Restore restores the policy, but cannot recover deleted snapshots. This requires an individual choice.";
        bool paintSupported = policyEdition && (build > 26100 || build == 26100 && revision >= 3360
            || (build == 22621 || build == 22631) && revision >= 4870);
        foreach (var (name, title) in new[] { ("DisableCocreator", "Disable Paint Cocreator"), ("DisableGenerativeFill", "Disable Paint generative fill"), ("DisableImageCreator", "Disable Paint Image Creator") })
            Add(name.ToLowerInvariant(), title, @"Software\Microsoft\Windows\CurrentVersion\Policies\Paint", name, 1,
                "Disables this Paint AI feature while preserving Paint and Snipping Tool.", AiSource + "#" + name.ToLowerInvariant(), true, paintSupported);
        var copilot = Add("copilot-legacy", "Disable legacy Windows Copilot", @"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", 1,
            "Disables the older Windows Copilot pane. Manage the current Copilot app separately in Debloating.", AiSource + "#turnoffwindowscopilot",
            supported: policyEdition && (build > 22621 || build == 22621 && revision >= 2361));
        copilot.TradeOff = "Microsoft has deprecated this policy. It does not block the current standalone Copilot app, websites or AI inside other apps.";
        return list;
    }
}
