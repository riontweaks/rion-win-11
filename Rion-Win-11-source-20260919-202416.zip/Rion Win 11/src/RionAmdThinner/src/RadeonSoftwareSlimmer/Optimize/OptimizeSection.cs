using System.Collections.Generic;

namespace RadeonSoftwareSlimmer.Optimize
{
    public enum OptimizeSection
    {
        DiskCleanup,
        RegistryTweaks,
        BackgroundServices,
        Debloat,
        Runtimes,
        SystemFileCheck,
        GpuDriver,
        ProcessReduction,
    }

    public sealed class OptimizeSectionInfo
    {
        public OptimizeSection Section { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        /// <summary>Segoe MDL2 Assets glyph string.</summary>
        public string Glyph { get; set; }

        public bool RecommendedDefault { get; set; }
        public bool MayNeedReboot { get; set; }
        public string EstDuration { get; set; }

        public static IReadOnlyList<OptimizeSectionInfo> All { get; } = new List<OptimizeSectionInfo>
        {
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.ProcessReduction,
                Title = "Process reduction",
                Description = "Review background services and startup apps, with RAM-tier service grouping. Choose which devices, reporting features and vendor helpers to keep. Cryptography, core networking, audio, Search and recovery stay protected. Scans fresh each run.",
                Glyph = "",
                RecommendedDefault = false,
                MayNeedReboot = true,
                EstDuration = "~1 min",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.DiskCleanup,
                Title = "Disk cleanup",
                Description = "Clear temp files, the Windows Update cache, thumbnail/icon caches and other safe "
                              + "leftovers before the rest of the run.",
                Glyph = "",
                RecommendedDefault = true,
                EstDuration = "~1 min",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.RegistryTweaks,
                Title = "Recommended tweaks",
                Description = "Apply every tweak marked Recommended in the Tweaks tab: privacy, suggestions and interface settings. Uses the same list as Apply recommended and skips changes already applied. Hardware, security, power and other individual choices remain separate.",
                Glyph = "",
                RecommendedDefault = true,
                MayNeedReboot = true,
                EstDuration = "instant",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.BackgroundServices,
                Title = "Trim background services",
                Description = "Set a curated set of non-essential Windows services (diagnostics tracking, "
                              + "retail demo, maps broker, fax, remote registry…) to Manual. Detects per-user instances and preserves protected or already-disabled services. Saves previous startup values; Manual services may still run on demand.",
                Glyph = "",
                RecommendedDefault = false,
                EstDuration = "instant",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.Debloat,
                Title = "Remove bloatware apps",
                Description = "Remove catalog-matched desktop and Store apps: Skype, Teams, Paint, Bing News/Weather, Tips, Feedback Hub, "
                              + "Maps, Solitaire and Clipchamp. Snipping Tool, Notepad, Camera, Calculator, Photos and Terminal are always kept. Xbox, Phone Link and OneDrive follow your keep choices. Store and shared runtimes remain available. For an individual checklist and optional Widgets removal, use Debloating.",
                Glyph = "",
                RecommendedDefault = false,
                EstDuration = "~2 min",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.Runtimes,
                Title = "Runtimes & DirectX",
                Description = "Detect missing Visual C++ redistributables, the .NET Desktop Runtime and the "
                              + "DirectX end-user runtime, and install the ones that are missing.",
                Glyph = "",
                RecommendedDefault = true,
                EstDuration = "1-5 min",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.SystemFileCheck,
                Title = "System file check",
                Description = "Run SFC and DISM to check and repair Windows system files. "
                              + "May take 5–20 minutes or longer.",
                Glyph = "",
                RecommendedDefault = true,
                EstDuration = "5-20 min",
            },
            new OptimizeSectionInfo
            {
                Section = OptimizeSection.GpuDriver,
                Title = "GPU driver",
                Description = "Check the installed AMD driver's date. If it is more than six months old, "
                              + "download the current package and hand it to the AMD installer.",
                Glyph = "",
                RecommendedDefault = false,
                EstDuration = "varies",
            },
        };
    }
}
