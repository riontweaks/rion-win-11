using System;
using System.Collections.Generic;
using System.Linq;

namespace RadeonSoftwareSlimmer.Optimize;

public static class GeneralTweakCatalog
{
	private static readonly HashSet<string> OwnedByAnotherCard = new HashSet<string>(StringComparer.Ordinal) { "svchost-split-threshold", "network-throttling-off" };

	private static readonly HashSet<string> RecommendedIds = new HashSet<string>(StringComparer.Ordinal)
	{
		"menu-show-delay", "min-animate-off", "telemetry-min", "advertising-id-off", "tailored-experiences-off", "consumer-features-off", "cdm-silent-apps-off", "cdm-start-suggestions-off", "cdm-tips-off", "telemetry-feedback-off",
		"telemetry-devicename-off", "telemetry-onesettings-off", "ceip-off", "appcompat-ait-off", "appcompat-inventory-off", "cloudcontent-soft-landing-off", "cloudcontent-account-state-off", "spotlight-settings-off", "spotlight-notifications-off", "spotlight-welcome-off"
	};

	public static IReadOnlyList<SystemTweak> Defined { get; } = TweakCatalog.All.Concat(ResearchedTweakCatalog.General).Concat(WindowsContentTweaks.All).Concat(OptimizerImportCatalog.All)
		.Concat(BasicTweakCatalog.All)
		.Concat(MultimediaTweakCatalog.All)
		.Concat(QualityOfLifeCatalog.All)
		.ToList();

	public static IReadOnlyList<SystemTweak> All { get; } = Defined.Where((SystemTweak t) => !OwnedByAnotherCard.Contains(t.Id)).ToList();

	public static IEnumerable<SystemTweak> Recommended => All.Where(IsRecommended);

	public static bool IsRecommended(SystemTweak tweak)
	{
		if (RecommendedIds.Contains(tweak.Id) && !tweak.ManualOnly && !tweak.IsAdjustable)
		{
			return string.IsNullOrEmpty(tweak.ApplyBlockedReason);
		}
		return false;
	}
}
