using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>
    /// The optional AppX debloat list. Everyday Windows utilities are protected. Removal is via
    /// Remove-AppxPackage / Remove-AppxProvisionedPackage; it is not registry-revertible, so this
    /// is an explicit opt-in section. Supported apps can be reinstalled from Microsoft Store;
    /// retired products may no longer be available. Uninstall does not preserve local app data.
    /// </summary>
    public static class DebloatCatalog
    {
        /// <summary>Exact version-independent AppX names; unknown identities stay review-only.</summary>
        public static IReadOnlyList<string> Remove { get; } = new[]
        {
            "Microsoft.SkypeApp",
            "Microsoft.YourPhone",                 // Phone Link; some builds mark it non-removable
            "Microsoft.Copilot",                   // standalone optional Copilot app
            "MicrosoftTeams",                      // consumer Teams / Chat
            "MSTeams",
            "Microsoft.Paint",                     // Store "Paint" app
            "Microsoft.MSPaint",                   // Paint 3D
            "Microsoft.BingNews",
            "Microsoft.BingWeather",
            "Microsoft.BingFinance",
            "Microsoft.BingSports",
            "Microsoft.GetHelp",
            "Microsoft.Getstarted",                // Tips
            "Microsoft.WindowsFeedbackHub",
            "Microsoft.WindowsMaps",
            "Microsoft.MicrosoftOfficeHub",
            "Microsoft.People",
            "Microsoft.MicrosoftSolitaireCollection",
            "Microsoft.Windows.DevHome",
            "Microsoft.Todos",
            "Microsoft.PowerAutomateDesktop",
            "Microsoft.MixedReality.Portal",
            "Microsoft.Microsoft3DViewer",
            "Microsoft.Print3D",
            "Microsoft.549981C3F5F10",             // Cortana
            "MicrosoftCorporationII.QuickAssist",
            "Microsoft.Family",
            "Microsoft.OutlookForWindows",         // "new Outlook" nag app
            "Clipchamp.Clipchamp",
            "Microsoft.ZuneMusic",                 // Groove (Media Player kept separately)
            "Microsoft.ZuneVideo",
            "Microsoft.WindowsAlarms",
            "Microsoft.GamingApp.Beta",
            "Microsoft.GamingApp",
            "Microsoft.XboxApp",
            "Microsoft.XboxGamingOverlay",
            "Microsoft.XboxGameOverlay",
            "Microsoft.Xbox.TCUI",
            "Microsoft.XboxIdentityProvider",
            "Microsoft.XboxSpeechToTextOverlay",
            "Microsoft.WindowsSoundRecorder",
            "microsoft.windowscommunicationsapps",
            "Microsoft.MicrosoftJournal",
            "Microsoft.BingSearch",
        };

        /// <summary>Never removed — matched as a fragment, wins over the remove list.</summary>
        public static IReadOnlyList<string> KeepAlways { get; } = new[]
        {
            "Microsoft.ScreenSketch",              // Snipping Tool
            "Microsoft.WindowsTerminal",
            "Microsoft.Windows.Photos",
            "Microsoft.WindowsCalculator",
            "Microsoft.WindowsCamera",
            "Microsoft.WindowsNotepad",
            "Microsoft.WindowsStore",
            "Microsoft.StorePurchaseApp",
            "Microsoft.GamingServices",            // runtime for existing installed games
            "Microsoft.SecHealthUI",               // Windows Security
            "Microsoft.VCLibs",
            "Microsoft.NET",
            "Microsoft.UI.Xaml",
            "Microsoft.Services.Store",
            "Microsoft.WebpImageExtension",
            "Microsoft.HEIFImageExtension",
            "Microsoft.RawImageExtension",
            "Microsoft.VP9VideoExtensions",
            "Microsoft.WebMediaExtensions",
            "MicrosoftWindows.Client",
            "Microsoft.DesktopAppInstaller",       // winget
            "Microsoft.MicrosoftEdge",
            "MicrosoftCorporationII.WinAppRuntime",
            "Microsoft.WindowsAppRuntime",
            "Microsoft.LanguageExperiencePack",
        };

        /// <summary>
        /// Removes the debloat set for the current + all users and the provisioned image.
        /// Streams progress lines to <paramref name="onLine"/>. Returns removed / not-present /
        /// failed display names.
        /// </summary>
        public static async Task<(List<string> removed, List<string> notPresent, List<string> failed)>
            RunAsync(Action<string> onLine, CancellationToken ct) => await RunAsync(onLine, null, ct);

        /// <summary>onProgress reports (fragments processed, total fragments) as the script works
        /// through <see cref="Remove"/> — a fragment can remove zero, one, or several packages, so
        /// this counts fragments, not individual removals; good enough for a progress bar without
        /// needing per-package foreknowledge.</summary>
        public static async Task<(List<string> removed, List<string> notPresent, List<string> failed)>
            RunAsync(Action<string> onLine, Action<int, int> onProgress, CancellationToken ct, IReadOnlyCollection<string> keep = null,
                bool removeWidgets = false, IReadOnlyCollection<string> reviewedNames = null)
        {
            var removed = new List<string>();
            var notPresent = new List<string>();
            var failed = new List<string>();

            keep ??= new[] { "Microsoft OneDrive" }; // sync removal requires an explicit caller choice
            var desktop = await DesktopDebloatCatalog.RunAsync(onLine, ct, keep, reviewedNames).ConfigureAwait(false);
            removed.AddRange(desktop.removed);
            failed.AddRange(desktop.failed);

            string script = CreateStoreScript(keep, removeWidgets, reviewedNames);

            var res = await ShellRunner.PowerShellAsync(script, line =>
            {
                string[] parts = line.Split('\t');
                if (parts.Length >= 3 && parts[0] == "PROGRESS" && int.TryParse(parts[1], out int cur) && int.TryParse(parts[2], out int tot)) { onProgress?.Invoke(cur, tot); }
                else if (parts.Length >= 2 && parts[0] == "GONE") { removed.Add(parts[1]); onLine?.Invoke("Removed " + parts[1]); }
                else if (parts.Length >= 2 && parts[0] == "PROV") { notPresent.Remove(parts[1]); removed.Add(parts[1] + " (new-user provisioning)"); onLine?.Invoke("De-provisioned " + parts[1]); }
                else if (parts.Length >= 2 && parts[0] == "MISS") { notPresent.Add(parts[1]); }
                else if (parts.Length >= 2 && parts[0] == "FAIL") { failed.Add(string.Join(": ", parts.Skip(1))); onLine?.Invoke("Could not remove " + failed.Last()); }
                else if (parts.Length >= 2 && parts[0] == "INFO") { onLine?.Invoke(string.Join(" · ", parts.Skip(1))); }
            }, timeoutMs: 8 * 60 * 1000, ct: ct).ConfigureAwait(false);

            foreach (string r in removed.Skip(desktop.removed.Count))
                AuditLog.Action("Auto-Optimize", "RemoveAppx", r, newValue: "removed", result: "OK", reversible: false);

            ct.ThrowIfCancellationRequested();
            if (res.ExitCode != 0 || res.TimedOut || !(res.Output ?? "").Split('\n').Any(l => l.Trim() == "DONE"))
                failed.Add("Store removal incomplete (exit " + res.ExitCode + (res.TimedOut ? ", timed out" : "") + ").");

            return (removed, notPresent, failed);
        }
        public static string CreateStoreScript(IReadOnlyCollection<string> keep = null,
            bool removeWidgets = false, IReadOnlyCollection<string> reviewedNames = null) =>
            DebloatPackageRemoval.CreateScript(keep, removeWidgets, reviewedNames);
    }
}
