using System;
using System.IO;
using System.Linq;
using Microsoft.Win32;
using RadeonSoftwareSlimmer.Intefaces;
using RadeonSoftwareSlimmer.Services;

namespace RadeonSoftwareSlimmer.Optimize
{
    /// <summary>Inspects and restores historical VBS/HVCI configuration changes. New disabling is retired.</summary>
    internal static class VbsTweak
    {
        internal const string DeviceGuardKey = @"SYSTEM\CurrentControlSet\Control\DeviceGuard";
        internal const string HvciKey = DeviceGuardKey + @"\Scenarios\HypervisorEnforcedCodeIntegrity";
        internal const string PolicyKey = @"SOFTWARE\Policies\Microsoft\Windows\DeviceGuard";
        private const string HistoryDescription = "VBS and memory integrity configuration";
        private static readonly (string Path, string Name)[] Settings =
        {
            (DeviceGuardKey, "EnableVirtualizationBasedSecurity"),
            (HvciKey, "Enabled"),
        };

        public static bool? IsDisabled() => IsDisabled(new WindowsRegistry());
        public static bool Apply() => throw new InvalidOperationException("Disabling VBS / memory integrity is retired. Restore saved state in the setting’s Revert changes action.");
        public static bool Revert() => Revert(new WindowsRegistry(), BackupStore.BackupDirectory);

        internal static bool? IsDisabled(IRegistry registry)
        {
            try
            {
                // Absence is not proof that Windows has disabled a protection by default.
                return Settings.All(setting => Read(registry, setting.Path, setting.Name)
                    .Same(RegistryValueSnapshot.Capture(true, 0, RegistryValueKind.DWord)));
            }
            catch { return null; }
        }

        internal static bool Revert(IRegistry registry, string backupDirectory)
        {
            lock (RegistryChangeHistory.Sync)
            {
                var targets = Settings.Select(setting => "HKLM\\" + setting.Path + "\\" + setting.Name).ToArray();
                var entries = RegistryChangeHistory.ListEntries(backupDirectory, registry)
                    .Where(entry => entry.Description == HistoryDescription && entry.Status != "Restored"
                        && targets.Contains(entry.Target, StringComparer.OrdinalIgnoreCase)).ToList();
                if (entries.Count == 0)
                    throw new InvalidOperationException("No saved VBS configuration is available. Older versions did not capture these values; choose the desired protection in Windows Security. No defaults were substituted.");

                var failures = entries.Select(entry => RegistryChangeHistory.Restore(entry.Id, registry, backupDirectory))
                    .Where(result => !result.Success).Select(result => result.Message).ToArray();
                if (failures.Length > 0)
                    throw new IOException("VBS recovery is incomplete: " + string.Join(" ", failures));
                return true;
            }
        }

        private static RegistryValueSnapshot Read(IRegistry registry, string path, string name)
        {
            using (var key = registry.LocalMachine.OpenSubKey(path, false))
                return RegistryValueSnapshot.Read(key, name);
        }

    }
}
