namespace PowerSettingsExplorer.Services;

public enum RecoConfidence
{
    /// <summary>First-party (Microsoft / silicon vendor) documentation backs this value.</summary>
    Strong,
    /// <summary>Documented setting, value is a defensible default for a performance-first plan
    /// but carries a real trade-off (power draw, heat, battery) - not a blanket "always do this".</summary>
    Moderate,
}

/// <summary>
/// One curated recommendation for a Windows power setting. <see cref="ValueMatch"/> is compared
/// (case-insensitive, exact only) against each possible value's friendly name; for ranged
/// settings <see cref="RangedTarget"/> is used instead.
/// </summary>
public sealed record Recommendation(
    Guid Setting,
    string ValueMatch,
    uint? RangedTarget,
    string Rationale,
    string SourceLabel,
    string SourceUrl,
    RecoConfidence Confidence,
    bool IndividualOnly = false)
{
    // Never substitute a nearby number or a partial English label for the sourced value.
    public uint? ResolveTarget(bool ranged, uint min, uint max, uint increment,
        IEnumerable<(uint Index, string Name)> values)
    {
        if (ranged)
        {
            if (RangedTarget is not { } value || value < min || value > max) return null;
            return (value - min) % Math.Max(1u, increment) == 0 ? value : null;
        }
        if (string.IsNullOrWhiteSpace(ValueMatch)) return null;
        var matches = values.Where(v => string.Equals(v.Name.Trim(), ValueMatch, StringComparison.OrdinalIgnoreCase)).ToArray();
        return matches.Length == 1 ? matches[0].Index : null;
    }
}

/// <summary>
/// Hand-maintained list of power-setting recommendations. Deliberately small: an entry only
/// earns a place if the value is backed by first-party documentation or clear, long-standing
/// consensus. Everything here targets a desktop / plugged-in ("AC") performance-first plan.
/// </summary>
public static class RecommendationCatalog
{
    private const string PowerPolicyDoc =
        "https://learn.microsoft.com/windows/win32/power/power-policy-settings";
    private const string PerfTuningDoc =
        "https://learn.microsoft.com/en-us/windows-server/administration/performance-tuning/hardware/power/";

    private static readonly Recommendation[] Items =
    {
        new(new("3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e"), "", 600,
            "Suggested AC starting point: turn the screen off after 10 idle minutes. Saves display power without stopping background work. the screen will blank during unattended viewing unless the app requests it stay on. Adjust for your workflow.",
            "Microsoft — Display idle timeout", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/display-settings-display-idle-timeout", RecoConfidence.Moderate, true),
        new(new("29f6c1db-86da-48c5-9fdb-f2b67b1f44da"), "", 1800,
            "Suggested AC starting point: sleep after 30 idle minutes. sleep can interrupt unattended downloads, remote access and long-running jobs. Choose Never for a machine that must stay available. This is a convenience choice, not an FPS optimization.",
            "Microsoft — Sleep idle timeout", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/sleep-settings-sleep-idle-timeout", RecoConfidence.Moderate, true),
        new(new("9d7815a6-7ee4-497e-8888-515a05f02364"), "", 10800,
            "Suggested AC starting point: hibernate after three hours asleep. resume is slower and hibernation requires disk space and system support. Modern Standby behavior depends on hardware. This does not enable hibernation if it is disabled.",
            "Microsoft — Hibernate idle timeout", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/sleep-settings-hibernate-idle-timeout", RecoConfidence.Moderate, true),
        // ---- Processor power management (54533251-...) --------------------------------
        new(new("94d3a615-a899-4ac5-ae2b-e4d8f634367f"), "Active", null,
            "Active cooling requests increased fan cooling before reducing processor performance, "
            + "where supported. Firmware still controls thermal limits; passive cooling may be intentional.",
            "Microsoft — Power Policy Settings", PowerPolicyDoc, RecoConfidence.Strong),

        new(new("be337238-0d82-4146-a960-4f3749d470c7"), "", null,
            "Boost-mode behavior depends on the processor performance interface and firmware. Aggressive is not a universal best value. Review the CPU or system-vendor policy before changing the current mode.",
            "Microsoft - processor power policy", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/options-for-perf-state-engine-perfboostmode", RecoConfidence.Moderate, true),

        new(new("893dee8e-2bef-41e0-89c6-b55d0929964c"), "", null,
            "Minimum processor state is a performance-policy floor, not a fixed CPU clock. Keep the platform-provisioned value unless a measured workload needs a different floor. There is no universal 100% recommendation.",
            "Microsoft - processor power policy", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/options-for-perf-state-engine-minperformance", RecoConfidence.Moderate, true),

        new(new("bc5038f7-23e0-4960-96da-33abaf5935ec"), "", 100,
            "A maximum processor state of 100% avoids a lower cap from this setting. Actual clocks and "
            + "boost still depend on firmware, thermals and other policies. A lower value may be intentional "
            + "for temperature or power limits; review that purpose before changing it.",
            "Microsoft — Power Policy Settings", PowerPolicyDoc, RecoConfidence.Strong),

        new(new("45bcc044-d885-43e2-8605-ee0ec6e96b59"), "", null,
            "Boost policy interpretation depends on processor and firmware support. Do not assume this legacy percentage controls boost on every modern CPU. Keep the provisioned value unless the platform documentation supports a change.",
            "Microsoft - processor power policy", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/configure-processor-power-management-options", RecoConfidence.Moderate, true),

        new(new("465e1f50-b610-473a-ab58-00d1077dc418"), "", null,
            "Performance increase policy applies to OS-directed frequency scaling. Rocket is not a universal latency recommendation and does not govern autonomous CPPC performance selection. Keep the platform value unless its applicability and benefit are established.",
            "Microsoft - processor power policy", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/options-for-perf-state-engine-perfincreasepolicy", RecoConfidence.Moderate, true),

        new(new("0cc5b647-c1df-4637-891a-dec35c318583"), "", null,
            "Core parking depends on CPU topology, chipset software and workload. Keeping every logical processor unparked can interfere with platform scheduling choices. There is no universal 100% recommendation.",
            "Microsoft - processor power policy", "https://learn.microsoft.com/en-us/windows-hardware/customize/power-settings/configure-processor-power-management-options", RecoConfidence.Moderate, true),

        new(new("5d76a2ca-e8c0-402f-a133-2158492d58ad"), "", null,
            "Processor idle disable controls CPU idle states: 0 allows idle; 1 disables idle. "
            + "Disabling idle may reduce wake-up latency, but increases power use and heat and can reduce thermal headroom. "
            + "A timer sleep result does not establish lower game latency or higher FPS. Keep the current policy unless testing a specific issue; avoid disabling idle on battery. "
            + "The Windows Hidden attribute only controls visibility, not whether idle is enabled. "
            + "Edit the selected plan's plugged-in or battery value below; Apply changes saves its previous value for recovery. "
            + "The linked Microsoft server guidance explains the mechanism, not a Windows 11 gaming recommendation.",
            "Microsoft — Processor idle states and IDLEDISABLE",
            "https://devblogs.microsoft.com/sustainable-software/tuning-servers-for-energy-savings/", RecoConfidence.Moderate, true),

        new(new("3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb"), "", null,
            "Keep the platform thermal-management policy. Disabling software throttle states is not a general performance recommendation, particularly on mobile or thermally constrained systems.",
            "Microsoft - processor power policy", "https://learn.microsoft.com/windows/win32/power/power-policy-settings", RecoConfidence.Moderate, true),

        // ---- PCI Express (501a4d13-...) ---------------------------------------------
        new(new("ee12f906-d277-404b-b6da-e5fa1a576df5"), "Off", null,
            "Disables PCIe link power saving. Consider for a diagnosed device wake or compatibility "
            + "issue; a performance gain is not established. Idle power can increase.",
            "Microsoft — Performance Tuning: Power", PerfTuningDoc, RecoConfidence.Moderate, true),

        // ---- USB settings (2a737441-...) ------------------------------------------
        new(new("48e6b7a6-50f5-4782-a5d4-53bb8f07e226"), "Disabled", null,
            "Disables USB selective suspend. Consider only when diagnosing a reproducible device "
            + "disconnect or resume problem; improved game performance is not established. Microsoft "
            + "recommends leaving selective suspend enabled. Disabling it increases power use.",
            "Microsoft — USB selective suspend", "https://learn.microsoft.com/en-us/windows-hardware/drivers/usbcon/usb-selective-suspend", RecoConfidence.Moderate, true),

        // ---- Hard disk (0012ee47-...) --------------------------------------------
        new(new("6738e2c4-e8a5-4a42-b16a-e040e769756e"), "", 0,
            "\"Never\" (0) prevents this idle disk timeout. It may avoid spin-up waits on hard disks, "
            + "but can increase power use. It does not control every SATA or NVMe power state.",
            "Long-standing consensus (SSD desktop)", "", RecoConfidence.Moderate, true),

        new(new("dab60367-53fe-4fbc-825e-521d069d2456"), "Active", null,
            "AHCI Link Power Management = Active requests that SATA links avoid HIPM/DIPM sleep. "
            + "Consider only for a demonstrated SATA wake issue; NVMe uses different controls. "
            + "Idle power can increase.",
            "Long-standing consensus (SATA latency)", "", RecoConfidence.Moderate, true),

        // ---- Multimedia settings (9596fb26-...) --------------------------------
        new(new("03680956-93bc-4294-bba6-4e0f09bb717f"), "Prevent idling to sleep", null,
            "\"When sharing media\" = Prevent idling to sleep keeps the machine awake while it is "
            + "streaming / casting to another device, instead of dropping to sleep mid-stream.",
            "Microsoft — Power Policy Settings", PowerPolicyDoc, RecoConfidence.Moderate, true),

        // ---- Wireless adapter settings (19cbb8fa-...) ---------------------------
        new(new("12bbebe6-58d6-4636-95bb-3217ef867c1a"), "Maximum Performance", null,
            "Requests maximum performance from supported Wi-Fi power policies. The adapter driver "
            + "may manage power differently; lower ping or jitter is not guaranteed. Battery use can increase.",
            "Intel / adapter-vendor guidance", "", RecoConfidence.Moderate, true),
    };

    private static readonly Dictionary<Guid, Recommendation> ByGuid =
        Items.ToDictionary(r => r.Setting);

    public static Recommendation? For(Guid settingGuid, bool isMobile = false) =>
        ByGuid.TryGetValue(settingGuid, out var r) ? (isMobile ? r with { IndividualOnly = true } : r) : null;

    public static int Count => Items.Length;
}
