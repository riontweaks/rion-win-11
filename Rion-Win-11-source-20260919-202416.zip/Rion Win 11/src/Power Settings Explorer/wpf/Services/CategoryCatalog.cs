namespace PowerSettingsExplorer.Services;

/// <summary>A left-rail category grouping one or more power subgroups by what they do.</summary>
public sealed record PowerCategory(string Id, string Name, string Glyph, int Order);

public static class CategoryCatalog
{
    public const string GeneralId = "general";

    // Glyphs are Segoe MDL2 Assets / Segoe Fluent Icons code points.
    public static readonly PowerCategory General =
        new(GeneralId, "General", "", 100);

    private static readonly PowerCategory[] Categories =
    {
        new("battery",   "Battery & energy", "", 10),
        new("sleep",     "Sleep & wake",     "", 20),
        new("display",   "Display & media",  "", 30),
        new("processor", "Processor",        "", 40),
        new("devices",   "Disks & devices",  "", 50),
        new("buttons",   "Buttons & lid",    "", 60),
        General,
    };

    public static IReadOnlyList<PowerCategory> All => Categories;

    /// <summary>Known Windows subgroup GUID -> category id.</summary>
    private static readonly Dictionary<Guid, string> Map = new()
    {
        [new("e73a048d-bf27-4f12-9731-8b2076e8891f")] = "battery",   // Battery
        [new("de830923-a562-41af-a086-e3a2c6bad2da")] = "battery",   // Energy Saver
        [new("f15576e8-98b7-4186-b944-eafa664402d9")] = "battery",   // Power Saving / adaptive
        [new("238c9fa8-0aad-41ed-83f4-97be242c8f20")] = "sleep",     // Sleep
        [new("8619b916-e004-4dd8-9b66-dae86f806698")] = "sleep",     // Presence-aware power behavior
        [new("2e601130-5351-4d9d-8e04-252966bad054")] = "sleep",     // Idle resiliency
        [new("7516b95f-f776-4464-8c53-06167f40cc99")] = "display",   // Display
        [new("0d7dbae2-4294-402a-ba8e-26777e8488cd")] = "display",   // Desktop background
        [new("9596fb26-9850-41fd-ac3e-f7c3c00afd4b")] = "display",   // Multimedia
        [new("5fb4938d-1ee8-4b0f-9a3c-5036b0ab995c")] = "display",   // Switchable dynamic graphics
        [new("44f3beca-a7c0-460e-9df2-bb8b99e0cba6")] = "display",   // Intel graphics
        [new("f693fb01-e858-4f40-9194-a4d7d6a3d3d0")] = "display",   // AMD/ATI graphics
        [new("54533251-82be-4824-96c1-47b60b740d00")] = "processor", // Processor power management
        [new("48672f38-7a9a-4bb2-8bf8-3d85be19de4e")] = "processor", // Interrupt steering
        [new("0012ee47-9041-4b5d-9b77-535fba8b1442")] = "devices",   // Hard disk
        [new("501a4d13-42af-4429-9fd1-a8218c268e20")] = "devices",   // PCI Express
        [new("2a737441-1930-4402-8d77-b2bebba308a3")] = "devices",   // USB settings
        [new("19cbb8fa-5279-450e-9fac-8a3d5fedd0c1")] = "devices",   // Wireless adapter settings
        [new("0b2d69d7-a2a1-449c-9680-f91c70521c60")] = "devices",   // AHCI link power (HIPM/DIPM)
        [new("dab60367-53fe-4fbc-825e-521d069d2456")] = "devices",   // AHCI link power - adaptive
        [new("4f971e89-eebd-4455-a8de-9e59040e7347")] = "buttons",   // Power buttons and lid
        [new("02f815b5-a5cf-4c84-bf20-649d1f75d3d8")] = GeneralId,   // Internet Explorer
        [new("fea3413e-7e05-4911-9a71-700331f1c294")] = GeneralId,   // (no subgroup)
    };

    public static PowerCategory Resolve(Guid subgroup) =>
        Map.TryGetValue(subgroup, out var id)
            ? Categories.First(c => c.Id == id)
            : General;
}
