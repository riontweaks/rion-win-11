using System.IO;
using System.Text.Json;
using PowerSettingsExplorer.Interop;

namespace PowerSettingsExplorer.Services;

public sealed record PowerHistoryEntry(string Id, DateTime TimestampUtc, string Description, string Target,
    string PreviousValue, string RequestedValue, string Status, string Error, bool CanRestore);
public sealed record PowerHistoryResult(bool Success, string Message);
public readonly record struct PowerTarget(Guid Scheme, Guid Subgroup, Guid Setting, bool Dc);

public interface IPowerHistoryBackend
{
    uint Read(PowerTarget target);
    void Validate(PowerTarget target, uint value);
    void Write(PowerTarget target, uint value);
    void Activate();
}

public static class PowerChangeHistory
{
    private static readonly PowerHistoryStore Store = new(new WindowsPowerHistoryBackend(),
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "history", "power"));
    public static IReadOnlyList<PowerHistoryEntry> ListEntries() => Store.ListEntries();
    public static PowerHistoryResult Restore(string id) => Store.Restore(id);
    public static PowerHistoryResult Apply(PowerTarget target, uint value, string description) => Store.Apply(target, value, description);
}

public sealed class PowerHistoryStore
{
    private readonly IPowerHistoryBackend backend;
    private readonly string directory;
    private readonly object gate = new();
    public PowerHistoryStore(IPowerHistoryBackend backend, string directory)
    { this.backend = backend; this.directory = directory; }

    public sealed class Record
    {
        public int Version { get; set; } = 1;
        public string Id { get; set; } = "";
        public DateTime TimestampUtc { get; set; }
        public string Description { get; set; } = "";
        public PowerTarget Target { get; set; }
        public uint Previous { get; set; }
        public uint Requested { get; set; }
        public string Status { get; set; } = "Prepared";
        public string Error { get; set; } = "";
    }

    private void Save(Record record)
    {
        Directory.CreateDirectory(directory);
        string path = Path.Combine(directory, record.Id + ".json");
        string temporary = path + ".tmp";
        using (var stream = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None))
        { JsonSerializer.Serialize(stream, record); stream.Flush(true); }
        File.Move(temporary, path, true);
    }

    private Record Load(string id)
    {
        if (!Guid.TryParseExact(id, "N", out _)) throw new InvalidDataException("Invalid history identifier.");
        var record = JsonSerializer.Deserialize<Record>(File.ReadAllText(Path.Combine(directory, id + ".json")))
            ?? throw new InvalidDataException("Empty history record.");
        if (record.Version != 1 || record.Id != id || record.Target.Scheme == Guid.Empty || record.Target.Setting == Guid.Empty
            || record.Previous == record.Requested
            || record.Status is not ("Prepared" or "Applied" or "Failed" or "Restoring" or "Restored" or "Restore failed"))
            throw new InvalidDataException("Unsupported or invalid history record.");
        return record;
    }

    public PowerHistoryResult Apply(PowerTarget target, uint value, string description)
    {
        lock (gate)
        {
            Record? record = null;
            try
            {
                backend.Validate(target, value);
                uint previous = backend.Read(target);
                if (previous == value) { backend.Activate(); return new(true, "Requested value verified and active plan refreshed."); }
                record = new() { Id = Guid.NewGuid().ToString("N"), TimestampUtc = DateTime.UtcNow,
                    Description = description, Target = target, Previous = previous, Requested = value };
                Save(record); // A durable recovery record is required before any write.
                if (backend.Read(target) != previous) throw new InvalidOperationException("Setting changed during preparation. Refresh and retry.");
                backend.Write(target, value);
                if (backend.Read(target) != value) throw new IOException("Windows did not retain the requested value.");
                backend.Activate();
                record.Status = "Applied";
                Save(record);
                return new(true, "Applied and verified.");
            }
            catch (Exception ex)
            {
                if (record != null)
                {
                    record.Status = "Failed"; record.Error = ex.Message;
                    try { Save(record); } catch { /* The durable prepared record remains the recovery source. */ }
                }
                return new(false, ex.Message);
            }
        }
    }

    public IReadOnlyList<PowerHistoryEntry> ListEntries()
    {
        lock (gate)
        {
            var entries = new List<PowerHistoryEntry>();
            if (!Directory.Exists(directory)) return entries;
            foreach (string path in Directory.EnumerateFiles(directory, "*.json"))
            {
                string id = Path.GetFileNameWithoutExtension(path);
                try
                {
                    var r = Load(id);
                    string status = r.Status, error = r.Error;
                    bool canRestore = false;
                    try
                    {
                        uint current = backend.Read(r.Target);
                        if (r.Status == "Restored") status = current == r.Previous ? "Restored" : "Changed after restore";
                        else if (current == r.Requested) { canRestore = true; status = r.Status == "Applied" ? "Applied" : "Recovery available"; }
                        else if (current == r.Previous)
                        { status = "Original value present"; canRestore = r.Status is "Restoring" or "Restore failed"; }
                        else { status = "Conflict"; error = "Current value differs from both the recorded original and requested values."; }
                    }
                    catch (Exception ex) { status = "Unavailable"; error = ex.Message; }
                    entries.Add(new(r.Id, r.TimestampUtc, r.Description,
                        $"{r.Target.Scheme:D} / {r.Target.Subgroup:D} / {r.Target.Setting:D} / {(r.Target.Dc ? "DC" : "AC")}",
                        r.Previous.ToString(), r.Requested.ToString(), status, error, canRestore));
                }
                catch (Exception ex) { entries.Add(new(id, File.GetLastWriteTimeUtc(path), "Unreadable power history", path, "", "", "Unreadable", ex.Message, false)); }
            }
            return entries.OrderByDescending(e => e.TimestampUtc).ToList();
        }
    }

    public PowerHistoryResult Restore(string id)
    {
        lock (gate)
        {
            Record? r = null;
            try
            {
                r = Load(id);
                if (r.Status == "Restored") return new(false, "This entry was already restored. Refresh history.");
                uint current = backend.Read(r.Target);
                if (current != r.Requested && current != r.Previous)
                    return new(false, "Restore blocked: this setting changed outside this history entry.");
                backend.Validate(r.Target, r.Previous);
                r.Status = "Restoring"; r.Error = ""; Save(r);
                if (backend.Read(r.Target) != current) throw new InvalidOperationException("Setting changed during recovery. Refresh history.");
                if (current != r.Previous) backend.Write(r.Target, r.Previous);
                if (backend.Read(r.Target) != r.Previous) throw new IOException("Windows did not retain the original value.");
                backend.Activate();
                r.Status = "Restored"; Save(r);
                return new(true, "Original value restored and verified.");
            }
            catch (Exception ex)
            {
                if (r != null) { r.Status = "Restore failed"; r.Error = ex.Message; try { Save(r); } catch { } }
                return new(false, ex.Message);
            }
        }
    }
}

internal sealed class WindowsPowerHistoryBackend : IPowerHistoryBackend
{
    public uint Read(PowerTarget t) => t.Dc ? PowerApi.GetDcIndex(t.Scheme, t.Subgroup, t.Setting) : PowerApi.GetAcIndex(t.Scheme, t.Subgroup, t.Setting);
    public void Validate(PowerTarget t, uint value)
    {
        if (t.Scheme == Guid.Empty || t.Setting == Guid.Empty) throw new InvalidDataException("Invalid power setting identifier.");
        Read(t); // Reject missing schemes/settings instead of creating imported identifiers.
        if (PowerApi.TryReadRange(t.Subgroup, t.Setting, out uint min, out uint max, out uint step))
        {
            if (value < min || value > max || (value - min) % Math.Max(1u, step) != 0)
                throw new InvalidDataException("Value is outside the supported range or increment.");
        }
        else if (!PowerApi.PossibleValueExists(t.Subgroup, t.Setting, value))
            throw new InvalidDataException("This value is not a supported choice for the power setting.");
    }
    public void Write(PowerTarget t, uint value)
    { if (t.Dc) PowerApi.SetDcIndex(t.Scheme, t.Subgroup, t.Setting, value); else PowerApi.SetAcIndex(t.Scheme, t.Subgroup, t.Setting, value); }
    public void Activate() => PowerApi.ReApplyActiveScheme();
}
