using System.Diagnostics;
using Microsoft.Win32;
using PowerSettingsExplorer.Models;

namespace PowerSettingsExplorer.Services;

/// <summary>
/// Recreates missing stock power plans from their factory templates under
/// HKLM\SYSTEM\CurrentControlSet\Control\Power\User\Default\PowerSchemes, which survive the visible
/// scheme being deleted.
///
/// Never <c>powercfg -restoredefaultschemes</c> — it deletes every custom scheme.
/// <c>powercfg /duplicatescheme</c> is only a fallback; it needs a live source scheme, so it fails
/// on exactly the machines this exists for.
///
/// A stock GUID that still exists is skipped: a renamed stock plan keeps its original GUID, so
/// writing to it would rename a plan the user is running.
/// </summary>
public static class PowerPlanRestore
{
    /// <summary>The three plans a stock Windows install exposes, in the order Windows lists them.</summary>
    public static readonly (Guid Id, string Name)[] StockPlans =
    {
        (Guid.Parse("381b4222-f694-41f0-9685-ff5bb260df2e"), "Balanced"),
        (Guid.Parse("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"), "High performance"),
        (Guid.Parse("a1841308-3541-4fab-bc81-f71556f20b4a"), "Power saver")
    };

    public sealed record RestoreOutcome(string Name, bool Restored, string Detail);

    /// <summary>
    /// Restores whichever stock plans are missing from <paramref name="existing"/>. Returns one row
    /// per stock plan so the caller can report what actually happened rather than assuming success.
    /// </summary>
    public static IReadOnlyList<RestoreOutcome> RestoreMissing(IEnumerable<PowerScheme> existing)
    {
        var present = existing.Select(p => p.Id).ToHashSet();
        var results = new List<RestoreOutcome>();

        foreach (var (id, name) in StockPlans)
        {
            if (present.Contains(id))
            {
                // Possibly renamed by the user — left exactly as it is, name included.
                results.Add(new RestoreOutcome(name, false, "already present"));
                continue;
            }

            // powercfg /duplicatescheme needs a *live* source scheme. Once a stock plan has been
            // deleted there is nothing to duplicate, and it fails with "The power scheme, subgroup
            // or setting specified does not exist" — so seed the scheme from its own template
            // first, then let powercfg re-derive whatever it keeps outside the registry.
            var (ok, message) = SeedFromTemplate(id);
            if (!ok)
            {
                var (dupOk, dupMessage) = Duplicate(id);
                results.Add(new RestoreOutcome(name, dupOk, dupOk ? "restored" : $"{message}; {dupMessage}"));
                continue;
            }

            results.Add(new RestoreOutcome(name, true, "restored"));
        }

        return results;
    }

    private const string UserSchemes = @"SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes";
    private const string DefaultSchemes = @"SYSTEM\CurrentControlSet\Control\Power\User\Default\PowerSchemes";

    /// <summary>
    /// Recreates one scheme by copying its untouched factory template
    /// (…\Power\User\Default\PowerSchemes\&lt;guid&gt;) into the live scheme list. This is where
    /// Windows keeps the originals, which is why a stock plan can come back at all after being
    /// deleted. Only ever writes the one GUID asked for, and refuses to overwrite a live scheme.
    /// </summary>
    private static (bool Ok, string Message) SeedFromTemplate(Guid id)
    {
        try
        {
            using RegistryKey? template = Registry.LocalMachine.OpenSubKey($@"{DefaultSchemes}\{id:B}", false)
                ?? Registry.LocalMachine.OpenSubKey($@"{DefaultSchemes}\{id:D}", false);
            if (template == null) return (false, "no factory template for this plan on this machine");

            using RegistryKey? root = Registry.LocalMachine.OpenSubKey(UserSchemes, true);
            if (root == null) return (false, "the power scheme list could not be opened for writing");

            string leaf = template.Name[(template.Name.LastIndexOf('\\') + 1)..];
            using (RegistryKey? live = root.OpenSubKey(leaf, false))
                if (live != null) return (false, "a scheme with this id already exists");

            using RegistryKey destination = root.CreateSubKey(leaf, true);
            CopyKey(template, destination);
            return (true, "restored from template");
        }
        catch (Exception ex) { return (false, ex.Message); }
    }

    private static void CopyKey(RegistryKey source, RegistryKey destination)
    {
        foreach (string name in source.GetValueNames())
            destination.SetValue(name, source.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames)!,
                source.GetValueKind(name));

        foreach (string childName in source.GetSubKeyNames())
        {
            using RegistryKey? child = source.OpenSubKey(childName, false);
            if (child == null) continue;
            using RegistryKey copy = destination.CreateSubKey(childName, true);
            CopyKey(child, copy);
        }
    }

    private static (bool Ok, string Message) Duplicate(Guid id)
    {
        try
        {
            var psi = new ProcessStartInfo("powercfg.exe", $"/duplicatescheme {id:D} {id:D}")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using var process = Process.Start(psi);
            if (process == null) return (false, "powercfg could not be started");

            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();
            if (!process.WaitForExit(20_000))
            {
                try { process.Kill(true); } catch { }
                return (false, "powercfg did not finish");
            }

            if (process.ExitCode == 0) return (true, output.Trim());

            string detail = (error + " " + output).Trim();
            return (false, detail.Length > 0 ? detail : $"powercfg exited {process.ExitCode}");
        }
        catch (Exception ex) { return (false, ex.Message); }
    }
}
