namespace PowerSettingsExplorer.Services;

/// <summary>
/// Power settings that a stock Windows 10/11 desktop hides from Control Panel by
/// default (they ship with <c>POWER_ATTRIBUTE_HIDE</c> set).
///
/// This is a hand-maintained reference list, used only to badge these rows with a
/// star in the UI. On a machine that has already been tuned (a "show all power
/// options" registry import, a debloat/optimiser tool, etc.) the live hide
/// attribute has been cleared, so <see cref="Interop.PowerApi.IsHidden"/> no longer
/// reports them - but they are still the "advanced" settings most people never see.
/// Not exhaustive; add GUIDs as needed.
/// </summary>
public static class AdvancedSettings
{
    private static readonly HashSet<Guid> Ids = new()
    {
        new("245d8541-3943-4422-b025-13a784f679b7"), // Power plan type  (no subgroup)

        // ---- Processor power management ----------------------------------------
        new("893dee8e-2bef-41e0-89c6-b55d0929964c"), // Minimum processor state
        new("bc5038f7-23e0-4960-96da-33abaf5935ec"), // Maximum processor state
        new("94d3a615-a899-4ac5-ae2b-e4d8f634367f"), // System cooling policy
        new("be337238-0d82-4146-a960-4f3749d470c7"), // Processor performance boost mode
        new("45bcc044-d885-43e2-8605-ee0ec6e96b59"), // Processor performance boost policy
        new("465e1f50-b610-473a-ab58-00d1077dc418"), // Processor performance increase policy
        new("40fbefc7-2e9d-4d25-a185-0cfd8574bac6"), // Processor performance decrease policy
        new("06cadf0e-64ed-448a-8927-ce7bf90eb35d"), // Processor performance increase threshold
        new("12a0ab44-fe28-4fa9-b3bd-4b64f44960a6"), // Processor performance decrease threshold
        new("0cc5b647-c1df-4637-891a-dec35c318583"), // Core parking: minimum cores
        new("ea062031-0e34-4ff1-9b6d-eb1059334028"), // Core parking: maximum cores
        new("3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb"), // Allow Throttle States
        new("5d76a2ca-e8c0-402f-a133-2158492d58ad"), // Processor idle disable
        new("4d2b0152-7d5c-498b-88e2-34345392a2c5"), // Processor idle threshold scaling
        new("36687f9e-e3a5-4dbf-b1dc-15eb381c6863"), // Allow throttle states (efficiency class 1)

        // ---- Hard disk -------------------------------------------------------
        new("dab60367-53fe-4fbc-825e-521d069d2456"), // AHCI Link Power Management - HIPM/DIPM
        new("0b2d69d7-a2a1-449c-9680-f91c70521c60"), // AHCI Link Power Management - Adaptive

        // ---- USB ----------------------------------------------------------
        new("0853a681-27c8-4100-a2fd-82013e970683"), // USB 3 Link Power Management
        new("d4e98f31-5ffe-4ce1-be31-1b38b384c009"), // USB Hub Selective Suspend Timeout

        // ---- Sleep --------------------------------------------------------
        new("7bc4a2f9-d8fc-4469-b07b-33eb785aaca0"), // Unattended sleep timeout

        // ---- Display ------------------------------------------------------
        new("82dbcf2d-cd67-40c5-bfdc-9f1a5ccd4663"), // Console lock display off timeout
    };

    public static bool Contains(Guid settingGuid) => Ids.Contains(settingGuid);
    public static int Count => Ids.Count;
}
