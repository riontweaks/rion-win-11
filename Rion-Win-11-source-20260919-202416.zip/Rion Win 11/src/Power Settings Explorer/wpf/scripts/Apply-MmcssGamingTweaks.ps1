<#
    Apply-MmcssGamingTweaks.ps1  (v1)

    Tunes the Multimedia Class Scheduler Service (MMCSS) so foreground games and
    audio get more CPU/GPU headroom and the multimedia network throttle is off.

    What it changes (all under
      HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile):

        SystemResponsiveness      20  -> 10   (percent of CPU reserved for background
                                               work; lower = more for games/audio.
                                               Tunable with -SystemResponsiveness.)
        NetworkThrottlingIndex    10  -> 0xFFFFFFFF  (disables the 10-packets/ms
                                               multimedia network throttle. Harmless
                                               on a modern desktop; can raise NIC
                                               interrupt load on very old hardware.)

      ...\SystemProfile\Tasks\Games:

        GPU Priority               2  -> 8    (GPU queue priority for the Games task)
        Priority                   2  -> 6    (CPU thread priority for the Games task)
        Scheduling Category   Medium  -> High
        SFIO Priority        Normal   -> High (scheduled-file-I/O priority)

    These are the long-documented MMCSS "Games" task parameters. Nothing here
    touches security, mitigations, drivers or Windows Update.

    REAL revert: on apply, the prior value (or "absent") of every value it writes
    is saved to a sidecar next to the script:
        Apply-MmcssGamingTweaks.backup.json
    -Revert restores those exact values and removes values that were absent.

    Run from an ELEVATED PowerShell session (except -ListOnly).

    Usage:
        powershell -ExecutionPolicy Bypass -File .\Apply-MmcssGamingTweaks.ps1
        powershell -ExecutionPolicy Bypass -File .\Apply-MmcssGamingTweaks.ps1 -ListOnly
        powershell -ExecutionPolicy Bypass -File .\Apply-MmcssGamingTweaks.ps1 -WhatIf
        powershell -ExecutionPolicy Bypass -File .\Apply-MmcssGamingTweaks.ps1 -Revert
#>

#Requires -Version 5.1
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$Revert,
    [switch]$ListOnly,
    [ValidateRange(0, 100)]
    [int]$SystemResponsiveness = 10
)

$ErrorActionPreference = 'Stop'

$SysProfile = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
$GamesTask  = "$SysProfile\Tasks\Games"
$BackupPath = Join-Path $PSScriptRoot 'Apply-MmcssGamingTweaks.backup.json'

# A REG_DWORD is 32 bits. Depending on the box, PowerShell may surface a large one
# as -1 or as 4294967295 (or a string). Normalise anything to the signed Int32 bit
# pattern, which is what New-ItemProperty -PropertyType DWord wants.
function As-Int32Dword($v) {
    $u = [uint32]([int64]$v -band 0xFFFFFFFFL)
    return [BitConverter]::ToInt32([BitConverter]::GetBytes($u), 0)
}
function As-HexDword($v) {
    return '0x{0:X8}' -f ([uint32]([int64](As-Int32Dword $v) -band 0xFFFFFFFFL))
}

# desired end-state  (NetworkThrottlingIndex -1 == the 0xFFFFFFFF "disabled" DWord)
$targets = @(
    [pscustomobject]@{ Path = $SysProfile; Name = 'SystemResponsiveness';   Type = 'DWord';  Desired = [int]$SystemResponsiveness }
    [pscustomobject]@{ Path = $SysProfile; Name = 'NetworkThrottlingIndex'; Type = 'DWord';  Desired = [int](-1) }
    [pscustomobject]@{ Path = $GamesTask;  Name = 'GPU Priority';           Type = 'DWord';  Desired = 8 }
    [pscustomobject]@{ Path = $GamesTask;  Name = 'Priority';               Type = 'DWord';  Desired = 6 }
    [pscustomobject]@{ Path = $GamesTask;  Name = 'Scheduling Category';    Type = 'String'; Desired = 'High' }
    [pscustomobject]@{ Path = $GamesTask;  Name = 'SFIO Priority';          Type = 'String'; Desired = 'High' }
)

function Get-CurrentValue($path, $name) {
    try {
        $ip = Get-ItemProperty -LiteralPath $path -Name $name -ErrorAction Stop
        return , $ip.$name          # unary comma: keep single values from unrolling
    } catch { return $null }
}

function Show-State {
    Write-Host ''
    Write-Host 'MMCSS / Games task - current vs target:' -ForegroundColor Cyan
    foreach ($t in $targets) {
        $cur = Get-CurrentValue $t.Path $t.Name
        $curTxt = if ($null -eq $cur) { '(absent)' }
                  elseif ($t.Name -eq 'NetworkThrottlingIndex') { As-HexDword $cur }
                  else { "$cur" }
        $wantTxt = if ($t.Name -eq 'NetworkThrottlingIndex') { As-HexDword $t.Desired } else { "$($t.Desired)" }
        '{0,-22} {1,-14} -> {2}' -f $t.Name, $curTxt, $wantTxt | Write-Host
    }
    Write-Host ''
}

# ---------------------------------------------------------------- elevation
$isAdmin = ([Security.Principal.WindowsPrincipal] `
            [Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and -not $ListOnly) {
    Write-Warning 'Run this from an elevated PowerShell session (Run as administrator), or use -ListOnly.'
    exit 1
}

Show-State
if ($ListOnly) { return }

$changed = 0

# ================================================================ REVERT
if ($Revert) {
    if (-not (Test-Path $BackupPath)) {
        Write-Warning "No backup file next to the script ($BackupPath). Nothing to revert to."
        exit 1
    }
    $backup = Get-Content -LiteralPath $BackupPath -Raw | ConvertFrom-Json
    Write-Host "Restoring from $BackupPath" -ForegroundColor DarkGray

    foreach ($b in $backup.items) {
        if ($b.hadValue) {
            if ($PSCmdlet.ShouldProcess("$($b.path)\$($b.name)", "restore -> $($b.value)")) {
                if (-not (Test-Path $b.path)) { New-Item -Path $b.path -Force | Out-Null }
                $val = if ($b.type -eq 'DWord') { As-Int32Dword $b.value } else { [string]$b.value }
                New-ItemProperty -LiteralPath $b.path -Name $b.name -Value $val -PropertyType $b.type -Force | Out-Null
                $changed++
            }
        } else {
            if ($PSCmdlet.ShouldProcess("$($b.path)\$($b.name)", "remove (was absent)")) {
                Remove-ItemProperty -LiteralPath $b.path -Name $b.name -ErrorAction SilentlyContinue
                $changed++
            }
        }
    }

    if (-not $WhatIfPreference) {
        Rename-Item -LiteralPath $BackupPath -NewName ((Split-Path $BackupPath -Leaf) + '.used') -Force
    }
    Write-Host ''
    Write-Host "Reverted $changed value(s). Reboot for the Games task changes to take effect." -ForegroundColor Green
    return
}

# ================================================================ APPLY
$backup = [ordered]@{
    createdUtc = (Get-Date).ToUniversalTime().ToString('o')
    items      = @()
}

foreach ($t in $targets) {
    $cur = Get-CurrentValue $t.Path $t.Name

    $backup.items += [ordered]@{
        path     = $t.Path
        name     = $t.Name
        type     = $t.Type
        hadValue = ($null -ne $cur)
        value    = if ($null -eq $cur) { $null }
                   elseif ($t.Type -eq 'DWord') { As-Int32Dword $cur }
                   else { [string]$cur }
    }

    $same = ($null -ne $cur) -and (
        ($t.Type -eq 'DWord'  -and (As-Int32Dword $cur) -eq (As-Int32Dword $t.Desired)) -or
        ($t.Type -eq 'String' -and [string]$cur -eq [string]$t.Desired)
    )
    if ($same) { continue }

    $wantTxt = if ($t.Name -eq 'NetworkThrottlingIndex') { As-HexDword $t.Desired } else { "$($t.Desired)" }
    if ($PSCmdlet.ShouldProcess("$($t.Path)\$($t.Name)", "set -> $wantTxt")) {
        if (-not (Test-Path $t.Path)) { New-Item -Path $t.Path -Force | Out-Null }
        $val = if ($t.Type -eq 'DWord') { As-Int32Dword $t.Desired } else { [string]$t.Desired }
        New-ItemProperty -LiteralPath $t.Path -Name $t.Name -Value $val -PropertyType $t.Type -Force | Out-Null
        $changed++
        Write-Host ("  [set] {0} = {1}" -f $t.Name, $wantTxt) -ForegroundColor Green
    }
}

if (-not $WhatIfPreference) {
    $backup | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $BackupPath -Encoding UTF8
    Write-Host ''
    Write-Host "Backup written: $BackupPath  (needed for a clean -Revert)" -ForegroundColor DarkGray
}

Write-Host ''
Write-Host ("Applied {0} change(s)." -f $changed) -ForegroundColor Green
Write-Host 'Reboot (or sign out/in) so the MMCSS Games task picks up the new values.' -ForegroundColor Cyan
