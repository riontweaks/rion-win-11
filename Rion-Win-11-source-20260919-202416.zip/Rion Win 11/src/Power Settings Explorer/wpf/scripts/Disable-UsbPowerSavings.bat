@echo off
setlocal
REM Self-elevating launcher for Disable-UsbPowerSavings.ps1
REM Double-click to apply.  Pass  revert  (or -revert / /revert) to undo.

set "PS1=%~dp0Disable-UsbPowerSavings.ps1"

if not exist "%PS1%" (
    echo [X] Disable-UsbPowerSavings.ps1 was not found next to this launcher:
    echo     %PS1%
    echo.
    pause
    exit /b 1
)

set "ARGS="
if /I "%~1"=="revert"  set "ARGS=-Revert"
if /I "%~1"=="-revert" set "ARGS=-Revert"
if /I "%~1"=="/revert" set "ARGS=-Revert"

REM already elevated?
net session >nul 2>&1
if %errorlevel%==0 goto run

REM relaunch elevated. Only pass -ArgumentList when there is actually an argument.
if defined ARGS (
    powershell -NoProfile -Command "try { Start-Process -Verb RunAs -FilePath '%ComSpec%' -ArgumentList '/c','\"%~f0\" %~1' } catch { exit 1 }"
) else (
    powershell -NoProfile -Command "try { Start-Process -Verb RunAs -FilePath '%ComSpec%' -ArgumentList '/c','\"%~f0\"' } catch { exit 1 }"
)
if errorlevel 1 (
    echo.
    echo [X] Elevation was cancelled or failed - nothing was changed.
    echo.
    pause
)
exit /b

:run
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %ARGS%
set "RC=%errorlevel%"
echo.
echo (script exit code %RC%)
pause
exit /b %RC%
