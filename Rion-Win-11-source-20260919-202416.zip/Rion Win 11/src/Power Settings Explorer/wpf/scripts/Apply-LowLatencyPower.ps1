<#
    Apply-LowLatencyPower.ps1  (v2)

    Creates a NEW power plan called "Low-Latency" (cloned from your current plan)
    and applies a conservative set of latency / responsiveness tweaks to it.
    Your existing plans are untouched.

    v2 changes:
      * Locale-proof plan/GUID parsing (regex, not column positions).
      * Every powercfg write is checked; unsupported settings are reported
        instead of failing silently.
      * The plan you were on is recorded to a sidecar, so -Remove puts you
        back on THAT plan (not always Balanced).
      * Aborts cleanly if the clone fails.
      * -ShowInUi unhides the settings it edits so you can see them in
        Control Panel > Power Options > Change advanced power settings.

    What it changes (AC = plugged in, DC = battery):
      * Minimum processor state         100% (AC) / 5% (DC)
      * Maximum processor state         100%
      * Core-parking min cores          100% (nothing parked)
      * Processor performance boost     Aggressive
      * USB selective suspend           Disabled
      * PCI Express link state (ASPM)   Off (AC) / Moderate (DC)
      * Turn off hard disk after        Never (AC)
      * Latency-sensitivity hint        100%

    With -Aggressive (desktop / AC only, real power + heat cost):
      * Processor idle states (C-states) DISABLED on AC

    Usage:
        powershell -ExecutionPolicy Bypass -File .\Apply-LowLatencyPower.ps1
        powershell -ExecutionPolicy Bypass -File .\Apply-LowLatencyPower.ps1 -Aggressive -ShowInUi
        powershell -ExecutionPolicy Bypass -File .\Apply-LowLatencyPower.ps1 -Remove
#>

#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param(
    [switch]$Aggressive,
    [switch]$Remove,
    [switch]$ShowInUi
)

$ErrorActionPreference = 'Stop'
$PlanName    = 'Low-Latency'
$SourceFile  = Join-Path $PSScriptRoot 'Apply-LowLatencyPower.source.txt'
$GuidRx      = '[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}'

function Get-ActivePlanGuid {
    if ((powercfg /getactivescheme) -join "`n" -match $GuidRx) { $Matches[0].ToLower() }
}

function Get-PlanGuidByName([string]$name) {
    foreach ($line in (powercfg /list)) {
        if ($line -match $GuidRx) {
            $g = $Matches[0]
            if ($line -match [regex]::Escape("($name)")) { return $g.ToLower() }
        }
    }
    $null
}

# ---- remove mode -----------------------------------------------------------
if ($Remove) {
    $g = Get-PlanGuidByName $PlanName
    if (-not $g) { Write-Host "No '$PlanName' plan found." -ForegroundColor Yellow; return }

    if ((Get-ActivePlanGuid) -eq $g) {
        $restore = $null
        $plans   = powercfg /list
        if ((Test-Path $SourceFile) -and ((Get-Content $SourceFile -Raw).Trim() -match "^$GuidRx$")) {
            $cand = (Get-Content $SourceFile -Raw).Trim()
            if (($plans -join "`n") -match [regex]::Escape($cand)) { $restore = $cand }   # sidecar plan still exists
        }
        if (-not $restore) {
            foreach ($line in $plans) {                                                   # else: any other plan
                if ($line -match $GuidRx -and $Matches[0].ToLower() -ne $g) { $restore = $Matches[0]; break }
            }
        }
        if ($restore) { powercfg /setactive $restore; Write-Host "Switched active plan back to $restore" -ForegroundColor Green }
        else          { Write-Warning "Could not find another plan to switch to; delete may fail while '$PlanName' is active." }
    }
    powercfg /delete $g
    Remove-Item $SourceFile -ErrorAction SilentlyContinue
    Write-Host "Removed the '$PlanName' plan." -ForegroundColor Green
    return
}

# ---- create / reuse the plan --------------------------------------------------
$planGuid = Get-PlanGuidByName $PlanName
if (-not $planGuid) {
    $src = Get-ActivePlanGuid
    if (-not $src) { Write-Error 'Could not determine the active power plan.'; exit 1 }
    Set-Content -LiteralPath $SourceFile -Value $src -Encoding ASCII   # remember where to return on -Remove

    $out = powercfg /duplicatescheme $src 2>&1
    if (($out -join "`n") -match $GuidRx) { $planGuid = $Matches[0].ToLower() }
    if (-not $planGuid) { Write-Error "powercfg /duplicatescheme failed:`n$out"; exit 1 }

    powercfg /changename $planGuid $PlanName "Latency/responsiveness tweaks (Apply-LowLatencyPower.ps1)"
    Write-Host "Created plan '$PlanName'  $planGuid  (cloned from $src)" -ForegroundColor Green
} else {
    Write-Host "Reusing existing plan '$PlanName'  $planGuid" -ForegroundColor Green
}

# ---- setting GUIDs ----------------------------------------------------------
$SUB_PROCESSOR   = '54533251-82be-4824-96c1-47b60b740d00'
$PROCTHROTTLEMIN = '893dee8e-2bef-41e0-89c6-b55d0929964c'
$PROCTHROTTLEMAX = 'bc5038f7-23e0-4960-96da-33abaf5935ec'
$CPMINCORES      = '0cc5b647-c1df-4637-891a-dec35c318583'
$PERFBOOSTMODE   = 'be337238-0d82-4146-a960-4f3749d470c7'
$IDLEDISABLE     = '5d76a2ca-e8c0-402f-a133-2158492d58ad'
$LATENCYHINT     = '0822df31-9c83-441c-a079-0de4cf009c7b'
$SUB_USB         = '2a737441-1930-4402-8d77-b2bebba308a3'
$USBSUSPEND      = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
$SUB_PCIEXPRESS  = '501a4d13-42af-4429-9fd1-a8218c268e20'
$ASPM            = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
$SUB_DISK        = '0012ee47-9041-4b5d-9b77-535fba8b1442'
$DISKIDLE        = '6738e2c4-e8a5-4a42-b16a-e040e769756e'

$fail = [System.Collections.Generic.List[string]]::new()

function Set-Idx {
    param([ValidateSet('AC','DC')]$Rail, $Sub, $Set, $Val, $Label)
    $flag = if ($Rail -eq 'AC') { '/setacvalueindex' } else { '/setdcvalueindex' }
    $err  = & powercfg $flag $planGuid $Sub $Set $Val 2>&1
    if ($LASTEXITCODE -ne 0) { $fail.Add(("{0} {1}: {2}" -f $Rail, $Label, ($err -join ' ').Trim())) }
}

if ($ShowInUi) {
    foreach ($p in @("$SUB_PROCESSOR $PROCTHROTTLEMIN","$SUB_PROCESSOR $CPMINCORES",
                     "$SUB_PROCESSOR $PERFBOOSTMODE","$SUB_PROCESSOR $LATENCYHINT",
                     "$SUB_PROCESSOR $IDLEDISABLE","$SUB_PCIEXPRESS $ASPM")) {
        & powercfg -attributes ($p -split ' ')[0] ($p -split ' ')[1] -ATTRIB_HIDE 2>&1 | Out-Null
    }
    Write-Host "Unhid the edited settings in the advanced power-options UI." -ForegroundColor DarkGray
}

Set-Idx AC $SUB_PROCESSOR  $PROCTHROTTLEMIN 100 'min processor state'
Set-Idx DC $SUB_PROCESSOR  $PROCTHROTTLEMIN 5   'min processor state'
Set-Idx AC $SUB_PROCESSOR  $PROCTHROTTLEMAX 100 'max processor state'
Set-Idx DC $SUB_PROCESSOR  $PROCTHROTTLEMAX 100 'max processor state'
Set-Idx AC $SUB_PROCESSOR  $CPMINCORES      100 'core-parking min cores'
Set-Idx DC $SUB_PROCESSOR  $CPMINCORES      100 'core-parking min cores'
Set-Idx AC $SUB_PROCESSOR  $PERFBOOSTMODE   2   'perf boost mode'
Set-Idx DC $SUB_PROCESSOR  $PERFBOOSTMODE   2   'perf boost mode'
Set-Idx AC $SUB_PROCESSOR  $LATENCYHINT     100 'latency hint'
Set-Idx DC $SUB_PROCESSOR  $LATENCYHINT     100 'latency hint'
Set-Idx AC $SUB_USB        $USBSUSPEND      0   'USB selective suspend'
Set-Idx DC $SUB_USB        $USBSUSPEND      0   'USB selective suspend'
Set-Idx AC $SUB_PCIEXPRESS $ASPM            0   'PCIe ASPM'
Set-Idx DC $SUB_PCIEXPRESS $ASPM            1   'PCIe ASPM'
Set-Idx AC $SUB_DISK       $DISKIDLE        0   'disk idle timeout'

if ($Aggressive) {
    Set-Idx AC $SUB_PROCESSOR $IDLEDISABLE 1 'processor idle disable'
    Write-Host "  -Aggressive: C-states DISABLED on AC (desktop only; high idle power/heat)." -ForegroundColor Yellow
}

powercfg /setactive $planGuid

Write-Host ''
if ($fail.Count) {
    Write-Host "$($fail.Count) setting(s) not applied (not supported on this system):" -ForegroundColor Yellow
    $fail | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
} else {
    Write-Host "All settings applied." -ForegroundColor Green
}
Write-Host "'$PlanName' is now active. Undo:  -Remove   (returns you to the plan you were on)." -ForegroundColor Cyan
