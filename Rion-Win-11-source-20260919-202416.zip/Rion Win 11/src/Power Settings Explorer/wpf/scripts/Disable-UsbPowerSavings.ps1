<#
    Disable-UsbPowerSavings.ps1  (v3)

    Turns OFF "Allow the computer to turn off this device to save power" for every
    present USB / HID / keyboard / mouse device, and disables USB selective
    suspend in the active power plan.

    v3 changes:
      * REAL revert. On apply, the original value of every registry item it is
        about to touch (plus the plan's USB-suspend AC/DC index) is written to
        a sidecar:  <script folder>\Disable-UsbPowerSavings.backup.json
        -Revert restores those exact values, and REMOVES values that did not
        exist before. If the sidecar is missing it falls back to Windows
        defaults and says so.
      * -WhatIf now gates every write (WMI, PnPCapabilities, Device Parameters
        AND the powercfg calls). A dry run changes nothing.
      * Present devices only - no more writing keys for every gadget ever
        plugged in.
      * Per-mechanism change counts in the summary.
      * -IncludeBluetooth adds Bluetooth-class input devices.

    Three independent mechanisms (a device may expose only some):
        1. WMI  MSPower_DeviceEnable          - the live GUI checkbox
        2. driver Class key  PnPCapabilities  - 0x18 = both PM checkboxes off
        3. per-device Device Parameters       - SelectiveSuspendEnabled = 0 etc.

    Run from an ELEVATED PowerShell session (except -ListOnly).

    Usage:
        powershell -ExecutionPolicy Bypass -File .\Disable-UsbPowerSavings.ps1
        powershell -ExecutionPolicy Bypass -File .\Disable-UsbPowerSavings.ps1 -WhatIf
        powershell -ExecutionPolicy Bypass -File .\Disable-UsbPowerSavings.ps1 -Revert
        powershell -ExecutionPolicy Bypass -File .\Disable-UsbPowerSavings.ps1 -ListOnly
#>

#Requires -Version 5.1
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$Revert,
    [switch]$ListOnly,
    [switch]$IncludeBluetooth
)

$ErrorActionPreference = 'Stop'

# Load the CIM module now, with WhatIf suppressed, so its alias setup doesn't
# spam "What if: Set Alias ..." lines on the first Get-CimInstance call.
if (-not (Get-Module CimCmdlets)) {
    $__w = $WhatIfPreference; $WhatIfPreference = $false
    Import-Module CimCmdlets -ErrorAction SilentlyContinue
    $WhatIfPreference = $__w
}

$SUB_USB     = '2a737441-1930-4402-8d77-b2bebba308a3'
$USBSUSPEND  = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
$DP_NAMES    = 'SelectiveSuspendEnabled','EnhancedPowerManagementEnabled','AllowIdleIrpInD3','DeviceSelectiveSuspended'
$PNPCAP_OFF  = 24            # 0x18 - disable "turn off to save power" + "allow wake"
$BackupPath  = Join-Path $PSScriptRoot 'Disable-UsbPowerSavings.backup.json'

$stateWord   = if ($Revert) { 'ON (restored)' } else { 'OFF' }
$suspendWord = if ($Revert) { 'Enabled' } else { 'Disabled' }

# ---------------------------------------------------------------- elevation
$isAdmin = ([Security.Principal.WindowsPrincipal] `
            [Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and -not $ListOnly) {
    Write-Warning 'Run this from an elevated PowerShell session (Run as administrator).'
    exit 1
}

# ---------------------------------------------------------------- backup store
# Layout:
#   $backup.powercfg = @{ scheme=<guid>; ac=<int|null>; dc=<int|null> }
#   $backup.devices[<InstanceId>] = @{
#       classKey       = <reg path | null>
#       pnpCapabilities = <int | null>          # null = value was absent
#       deviceParams    = @{ <name> = <int|null>; ... }
#   }
if ($Revert) {
    if (Test-Path $BackupPath) {
        $backup = Get-Content -LiteralPath $BackupPath -Raw | ConvertFrom-Json
        Write-Host "Using backup from $BackupPath" -ForegroundColor DarkGray
    } else {
        $backup = $null
        Write-Warning "No backup file next to the script - reverting to Windows defaults, not your original values."
    }
} else {
    $backup = [ordered]@{
        createdUtc = (Get-Date).ToUniversalTime().ToString('o')
        powercfg   = $null
        devices    = [ordered]@{}
    }
}

function Get-BackupDevice([string]$id) {
    if ($Revert) { return $backup.devices.$id }
    if (-not $backup.devices.Contains($id)) {
        $backup.devices[$id] = [ordered]@{ classKey = $null; pnpCapabilities = 'unset'; deviceParams = [ordered]@{} }
    }
    return $backup.devices[$id]
}

# ---------------------------------------------------------------- enumerate
$targetClasses = @('USB','HIDClass','Keyboard','Mouse')
if ($IncludeBluetooth) { $targetClasses += 'Bluetooth' }

$pnp = Get-PnpDevice | Where-Object { $_.Class -in $targetClasses -and $_.Present }

$pm = @(Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceEnable -ErrorAction SilentlyContinue)
Write-Host ("Present target devices: {0}   MSPower_DeviceEnable objects: {1}" -f $pnp.Count, $pm.Count) -ForegroundColor DarkGray
Write-Host ''
Write-Host 'Current power-management state (Enable = TRUE means Windows IS allowed to power the device down):' -ForegroundColor Cyan

$rows = foreach ($dev in ($pnp | Sort-Object Class, FriendlyName)) {
    $match = @($pm | Where-Object {
        ($_.InstanceName -replace '_0$','') -ieq $dev.InstanceId -or
         $_.InstanceName -ilike ($dev.InstanceId + '*')
    })
    [pscustomobject]@{
        Class       = $dev.Class
        Device      = $dev.FriendlyName
        HasWmiPower = [bool]$match.Count
        Enable      = if ($match.Count) { $match[0].Enable } else { $null }
        InstanceId  = $dev.InstanceId
        _match      = $match
    }
}
$rows | Format-Table Class, Device, HasWmiPower, Enable -AutoSize

if ($ListOnly) { return }

$targetEnable = [bool]$Revert     # $false = power-save OFF
$cnt = [ordered]@{ Wmi = 0; PnPCap = 0; DevParam = 0 }

foreach ($r in $rows) {
    $dev = $pnp | Where-Object InstanceId -eq $r.InstanceId | Select-Object -First 1

    # --- 1. WMI live checkbox --------------------------------------------------
    foreach ($entry in $r._match) {
        if ($entry.Enable -eq $targetEnable) { continue }
        if ($PSCmdlet.ShouldProcess($r.Device, "MSPower_DeviceEnable.Enable = $targetEnable")) {
            try {
                Set-CimInstance -InputObject $entry -Property @{ Enable = $targetEnable }
                $cnt.Wmi++
                Write-Host ("  [WMI {0}] {1}" -f $stateWord, $r.Device) -ForegroundColor Green
            } catch {
                Write-Warning ("  WMI failed on {0}: {1}" -f $r.Device, $_.Exception.Message)
            }
        }
    }

    if (-not $dev) { continue }
    $enumKey = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($dev.InstanceId)"

    # --- 2. driver Class key PnPCapabilities --------------------------------
    $drv = (Get-ItemProperty -LiteralPath $enumKey -Name Driver -ErrorAction SilentlyContinue).Driver
    if ($drv) {
        $classSub = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\$drv"
        if (Test-Path $classSub) {
            $bd = Get-BackupDevice $r.InstanceId

            if ($Revert) {
                if ($bd) {
                    $orig = $bd.pnpCapabilities
                    if ($PSCmdlet.ShouldProcess($r.Device, "restore PnPCapabilities")) {
                        if ($null -eq $orig -or $orig -eq 'unset') {
                            Remove-ItemProperty -LiteralPath $classSub -Name PnPCapabilities -ErrorAction SilentlyContinue
                        } else {
                            New-ItemProperty -LiteralPath $classSub -Name PnPCapabilities -Value ([int]$orig) -PropertyType DWord -Force | Out-Null
                        }
                        $cnt.PnPCap++
                    }
                }
            } else {
                $cur = (Get-ItemProperty -LiteralPath $classSub -Name PnPCapabilities -ErrorAction SilentlyContinue).PnPCapabilities
                $bd.classKey        = $classSub
                $bd.pnpCapabilities = if ($null -eq $cur) { $null } else { [int]$cur }
                if ($cur -ne $PNPCAP_OFF -and $PSCmdlet.ShouldProcess($r.Device, "PnPCapabilities = $PNPCAP_OFF")) {
                    New-ItemProperty -LiteralPath $classSub -Name PnPCapabilities -Value $PNPCAP_OFF -PropertyType DWord -Force | Out-Null
                    $cnt.PnPCap++
                }
            }
        }
    }

    # --- 3. Device Parameters selective suspend ---------------------------
    $dp = "$enumKey\Device Parameters"
    if (Test-Path $dp) {
        $bd = Get-BackupDevice $r.InstanceId
        foreach ($name in $DP_NAMES) {
            if ($Revert) {
                if (-not $bd) { continue }
                $orig = $bd.deviceParams.$name
                if ($PSCmdlet.ShouldProcess($r.Device, "restore $name")) {
                    if ($null -eq $orig) {
                        Remove-ItemProperty -LiteralPath $dp -Name $name -ErrorAction SilentlyContinue
                    } else {
                        New-ItemProperty -LiteralPath $dp -Name $name -Value ([int]$orig) -PropertyType DWord -Force | Out-Null
                    }
                    $cnt.DevParam++
                }
            } else {
                $cur = (Get-ItemProperty -LiteralPath $dp -Name $name -ErrorAction SilentlyContinue).$name
                $bd.deviceParams[$name] = if ($null -eq $cur) { $null } else { [int]$cur }
                if ($cur -ne 0 -and $PSCmdlet.ShouldProcess($r.Device, "$name = 0")) {
                    New-ItemProperty -LiteralPath $dp -Name $name -Value 0 -PropertyType DWord -Force | Out-Null
                    $cnt.DevParam++
                }
            }
        }
    }
}

# ---------------------------------------------------------------- power plan (USB selective suspend)
$schemeRoot = 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes'
$activeScheme = (Get-ItemProperty -LiteralPath $schemeRoot -Name ActivePowerScheme -ErrorAction SilentlyContinue).ActivePowerScheme

if (-not $Revert) {
    $key = "$schemeRoot\$activeScheme\$SUB_USB\$USBSUSPEND"
    $backup.powercfg = [ordered]@{
        scheme = $activeScheme
        ac     = (Get-ItemProperty -LiteralPath $key -Name ACSettingIndex -ErrorAction SilentlyContinue).ACSettingIndex
        dc     = (Get-ItemProperty -LiteralPath $key -Name DCSettingIndex -ErrorAction SilentlyContinue).DCSettingIndex
    }
}

$acVal = if ($Revert) { if ($backup -and $null -ne $backup.powercfg.ac) { [int]$backup.powercfg.ac } else { 1 } } else { 0 }
$dcVal = if ($Revert) { if ($backup -and $null -ne $backup.powercfg.dc) { [int]$backup.powercfg.dc } else { 1 } } else { 0 }

if ($PSCmdlet.ShouldProcess("active power plan", "USB selective suspend AC=$acVal DC=$dcVal")) {
    & powercfg /setacvalueindex SCHEME_CURRENT $SUB_USB $USBSUSPEND $acVal | Out-Null
    & powercfg /setdcvalueindex SCHEME_CURRENT $SUB_USB $USBSUSPEND $dcVal | Out-Null
    & powercfg /setactive SCHEME_CURRENT | Out-Null
}

# ---------------------------------------------------------------- save backup
if (-not $Revert -and -not $WhatIfPreference) {
    $backup | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $BackupPath -Encoding UTF8
    Write-Host ''
    Write-Host "Backup written: $BackupPath  (needed for a clean -Revert)" -ForegroundColor DarkGray
}
if ($Revert -and (Test-Path $BackupPath) -and -not $WhatIfPreference) {
    Rename-Item -LiteralPath $BackupPath -NewName ((Split-Path $BackupPath -Leaf) + '.used') -Force
}

# ---------------------------------------------------------------- summary
Write-Host ''
Write-Host ("WMI checkbox changes : {0}" -f $cnt.Wmi)      -ForegroundColor Green
Write-Host ("PnPCapabilities writes: {0}" -f $cnt.PnPCap)  -ForegroundColor Green
Write-Host ("Device Parameter writes: {0}" -f $cnt.DevParam) -ForegroundColor Green
Write-Host ("USB selective suspend (active plan) -> {0}" -f $suspendWord) -ForegroundColor Green
Write-Host ''
Write-Host 'Reboot (or disable/enable the device in Device Manager) to apply the registry parts.' -ForegroundColor Cyan
