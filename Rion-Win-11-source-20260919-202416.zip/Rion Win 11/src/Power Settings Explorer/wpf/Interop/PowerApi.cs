using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;
using PowerSettingsExplorer.Models;
using static PowerSettingsExplorer.Interop.PowerNative;

namespace PowerSettingsExplorer.Interop;

/// <summary>Managed convenience layer over <see cref="PowerNative"/>.</summary>
public static class PowerApi
{
    public static readonly Guid NoSubgroup = new("fea3413e-7e05-4911-9a71-700331f1c294");
    public static readonly Guid PowerPlanTypeSetting = new("245d8541-3943-4422-b025-13a784f679b7");

    public static readonly Guid[] HeteroThresholdSettings =
    {
        new("b000397d-9b0b-483d-98c9-692a6060cfbf"), // increase class 1
        new("f8861c27-95e7-475c-865b-13c0cb3f9d6b"), // decrease class 1
        new("b000397d-9b0b-483d-98c9-692a6060cfc0"), // increase class 2
        new("f8861c27-95e7-475c-865b-13c0cb3f9d6c"), // decrease class 2
    };

    public static Guid ActiveSchemeGuid { get; private set; } = Guid.Empty;

    public static bool IsMobile { get; } =
        PowerDeterminePlatformRole() is PowerPlatformRoleNative.PlatformRoleMobile
            or PowerPlatformRoleNative.PlatformRoleSlate;

    static PowerApi() => RefreshActiveScheme();

    // ---------------------------------------------------------------- schemes

    public static void RefreshActiveScheme()
    {
        IntPtr p = IntPtr.Zero;
        if (PowerGetActiveScheme(IntPtr.Zero, ref p) == ERROR_SUCCESS && p != IntPtr.Zero)
        {
            ActiveSchemeGuid = Marshal.PtrToStructure<Guid>(p);
            LocalFree(p);
        }
    }

    public static void SetActiveScheme(Guid scheme)
    {
        var g = scheme;
        if (PowerSetActiveScheme(IntPtr.Zero, ref g) == ERROR_SUCCESS)
            ActiveSchemeGuid = scheme;
    }

    public static void ReApplyActiveScheme()
    {
        RefreshActiveScheme();
        var g = ActiveSchemeGuid;
        PowerSetActiveScheme(IntPtr.Zero, ref g);
    }

    /// <summary>Renames a power scheme (its friendly name). Throws on failure.</summary>
    public static void WriteSchemeName(Guid scheme, string name)
    {
        var g = scheme;
        var sb = new StringBuilder(name ?? "");
        uint rc = PowerWriteFriendlyName(IntPtr.Zero, ref g, IntPtr.Zero, IntPtr.Zero,
            sb, (uint)((sb.Length + 1) * 2));
        if (rc != ERROR_SUCCESS) throw new Win32Exception((int)rc);
    }

    /// <summary>Deletes a power scheme. Windows refuses to delete the active scheme. Throws on failure.</summary>
    public static void DeleteScheme(Guid scheme)
    {
        var g = scheme;
        uint rc = PowerDeleteScheme(IntPtr.Zero, ref g);
        if (rc != ERROR_SUCCESS) throw new Win32Exception((int)rc);
    }

    public static List<PowerScheme> EnumerateSchemes()
    {
        var list = new List<PowerScheme>();
        foreach (var id in EnumerateGuids(POWER_DATA_ACCESSOR.ACCESS_SCHEME))
            list.Add(new PowerScheme
            {
                Id = id,
                Kind = SchemeKind.Plan,
                Name = ReadSchemeName(id) ?? id.ToString(),
                Description = ReadSchemeDescription(id) ?? "",
            });
        return list;
    }

    public static List<PowerScheme> EnumerateOverlays()
    {
        var list = new List<PowerScheme>();
        try
        {
            IntPtr key = IntPtr.Zero;
            if (PowerOpenUserPowerKey(ref key, KEY_READ, true) != ERROR_SUCCESS) return list;
            using var rk = RegistryKey.FromHandle(new SafeRegistryHandle(key, true));
            if (rk.GetValue("ActiveOverlayAcPowerScheme") is not string s ||
                s == "00000000-0000-0000-0000-000000000000")
                return list;

            foreach (var id in EnumerateGuids(POWER_DATA_ACCESSOR.ACCESS_OVERLAY_SCHEME))
                list.Add(new PowerScheme
                {
                    Id = id,
                    Kind = SchemeKind.Overlay,
                    Name = ReadSchemeName(id) ?? id.ToString(),
                    Description = ReadSchemeDescription(id) ?? "",
                });
        }
        catch { /* overlays unsupported on this build */ }
        return list;
    }

    public static Guid GetEffectiveOverlay()
    {
        Guid g = Guid.Empty;
        PowerGetActualOverlayScheme(ref g);
        return g;
    }

    public static void SetActiveOverlay(Guid overlay)
    {
        var g = overlay;
        PowerSetActiveOverlayScheme(ref g);
    }

    private static IEnumerable<Guid> EnumerateGuids(POWER_DATA_ACCESSOR access)
    {
        uint index = 0;
        while (true)
        {
            Guid buffer = Guid.Empty;
            uint size = (uint)Marshal.SizeOf<Guid>();
            if (PowerEnumerate(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, access, index, ref buffer, ref size) != ERROR_SUCCESS)
                yield break;
            yield return buffer;
            index++;
        }
    }

    // ---------------------------------------------------------------- subgroups + settings

    public static List<Guid> GetSubgroups(Guid scheme)
    {
        var list = new List<Guid> { NoSubgroup };
        uint index = 0;
        var s = scheme;
        while (true)
        {
            Guid buffer = Guid.Empty;
            uint size = (uint)Marshal.SizeOf<Guid>();
            if (PowerEnumerate(IntPtr.Zero, ref s, IntPtr.Zero, POWER_DATA_ACCESSOR.ACCESS_SUBGROUP, index, ref buffer, ref size) != ERROR_SUCCESS)
                break;
            list.Add(buffer);
            index++;
        }
        return list;
    }

    public static IEnumerable<(Guid Subgroup, Guid Setting)> EnumerateSettings(Guid scheme)
    {
        var s = scheme;
        foreach (var sub in GetSubgroups(scheme))
        {
            var subLocal = sub;
            uint index = 0;
            while (true)
            {
                Guid buffer = Guid.Empty;
                uint size = (uint)Marshal.SizeOf<Guid>();
                if (PowerEnumerate(IntPtr.Zero, ref s, ref subLocal, POWER_DATA_ACCESSOR.ACCESS_INDIVIDUAL_SETTING, index, ref buffer, ref size) != ERROR_SUCCESS)
                    break;
                yield return (sub, buffer);
                index++;
            }
        }
    }

    // ---------------------------------------------------------------- names / text

    private static string? ReadUnicode(Func<StringBuilder, uint, (uint rc, uint size)> call)
    {
        var sb = new StringBuilder(512);
        var (rc, size) = call(sb, (uint)sb.Capacity * 2);
        if (rc == ERROR_MORE_DATA)
        {
            sb.EnsureCapacity((int)size / 2 + 1);
            (rc, _) = call(sb, size);
        }
        return rc == ERROR_SUCCESS ? sb.ToString() : null;
    }

    public static string? ReadSchemeName(Guid id)
    {
        var g = id;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadFriendlyName(IntPtr.Zero, ref g, IntPtr.Zero, IntPtr.Zero, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadSchemeDescription(Guid id)
    {
        var g = id;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadDescription(IntPtr.Zero, ref g, IntPtr.Zero, IntPtr.Zero, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadSubgroupName(Guid subgroup)
    {
        if (subgroup == NoSubgroup) return null;
        var scheme = ActiveSchemeGuid;
        var sub = subgroup;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadFriendlyName(IntPtr.Zero, ref scheme, ref sub, IntPtr.Zero, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadSettingName(Guid subgroup, Guid setting)
    {
        var scheme = ActiveSchemeGuid;
        var sub = subgroup;
        var set = setting;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadFriendlyName(IntPtr.Zero, ref scheme, ref sub, ref set, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadSettingDescription(Guid subgroup, Guid setting)
    {
        var scheme = ActiveSchemeGuid;
        var sub = subgroup;
        var set = setting;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadDescription(IntPtr.Zero, ref scheme, ref sub, ref set, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadUnits(Guid subgroup, Guid setting)
    {
        var sub = subgroup;
        var set = setting;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadValueUnitsSpecifier(IntPtr.Zero, ref sub, ref set, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadPossibleName(Guid subgroup, Guid setting, uint idx)
    {
        var sub = subgroup;
        var set = setting;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadPossibleFriendlyName(IntPtr.Zero, ref sub, ref set, idx, sb, ref s);
            return (rc, s);
        });
    }

    public static string? ReadPossibleDescription(Guid subgroup, Guid setting, uint idx)
    {
        var sub = subgroup;
        var set = setting;
        return ReadUnicode((sb, sz) =>
        {
            uint s = sz;
            uint rc = PowerReadPossibleDescription(IntPtr.Zero, ref sub, ref set, idx, sb, ref s);
            return (rc, s);
        });
    }

    // ---------------------------------------------------------------- values

    public static bool TryReadRange(Guid subgroup, Guid setting, out uint min, out uint max, out uint increment)
    {
        var sub = subgroup;
        var set = setting;
        min = max = increment = 0;
        return PowerReadValueMin(IntPtr.Zero, ref sub, ref set, ref min) == ERROR_SUCCESS
            && PowerReadValueMax(IntPtr.Zero, ref sub, ref set, ref max) == ERROR_SUCCESS
            && PowerReadValueIncrement(IntPtr.Zero, ref sub, ref set, ref increment) == ERROR_SUCCESS;
    }

    public static uint GetAcIndex(Guid scheme, Guid subgroup, Guid setting)
    {
        var sc = scheme; var sub = subgroup; var set = setting; uint v = 0;
        if (PowerReadACValueIndex(IntPtr.Zero, ref sc, ref sub, ref set, ref v) != ERROR_SUCCESS)
            throw new Win32Exception();
        return v;
    }

    public static uint GetDcIndex(Guid scheme, Guid subgroup, Guid setting)
    {
        var sc = scheme; var sub = subgroup; var set = setting; uint v = 0;
        if (PowerReadDCValueIndex(IntPtr.Zero, ref sc, ref sub, ref set, ref v) != ERROR_SUCCESS)
            throw new Win32Exception();
        return v;
    }

    public static bool TryGetAcIndex(Guid scheme, Guid subgroup, Guid setting, out uint v)
    {
        var sc = scheme; var sub = subgroup; var set = setting; v = 0;
        return PowerReadACValueIndex(IntPtr.Zero, ref sc, ref sub, ref set, ref v) == ERROR_SUCCESS;
    }

    public static bool TryGetDcIndex(Guid scheme, Guid subgroup, Guid setting, out uint v)
    {
        var sc = scheme; var sub = subgroup; var set = setting; v = 0;
        return PowerReadDCValueIndex(IntPtr.Zero, ref sc, ref sub, ref set, ref v) == ERROR_SUCCESS;
    }

    public static void SetAcIndex(Guid scheme, Guid subgroup, Guid setting, uint value)
    {
        var sc = scheme; var sub = subgroup; var set = setting;
        if (PowerWriteACValueIndex(IntPtr.Zero, ref sc, ref sub, ref set, value) != ERROR_SUCCESS)
            throw new Win32Exception();
    }

    public static void SetDcIndex(Guid scheme, Guid subgroup, Guid setting, uint value)
    {
        var sc = scheme; var sub = subgroup; var set = setting;
        if (PowerWriteDCValueIndex(IntPtr.Zero, ref sc, ref sub, ref set, value) != ERROR_SUCCESS)
            throw new Win32Exception();
    }

    public static bool TryReadAcDefault(Guid scheme, Guid subgroup, Guid setting, out uint v)
    {
        var sc = scheme; var sub = subgroup; var set = setting; v = 0;
        return PowerReadACDefaultIndex(IntPtr.Zero, ref sc, ref sub, ref set, ref v) == ERROR_SUCCESS;
    }

    public static bool TryReadDcDefault(Guid scheme, Guid subgroup, Guid setting, out uint v)
    {
        var sc = scheme; var sub = subgroup; var set = setting; v = 0;
        return PowerReadDCDefaultIndex(IntPtr.Zero, ref sc, ref sub, ref set, ref v) == ERROR_SUCCESS;
    }

    // ---------------------------------------------------------------- possible values

    public static bool PossibleValueExists(Guid subgroup, Guid setting, uint idx)
    {
        var sub = subgroup; var set = setting; uint type = 0; uint size = 0;
        return PowerReadPossibleValue(IntPtr.Zero, ref sub, ref set, ref type, idx, IntPtr.Zero, ref size) == ERROR_SUCCESS;
    }

    public static (RegType Type, byte[] Raw)? ReadPossibleValue(Guid subgroup, Guid setting, uint idx)
    {
        var sub = subgroup; var set = setting;
        uint type = 0; uint size = 0;
        uint rc = PowerReadPossibleValue(IntPtr.Zero, ref sub, ref set, ref type, idx, IntPtr.Zero, ref size);
        if (rc != ERROR_SUCCESS && rc != ERROR_MORE_DATA) return null;
        IntPtr buf = Marshal.AllocHGlobal((int)size + 1);
        try
        {
            rc = PowerReadPossibleValue(IntPtr.Zero, ref sub, ref set, ref type, idx, buf, ref size);
            if (rc != ERROR_SUCCESS) return null;
            var bytes = new byte[size];
            Marshal.Copy(buf, bytes, 0, (int)size);
            return ((RegType)type, bytes);
        }
        finally { Marshal.FreeHGlobal(buf); }
    }

    public static void CreatePossibleSetting(Guid subgroup, Guid setting, uint idx)
    {
        var sub = subgroup; var set = setting;
        if (PowerCreatePossibleSetting(IntPtr.Zero, ref sub, ref set, idx) != ERROR_SUCCESS)
            throw new Win32Exception();
    }

    public static void WritePossibleValue(Guid subgroup, Guid setting, RegType type, uint idx, byte[] raw)
    {
        var sub = subgroup; var set = setting;
        IntPtr buf = Marshal.AllocHGlobal(raw.Length);
        try
        {
            Marshal.Copy(raw, 0, buf, raw.Length);
            if (PowerWritePossibleValue(IntPtr.Zero, ref sub, ref set, (uint)type, idx, buf, (uint)raw.Length) != ERROR_SUCCESS)
                throw new Win32Exception();
        }
        finally { Marshal.FreeHGlobal(buf); }
    }

    public static void WritePossibleFriendlyName(Guid subgroup, Guid setting, uint idx, string name)
    {
        var sub = subgroup; var set = setting;
        var sb = new StringBuilder(name);
        PowerWritePossibleFriendlyName(IntPtr.Zero, ref sub, ref set, idx, sb, (uint)(sb.Length * 2 + 2));
    }

    // ---------------------------------------------------------------- attributes (hidden)

    public static bool IsHidden(Guid subgroup, Guid setting)
    {
        var sub = subgroup; var set = setting;
        return (PowerReadSettingAttributes(ref sub, ref set) & 1u) != 0;
    }

    public static void SetHidden(Guid subgroup, Guid setting, bool hidden)
    {
        var sub = subgroup; var set = setting;
        uint attr = PowerReadSettingAttributes(ref sub, ref set);
        if (hidden) attr |= 1u;
        else { attr &= ~1u; attr |= 2u; }

        if (PowerWriteSettingAttributes(ref sub, ref set, attr) != ERROR_SUCCESS)
            throw new Win32Exception();

        if (!hidden && subgroup != NoSubgroup)
        {
            uint subAttr = PowerReadSettingAttributes(ref sub, IntPtr.Zero);
            if (subAttr == 1)
            {
                try
                {
                    using var rk = Registry.LocalMachine.OpenSubKey(
                        $@"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\{subgroup:D}", writable: true);
                    rk?.DeleteValue("Attributes", throwOnMissingValue: false);
                }
                catch { PowerWriteSettingAttributes(ref sub, IntPtr.Zero, 0u); }
            }
            else if ((subAttr & 1u) != 0)
            {
                PowerWriteSettingAttributes(ref sub, IntPtr.Zero, subAttr & ~1u);
            }
        }
        ReApplyActiveScheme();
    }

    public static string RegistryPath(Guid subgroup, Guid setting) => subgroup != NoSubgroup
        ? $@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\{subgroup:D}\{setting:D}"
        : $@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\{setting:D}";
}
