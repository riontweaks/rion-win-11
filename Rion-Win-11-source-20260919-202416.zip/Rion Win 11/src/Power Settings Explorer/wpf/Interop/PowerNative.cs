using System.Runtime.InteropServices;
using System.Security;
using System.Text;

namespace PowerSettingsExplorer.Interop;

/// <summary>Windows power-management and memory-management P/Invoke declarations.</summary>
[SuppressUnmanagedCodeSecurity]
internal static class PowerNative
{
    public const uint ERROR_SUCCESS = 0;
    public const uint ERROR_FILE_NOT_FOUND = 2;
    public const uint ERROR_MORE_DATA = 234;
    public const uint KEY_READ = 0x20019;

    internal enum POWER_DATA_ACCESSOR : uint
    {
        ACCESS_AC_POWER_SETTING_INDEX = 0,
        ACCESS_DC_POWER_SETTING_INDEX,
        ACCESS_FRIENDLY_NAME,
        ACCESS_DESCRIPTION,
        ACCESS_POSSIBLE_POWER_SETTING,
        ACCESS_POSSIBLE_POWER_SETTING_FRIENDLY_NAME,
        ACCESS_POSSIBLE_POWER_SETTING_DESCRIPTION,
        ACCESS_DEFAULT_AC_POWER_SETTING,
        ACCESS_DEFAULT_DC_POWER_SETTING,
        ACCESS_POSSIBLE_VALUE_MIN,
        ACCESS_POSSIBLE_VALUE_MAX,
        ACCESS_POSSIBLE_VALUE_INCREMENT,
        ACCESS_POSSIBLE_VALUE_UNITS,
        ACCESS_ICON_RESOURCE,
        ACCESS_DEFAULT_SECURITY_DESCRIPTOR,
        ACCESS_ATTRIBUTES,
        ACCESS_SCHEME,
        ACCESS_SUBGROUP,
        ACCESS_INDIVIDUAL_SETTING,
        ACCESS_ACTIVE_SCHEME,
        ACCESS_CREATE_SCHEME,
        ACCESS_AC_POWER_SETTING_MAX,
        ACCESS_DC_POWER_SETTING_MAX,
        ACCESS_AC_POWER_SETTING_MIN,
        ACCESS_DC_POWER_SETTING_MIN,
        ACCESS_PROFILE,
        ACCESS_OVERLAY_SCHEME,
        ACCESS_ACTIVE_OVERLAY_SCHEME,
    }

    [DllImport("kernel32.dll")]
    public static extern IntPtr LocalFree(IntPtr hMem);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerGetActiveScheme(IntPtr UserRootPowerKey, ref IntPtr ActivePolicyGuid);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerSetActiveScheme(IntPtr UserRootPowerKey, ref Guid SchemeGuid);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerEnumerate(IntPtr RootPowerKey, IntPtr SchemeGuid, IntPtr SubGroupOfPowerSetting,
        POWER_DATA_ACCESSOR AccessFlags, uint Index, ref Guid Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerEnumerate(IntPtr RootPowerKey, ref Guid SchemeGuid, IntPtr SubGroupOfPowerSetting,
        POWER_DATA_ACCESSOR AccessFlags, uint Index, ref Guid Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerEnumerate(IntPtr RootPowerKey, ref Guid SchemeGuid, ref Guid SubGroupOfPowerSetting,
        POWER_DATA_ACCESSOR AccessFlags, uint Index, ref Guid Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadFriendlyName(IntPtr RootPowerKey, ref Guid SchemeGuid,
        IntPtr SubGroupOfPowerSettingGuid, IntPtr PowerSettingGuid, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadFriendlyName(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, IntPtr PowerSettingGuid, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadFriendlyName(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadDescription(IntPtr RootPowerKey, ref Guid SchemeGuid,
        IntPtr SubGroupOfPowerSettingGuid, IntPtr PowerSettingGuid, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadDescription(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern PowerPlatformRoleNative PowerDeterminePlatformRole();

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadACValueIndex(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, ref uint AcValueIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadDCValueIndex(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, ref uint DcValueIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerWriteACValueIndex(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, uint AcValueIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerWriteDCValueIndex(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, uint DcValueIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadACDefaultIndex(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, ref uint AcDefaultIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadDCDefaultIndex(IntPtr RootPowerKey, ref Guid SchemeGuid,
        ref Guid SubGroupOfPowerSettingGuid, ref Guid PowerSettingGuid, ref uint DcDefaultIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadValueMin(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, ref uint ValueMinimum);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadValueMax(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, ref uint ValueMaximum);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadValueIncrement(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, ref uint ValueIncrement);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadValueUnitsSpecifier(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadPossibleValue(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, ref uint Type, uint PossibleSettingIndex, IntPtr Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerWritePossibleValue(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, uint Type, uint PossibleSettingIndex, IntPtr Buffer, uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadPossibleFriendlyName(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, uint PossibleSettingIndex, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerWritePossibleFriendlyName(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, uint PossibleSettingIndex, StringBuilder Buffer, uint BufferSize);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerReadPossibleDescription(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, uint PossibleSettingIndex, StringBuilder Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadSettingAttributes(ref Guid SubGroupGuid, ref Guid PowerSettingGuid);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerReadSettingAttributes(ref Guid SubGroupGuid, IntPtr PowerSettingGuid);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerWriteSettingAttributes(ref Guid SubGroupGuid, ref Guid PowerSettingGuid, uint Attributes);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerWriteSettingAttributes(ref Guid SubGroupGuid, IntPtr PowerSettingGuid, uint Attributes);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerCreatePossibleSetting(IntPtr RootPowerKey, ref Guid SubGroupOfPowerSettingGuid,
        ref Guid PowerSettingGuid, uint PossibleSettingIndex);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerOpenUserPowerKey(ref IntPtr phUserPowerKey, uint Access, [MarshalAs(UnmanagedType.Bool)] bool OpenExisting);

    [DllImport("powrprof.dll")]
    public static extern uint PowerSetActiveOverlayScheme(ref Guid OverlaySchemeGuid);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerGetActualOverlayScheme(ref Guid ActualOverlayGuid);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerGetEffectiveOverlayScheme(ref Guid EffectiveOverlayGuid);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern uint PowerWriteFriendlyName(IntPtr RootPowerKey, ref Guid SchemeGuid,
        IntPtr SubGroupOfPowerSettingsGuid, IntPtr PowerSettingGuid, StringBuilder Buffer, uint BufferSize);

    [DllImport("powrprof.dll", SetLastError = true)]
    public static extern uint PowerDeleteScheme(IntPtr RootPowerKey, ref Guid SchemeGuid);
}

internal enum PowerPlatformRoleNative
{
    PlatformRoleUnspecified = 0,
    PlatformRoleDesktop,
    PlatformRoleMobile,
    PlatformRoleWorkstation,
    PlatformRoleEnterpriseServer,
    PlatformRoleSOHOServer,
    PlatformRoleAppliancePC,
    PlatformRolePerformanceServer,
    PlatformRoleSlate,
    PlatformRoleMaximum,
}
