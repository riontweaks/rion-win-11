using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace PowerSettingsExplorer.Interop;

/// <summary>
/// Paints a stock <see cref="Window"/>'s native caption dark, so a dialog opened out of the shell
/// doesn't arrive with a white title bar on an otherwise black app.
///
/// The shell's own windows inherit <c>GlassKit.GlassWindow</c>, which does this and more, but this
/// project is a leaf library with no project references — duplicating the two attribute calls is
/// cheaper than inverting the dependency for a title bar.
/// </summary>
public static class WindowChromeDark
{
    private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
    private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
    private const int DWMWCP_ROUND = 2;

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(nint hwnd, int attribute, ref int value, int size);

    /// <summary>Call from <c>OnSourceInitialized</c> — the HWND does not exist before then.</summary>
    public static void Apply(Window window)
    {
        nint hwnd = new WindowInteropHelper(window).Handle;
        if (hwnd == 0) return;

        int on = 1;
        DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, ref on, sizeof(int));

        // Both are best-effort: on Windows 10 the corner attribute is simply ignored.
        int round = DWMWCP_ROUND;
        DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ref round, sizeof(int));
    }
}
