using System.Windows;
using System.Windows.Controls;
using PowerSettingsExplorer.ViewModels;

namespace PowerSettingsExplorer.Views;

public partial class ChangesWindow : Window
{
    public ChangesWindow() => InitializeComponent();

    protected override void OnSourceInitialized(System.EventArgs e)
    {
        base.OnSourceInitialized(e);
        Interop.WindowChromeDark.Apply(this);
    }

    private void OnClose(object sender, RoutedEventArgs e) => Close();

    private void OnRowDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (e.OriginalSource is DependencyObject d
            && ItemsControl.ContainerFromElement(RowList, d) is ListBoxItem { DataContext: PlanChangeRow row }
            && DataContext is ChangesViewModel vm)
        {
            vm.OpenSettingCommand.Execute(row);
            Close();
        }
    }
}
