using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Navigation;
using PowerSettingsExplorer.ViewModels;

namespace PowerSettingsExplorer.Views;

/// <summary>
/// Power Settings Explorer+ as a hosted module. Former MainWindow (3-column grid,
/// no chrome) with the DWM dark-title-bar call removed — the Rion Win 11 shell
/// owns the window.
/// </summary>
public partial class PowerSettingsView : UserControl
{
    private readonly MainViewModel _vm = new();
    private bool _loaded;

    public PowerSettingsView()
    {
        InitializeComponent();
        DataContext = _vm;
        Loaded += async (_, _) =>
        {
            if (_loaded) return;          // Loaded can re-fire if the shell re-parents the view
            _loaded = true;
            await _vm.LoadAsync();
        };
    }

    // The host sidebar leaves less room than a standalone window. Stack the panes
    // on small windows instead of forcing their combined minimum width offscreen.
    private void Workspace_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e)
    {
        bool compact = e.NewSize.Width < 850;
        WorkspaceGrid.Height = compact ? Math.Max(800, e.NewSize.Height) : e.NewSize.Height;
        PageScroll.VerticalScrollBarVisibility = compact ? ScrollBarVisibility.Auto : ScrollBarVisibility.Disabled;
        DetailsColumn.Width = compact ? new System.Windows.GridLength(0) : new System.Windows.GridLength(1.15, System.Windows.GridUnitType.Star);
        DetailsRow.Height = compact ? new System.Windows.GridLength(1, System.Windows.GridUnitType.Star) : new System.Windows.GridLength(0);
        Grid.SetRow(DetailsPane, compact ? 1 : 0);
        Grid.SetColumn(DetailsPane, compact ? 0 : 1);
    }

    private void OnSourceLinkClick(object sender, RequestNavigateEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true }); }
        catch { /* no browser / blocked */ }
        e.Handled = true;
    }

    private void MoreButton_Click(object sender, System.Windows.RoutedEventArgs e)
        => MorePopup.IsOpen = !MorePopup.IsOpen;
}
