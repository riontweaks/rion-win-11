# Power Settings Explorer (WPF rebuild)

A dark, side-navigated rebuild of the 2017 WinForms `PowerSettingsExplorer.exe`.
Same power engine (`powrprof.dll` P/Invoke, ported from the decompiled original),
new .NET 8 WPF UI.

## What it does

- Enumerates **every** power-scheme setting registered on the machine — hidden ones
  included (via `PowerEnumerate(ACCESS_INDIVIDUAL_SETTING)`, no attribute filtering).
- Left rail groups settings by function (Battery & energy, Sleep & wake, Display &
  media, Processor, Disks & devices, Buttons & lid, General) with live counts.
- Per-setting details pane: description, GUIDs, **Hide from Windows** toggle
  (`ATTRIB_HIDE`), and one expandable row per power plan with **PLUGGED IN /
  ON BATTERY** editors and a **Make active** button.
- **Power modes** tab appears when the machine exposes overlay schemes (the Win10/11
  power-mode slider).
- Import / Export settings as XML, generate a `powercfg` **.bat** of pending changes,
  **Unhide all**, **Show all hidden settings** filter, **Open in Registry Editor**.
- With **Show all hidden settings** on, every setting whose `ATTRIB_HIDE` bit is set
  is marked with a gold **★** before its name (a legend appears in the command bar).
  Nothing is starred when the machine has no hidden settings.
- Changes are staged; **Apply changes** writes them and re-applies the active scheme.

## Build

The csproj is configured for a **standalone single-file** build — one self-contained
`PowerSettingsExplorer.exe` (~66 MB, no .NET install needed on the target machine):

```
dotnet publish -c Release -o dist
```

`dotnet build` / `dotnet run` still work for development.

The Rion logo (a bold **R** on an accent square) is `Assets/rion.ico` — used as the
exe icon, the window icon, and drawn as the `RION` wordmark in the nav header.
Regenerate it with `Assets/make-icon.ps1`. Assembly metadata: `Company = Rion`.

Runs as `asInvoker`; writing hidden-attributes / HKLM power keys needs elevation, so
the app shows a **Run as administrator** button in the nav when it isn't elevated.

## Layout

| File | Role |
|---|---|
| `Interop/PowerNative.cs` | raw `powrprof.dll` / `kernel32` P/Invoke |
| `Interop/PowerApi.cs` | managed wrapper (buffers, enumeration, read/write) |
| `Models/` | `PwrSetting`, `PwrPossibleValue`, `PowerScheme`, enums |
| `Services/CategoryCatalog.cs` | subgroup GUID → left-rail category |
| `Services/PowerSettingsService.cs` | enumerate-all, import, export, script |
| `ViewModels/` | `MainViewModel` + `SettingVM` + `PlanValueVM` + `CategoryVM` |
| `Views/MainWindow.xaml` | the 3-pane UI |
| `Themes/Dark.xaml` | palette + control styles |

## Not yet ported

- Adding heterogeneous-CPU (P/E-core) threshold possible-values — button is present
  but shows a placeholder.
- Numeric ranged editor is a plain text box (no slider/stepper yet).
