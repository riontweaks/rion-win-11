namespace PowerSettingsExplorer.Models;

public sealed class PowerScheme
{
    public Guid Id { get; init; }
    public SchemeKind Kind { get; init; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";

    public override string ToString() => Name;
}
