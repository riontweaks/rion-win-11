using System.Text;
using PowerSettingsExplorer.Interop;

namespace PowerSettingsExplorer.Models;

/// <summary>One entry in a non-ranged setting's list of possible values.</summary>
public sealed class PwrPossibleValue
{
    public PwrPossibleValue(PwrSetting owner, uint index)
    {
        Owner = owner;
        Index = index;
    }

    public PwrSetting Owner { get; }
    public uint Index { get; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public RegType RegType { get; set; } = RegType.REG_NONE;
    public byte[] Raw { get; set; } = Array.Empty<byte>();

    /// <summary>Human-readable rendering of <see cref="Raw"/> according to <see cref="RegType"/>.</summary>
    public string Value
    {
        get
        {
            try
            {
                return RegType switch
                {
                    RegType.REG_SZ or RegType.REG_EXPAND_SZ or RegType.REG_LINK
                        => Encoding.Unicode.GetString(Raw).TrimEnd('\0'),
                    RegType.REG_DWORD when Raw.Length >= 4 => BitConverter.ToUInt32(Raw, 0).ToString("X8"),
                    RegType.REG_DWORD_BIG_ENDIAN when Raw.Length >= 4
                        => BitConverter.ToUInt32(Raw.Take(4).Reverse().ToArray(), 0).ToString("X8"),
                    RegType.REG_QWORD when Raw.Length >= 8 => BitConverter.ToUInt64(Raw, 0).ToString("X16"),
                    RegType.REG_BINARY => string.Join(' ', Raw.Select(b => b.ToString("X2"))),
                    _ => string.Join(' ', Raw.Select(b => b.ToString("X2"))),
                };
            }
            catch { return string.Join(' ', Raw.Select(b => b.ToString("X2"))); }
        }
    }

    public string Display => string.IsNullOrWhiteSpace(Name) ? $"Value #{Index}" : Name;

    public override string ToString() =>
        $"{Index} - {Value} - {Name}{(string.IsNullOrWhiteSpace(Description) ? "" : " - " + Description)}";

    internal static PwrPossibleValue Load(PwrSetting owner, uint index)
    {
        var pv = new PwrPossibleValue(owner, index)
        {
            Name = PowerApi.ReadPossibleName(owner.SubgroupGuid, owner.SettingGuid, index) ?? $"Value #{index}",
            Description = PowerApi.ReadPossibleDescription(owner.SubgroupGuid, owner.SettingGuid, index) ?? "",
        };
        if (PowerApi.ReadPossibleValue(owner.SubgroupGuid, owner.SettingGuid, index) is { } read)
        {
            pv.RegType = read.Type;
            pv.Raw = read.Raw;
        }
        return pv;
    }
}
