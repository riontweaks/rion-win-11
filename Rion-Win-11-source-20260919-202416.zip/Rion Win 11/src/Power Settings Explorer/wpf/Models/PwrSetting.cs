using PowerSettingsExplorer.Interop;

namespace PowerSettingsExplorer.Models;

/// <summary>A single Windows power setting (one GUID under one subgroup GUID).</summary>
public sealed class PwrSetting
{
    public PwrSetting(Guid subgroup, Guid setting)
    {
        SubgroupGuid = subgroup;
        SettingGuid = setting;
    }

    public Guid SubgroupGuid { get; }
    public Guid SettingGuid { get; }

    public string SubgroupName { get; set; } = "";
    public string Name { get; private set; } = "";
    public string Description { get; private set; } = "";

    public bool Initialized { get; private set; }
    public bool IsRanged { get; private set; }
    public string? Units { get; private set; }
    public uint ValueMin { get; private set; }
    public uint ValueMax { get; private set; }
    public uint ValueIncrement { get; private set; }

    public List<PwrPossibleValue> PossibleValues { get; } = new();

    public bool CanAddPossibleValue => PowerApi.HeteroThresholdSettings.Contains(SettingGuid);

    public bool Hidden
    {
        get => PowerApi.IsHidden(SubgroupGuid, SettingGuid);
        set
        {
            if (value == Hidden) return;
            PowerApi.SetHidden(SubgroupGuid, SettingGuid, value);
        }
    }

    /// <summary>Reads metadata for this setting. Returns false if it carries nothing usable.</summary>
    public bool Init()
    {
        try
        {
            Name = PowerApi.ReadSettingName(SubgroupGuid, SettingGuid) ?? SettingGuid.ToString();
            Description = PowerApi.ReadSettingDescription(SubgroupGuid, SettingGuid) ?? "";

            IsRanged = PowerApi.TryReadRange(SubgroupGuid, SettingGuid, out var min, out var max, out var inc);
            if (IsRanged)
            {
                ValueMin = min;
                ValueMax = max;
                ValueIncrement = inc == 0 ? 1 : inc;
                Units = PowerApi.ReadUnits(SubgroupGuid, SettingGuid);
                Initialized = true;
                return true;
            }

            int start = FindFirstPossibleValueIndex();
            if (start >= 0)
            {
                for (uint i = (uint)start; PowerApi.PossibleValueExists(SubgroupGuid, SettingGuid, i); i++)
                {
                    try { PossibleValues.Add(PwrPossibleValue.Load(this, i)); } catch { }
                }
            }

            AddDefaultIfMissing(PowerApi.TryReadAcDefault(PowerApi.ActiveSchemeGuid, SubgroupGuid, SettingGuid, out var acDef), acDef);
            AddDefaultIfMissing(PowerApi.TryReadDcDefault(PowerApi.ActiveSchemeGuid, SubgroupGuid, SettingGuid, out var dcDef), dcDef);

            if (PossibleValues.Count == 0) return false;

            Initialized = true;
            return true;
        }
        catch
        {
            Initialized = false;
            return false;
        }
    }

    private void AddDefaultIfMissing(bool ok, uint idx)
    {
        if (!ok || PossibleValues.Any(p => p.Index == idx)) return;
        try { PossibleValues.Add(PwrPossibleValue.Load(this, idx)); } catch { }
    }

    private int FindFirstPossibleValueIndex()
    {
        if (PowerApi.PossibleValueExists(SubgroupGuid, SettingGuid, 0)) return 0;
        if (!PowerApi.TryGetAcIndex(PowerApi.ActiveSchemeGuid, SubgroupGuid, SettingGuid, out var ac)) return -1;
        int n = (int)ac;
        while (n - 1 >= 0 && PowerApi.PossibleValueExists(SubgroupGuid, SettingGuid, (uint)(n - 1))) n--;
        return n;
    }

    public string DescribeIndex(uint index) =>
        PossibleValues.FirstOrDefault(p => p.Index == index)?.Display ?? $"value {index}";

    public void AddPossibleValue(uint index, byte[] bytes)
    {
        if (PossibleValues.Count == 0) return;
        PowerApi.CreatePossibleSetting(SubgroupGuid, SettingGuid, index);
        PowerApi.WritePossibleFriendlyName(SubgroupGuid, SettingGuid, index,
            $"({index}) {string.Concat(bytes.Select(b => b.ToString("X2")))}");
        var template = PossibleValues[0];
        PossibleValues.Add(new PwrPossibleValue(this, index)
        {
            Name = string.Join(",", bytes),
            RegType = template.RegType,
            Raw = bytes,
        });
    }
}
