using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using PowerSettingsExplorer.Interop;
using PowerSettingsExplorer.Models;

namespace PowerSettingsExplorer.ViewModels;

/// <summary>One field of one setting whose value on a given plan differs from the Windows default.</summary>
public sealed record PlanChange(
    SettingVM Setting,
    Guid Subgroup,
    Guid SettingGuid,
    string Field,
    string DefaultText,
    string CurrentText,
    bool Pending,
    bool IsDc);

/// <summary>A row in the "changes from default" window.</summary>
public sealed class PlanChangeRow
{
    private readonly IPendingSink _sink;
    private readonly Guid _planId;
    private readonly Action _afterReset;

    public PlanChangeRow(PlanChange change, Guid planId, IPendingSink sink, Action afterReset)
    {
        Change = change;
        _planId = planId;
        _sink = sink;
        _afterReset = afterReset;
        ResetCommand = new RelayCommand(() => { StageDefault(); _afterReset(); });
    }

    public PlanChange Change { get; }
    public SettingVM Setting => Change.Setting;

    public string SettingName => Change.Setting.Name;
    public string SubgroupName => Change.Setting.SubgroupName;
    public string Field => Change.Field;
    public string DefaultText => Change.DefaultText;
    public string CurrentText => Change.CurrentText;
    public bool Pending => Change.Pending;
    public string PendingGlyph => Change.Pending ? "●" : "";

    public RelayCommand ResetCommand { get; }

    /// <summary>Stages this setting's default value (AC and DC) as a pending change. No refresh.</summary>
    public void StageDefault()
    {
        var sub = Change.Subgroup;
        var set = Change.SettingGuid;
        var existing = _sink.GetPending(_planId, set);

        uint? ac = PowerApi.TryReadAcDefault(_planId, sub, set, out var a) ? a : existing?.Ac;
        uint? dc = PowerApi.IsMobile && PowerApi.TryReadDcDefault(_planId, sub, set, out var d)
            ? d : existing?.Dc;

        _sink.SetPending(_planId, sub, set, ac, dc);
        Change.Setting.RefreshAfterEdit();
    }
}

public sealed class ChangesViewModel : ObservableObject
{
    private readonly IReadOnlyList<SettingVM> _settings;
    private readonly IPendingSink _sink;
    private readonly Action<SettingVM> _navigate;

    public ChangesViewModel(
        IReadOnlyList<PowerScheme> plans,
        IReadOnlyList<SettingVM> settings,
        Guid initialPlan,
        IPendingSink sink,
        Action<SettingVM> navigate)
    {
        _settings = settings;
        _sink = sink;
        _navigate = navigate;

        Plans = new ObservableCollection<PowerScheme>(plans);
        _selectedPlan = Plans.FirstOrDefault(p => p.Id == initialPlan) ?? Plans.FirstOrDefault();

        CopyCommand = new RelayCommand(Copy, () => Rows.Count > 0);
        ResetAllCommand = new RelayCommand(ResetAll, () => Rows.Count > 0);
        OpenSettingCommand = new RelayCommand(o => { if (o is PlanChangeRow r) _navigate(r.Setting); });

        Recompute();
    }

    public ObservableCollection<PowerScheme> Plans { get; }

    private PowerScheme? _selectedPlan;
    public PowerScheme? SelectedPlan
    {
        get => _selectedPlan;
        set { if (Set(ref _selectedPlan, value)) Recompute(); }
    }

    public ObservableCollection<PlanChangeRow> Rows { get; } = new();

    public string Summary
    {
        get
        {
            if (SelectedPlan is null) return "No plan selected.";
            int n = Rows.Count;
            return n == 0
                ? $"Every setting on “{SelectedPlan.Name}” matches its Windows default."
                : $"{n} field{(n == 1 ? "" : "s")} differ{(n == 1 ? "s" : "")} from the Windows default on “{SelectedPlan.Name}”.";
        }
    }

    public string PendingHint =>
        Rows.Any(r => r.Pending)
            ? "● = staged, not yet written. Reset also stages — press “Apply changes” in the main window."
            : "Reset stages the default as a pending change — press “Apply changes” in the main window to write it.";

    public RelayCommand CopyCommand { get; }
    public RelayCommand ResetAllCommand { get; }
    public RelayCommand OpenSettingCommand { get; }

    public void Recompute()
    {
        Rows.Clear();
        if (SelectedPlan is { } plan)
        {
            foreach (var s in _settings)
                foreach (var c in s.ChangesOn(plan.Id))
                    Rows.Add(new PlanChangeRow(c, plan.Id, _sink, Recompute));
        }

        Raise(nameof(Summary));
        Raise(nameof(PendingHint));
        CopyCommand.RaiseCanExecuteChanged();
        ResetAllCommand.RaiseCanExecuteChanged();
    }

    private void Copy()
    {
        if (SelectedPlan is null) return;
        var sb = new StringBuilder();
        sb.AppendLine($"Changes from Windows default — {SelectedPlan.Name}");
        sb.AppendLine();
        sb.AppendLine("Setting\tSubgroup\tField\tWindows default\tCurrent\tStaged");
        foreach (var r in Rows)
            sb.AppendLine($"{r.SettingName}\t{r.SubgroupName}\t{r.Field}\t{r.DefaultText}\t{r.CurrentText}\t{(r.Pending ? "yes" : "")}");
        try { Clipboard.SetText(sb.ToString()); } catch { }
    }

    private void ResetAll()
    {
        if (Rows.Count == 0) return;
        if (MessageBox.Show(
                $"Stage every one of these {Rows.Count} field(s) back to its Windows default?\n\n"
                + "Nothing is written until you press “Apply changes” in the main window.",
                "Reset all to default", MessageBoxButton.YesNo, MessageBoxImage.Question)
            != MessageBoxResult.Yes)
            return;

        foreach (var r in Rows.ToList())
            r.StageDefault();
        Recompute();
    }
}
