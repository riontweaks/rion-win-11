using System.Collections.ObjectModel;
using PowerSettingsExplorer.Interop;
using PowerSettingsExplorer.Models;
using PowerSettingsExplorer.Services;

namespace PowerSettingsExplorer.ViewModels;

public interface IPendingSink
{
    (uint? Ac, uint? Dc)? GetPending(Guid scheme, Guid setting);
    void SetPending(Guid scheme, Guid subgroup, Guid setting, uint? ac, uint? dc);
    bool HasPending(Guid setting);
    void MakeActive(PowerScheme scheme);
    Guid ActiveSchemeId { get; }

    /// <summary>Every real power plan on the machine (not overlays).</summary>
    IReadOnlyList<PowerScheme> AllPlans { get; }

    /// <summary>Rename a power plan's friendly name. No-op for blank / unchanged names.</summary>
    void RenameScheme(Guid scheme, string newName);
    /// <summary>Delete a power plan (after confirming with the user).</summary>
    void DeleteScheme(Guid scheme);
    /// <summary>True when <paramref name="scheme"/> is a user plan that is safe to delete (not active, not the last one).</summary>
    bool CanDeleteScheme(Guid scheme);
}

public sealed class SettingVM : ObservableObject
{
    private readonly IPendingSink _sink;

    public SettingVM(PwrSetting model, IPendingSink sink)
    {
        Model = model;
        _sink = sink;
        Category = CategoryCatalog.Resolve(model.SubgroupGuid);
        Reco = RecommendationCatalog.For(model.SettingGuid, PowerApi.IsMobile);
        RecommendedIndex = ResolveRecommendedIndex();
        ApplyRecommendedCommand = new RelayCommand(ApplyRecommended, () => HasRecommendation && !IsAtRecommended);
        ResetToDefaultCommand = new RelayCommand(ResetToDefault, () => IsModifiedOnActivePlan);
    }

    public PwrSetting Model { get; }
    public PowerCategory Category { get; }

    // ---- recommendation (curated, sourced) -------------------------------------
    public Recommendation? Reco { get; }
    public uint? RecommendedIndex { get; }
    public RelayCommand ApplyRecommendedCommand { get; }

    /// <summary>Raised after <see cref="ApplyRecommended"/> stages a pending change.</summary>
    public event Action? PendingApplied;

    public bool HasGuidance => Reco is not null;
    public bool HasRecommendation => Reco is not null && RecommendedIndex is not null;
    public string RecommendationLabel => Reco?.Confidence == RecoConfidence.Strong ? "Recommended" : "Suggested";
    public bool RecommendationIsStrong => Reco?.Confidence == RecoConfidence.Strong;
    public bool HasRecommendationWarning => false;
    public string RecommendationWarning => "";

    public string RecommendationValueText =>
        RecommendedIndex is { } i ? Model.DescribeIndex(i) : "";

    public string RecommendationRationale => (Reco?.Rationale ?? "")
        + (Reco?.IndividualOnly == true ? " Individual choice; excluded from Apply recommended." : "")
        + (HasGuidance && !HasRecommendation ? " No automatic value is offered for this setting on this system." : "");
    public string RecommendationSourceLabel => Reco?.SourceLabel ?? "";
    public string RecommendationSourceUrl => Reco?.SourceUrl ?? "";
    public bool HasRecommendationUrl => !string.IsNullOrWhiteSpace(Reco?.SourceUrl);

    public string RecommendationHeadline =>
        HasRecommendation ? $"{RecommendationLabel}: {RecommendationValueText}" : "Review current configuration";

    public string RecommendationTooltip =>
        HasRecommendation
            ? $"{RecommendationHeadline}\n{RecommendationRationale}\nSource: {RecommendationSourceLabel}"
            : "";

    /// <summary>True when the active plan's plugged-in value already equals the recommendation.</summary>
    public bool IsAtRecommended
    {
        get
        {
            if (RecommendedIndex is not { } want) return false;
            try
            {
                if (_sink.GetPending(_sink.ActiveSchemeId, Model.SettingGuid) is { Ac: { } pac })
                    return pac == want;
                return PowerApi.TryGetAcIndex(_sink.ActiveSchemeId, Model.SubgroupGuid, Model.SettingGuid, out var ac)
                       && ac == want;
            }
            catch { return false; }
        }
    }

    private uint? ResolveRecommendedIndex() => Reco?.ResolveTarget(Model.IsRanged,
        Model.ValueMin, Model.ValueMax, Model.ValueIncrement,
        Model.PossibleValues.Select(v => (v.Index, v.Name)));

    private void ApplyRecommended()
    {
        if (RecommendedIndex is not { } want) return;
        _sink.SetPending(_sink.ActiveSchemeId, Model.SubgroupGuid, Model.SettingGuid, want, null);
        RefreshAfterEdit();
        PendingApplied?.Invoke();
    }

    /// <summary>
    /// Stages the recommended value on the active plan without raising <see cref="PendingApplied"/>
    /// (for bulk "apply all"). Returns true if something was actually staged.
    /// </summary>
    public bool TryStageRecommended()
    {
        if (!HasRecommendation || IsAtRecommended || RecommendedIndex is not { } want) return false;
        _sink.SetPending(_sink.ActiveSchemeId, Model.SubgroupGuid, Model.SettingGuid, want, null);
        RefreshAfterEdit();
        return true;
    }

    // ---- reset a single setting to its Windows default (active plan) ---------

    /// <summary>The active plan's Windows-default value for this setting, formatted for display.</summary>
    public string WindowsDefaultText
    {
        get
        {
            try
            {
                if (PowerApi.TryReadAcDefault(_sink.ActiveSchemeId, Model.SubgroupGuid, Model.SettingGuid, out var d))
                    return Describe(d);
            }
            catch { }
            return "";
        }
    }

    public bool HasWindowsDefault => WindowsDefaultText.Length > 0;

    /// <summary>True when the active plan's current (or staged) value differs from the Windows default.</summary>
    public bool IsModifiedOnActivePlan
    {
        get
        {
            try
            {
                var plan = _sink.ActiveSchemeId;
                var sub = Model.SubgroupGuid;
                var set = Model.SettingGuid;
                if (!PowerApi.TryReadAcDefault(plan, sub, set, out var def)) return false;
                uint cur;
                if (_sink.GetPending(plan, set) is { Ac: { } pac }) cur = pac;
                else if (!PowerApi.TryGetAcIndex(plan, sub, set, out cur)) return false;
                return cur != def;
            }
            catch { return false; }
        }
    }

    public RelayCommand ResetToDefaultCommand { get; }

    private void ResetToDefault()
    {
        var plan = _sink.ActiveSchemeId;
        var sub = Model.SubgroupGuid;
        var set = Model.SettingGuid;

        uint? ac = PowerApi.TryReadAcDefault(plan, sub, set, out var a) ? a : (uint?)null;
        uint? dc = PowerApi.IsMobile && PowerApi.TryReadDcDefault(plan, sub, set, out var d) ? d : (uint?)null;
        if (ac is null && dc is null) return;

        _sink.SetPending(plan, sub, set, ac, dc);
        RefreshAfterEdit();
        PendingApplied?.Invoke();
    }

    public string Name => Model.Name;
    public string SubgroupName => Model.SubgroupName;
    public string Description => string.IsNullOrWhiteSpace(Model.Description) ? "—" : Model.Description;
    public bool Initialized => Model.Initialized;
    public bool IsRanged => Model.IsRanged;
    public string? Units => Model.Units;
    public double Min => Model.ValueMin;
    public double Max => Model.ValueMax;
    public double Increment => Model.ValueIncrement == 0 ? 1 : Model.ValueIncrement;
    public IReadOnlyList<PwrPossibleValue> PossibleValues => Model.PossibleValues;
    public bool CanAddChoice => Model.CanAddPossibleValue;

    public string ChoiceCountText
    {
        get
        {
            if (!IsRanged) return $"{PossibleValues.Count} choice(s)";
            var u = string.IsNullOrEmpty(Units) ? "" : " " + Units;
            var max = Model.ValueMax >= uint.MaxValue - 1 ? "max" : Model.ValueMax.ToString();
            return $"{Model.ValueMin}–{max}{u}";
        }
    }

    public string Breadcrumb => $"{SubgroupName}  ›  {Name}  ›  {ChoiceCountText}";
    public string GuidFooter => $"{Model.SubgroupGuid:D}  /  {Model.SettingGuid:D}";

    public bool Hidden
    {
        get => Model.Hidden;
        set
        {
            if (value == Model.Hidden) return;
            try { Model.Hidden = value; }
            catch (Exception ex) { LastError = ex.Message; }
            Raise(nameof(Hidden));
            HiddenChanged?.Invoke();
        }
    }

    public event Action? HiddenChanged;

    public string? LastError { get; private set; }

    public string CurrentValueSummary
    {
        get
        {
            try
            {
                var scheme = _sink.ActiveSchemeId;
                uint ac;
                if (_sink.GetPending(scheme, Model.SettingGuid) is { Ac: { } pac }) ac = pac;
                else if (!PowerApi.TryGetAcIndex(scheme, Model.SubgroupGuid, Model.SettingGuid, out ac)) return "";
                return IsRanged
                    ? $"{ac}{(string.IsNullOrEmpty(Units) ? "" : " " + Units)}"
                    : Model.DescribeIndex(ac);
            }
            catch { return ""; }
        }
    }

    public bool IsDirty => _sink.HasPending(Model.SettingGuid);

    // ---- "has ever been changed from its Windows default" (on any plan) -------
    private bool? _modified;

    /// <summary>
    /// True when this setting's current value differs from its Windows default on at least one
    /// power plan (plugged-in, or on-battery for mobile). Cached; call <see cref="InvalidateModified"/>
    /// after anything that can change a plan value.
    /// </summary>
    public bool IsModifiedFromDefault => _modified ??= ComputeModified();

    /// <summary>Drives the blue glow: either an unsaved edit, or a saved deviation from default.</summary>
    public bool ShowChangedGlow => IsDirty || IsModifiedFromDefault;

    public void InvalidateModified()
    {
        _modified = null;
        Raise(nameof(IsModifiedFromDefault));
        Raise(nameof(ShowChangedGlow));
    }

    private bool ComputeModified()
    {
        try
        {
            var sub = Model.SubgroupGuid;
            var set = Model.SettingGuid;
            foreach (var plan in _sink.AllPlans)
            {
                if (PowerApi.TryReadAcDefault(plan.Id, sub, set, out var acDef)
                    && PowerApi.TryGetAcIndex(plan.Id, sub, set, out var acCur)
                    && acCur != acDef)
                    return true;

                if (PowerApi.IsMobile
                    && PowerApi.TryReadDcDefault(plan.Id, sub, set, out var dcDef)
                    && PowerApi.TryGetDcIndex(plan.Id, sub, set, out var dcCur)
                    && dcCur != dcDef)
                    return true;
            }
        }
        catch { /* setting has no readable default - treat as unmodified */ }
        return false;
    }

    // ---- per-plan "what changed from the Windows default" --------------------

    private string Describe(uint index) => IsRanged
        ? $"{index}{(string.IsNullOrEmpty(Units) ? "" : " " + Units)}"
        : Model.DescribeIndex(index);

    /// <summary>
    /// Every field (plugged-in, and on-battery for mobile) of this setting whose value on
    /// <paramref name="planId"/> differs from its Windows default. A staged (pending) edit is
    /// treated as the current value, so a not-yet-applied change still shows up.
    /// </summary>
    public IEnumerable<PlanChange> ChangesOn(Guid planId)
    {
        var sub = Model.SubgroupGuid;
        var set = Model.SettingGuid;
        var pending = _sink.GetPending(planId, set);

        if (PowerApi.TryReadAcDefault(planId, sub, set, out var acDef))
        {
            uint? cur = pending is { Ac: { } pac } ? pac
                : PowerApi.TryGetAcIndex(planId, sub, set, out var v) ? v : null;
            if (cur is { } c && c != acDef)
                yield return new PlanChange(this, sub, set, "Plugged in",
                    Describe(acDef), Describe(c), pending is { Ac: { } }, false);
        }

        if (PowerApi.IsMobile && PowerApi.TryReadDcDefault(planId, sub, set, out var dcDef))
        {
            uint? cur = pending is { Dc: { } pdc } ? pdc
                : PowerApi.TryGetDcIndex(planId, sub, set, out var v) ? v : null;
            if (cur is { } c && c != dcDef)
                yield return new PlanChange(this, sub, set, "On battery",
                    Describe(dcDef), Describe(c), pending is { Dc: { } }, true);
        }
    }

    public ObservableCollection<PlanValueVM> PlanRows { get; } = new();

    public void BuildRows(IEnumerable<PowerScheme> schemes, bool showDc)
    {
        PlanRows.Clear();
        foreach (var s in schemes)
            PlanRows.Add(new PlanValueVM(s, this, _sink, showDc));
    }

    public void RefreshAfterEdit()
    {
        Raise(nameof(CurrentValueSummary));
        Raise(nameof(IsDirty));
        Raise(nameof(IsAtRecommended));
        Raise(nameof(IsModifiedOnActivePlan));
        Raise(nameof(WindowsDefaultText));
        Raise(nameof(HasWindowsDefault));
        ApplyRecommendedCommand.RaiseCanExecuteChanged();
        ResetToDefaultCommand.RaiseCanExecuteChanged();
        InvalidateModified();
    }

    public bool Matches(string q)
    {
        if (string.IsNullOrWhiteSpace(q)) return true;
        return Name.Contains(q, StringComparison.OrdinalIgnoreCase)
            || SubgroupName.Contains(q, StringComparison.OrdinalIgnoreCase)
            || Model.Description.Contains(q, StringComparison.OrdinalIgnoreCase)
            || Model.SettingGuid.ToString().Contains(q, StringComparison.OrdinalIgnoreCase);
    }
}
