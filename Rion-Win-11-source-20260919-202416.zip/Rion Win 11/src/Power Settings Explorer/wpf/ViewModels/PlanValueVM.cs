using PowerSettingsExplorer.Interop;
using PowerSettingsExplorer.Models;

namespace PowerSettingsExplorer.ViewModels;

/// <summary>One plan (or power-mode overlay) row in the details pane for the selected setting.</summary>
public sealed class PlanValueVM : ObservableObject
{
    private readonly SettingVM _setting;
    private readonly IPendingSink _sink;
    private bool _loading;

    public PlanValueVM(PowerScheme scheme, SettingVM setting, IPendingSink sink, bool showDc)
    {
        Scheme = scheme;
        _setting = setting;
        _sink = sink;
        ShowDc = showDc;
        MakeActiveCommand = new RelayCommand(() => _sink.MakeActive(Scheme));

        _loading = true;
        LoadCurrent();
        _loading = false;

        IsExpanded = IsActive;

        BeginRenameCommand  = new RelayCommand(BeginRename, () => CanEdit);
        CommitRenameCommand = new RelayCommand(CommitRename);
        CancelRenameCommand = new RelayCommand(() => IsEditingName = false);
        DeleteCommand       = new RelayCommand(() => _sink.DeleteScheme(Scheme.Id), () => CanDelete);
    }

    public PowerScheme Scheme { get; }
    public string Name => Scheme.Name;
    public bool ShowDc { get; }

    public bool IsActive => Scheme.Kind == SchemeKind.Plan && Scheme.Id == _sink.ActiveSchemeId;

    /// <summary>Only real power plans can be renamed / deleted — not power-mode overlays.</summary>
    public bool CanEdit => Scheme.Kind == SchemeKind.Plan;
    public bool CanDelete => CanEdit && _sink.CanDeleteScheme(Scheme.Id);

    /// <summary>True when this plan has an unsaved (pending) value for the selected setting.</summary>
    public bool IsChanged => _sink.GetPending(Scheme.Id, _setting.Model.SettingGuid) is not null;

    public RelayCommand MakeActiveCommand { get; }
    public RelayCommand BeginRenameCommand { get; }
    public RelayCommand CommitRenameCommand { get; }
    public RelayCommand CancelRenameCommand { get; }
    public RelayCommand DeleteCommand { get; }

    private bool _isEditingName;
    public bool IsEditingName
    {
        get => _isEditingName;
        set { if (Set(ref _isEditingName, value) && value) EditName = Scheme.Name; }
    }

    private string _editName = "";
    public string EditName { get => _editName; set => Set(ref _editName, value); }

    private void BeginRename() => IsEditingName = true;

    private void CommitRename()
    {
        _sink.RenameScheme(Scheme.Id, EditName);
        IsEditingName = false;
        Raise(nameof(Name));
    }

    private bool _isExpanded;
    public bool IsExpanded { get => _isExpanded; set => Set(ref _isExpanded, value); }

    private bool _isSelected;
    public bool IsSelected { get => _isSelected; set => Set(ref _isSelected, value); }

    // ---- enum editing --------------------------------------------------------
    public IReadOnlyList<PwrPossibleValue> Choices => _setting.PossibleValues;

    private PwrPossibleValue? _acChoice;
    public PwrPossibleValue? AcChoice
    {
        get => _acChoice;
        set { if (Set(ref _acChoice, value)) Push(); }
    }

    private PwrPossibleValue? _dcChoice;
    public PwrPossibleValue? DcChoice
    {
        get => _dcChoice;
        set { if (Set(ref _dcChoice, value)) Push(); }
    }

    // ---- ranged editing ----------------------------------------------------
    public bool IsRanged => _setting.IsRanged;
    public double Min => _setting.Min;
    public double Max => _setting.Max;
    public double Increment => _setting.Increment;
    public string Units => _setting.Units ?? "";

    private double _acNumber;
    public double AcNumber
    {
        get => _acNumber;
        set { if (Set(ref _acNumber, value)) Push(); }
    }

    private double _dcNumber;
    public double DcNumber
    {
        get => _dcNumber;
        set { if (Set(ref _dcNumber, value)) Push(); }
    }

    // ----------------------------------------------------------------------
    private void LoadCurrent()
    {
        var pending = _sink.GetPending(Scheme.Id, _setting.Model.SettingGuid);
        uint? ac = pending?.Ac;
        uint? dc = pending?.Dc;

        if (ac is null && PowerApi.TryGetAcIndex(Scheme.Id, _setting.Model.SubgroupGuid, _setting.Model.SettingGuid, out var acv))
            ac = acv;
        if (dc is null && PowerApi.TryGetDcIndex(Scheme.Id, _setting.Model.SubgroupGuid, _setting.Model.SettingGuid, out var dcv))
            dc = dcv;

        if (IsRanged)
        {
            _acNumber = ac ?? Min;
            _dcNumber = dc ?? Min;
        }
        else
        {
            _acChoice = _setting.PossibleValues.FirstOrDefault(p => p.Index == ac)
                        ?? _setting.PossibleValues.FirstOrDefault();
            _dcChoice = _setting.PossibleValues.FirstOrDefault(p => p.Index == dc)
                        ?? _setting.PossibleValues.FirstOrDefault();
        }
    }

    private void Push()
    {
        if (_loading) return;

        uint? ac = IsRanged ? (uint)Math.Round(AcNumber) : AcChoice?.Index;
        uint? dc = IsRanged ? (uint)Math.Round(DcNumber) : DcChoice?.Index;

        _sink.SetPending(Scheme.Id, _setting.Model.SubgroupGuid, _setting.Model.SettingGuid, ac, dc);
        _setting.RefreshAfterEdit();
        Raise(nameof(IsChanged));
    }
}
