namespace PowerSettingsExplorer.ViewModels;
public enum DetailsTab { Plans, Modes }
