using PowerSettingsExplorer.Services;

namespace PowerSettingsExplorer.ViewModels;

public sealed class CategoryVM : ObservableObject
{
    public CategoryVM(string id, string name, string glyph)
    {
        Id = id;
        Name = name;
        Glyph = glyph;
    }

    public static CategoryVM From(PowerCategory c) => new(c.Id, c.Name, c.Glyph);

    public string Id { get; }
    public string Name { get; }
    public string Glyph { get; }

    private int _count;
    public int Count { get => _count; set => Set(ref _count, value); }

    public const string AllId = "all";
}
