using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using Microsoft.Win32;
using PowerSettingsExplorer.Interop;
using PowerSettingsExplorer.Models;
using PowerSettingsExplorer.Services;
using PowerSettingsExplorer.Views;

namespace PowerSettingsExplorer.ViewModels;

public sealed class MainViewModel : ObservableObject, IPendingSink
{
	private readonly record struct PendingEntry(Guid Subgroup, uint? Ac, uint? Dc);

	private readonly List<SettingVM> _all = new List<SettingVM>();

	private readonly Dictionary<(Guid Scheme, Guid Setting), PendingEntry> _pending = new Dictionary<(Guid, Guid), PendingEntry>();

	private bool _busy;

	private string _searchText = "";

	private CategoryVM _selectedCategory;

	private bool _includeHidden;

	private bool _revealHiddenPrompted;

	private bool _showRevealHiddenPrompt;

	private SettingVM? _selectedSetting;

	private DetailsTab _tab;

	private string _activePlanName = "";

	public static Func<string, bool>? BeforeApply { get; set; }

	public ObservableCollection<CategoryVM> Categories { get; } = new ObservableCollection<CategoryVM>();

	public ICollectionView SettingsView { get; }

	public ObservableCollection<PowerScheme> Plans { get; } = new ObservableCollection<PowerScheme>();

	public ObservableCollection<PowerScheme> Overlays { get; } = new ObservableCollection<PowerScheme>();

	public bool IsElevated { get; } = new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);

	public bool IsBusy
	{
		get
		{
			return _busy;
		}
		set
		{
			Set(ref _busy, value, "IsBusy");
		}
	}

	public string SearchText
	{
		get
		{
			return _searchText;
		}
		set
		{
			if (Set(ref _searchText, value, "SearchText"))
			{
				RefreshView();
			}
		}
	}

	public CategoryVM SelectedCategory
	{
		get
		{
			return _selectedCategory;
		}
		set
		{
			if (Set(ref _selectedCategory, value, "SelectedCategory"))
			{
				RefreshView();
			}
		}
	}

	public bool IncludeHidden
	{
		get
		{
			return _includeHidden;
		}
		set
		{
			if (Set(ref _includeHidden, value, "IncludeHidden"))
			{
				RefreshView();
				Raise("HiddenButtonText");
			}
		}
	}

	public int HiddenCount => _all.Count((SettingVM s) => s.Hidden);

	public bool ShowRevealHiddenPrompt
	{
		get
		{
			return _showRevealHiddenPrompt;
		}
		private set
		{
			Set(ref _showRevealHiddenPrompt, value, "ShowRevealHiddenPrompt");
		}
	}

	public string HiddenPromptText
	{
		get
		{
			if (HiddenCount != 1)
			{
				return $"{HiddenCount} power settings are hidden by Windows.";
			}
			return "1 power setting is hidden by Windows.";
		}
	}

	public string HiddenButtonText
	{
		get
		{
			if (IncludeHidden)
			{
				return "Show visible settings only";
			}
			int hiddenCount = HiddenCount;
			if (hiddenCount > 0)
			{
				return $"Show {hiddenCount} hidden setting{((hiddenCount == 1) ? "" : "s")}";
			}
			return "Nothing is hidden";
		}
	}

	public SettingVM? SelectedSetting
	{
		get
		{
			return _selectedSetting;
		}
		set
		{
			if (Set(ref _selectedSetting, value, "SelectedSetting"))
			{
				_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
				Raise("HasSelection");
				OpenRegeditCommand.RaiseCanExecuteChanged();
				AddChoiceCommand.RaiseCanExecuteChanged();
			}
		}
	}

	public bool HasSelection => _selectedSetting != null;

	public DetailsTab Tab
	{
		get
		{
			return _tab;
		}
		set
		{
			if (Set(ref _tab, value, "Tab"))
			{
				_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
			}
		}
	}

	public bool HasOverlays => Overlays.Count > 0;

	public string ActivePlanName
	{
		get
		{
			return _activePlanName;
		}
		private set
		{
			Set(ref _activePlanName, value, "ActivePlanName");
		}
	}

	public string HeaderTitle
	{
		get
		{
			if (!(SelectedCategory.Id == "all"))
			{
				return SelectedCategory.Name;
			}
			return "All settings";
		}
	}

	public RelayCommand ReloadCommand { get; }

	public RelayCommand ApplyCommand { get; }

	public RelayCommand ImportCommand { get; }

	public RelayCommand ExportCommand { get; }

	public RelayCommand SaveScriptCommand { get; }

	public RelayCommand UnhideAllCommand { get; }

	public RelayCommand RefreshPlansCommand { get; }

	public RelayCommand RestoreDefaultPlansCommand { get; }

	public RelayCommand ToggleHiddenCommand { get; }

	public RelayCommand OpenRegeditCommand { get; }

	public RelayCommand AddChoiceCommand { get; }

	public RelayCommand RelaunchElevatedCommand { get; }

	public RelayCommand ShowChangesCommand { get; }

	public RelayCommand ApplyAllRecommendedCommand { get; }

	public RelayCommand UnhideAllFromPromptCommand { get; }

	public RelayCommand RevealHiddenNoCommand { get; }

	public int RecommendationsOutstanding => _all.Count(delegate(SettingVM s)
	{
		if (s.HasRecommendation)
		{
			Recommendation? reco = s.Reco;
			if ((object)reco == null || !reco.IndividualOnly)
			{
				return !s.IsAtRecommended;
			}
		}
		return false;
	});

	public string ApplyAllRecommendedText
	{
		get
		{
			int recommendationsOutstanding = RecommendationsOutstanding;
			if (recommendationsOutstanding != 0)
			{
				return $"Apply {recommendationsOutstanding} recommended value{((recommendationsOutstanding == 1) ? "" : "s")}";
			}
			return "Recommendations applied";
		}
	}

	public Guid ActiveSchemeId => PowerApi.ActiveSchemeGuid;

	public IReadOnlyList<PowerScheme> AllPlans => Plans;

	public int PendingCount => _pending.Count;

	public string ApplyButtonText
	{
		get
		{
			if (_pending.Count != 0)
			{
				return $"Apply {_pending.Count} change{((_pending.Count == 1) ? "" : "s")}";
			}
			return "Apply changes";
		}
	}

	public MainViewModel()
	{
		SettingsView = CollectionViewSource.GetDefaultView(_all);
		SettingsView.Filter = (object o) => o is SettingVM s && PassesFilter(s);
		Categories.Add(new CategoryVM("all", "All settings", ""));
		foreach (PowerCategory item in CategoryCatalog.All)
		{
			Categories.Add(CategoryVM.From(item));
		}
		_selectedCategory = Categories[0];
		ReloadCommand = new RelayCommand((Action)async delegate
		{
			await LoadAsync();
		}, (Func<bool>?)null);
		ApplyCommand = new RelayCommand(Apply, () => _pending.Count > 0);
		ImportCommand = new RelayCommand(Import);
		ExportCommand = new RelayCommand(Export);
		SaveScriptCommand = new RelayCommand(SaveScript, () => _pending.Count > 0);
		UnhideAllCommand = new RelayCommand(UnhideAll);
		RefreshPlansCommand = new RelayCommand(RefreshPlans);
		RestoreDefaultPlansCommand = new RelayCommand(RestoreDefaultPlans);
		ToggleHiddenCommand = new RelayCommand((Action)delegate
		{
			IncludeHidden = !IncludeHidden;
		}, (Func<bool>?)null);
		OpenRegeditCommand = new RelayCommand(OpenRegedit, () => SelectedSetting != null);
		AddChoiceCommand = new RelayCommand(AddChoice, () => SelectedSetting?.CanAddChoice ?? false);
		RelaunchElevatedCommand = new RelayCommand(RelaunchElevated, () => !IsElevated);
		ShowChangesCommand = new RelayCommand(ShowChanges, () => _all.Count > 0);
		ApplyAllRecommendedCommand = new RelayCommand(ApplyAllRecommended, () => RecommendationsOutstanding > 0);
		UnhideAllFromPromptCommand = new RelayCommand(UnhideAllFromPrompt);
		RevealHiddenNoCommand = new RelayCommand((Action)delegate
		{
			ShowRevealHiddenPrompt = false;
		}, (Func<bool>?)null);
	}

	public void RaiseHiddenSummary()
	{
		Raise("HiddenCount");
		Raise("HiddenButtonText");
		Raise("HiddenPromptText");
	}

	private void RaiseRecoSummary()
	{
		Raise("RecommendationsOutstanding");
		Raise("ApplyAllRecommendedText");
		ApplyAllRecommendedCommand.RaiseCanExecuteChanged();
	}

	public async Task LoadAsync()
	{
		IsBusy = true;
		_pending.Clear();
		PendingChanged();
		_all.Clear();
		Plans.Clear();
		Overlays.Clear();
		SelectedSetting = null;
		try
		{
			PowerApi.RefreshActiveScheme();
			var (list, list2, source) = await Task.Run(delegate
			{
				List<PowerScheme> item = PowerApi.EnumerateSchemes();
				List<PowerScheme> item2 = PowerApi.EnumerateOverlays();
				List<PwrSetting> item3 = PowerSettingsService.LoadAll().ToList();
				return (p: item, o: item2, s: item3);
			});
			foreach (PowerScheme item4 in list)
			{
				Plans.Add(item4);
			}
			foreach (PowerScheme item5 in list2)
			{
				Overlays.Add(item5);
			}
			foreach (PwrSetting item6 in source.Where((PwrSetting m) => m.Initialized))
			{
				SettingVM vm = new SettingVM(item6, this);
				vm.HiddenChanged += delegate
				{
					RecountCategories();
					RefreshView();
					RaiseHiddenSummary();
				};
				vm.PendingApplied += delegate
				{
					if (_selectedSetting == vm)
					{
						vm.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
					}
					RefreshView();
				};
				_all.Add(vm);
			}
			RecountCategories();
			RefreshView();
			RaiseRecoSummary();
			RaiseHiddenSummary();
			Raise("HasOverlays");
			RefreshActivePlanName();
			SelectedSetting = SettingsView.Cast<SettingVM>().FirstOrDefault();
			if (!_revealHiddenPrompted && !IncludeHidden && HiddenCount > 0)
			{
				_revealHiddenPrompted = true;
				ShowRevealHiddenPrompt = true;
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Load failed", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
		finally
		{
			IsBusy = false;
		}
	}

	private IEnumerable<PowerScheme> AllSchemesForTab()
	{
		if (Tab != DetailsTab.Modes || !HasOverlays)
		{
			return Plans;
		}
		return Overlays;
	}

	private bool PassesFilter(SettingVM s)
	{
		if (!IncludeHidden && s.Hidden)
		{
			return false;
		}
		if (SelectedCategory.Id != "all" && s.Category.Id != SelectedCategory.Id)
		{
			return false;
		}
		return s.Matches(SearchText);
	}

	private void RefreshView()
	{
		SettingsView.Refresh();
		Raise("HeaderTitle");
	}

	private void RecountCategories()
	{
		foreach (CategoryVM c in Categories)
		{
			c.Count = ((c.Id == "all") ? _all.Count((SettingVM s) => IncludeHidden || !s.Hidden) : _all.Count((SettingVM s) => s.Category.Id == c.Id && (IncludeHidden || !s.Hidden)));
		}
	}

	private void RefreshActivePlanName()
	{
		PowerApi.RefreshActiveScheme();
		ActivePlanName = Plans.FirstOrDefault((PowerScheme p) => p.Id == PowerApi.ActiveSchemeGuid)?.Name ?? "(unknown)";
	}

	public (uint? Ac, uint? Dc)? GetPending(Guid scheme, Guid setting)
	{
		if (!_pending.TryGetValue((scheme, setting), out var value))
		{
			return null;
		}
		return (value.Ac, value.Dc);
	}

	public void SetPending(Guid scheme, Guid subgroup, Guid setting, uint? ac, uint? dc)
	{
		_pending[(scheme, setting)] = new PendingEntry(subgroup, ac, dc);
		PendingChanged();
	}

	public bool HasPending(Guid setting)
	{
		return _pending.Keys.Any(((Guid Scheme, Guid Setting) k) => k.Setting == setting);
	}

	private void PendingChanged()
	{
		ApplyCommand.RaiseCanExecuteChanged();
		SaveScriptCommand.RaiseCanExecuteChanged();
		Raise("PendingCount");
		Raise("ApplyButtonText");
		RaiseRecoSummary();
	}

	public void MakeActive(PowerScheme scheme)
	{
		if (scheme.Kind == SchemeKind.Overlay)
		{
			PowerApi.SetActiveOverlay(scheme.Id);
		}
		else
		{
			PowerApi.SetActiveScheme(scheme.Id);
		}
		RefreshActivePlanName();
		_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
		foreach (SettingVM item in _all)
		{
			item.RefreshAfterEdit();
		}
		RaiseRecoSummary();
	}

	public bool CanDeleteScheme(Guid scheme)
	{
		PowerScheme powerScheme = Plans.FirstOrDefault((PowerScheme x) => x.Id == scheme);
		if (powerScheme != null && powerScheme.Kind == SchemeKind.Plan && scheme != PowerApi.ActiveSchemeGuid)
		{
			return Plans.Count > 1;
		}
		return false;
	}

	public void RenameScheme(Guid scheme, string newName)
	{
		PowerScheme powerScheme = Plans.FirstOrDefault((PowerScheme x) => x.Id == scheme);
		if (powerScheme == null)
		{
			return;
		}
		newName = (newName ?? "").Trim();
		if (newName.Length == 0 || newName == powerScheme.Name)
		{
			return;
		}
		try
		{
			PowerApi.WriteSchemeName(scheme, newName);
			powerScheme.Name = newName;
			RefreshActivePlanName();
			_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
			RefreshView();
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Rename failed", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	public void DeleteScheme(Guid scheme)
	{
		PowerScheme powerScheme = Plans.FirstOrDefault((PowerScheme x) => x.Id == scheme);
		if (powerScheme == null)
		{
			return;
		}
		if (scheme == PowerApi.ActiveSchemeGuid)
		{
			MessageBox.Show("This plan is active. Switch to another plan first, then delete it.", "Can't delete the active plan", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
		else
		{
			if (MessageBox.Show("Delete the power plan “" + powerScheme.Name + "”? This cannot be undone.", "Delete power plan", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
			{
				return;
			}
			try
			{
				PowerApi.DeleteScheme(scheme);
				Plans.Remove(powerScheme);
				foreach (var item in _pending.Keys.Where(((Guid Scheme, Guid Setting) k) => k.Scheme == scheme).ToList())
				{
					_pending.Remove(item);
				}
				PendingChanged();
				_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
				RefreshView();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Delete failed", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}
	}

	private void Apply()
	{
		if (_pending.Count == 0)
		{
			return;
		}
		Func<string, bool>? beforeApply = BeforeApply;
		if (beforeApply != null && !beforeApply("Apply staged power settings"))
		{
			return;
		}
		List<string> list = new List<string>();
		foreach (KeyValuePair<(Guid, Guid), PendingEntry> item in _pending.ToList())
		{
			item.Deconstruct(out var key, out var value);
			(Guid, Guid) tuple = key;
			Guid scheme = tuple.Item1;
			Guid setting = tuple.Item2;
			PendingEntry e = value;
			string description = (Plans.FirstOrDefault((PowerScheme p) => p.Id == scheme)?.Name ?? scheme.ToString()) + ": " + (_all.FirstOrDefault((SettingVM s) => s.Model.SettingGuid == setting && s.Model.SubgroupGuid == e.Subgroup)?.Name ?? setting.ToString());
			uint? ac = e.Ac;
			uint? dc = e.Dc;
			uint? ac2 = e.Ac;
			if (ac2.HasValue)
			{
				uint valueOrDefault = ac2.GetValueOrDefault();
				PowerHistoryResult powerHistoryResult = PowerChangeHistory.Apply(new PowerTarget(scheme, e.Subgroup, setting, Dc: false), valueOrDefault, description);
				if (powerHistoryResult.Success)
				{
					ac = null;
				}
				else
				{
					list.Add($"{setting} AC: {powerHistoryResult.Message}");
				}
			}
			ac2 = e.Dc;
			if (ac2.HasValue)
			{
				uint valueOrDefault2 = ac2.GetValueOrDefault();
				PowerHistoryResult powerHistoryResult2 = PowerChangeHistory.Apply(new PowerTarget(scheme, e.Subgroup, setting, Dc: true), valueOrDefault2, description);
				if (powerHistoryResult2.Success)
				{
					dc = null;
				}
				else
				{
					list.Add($"{setting} DC: {powerHistoryResult2.Message}");
				}
			}
			if (!ac.HasValue && !dc.HasValue)
			{
				_pending.Remove((scheme, setting));
			}
			else
			{
				_pending[(scheme, setting)] = new PendingEntry(e.Subgroup, ac, dc);
			}
		}
		PendingChanged();
		foreach (SettingVM item2 in _all)
		{
			item2.RefreshAfterEdit();
		}
		_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
		if (list.Count > 0)
		{
			MessageBox.Show(string.Join("\n", list), "Some settings were not applied", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}
	}

	private void Import()
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "Power settings XML|*.xml|All files|*.*"
		};
		if (openFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			IReadOnlyList<string> readOnlyList = PowerSettingsService.Import(openFileDialog.FileName);
			if (readOnlyList.Count > 0)
			{
				MessageBox.Show(string.Join("\n", readOnlyList), "Some imported settings were not applied", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			foreach (SettingVM item in _all)
			{
				item.RefreshAfterEdit();
			}
			_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
			RefreshView();
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Import failed", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void Export()
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Power settings XML|*.xml",
			FileName = "power-settings.xml"
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		try
		{
			PowerSettingsService.Export(saveFileDialog.FileName, Plans.Concat(Overlays).ToList(), _all.Select((SettingVM s) => s.Model));
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Export failed", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void SaveScript()
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Batch script|*.bat",
			FileName = "apply-power-settings.bat"
		};
		if (saveFileDialog.ShowDialog() != true)
		{
			return;
		}
		IEnumerable<PowerChange> changes = _pending.Select(delegate(KeyValuePair<(Guid Scheme, Guid Setting), PendingEntry> kv)
		{
			(Guid, Guid) key = kv.Key;
			Guid scheme = key.Item1;
			Guid setting = key.Item2;
			SettingVM settingVM = _all.FirstOrDefault((SettingVM s) => s.Model.SettingGuid == setting);
			PowerScheme powerScheme = Plans.Concat(Overlays).FirstOrDefault((PowerScheme p) => p.Id == scheme);
			return new PowerChange(scheme, powerScheme?.Name ?? scheme.ToString(), kv.Value.Subgroup, setting, settingVM?.SubgroupName ?? "", settingVM?.Name ?? setting.ToString(), kv.Value.Ac, kv.Value.Dc);
		});
		try
		{
			PowerSettingsService.WriteScript(saveFileDialog.FileName, changes);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Save failed", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void RefreshPlans()
	{
		try
		{
			PowerApi.RefreshActiveScheme();
			List<PowerScheme> list = PowerApi.EnumerateSchemes();
			List<PowerScheme> list2 = PowerApi.EnumerateOverlays();
			Guid? id = SelectedPlanId();
			Plans.Clear();
			Overlays.Clear();
			foreach (PowerScheme item in list)
			{
				Plans.Add(item);
			}
			foreach (PowerScheme item2 in list2)
			{
				Overlays.Add(item2);
			}
			Raise("HasOverlays");
			RefreshActivePlanName();
			_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
			RestoreExpandedPlan(id);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Refresh failed", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private Guid? SelectedPlanId()
	{
		return _selectedSetting?.PlanRows.FirstOrDefault((PlanValueVM r) => r.IsExpanded)?.Scheme.Id;
	}

	private void RestoreExpandedPlan(Guid? id)
	{
		if (!id.HasValue)
		{
			return;
		}
		Guid valueOrDefault = id.GetValueOrDefault();
		if (_selectedSetting == null)
		{
			return;
		}
		foreach (PlanValueVM planRow in _selectedSetting.PlanRows)
		{
			if (planRow.Scheme.Id == valueOrDefault)
			{
				planRow.IsExpanded = true;
				break;
			}
		}
	}

	private void RestoreDefaultPlans()
	{
		List<string> list = (from p in PowerPlanRestore.StockPlans
			where Plans.All((PowerScheme existing) => existing.Id != p.Id)
			select p.Name).ToList();
		if (list.Count == 0)
		{
			MessageBox.Show("Balanced, High performance and Power saver are all present. Nothing to restore.", "Restore default power plans", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
		else
		{
			if (MessageBox.Show("Recreate " + string.Join(", ", list) + "?\n\nYour own power plans are not touched, and any stock plan that still exists — including a renamed one — is left exactly as it is.", "Restore default power plans", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
			{
				return;
			}
			if (!IsElevated)
			{
				MessageBox.Show("Recreating a power plan writes to HKEY_LOCAL_MACHINE, which needs administrator rights. Relaunch elevated and try again.", "Restore default power plans", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return;
			}
			IReadOnlyList<PowerPlanRestore.RestoreOutcome> readOnlyList = PowerPlanRestore.RestoreMissing(Plans);
			RefreshPlans();
			List<string> list2 = new List<string>();
			bool flag = false;
			foreach (PowerPlanRestore.RestoreOutcome result in readOnlyList)
			{
				bool flag2 = Plans.Any((PowerScheme p) => p.Id == PowerPlanRestore.StockPlans.First(((Guid Id, string Name) s) => s.Name == result.Name).Id);
				if (result.Detail == "already present")
				{
					list2.Add(result.Name + " — already present, left as it is");
					continue;
				}
				if (flag2)
				{
					list2.Add(result.Name + " — restored");
					continue;
				}
				flag = true;
				list2.Add(result.Name + " — not restored: " + result.Detail);
			}
			MessageBox.Show(string.Join("\n", list2), "Restore default power plans", MessageBoxButton.OK, flag ? MessageBoxImage.Exclamation : MessageBoxImage.Asterisk);
		}
	}

	private void UnhideAll()
	{
		if (MessageBox.Show("Reveal every hidden power setting in the Windows UI?", "Unhide all", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
		{
			return;
		}
		foreach (SettingVM item in _all.Where((SettingVM s) => s.Hidden))
		{
			try
			{
				item.Hidden = false;
			}
			catch
			{
			}
		}
		RecountCategories();
		RefreshView();
		RaiseHiddenSummary();
	}

	private void UnhideAllFromPrompt()
	{
		ShowRevealHiddenPrompt = false;
		foreach (SettingVM item in _all.Where((SettingVM s) => s.Hidden))
		{
			try
			{
				item.Hidden = false;
			}
			catch
			{
			}
		}
		IncludeHidden = true;
		RecountCategories();
		RefreshView();
		RaiseHiddenSummary();
	}

	private void OpenRegedit()
	{
		SettingVM selectedSetting = SelectedSetting;
		if (selectedSetting == null)
		{
			return;
		}
		try
		{
			using RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Applets\\Regedit");
			registryKey?.SetValue("LastKey", PowerApi.RegistryPath(selectedSetting.Model.SubgroupGuid, selectedSetting.Model.SettingGuid));
			Process.Start(new ProcessStartInfo("regedit.exe")
			{
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
		}
	}

	private void AddChoice()
	{
		MessageBox.Show("Adding heterogeneous-CPU threshold values isn't wired up in this build yet.", "Add a choice", MessageBoxButton.OK, MessageBoxImage.Asterisk);
	}

	private void ShowChanges()
	{
		if (_all.Count == 0)
		{
			return;
		}
		Guid initialPlan = (Plans.Any((PowerScheme p) => p.Id == PowerApi.ActiveSchemeGuid) ? PowerApi.ActiveSchemeGuid : (Plans.FirstOrDefault()?.Id ?? Guid.Empty));
		ChangesWindow changesWindow = new ChangesWindow();
		changesWindow.Owner = Application.Current?.MainWindow;
		changesWindow.DataContext = new ChangesViewModel(Plans.ToList(), _all, initialPlan, this, delegate(SettingVM s)
		{
			if (!IncludeHidden && s.Hidden)
			{
				IncludeHidden = true;
			}
			if (SelectedCategory.Id != "all")
			{
				SelectedCategory = Categories[0];
			}
			SearchText = "";
			SelectedSetting = s;
		});
		changesWindow.ShowDialog();
		foreach (SettingVM item in _all)
		{
			item.RefreshAfterEdit();
		}
		_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
		RefreshView();
	}

	private void ApplyAllRecommended()
	{
		List<SettingVM> list = _all.Where(delegate(SettingVM s)
		{
			if (s.HasRecommendation)
			{
				Recommendation? reco = s.Reco;
				if ((object)reco == null || !reco.IndividualOnly)
				{
					return !s.IsAtRecommended;
				}
			}
			return false;
		}).ToList();
		if (list.Count == 0)
		{
			return;
		}
		string text = string.Join("\n", from s in list
			orderby s.SubgroupName
			select "  • " + s.Name + "  →  " + s.RecommendationValueText);
		if (MessageBox.Show($"Stage the recommended value for these {list.Count} setting(s) on the active plan?\n\n" + text + "\n\nNothing is written until you press “Apply changes”. Open each setting to read why it is recommended and its trade-offs.", "Apply recommended values", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
		{
			return;
		}
		int num = 0;
		foreach (SettingVM item in list)
		{
			if (item.TryStageRecommended())
			{
				num++;
			}
		}
		if (num != 0)
		{
			_selectedSetting?.BuildRows(AllSchemesForTab(), PowerApi.IsMobile);
			RefreshView();
			RaiseRecoSummary();
		}
	}

	private void RelaunchElevated()
	{
		if (!IsElevated)
		{
			MessageBox.Show("Rion Win 11 needs to run as administrator. Close it and relaunch from an elevated shortcut (right-click → Run as administrator).", "Administrator required", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
	}
}