using System.IO;
using System.Text.Json;
using NUnit.Framework;
using PowerSettingsExplorer.Services;

public class PowerHistoryTests
{
    private string directory = "";
    private Fake backend = null!;
    private PowerHistoryStore store = null!;
    private readonly PowerTarget target = new(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), false);
    [SetUp] public void Setup()
    {
        directory = Path.Combine(Path.GetTempPath(), "RionPowerTests-" + Guid.NewGuid().ToString("N"));
        backend = new Fake(); store = new(backend, directory);
    }
    [TearDown] public void Cleanup() { if (Directory.Exists(directory)) Directory.Delete(directory, true); }

    [Test] public void ApplyJournalsBeforeWriteAndRestoresExactValue()
    {
        backend.BeforeWrite = () => Assert.That(Directory.GetFiles(directory, "*.json"), Has.Length.EqualTo(1));
        Assert.That(store.Apply(target, 80, "test").Success, Is.True);
        var entry = store.ListEntries().Single();
        Assert.That(entry.PreviousValue, Is.EqualTo("37"));
        Assert.That(store.Restore(entry.Id).Success, Is.True);
        Assert.That(backend.Value, Is.EqualTo(37));
        Assert.That(store.ListEntries().Single().Status, Is.EqualTo("Restored"));
    }
    [Test] public void ConflictDoesNotOverwriteExternalValue()
    {
        store.Apply(target, 80, "test"); backend.Value = 61;
        Assert.That(store.ListEntries().Single().CanRestore, Is.False);
        Assert.That(store.Restore(store.ListEntries().Single().Id).Success, Is.False);
        Assert.That(backend.Value, Is.EqualTo(61));
    }
    [Test] public void RepeatedApplyDoesNotLoseBaseline()
    {
        store.Apply(target, 80, "test"); store.Apply(target, 80, "repeat");
        Assert.That(store.ListEntries(), Has.Count.EqualTo(1));
        Assert.That(store.ListEntries().Single().PreviousValue, Is.EqualTo("37"));
    }
    [Test] public void FailedActivationDuringRestoreCanBeRetried()
    {
        store.Apply(target, 80, "test"); string id = store.ListEntries().Single().Id;
        backend.FailActivation = true;
        Assert.That(store.Restore(id).Success, Is.False);
        Assert.That(backend.Value, Is.EqualTo(37));
        Assert.That(store.ListEntries().Single().CanRestore, Is.True);
        backend.FailActivation = false;
        Assert.That(store.Restore(id).Success, Is.True);
    }
    [Test] public void UnwritableStorageBlocksMutation()
    {
        Directory.CreateDirectory(directory); string file = Path.Combine(directory, "file"); File.WriteAllText(file, "x");
        var blocked = new PowerHistoryStore(backend, file);
        Assert.That(blocked.Apply(target, 80, "test").Success, Is.False);
        Assert.That(backend.Writes, Is.Zero);
    }
    [Test] public void ReadbackMismatchKeepsRecoveryRecord()
    {
        backend.IgnoreWrite = true;
        Assert.That(store.Apply(target, 80, "test").Success, Is.False);
        Assert.That(store.ListEntries(), Has.Count.EqualTo(1));
        Assert.That(store.ListEntries().Single().Error, Does.Contain("retain"));
    }
    [Test] public void InvalidValueAndCorruptJournalCannotWrite()
    {
        Assert.That(store.Apply(target, 101, "test").Success, Is.False);
        Directory.CreateDirectory(directory);
        string id = Guid.NewGuid().ToString("N"); File.WriteAllText(Path.Combine(directory, id + ".json"), "{broken");
        Assert.That(store.ListEntries().Single().Status, Is.EqualTo("Unreadable"));
        Assert.That(store.Restore(id).Success, Is.False);
        Assert.That(store.Restore("../outside").Success, Is.False);
        Assert.That(backend.Writes, Is.Zero);
    }
    [Test] public void RestoreUsesRecordedDcAndIdentifiersAfterRestart()
    {
        var dc = target with { Dc = true };
        store.Apply(dc, 80, "DC test");
        var restarted = new PowerHistoryStore(backend, directory);
        Assert.That(restarted.Restore(restarted.ListEntries().Single().Id).Success, Is.True);
        Assert.That(backend.LastTarget, Is.EqualTo(dc));
    }
    [Test] public void LegacyXmlRoutesAcAndDcThroughJournalAndReportsPartialFailure()
    {
        Directory.CreateDirectory(directory);
        string xml = Path.Combine(directory, "input.xml");
        File.WriteAllText(xml, $"<root><subgroup guid='{target.Subgroup}'><setting guid='{target.Setting}' name='test'><acindex scheme='{target.Scheme}' value='80'/><dcindex scheme='{target.Scheme}' value='101'/></setting></subgroup></root>");
        var errors = PowerSettingsService.Import(xml, store.Apply);
        Assert.That(errors, Has.Count.EqualTo(1));
        Assert.That(errors.Single(), Does.Contain("DC"));
        Assert.That(backend.Writes, Is.EqualTo(1));
        Assert.That(store.ListEntries(), Has.Count.EqualTo(1));
    }
    [Test] public void MalformedImportIdentifiersNeverReachWriteDelegate()
    {
        Directory.CreateDirectory(directory);
        string xml = Path.Combine(directory, "input.xml");
        File.WriteAllText(xml, "<root><subgroup guid='invalid'><setting guid='invalid'/></subgroup></root>");
        int calls = 0;
        var errors = PowerSettingsService.Import(xml, (_, _, _) => { calls++; return new(true, ""); });
        Assert.That(errors, Is.Not.Empty); Assert.That(calls, Is.Zero);
    }
    [Test] public void XmlExternalEntitiesAreRejectedBeforeAnyWrite()
    {
        Directory.CreateDirectory(directory);
        string xml = Path.Combine(directory, "input.xml");
        File.WriteAllText(xml, "<!DOCTYPE root [<!ENTITY x SYSTEM 'file:///not-read'>]><root>&x;</root>");
        int calls = 0;
        Assert.Throws<System.Xml.XmlException>(() => PowerSettingsService.Import(xml, (_, _, _) => { calls++; return new(true, ""); }));
        Assert.That(calls, Is.Zero);
    }
    private sealed class Fake : IPowerHistoryBackend
    {
        public uint Value = 37; public int Writes; public bool IgnoreWrite, FailActivation;
        public PowerTarget LastTarget; public Action? BeforeWrite;
        public uint Read(PowerTarget t) => Value;
        public void Validate(PowerTarget t, uint value) { if (value > 100) throw new InvalidDataException("Unsupported value"); }
        public void Write(PowerTarget t, uint value) { BeforeWrite?.Invoke(); LastTarget = t; Writes++; if (!IgnoreWrite) Value = value; }
        public void Activate() { if (FailActivation) throw new IOException("Activation failed"); }
    }
}
