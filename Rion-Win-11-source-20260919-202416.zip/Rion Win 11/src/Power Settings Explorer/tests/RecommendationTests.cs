using NUnit.Framework;
using PowerSettingsExplorer.Services;

namespace PowerHistory.Tests;

public class RecommendationTests
{
    [TestCase("893dee8e-2bef-41e0-89c6-b55d0929964c")]
    [TestCase("0cc5b647-c1df-4637-891a-dec35c318583")]
    [TestCase("465e1f50-b610-473a-ab58-00d1077dc418")]
    [TestCase("be337238-0d82-4146-a960-4f3749d470c7")]
    public void PlatformDependentSettingsHaveGuidanceWithoutUniversalTargets(string id)
    {
        var recommendation = RecommendationCatalog.For(Guid.Parse(id))!;
        Assert.That(recommendation.IndividualOnly, Is.True);
        Assert.That(recommendation.ResolveTarget(true, 0, 100, 1, Array.Empty<(uint, string)>()), Is.Null);
        Assert.That(recommendation.ValueMatch, Is.Empty);
        Assert.That(recommendation.Rationale, Is.Not.Empty);
    }
    [Test] public void MobileValuesAreExcludedFromBulk()
    {
        var id = Guid.Parse("bc5038f7-23e0-4960-96da-33abaf5935ec");
        Assert.That(RecommendationCatalog.For(id, true)!.IndividualOnly, Is.True);
        Assert.That(RecommendationCatalog.For(id, false)!.IndividualOnly, Is.False);
    }
    [Test] public void UnsupportedRangesAreRejectedInsteadOfClamped()
    {
        var r = new Recommendation(Guid.NewGuid(), "", 100, "", "", "", RecoConfidence.Strong);
        Assert.That(r.ResolveTarget(true, 0, 90, 1, Array.Empty<(uint, string)>()), Is.Null);
        Assert.That(r.ResolveTarget(true, 0, 100, 7, Array.Empty<(uint, string)>()), Is.Null);
        Assert.That(r.ResolveTarget(true, 0, 100, 5, Array.Empty<(uint, string)>()), Is.EqualTo(100));
    }
    [Test] public void AmbiguousAndPartialLabelsNeverSelectDifferentPolicies()
    {
        var r = new Recommendation(Guid.NewGuid(), "Active", null, "", "", "", RecoConfidence.Strong);
        Assert.That(r.ResolveTarget(false, 0, 0, 0, new[] { (1u, "Inactive"), (2u, "Active cooling") }), Is.Null);
        Assert.That(r.ResolveTarget(false, 0, 0, 0, new[] { (1u, "Active"), (2u, "ACTIVE") }), Is.Null);
        Assert.That(r.ResolveTarget(false, 0, 0, 0, new[] { (1u, "Passive"), (2u, "Active") }), Is.EqualTo(2));
    }
}
