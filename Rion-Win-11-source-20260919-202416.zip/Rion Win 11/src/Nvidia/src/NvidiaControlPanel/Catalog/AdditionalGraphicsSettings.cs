namespace Nvidia.Catalog;

/// <summary>Public NvApiDriverSettings.h controls. IDs and named values checked 2026-09-19.</summary>
internal static class AdditionalGraphicsSettings
{
    internal sealed record Entry(SettingDef Definition, uint DriverId, IReadOnlyDictionary<string, uint> Values);
    private static Entry Choice(int id, uint driverId, string name, string group, string symbol,
        string description, params (string Key, string Label, uint Value)[] values) => new(new SettingDef
        {
            Id = (SettingId)id, Tab = SettingTab.Performance, Name = name, Group = group,
            Control = ControlKind.Choice, Description = description,
            NvapiInterface = "NvAPI_DRS_SetSetting (" + symbol + "_ID)",
            Options = values.Select(v => new SettingOption(v.Key, v.Label)).ToArray(),
        }, driverId, values.ToDictionary(v => v.Key, v => v.Value));

    // Stable app IDs: never renumber. These controls intentionally have no automatic profile recommendations.
    internal static readonly Entry[] Entries =
    {
        Choice(428, 0x10115C8C, "Battery Boost frame limit", "Power management", "BATTERY_BOOST_APP_FPS",
            "Frame-rate target for Battery Boost on compatible notebooks. Lower targets can reduce power use while limiting smoothness. Zero removes this override; it does not enable Battery Boost. Desktop GPUs may not use this setting.",
            ("off", "No override", 0), ("30", "30 FPS", 30), ("40", "40 FPS", 40), ("60", "60 FPS", 60)),
        Choice(429, 0x10115C8D, "External quiet mode", "Power management", "EXTERNAL_QUIET_MODE",
            "Driver quiet-mode request on compatible systems. Firmware and driver support determine its effect; this is not a fan-speed or wattage control. It may reduce performance to prioritize quieter operation.",
            ("off", "Off", 0), ("on", "On", 1)),
        Choice(400, 0x00667329, "Ambient occlusion", "Image quality", "AO_MODE",
            "Driver ambient occlusion for compatible games. Application support is required.",
            ("off", "Off", 0), ("low", "Low", 1), ("medium", "Medium", 2), ("high", "High", 3)),
        Choice(401, 0x10FC2D9C, "Transparency multisampling", "Image quality", "AA_MODE_ALPHATOCOVERAGE",
            "Antialias alpha-tested edges in compatible applications.", ("off", "Off", 0), ("on", "On", 4)),
        Choice(402, 0x107D639D, "Antialiasing gamma correction", "Image quality", "AA_MODE_GAMMACORRECTION",
            "Gamma correction for antialiasing.", ("off", "Off", 0), ("fos", "When supported by the sampling mode", 1), ("on", "Always", 2)),
        Choice(403, 0x10D48A85, "Transparency supersampling", "Image quality", "AA_MODE_REPLAY",
            "Transparency antialiasing in compatible applications.", ("off", "Off", 0), ("transparency", "Transparency supersampling", 0x23)),
        Choice(404, 0x0098C1AC, "MFAA", "Image quality", "MAXWELL_B_SAMPLE_INTERLEAVE",
            "Multi-frame sampled antialiasing on supported GPUs and applications.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(405, 0x00E73211, "Anisotropic sample optimization", "Texture filtering", "PS_TEXFILTER_ANISO_OPTS2",
            "Allow anisotropic sample optimizations.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(406, 0x0084CD70, "Anisotropic filter optimization", "Texture filtering", "PS_TEXFILTER_BILINEAR_IN_ANISO",
            "Allow bilinear filtering optimizations within anisotropic filtering.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(407, 0x002ECAF2, "Trilinear optimization", "Texture filtering", "PS_TEXFILTER_DISABLE_TRILIN_SLOPE",
            "Allow trilinear filtering optimizations.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(408, 0x0019BB68, "Negative LOD bias", "Texture filtering", "PS_TEXFILTER_NO_NEG_LODBIAS",
            "Allow or clamp negative texture level-of-detail bias.", ("allow", "Allow", 0), ("clamp", "Clamp", 1)),
        Choice(409, 0x00638E8F, "Driver-controlled LOD bias", "Texture filtering", "AUTO_LODBIASADJUST",
            "Let the driver adjust texture level-of-detail bias.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(410, 0x0064B541, "Preferred refresh rate", "Sync & frame rate", "REFRESH_RATE_OVERRIDE",
            "Prefer the application's selected refresh rate or the highest available rate.",
            ("app", "Application-controlled", 0), ("highest", "Highest available", 1)),
        Choice(411, 0x10111133, "VR pre-rendered frames", "Sync & frame rate", "VRPRERENDERLIMIT",
            "Maximum pre-rendered frames for virtual reality. Zero leaves control to the application.",
            ("app", "Application-controlled", 0), ("1", "1", 1), ("2", "2", 2), ("3", "3", 3), ("4", "4", 4)),
        Choice(412, 0x20D690F8, "Vulkan/OpenGL present method", "Driver behaviour", "OGL_CPL_PREFER_DXPRESENT",
            "Choose automatic presentation, native presentation, or layered DXGI presentation.",
            ("auto", "Auto", 2), ("native", "Prefer native", 0), ("dxgi", "Prefer layered DXGI", 1)),
        Choice(413, 0x2072C5A3, "OpenGL GDI compatibility", "Driver behaviour", "OGL_CPL_GDI_COMPATIBILITY",
            "Select the driver's GDI compatibility preference for OpenGL.",
            ("auto", "Auto", 2), ("off", "Prefer disabled", 0), ("on", "Prefer enabled", 1)),
        Choice(414, 0x2097C2F6, "OpenGL deep colour", "Driver behaviour", "OGL_DEEP_COLOR_SCANOUT",
            "Enable deep-colour scanout for compatible 3D applications.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(415, 0x1094F16F, "PhysX visual indicator", "Indicators", "PHYSXINDICATOR",
            "Show the PhysX indicator in supported applications.", ("off", "Off", 0x34534064), ("on", "On", 0x24545582)),
        Choice(416, 0x1068FB9C, "FXAA visual indicator", "Indicators", "FXAA_INDICATOR_ENABLE",
            "Show the driver FXAA indicator.", ("off", "Off", 0), ("on", "On", 1)),
        Choice(417, 0x005A375C, "Adaptive V-Sync tear control", "Sync & frame rate", "VSYNCTEARCONTROL",
            "Enable adaptive tear control alongside Vertical sync On; this is a separate driver setting.",
            ("off", "Disabled", 0x96861077), ("on", "Enabled", 0x99941284)),
        Choice(418, 0x10E41DF4, "DLAA override", "DLSS overrides", "NGX_DLAA_OVERRIDE",
            "Request DLAA in compatible applications. GPU, driver and game support are required; restart the game after changing overrides.",
            ("default", "Application default", 0), ("on", "DLAA", 1)),
        Choice(419, 0x10308298, "DLSS frame generation mode", "DLSS overrides", "NGX_DLSSG_MODE",
            "Global frame-generation override for compatible applications. This cannot add frame generation to unsupported games or GPUs.",
            ("default", "No override", 0), ("off", "Off", 1), ("on", "On", 2), ("auto", "Auto", 3), ("dynamic", "Dynamic", 4)),
        Choice(420, 0x10E41E03, "DLSS frame generation override", "DLSS overrides", "NGX_DLSS_FG_OVERRIDE",
            "Enable the frame-generation override for supported applications. Restart the game after changing overrides.",
            ("off", "Off", 0), ("on", "On", 1)),
        Choice(421, 0x10E41DF1, "DLSS frame generation preset", "DLSS overrides", "NGX_DLSS_FG_OVERRIDE_RENDER_PRESET_SELECTION",
            "Select a driver model preset for compatible applications. Available presets depend on the installed driver and GPU.", Presets(26, true)),
        Choice(422, 0x10E41E02, "DLSS ray reconstruction override", "DLSS overrides", "NGX_DLSS_RR_OVERRIDE",
            "Enable ray-reconstruction overrides for compatible games. Requires application and GPU support.",
            ("off", "Off", 0), ("on", "On", 1)),
        Choice(423, 0x10BD9423, "DLSS ray reconstruction quality", "DLSS overrides", "NGX_DLSS_RR_MODE",
            "Choose the ray-reconstruction quality mode for compatible applications; custom retains the driver's existing custom ratio.", QualityModes()),
        Choice(424, 0x10E41DF7, "DLSS ray reconstruction preset", "DLSS overrides", "NGX_DLSS_RR_OVERRIDE_RENDER_PRESET_SELECTION",
            "Select a driver model preset for compatible applications. Available presets depend on the installed driver and GPU.", Presets(15, false)),
        Choice(425, 0x10E41E01, "DLSS super resolution override", "DLSS overrides", "NGX_DLSS_SR_OVERRIDE",
            "Enable super-resolution overrides for compatible applications. Restart the game after changing overrides.",
            ("off", "Off", 0), ("on", "On", 1)),
        Choice(426, 0x10AFB768, "DLSS super resolution quality", "DLSS overrides", "NGX_DLSS_SR_MODE",
            "Choose the super-resolution quality mode for compatible applications; custom retains the driver's existing custom ratio.", QualityModes()),
        Choice(427, 0x10E41DF3, "DLSS super resolution preset", "DLSS overrides", "NGX_DLSS_SR_OVERRIDE_RENDER_PRESET_SELECTION",
            "Select a driver model preset for compatible applications. Available presets depend on the installed driver and GPU.", Presets(15, false)),
    };
    private static (string, string, uint)[] QualityModes() => new[]
    {
        ("performance", "Performance", 0u), ("balanced", "Balanced", 1u), ("quality", "Quality", 2u),
        ("app", "Application-controlled", 3u), ("dlaa", "DLAA", 4u), ("ultra", "Ultra performance", 5u), ("custom", "Existing custom ratio", 6u),
    };
    private static (string, string, uint)[] Presets(int count, bool includeDefault)
    {
        var options = new List<(string, string, uint)> { ("off", "No preset override", 0) };
        for (uint value = 1; value <= count; value++)
        {
            string name = ((char)('A' + value - 1)).ToString();
            options.Add((name, "Preset " + name, value));
        }
        if (includeDefault) options.Add(("default", "Driver default", 0x00fffffe));
        options.Add(("latest", "Latest", 0x00ffffff));
        return options.ToArray();
    }
    private static readonly Dictionary<SettingId, Entry> ById = Entries.ToDictionary(e => e.Definition.Id);
    internal static Entry? Find(SettingId id) => ById.GetValueOrDefault(id);
}
