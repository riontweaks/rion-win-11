namespace Nvidia.Catalog;

public enum SettingTab { System, Display, Performance, Overclocking }

public enum ControlKind
{
    /// <summary>Enabled / disabled — rendered as a toggle switch.</summary>
    Toggle,
    /// <summary>One of a fixed option list — rendered as a dropdown.</summary>
    Choice,
    /// <summary>A number in a range — rendered as a slider with a value readout.</summary>
    Slider,
    /// <summary>Detected value shown as text without an editable control.</summary>
    ReadOnly,
}

public sealed record SettingOption(string Value, string Label)
{
    /// <summary>So a ComboBox that somehow renders the item directly (no DisplayMemberPath /
    /// template applied yet) still shows the friendly label, never "SettingOption { Value = … }".</summary>
    public override string ToString() => Label;
}

/// <summary>
/// One row in the catalog: what it is, how to render it, and which NVAPI interface backs it.
/// Declarative on purpose — the shell builds the whole UI from this list, and the native
/// provider wires <see cref="NvapiInterface"/> reads/writes without touching the view.
/// </summary>
public sealed record SettingDef
{
    public required SettingId Id { get; init; }
    public required SettingTab Tab { get; init; }
    public required string Group { get; init; }          // sub-header within the tab
    public required string Name { get; init; }
    public required string Description { get; init; }
    public required ControlKind Control { get; init; }

    /// <summary>Options for <see cref="ControlKind.Choice"/>. Empty otherwise.</summary>
    public IReadOnlyList<SettingOption> Options { get; init; } = Array.Empty<SettingOption>();

    // slider metadata (fallbacks; a live SettingValue may override min/max/step)
    public double Min { get; init; }
    public double Max { get; init; }
    public double Step { get; init; } = 1;
    public string Unit { get; init; } = "";

    /// <summary>NVAPI interface + accessor that backs this row (documentation only until the
    /// native provider is wired).</summary>
    public required string NvapiInterface { get; init; }

    /// <summary>
    /// False for rows the app will read but deliberately never write (e.g. color depth).
    /// The UI uses this to decide whether to render an Apply affordance at all.
    /// </summary>
    public bool Writable { get; init; } = true;

    public static readonly IReadOnlyList<SettingOption> OnOff = new SettingOption[]
    {
        new("on", "Enabled"),
        new("off", "Disabled"),
    };
}
