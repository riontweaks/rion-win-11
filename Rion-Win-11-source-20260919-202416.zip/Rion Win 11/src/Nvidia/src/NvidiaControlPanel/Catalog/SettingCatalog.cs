namespace Nvidia.Catalog;

/// <summary>
/// The hand-maintained map of every setting the app surfaces, plus the curated
/// recommendation table. Mirrors <c>Aldx.Catalog.SettingCatalog</c>'s shape exactly: an
/// entry earns its place only if the value is backed by NVIDIA guidance or clear consensus
/// for that profile.
///
/// Overclocking has no <see cref="SettingDef"/> rows here, same as the AMD side — that tab is
/// driven entirely by <c>TuningVm</c>/<c>GpuTuningInfo</c> instead of the generic setting/
/// recommendation mechanism, since power limit / clock offsets / fan curve aren't simple
/// independent toggles.
/// </summary>
public static class SettingCatalog
{
    private const string NvapiDoc = "NVIDIA — NVAPI Driver Settings (DRS) reference";
    private const string NvidiaGaming = "NVIDIA — Reflex / GeForce gaming guidance";
    private const string Consensus = "Long-standing community consensus";

    // ============================================================= settings
    private static readonly SettingDef[] Defs =
    {
        // ---------------------------------------------------- Display
        new()
        {
            Id = SettingId.Display_DynamicRange, Tab = SettingTab.Display, Group = "Colour",
            Name = "Output dynamic range", Control = ControlKind.Choice,
            Description = "Full or limited output levels. Match the display's input range.",
            Options = new SettingOption[] { new("full", "Full"), new("limited", "Limited") },
            NvapiInterface = "NvAPI_Disp_ColorControl",
        },
        new()
        {
            Id = SettingId.Display_GSync, Tab = SettingTab.Display, Group = "Adaptive sync",
            Name = "NVIDIA G-SYNC", Control = ControlKind.Choice, Options = new SettingOption[] { new("off", "Disabled"), new("fullscreen", "Full screen"), new("windowed", "Windowed and full screen") },
            Description = "Variable refresh rate — the display refreshes in step with the GPU to remove tearing without the latency of V-Sync.",
            NvapiInterface = "NvAPI_DRS_SetSetting (VRR_MODE_ID)",
        },
        new()
        {
            Id = SettingId.Display_Dsr, Tab = SettingTab.Display, Group = "Scaling",
            Name = "Dynamic Super Resolution (DSR)", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Renders games at a higher-than-native resolution and downscales to the panel for extra sharpness.",
            NvapiInterface = "NvAPI_DRS_SetSetting (DSR_ENABLE)",
        },
        new()
        {
            Id = SettingId.Display_DsrSmoothness, Tab = SettingTab.Display, Group = "Scaling",
            Name = "DSR smoothness", Control = ControlKind.Slider, Min = 0, Max = 100, Unit = "%",
            Description = "Blends in a slight softening filter to hide upscaling artifacts. Lower is sharper.",
            NvapiInterface = "NvAPI_DRS_SetSetting (DSR_SMOOTHNESS)",
        },
        new()
        {
            Id = SettingId.Display_GpuScaling, Tab = SettingTab.Display, Group = "Scaling",
            Name = "GPU scaling", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "The GPU (not the monitor) scales non-native resolutions. Required for the scaling-mode and integer-scaling options.",
            NvapiInterface = "NvAPI_DISP_SetDisplayConfig",
        },
        new()
        {
            Id = SettingId.Display_ScalingMode, Tab = SettingTab.Display, Group = "Scaling",
            Name = "Scaling mode", Control = ControlKind.Choice,
            Description = "How a non-native resolution fills the panel.",
            Options = new SettingOption[]
            {
                new("aspect", "Aspect ratio"),
                new("full", "Full-screen"),
                new("center", "No scaling"), new("integer", "Integer scaling"),
            },
            NvapiInterface = "NvAPI_DISP_SetDisplayConfig",
        },
        new()
        {
            Id = SettingId.Display_IntegerScaling, Tab = SettingTab.Display, Group = "Scaling",
            Name = "Integer scaling", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Scales by whole multiples so low-res / pixel-art content stays crisp instead of blurred.",
            NvapiInterface = "NvAPI_DISP_SetDisplayConfig",
        },
        new()
        {
            Id = SettingId.Display_ColorDepth, Tab = SettingTab.Display, Group = "Colour",
            Name = "Colour depth", Control = ControlKind.Choice,
            Description = "Bits per channel sent to the display. Changes require confirmation within 15 seconds.",
            Options = new SettingOption[] { new("8", "8 bpc"), new("10", "10 bpc"), new("12", "12 bpc") },
            NvapiInterface = "NvAPI_Disp_ColorControl",
        },
        new()
        {
            Id = SettingId.Display_ColorFormat, Tab = SettingTab.Display, Group = "Colour",
            Name = "Colour format", Control = ControlKind.Choice,
            Description = "Output colour encoding. Changes require confirmation within 15 seconds.",
            Options = new SettingOption[] { new("rgb", "RGB"), new("ycbcr444", "YCbCr444"), new("ycbcr422", "YCbCr422"), new("ycbcr420", "YCbCr420") },
            NvapiInterface = "NvAPI_Disp_ColorControl",
        },
        new()
        {
            Id = SettingId.Display_Hdcp, Tab = SettingTab.Display, Group = "Colour",
            Name = "GPU HDCP capability", Control = ControlKind.ReadOnly,
            Description = "GPU HDCP hardware/key support. This is not the current monitor's HDCP version or active content-protection status. Read-only.",
            NvapiInterface = "NvAPI_GPU_GetHDCPSupportStatus (read-only)",
        },

        // ---------------------------------------------------- Performance / 3D
        new()
        {
            Id = SettingId.Perf_LowLatencyMode, Tab = SettingTab.Performance, Group = "Latency",
            Name = "Pre-rendered frame queue", Control = ControlKind.Choice,
            Description = "Choose application-controlled queuing or a one-frame queue. NVIDIA Ultra Low Latency and in-game Reflex use different APIs.",
            Options = new SettingOption[] { new("off", "Application-controlled"), new("on", "One frame") },
            NvapiInterface = "NvAPI_DRS_SetSetting (PRERENDERLIMIT_ID)",
        },
        new()
        {
            Id = SettingId.Perf_ReflexBoost, Tab = SettingTab.Performance, Group = "Latency",
            Name = "Reflex + Boost (in game)", Control = ControlKind.ReadOnly, Writable = false, Options = SettingDef.OnOff,
            Description = "Enable Reflex and Boost in supported games. This is not a global driver switch.",
            NvapiInterface = "In-game Reflex integration; no verified global DRS mapping",
        },
        new()
        {
            Id = SettingId.Perf_ImageScaling, Tab = SettingTab.Performance, Group = "Upscaling & sharpening",
            Name = "NVIDIA Image Scaling", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Renders below native resolution and upscales with a sharpening filter — a driver-level performance boost for any game.",
            NvapiInterface = "NvAPI_DRS_SetSetting (NIS_ENABLE)",
        },
        new()
        {
            Id = SettingId.Perf_ImageScalingSharpness, Tab = SettingTab.Performance, Group = "Upscaling & sharpening",
            Name = "Sharpening", Control = ControlKind.Slider, Min = 0, Max = 100, Unit = "%",
            Description = "How aggressively NVIDIA Image Scaling sharpens the upscaled image.",
            NvapiInterface = "NvAPI_DRS_SetSetting (NIS_SHARPNESS)",
        },
        new()
        {
            Id = SettingId.Perf_VerticalSync, Tab = SettingTab.Performance, Group = "Sync & frame rate",
            Name = "Vertical sync", Control = ControlKind.Choice,
            Description = "Fast Sync removes tearing above your refresh rate without V-Sync's added latency.",
            Options = new SettingOption[]
            {
                new("app", "Application-controlled"), new("off", "Off"), new("on", "On"), new("fast", "Fast"), new("half", "Half refresh rate"),
            },
            NvapiInterface = "NvAPI_DRS_SetSetting (VSYNCMODE)",
        },
        new()
        {
            Id = SettingId.Perf_FrameRateLimiter, Tab = SettingTab.Performance, Group = "Sync & frame rate",
            Name = "Max frame rate", Control = ControlKind.Slider, Min = 0, Max = 360, Unit = "FPS",
            Description = "Caps the frame rate. 0 means uncapped.",
            NvapiInterface = "NvAPI_DRS_SetSetting (FRL_FPS)",
        },
        new()
        {
            Id = SettingId.Perf_AntiAliasingMode, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Antialiasing mode", Control = ControlKind.Choice,
            Description = "Whether the driver overrides a game's own antialiasing choice.",
            Options = new SettingOption[] { new("app", "Application-controlled"), new("override", "Override"), new("enhance", "Enhance") },
            NvapiInterface = "NvAPI_DRS_SetSetting (ANTIALIASING_MODE)",
        },
        new()
        {
            Id = SettingId.Perf_AntiAliasingLevel, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Antialiasing level", Control = ControlKind.Choice,
            Description = "Multisampling amount when the driver controls antialiasing.",
            Options = new SettingOption[] { new("none", "None"), new("2x", "2x diagonal"), new("4x", "4x"), new("8x", "8x") },
            NvapiInterface = "NvAPI_DRS_SetSetting (ANTIALIASING_LEVEL)",
        },
        new()
        {
            Id = SettingId.Perf_AntiAliasingMethod, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "FXAA", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "A cheap post-process antialiasing pass, on top of whatever the game already does.",
            NvapiInterface = "NvAPI_DRS_SetSetting (FXAA_ENABLE)",
        },
        new()
        {
            Id = SettingId.Perf_AnisotropicFiltering, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anisotropic filtering", Control = ControlKind.Choice, Options = new SettingOption[] { new("app", "Application-controlled"), new("override", "Override") },
            Description = "Sharpens textures viewed at oblique angles (floors, roads).",
            NvapiInterface = "NvAPI_DRS_SetSetting (ANISO_MODE)",
        },
        new()
        {
            Id = SettingId.Perf_AnisotropicLevel, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anisotropic filtering level", Control = ControlKind.Choice,
            Description = "Maximum anisotropic samples when the driver controls filtering.",
            Options = new SettingOption[] { new("app", "Point filtering"), new("linear", "Linear filtering"), new("2x", "2x"), new("4x", "4x"), new("8x", "8x"), new("16x", "16x") },
            NvapiInterface = "NvAPI_DRS_SetSetting (ANISO_LEVEL)",
        },
        new()
        {
            Id = SettingId.Perf_TextureFilteringQuality, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Texture filtering quality", Control = ControlKind.Choice,
            Description = "Trades filtering precision for GPU headroom.",
            Options = new SettingOption[]
            {
                new("high_performance", "High performance"), new("performance", "Performance"),
                new("quality", "Quality"), new("high_quality", "High quality"),
            },
            NvapiInterface = "NvAPI_DRS_SetSetting (QUALITY_ENHANCEMENTS)",
        },
        new()
        {
            Id = SettingId.Perf_ThreadedOptimization, Tab = SettingTab.Performance, Group = "Driver behaviour",
            Name = "Threaded optimization", Control = ControlKind.Choice,
            Description = "Lets the driver spread its own work across CPU threads.",
            Options = new SettingOption[] { new("auto", "Auto"), new("on", "On"), new("off", "Off") },
            NvapiInterface = "NvAPI_DRS_SetSetting (OGL_THREAD_CONTROL)",
        },
        new()
        {
            Id = SettingId.Perf_TripleBuffering, Tab = SettingTab.Performance, Group = "Driver behaviour",
            Name = "OpenGL triple buffering", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Smooths frame pacing in OpenGL titles when V-Sync is on, at the cost of a little latency.",
            NvapiInterface = "NvAPI_DRS_SetSetting (OGL_TRIPLE_BUFFER)",
        },
        new()
        {
            Id = SettingId.Perf_ShaderCache, Tab = SettingTab.Performance, Group = "Driver behaviour",
            Name = "Shader cache", Control = ControlKind.Choice,
            Description = "Caches compiled shaders on disk so games stop re-compiling them every launch.",
            Options = new SettingOption[] { new("off", "Off"), new("on", "On") },
            NvapiInterface = "NvAPI_DRS_SetSetting (PS_SHADERDISKCACHE)",
        },
        new()
        {
            Id = SettingId.Perf_PowerManagementMode, Tab = SettingTab.Performance, Group = "Driver behaviour",
            Name = "Power management mode", Control = ControlKind.Choice,
            Description = "Whether the driver favours ramping clocks up early for consistent frame times, or saving power.",
            Options = new SettingOption[]
            {
                new("optimal", "Optimal power"), new("adaptive", "Adaptive"), new("max", "Prefer maximum performance"),
                new("driver", "Driver-controlled"), new("minimum", "Prefer minimum power"), new("consistent", "Prefer consistent performance"),
            },
            NvapiInterface = "NvAPI_DRS_SetSetting (PREFERRED_PSTATE)",
        },
    };

    // ============================================================= recommendations
    private static readonly Recommendation[] Recos =
    {
        // -------- Esports (latency first) ------------------------------
        new(SettingId.Perf_LowLatencyMode, RecoProfile.Esports, "ultra",
            "The fastest input-to-photon path NVIDIA offers. The FPS cost is small on a GPU with headroom.",
            NvidiaGaming, RecoConfidence.Strong),
        new(SettingId.Perf_ReflexBoost, RecoProfile.Esports, "on",
            "Keeps clocks up during CPU-bound stretches (menus, low-GPU-load moments) instead of ramping late.",
            NvidiaGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_VerticalSync, RecoProfile.Esports, "off",
            "Any sync mode adds a frame of latency somewhere. Pair with a frame-rate cap instead.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_FrameRateLimiter, RecoProfile.Esports, "0",
            "Leave uncapped for a competitive title unless you specifically need to stay under your GSYNC ceiling — set that manually if so.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_ImageScaling, RecoProfile.Esports, "off",
            "Upscaling adds a small amount of latency and a softer image. Competitive titles usually run comfortably native.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_TextureFilteringQuality, RecoProfile.Esports, "high_performance",
            "Frees a sliver of GPU time; invisible in fast motion.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_AntiAliasingMethod, RecoProfile.Esports, "off",
            "Post-process AA blurs the image, including distant enemies. Leave AA to the game's own setting.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Display_GSync, RecoProfile.Esports, "fullscreen",
            "Tear-free inside the range with none of V-Sync's added latency. Pair with a frame-rate cap below refresh.",
            NvidiaGaming, RecoConfidence.Strong),

        // -------- Quality (fidelity first) ------------------------------
        new(SettingId.Perf_ImageScaling, RecoProfile.Quality, "off",
            "Prefer a game's own DLSS/TAA upscaler over the driver's spatial-only scaler when image quality is the priority.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_AnisotropicFiltering, RecoProfile.Quality, "override",
            "Non-negotiable for a clean image; near-zero cost.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_AnisotropicLevel, RecoProfile.Quality, "16x",
            "Maximum sharpness for oblique textures.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_TextureFilteringQuality, RecoProfile.Quality, "high_quality",
            "Keeps full trilinear/aniso precision — no shimmering on high-contrast textures.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_PowerManagementMode, RecoProfile.Quality, "max",
            "Keeps clocks consistently high instead of ramping per-frame, which helps frame-time stability.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Display_ColorDepth, RecoProfile.Quality, "10",
            "10 bpc for HDR and gradient-heavy content, provided the link has bandwidth for it at your refresh rate.",
            Consensus, RecoConfidence.Moderate),

        // -------- Efficiency (quiet / cool / laptop) --------------------
        new(SettingId.Perf_FrameRateLimiter, RecoProfile.Efficiency, "60",
            "A global cap stops the GPU rendering hundreds of pointless frames in menus and light scenes.",
            NvidiaGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_ImageScaling, RecoProfile.Efficiency, "on",
            "Rendering below native and upscaling is a large perf-per-watt win on a thermally limited laptop.",
            NvidiaGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_PowerManagementMode, RecoProfile.Efficiency, "optimal",
            "Lets the driver ramp clocks down between frames instead of holding them high.",
            NvidiaGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_LowLatencyMode, RecoProfile.Efficiency, "off",
            "Ultra/On can hold clocks higher to shrink the render queue — not what you want when minimising power.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_ReflexBoost, RecoProfile.Efficiency, "off",
            "Boost exists specifically to keep clocks from idling down — the opposite of a power-saving goal.",
            Consensus, RecoConfidence.Moderate),
    };

    private static readonly Dictionary<(SettingId, RecoProfile), Recommendation> RecoByKey =
        Recos.ToDictionary(r => (r.Setting, r.Profile));

    public static IEnumerable<SettingDef> ForTab(SettingTab tab) => Defs.Concat(AdditionalGraphicsSettings.Entries.Select(e => e.Definition)).Where(d => d.Tab == tab);

    public static Recommendation? For(SettingId id, RecoProfile profile) =>
        (int)id >= 200 && (int)id < 300 ? ProfileCatalog.Get(id, profile) : RecoByKey.TryGetValue((id, profile), out var r) ? r : null;

    public static int RecommendationCount => Recos.Length;
}





