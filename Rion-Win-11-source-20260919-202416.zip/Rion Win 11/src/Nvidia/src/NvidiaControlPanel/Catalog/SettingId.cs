namespace Nvidia.Catalog;

/// <summary>
/// Stable identifier for every setting the app knows about. The name is the contract
/// between <see cref="SettingCatalog"/>, the recommendation table, and the NVAPI provider —
/// never renumber, only append.
///
/// No 1:1 mapping to every AMD/ADLX setting exists — Radeon Chill (dynamic FPS cap tied to
/// motion) and Radeon Boost (dynamic resolution under motion) have no NVIDIA driver-level
/// equivalent and are deliberately omitted rather than forced onto an unrelated feature.
/// </summary>
public enum SettingId
{
    // ---- Display ------------------------------------------------------------
    Display_GSync = 100,
    Display_Dsr,
    Display_DsrSmoothness,
    Display_GpuScaling,
    Display_ScalingMode,
    Display_IntegerScaling,
    Display_ColorDepth,
    Display_ColorFormat,
    Display_Hdcp,
    Display_DynamicRange,

    // ---- Performance / 3D settings (NVAPI Driver Settings / DRS) -------------
    Perf_LowLatencyMode = 200,
    Perf_ReflexBoost,
    Perf_ImageScaling,
    Perf_ImageScalingSharpness,
    Perf_VerticalSync,
    Perf_FrameRateLimiter,
    Perf_AntiAliasingMode,
    Perf_AntiAliasingLevel,
    Perf_AntiAliasingMethod,
    Perf_AnisotropicFiltering,
    Perf_AnisotropicLevel,
    Perf_TextureFilteringQuality,
    Perf_ThreadedOptimization,
    Perf_TripleBuffering,
    Perf_ShaderCache,
    Perf_PowerManagementMode,

    // ---- Overclocking / GPU Tuning (undocumented NVAPI tuning interfaces) ---
    Oc_TuningMode = 300,
    Oc_PowerLimitPercent,
    Oc_TempLimitC,
    Oc_CoreClockOffsetMhz,
    Oc_MemClockOffsetMhz,
    // No Oc_FanZeroRpm: NVIDIA has no explicit "Zero RPM" toggle — fan-stop is just what the
    // fan curve does when its lowest point is 0%, so there's no separate id for it here.
    Oc_FanTargetSpeedPercent,
    Oc_FanMaxSpeedPercent,
    Oc_FanTargetTempC,
    Oc_FanMaxTempC,
}
