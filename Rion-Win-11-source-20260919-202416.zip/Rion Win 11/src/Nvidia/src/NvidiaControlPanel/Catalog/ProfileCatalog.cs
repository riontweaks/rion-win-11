namespace Nvidia.Catalog;

/// <summary>App-curated global graphics presets, not vendor-certified performance guarantees.</summary>
public static class ProfileCatalog
{
    public static string Description(RecoProfile profile) => profile switch
    {
        RecoProfile.Esports => "Recommended starting point for competitive play: reduce driver queueing and avoid extra image processing. Prefer in-game Reflex where available; measure results per game.",
        RecoProfile.Quality => "Prioritize texture clarity while leaving anti-aliasing to the game. Higher image quality can reduce frame rate.",
        RecoProfile.Efficiency => "Reduce rendering work and power use with a frame-rate target. Adjust the target for your display and games after applying.",
        _ => "A general-purpose graphics baseline with application-controlled anti-aliasing and normal power behavior."
    };
    public static IReadOnlyDictionary<SettingId, string> Values(RecoProfile profile)
    {
        bool esports = profile == RecoProfile.Esports, quality = profile == RecoProfile.Quality, efficiency = profile == RecoProfile.Efficiency;
        return new Dictionary<SettingId, string>
        {
            [SettingId.Perf_LowLatencyMode] = esports ? "on" : "off",
            [SettingId.Perf_FrameRateLimiter] = efficiency ? "60" : "0",
            [SettingId.Perf_VerticalSync] = "off",
            [SettingId.Perf_AntiAliasingMode] = "app",
            [SettingId.Perf_AntiAliasingMethod] = "off",
            [SettingId.Perf_AnisotropicFiltering] = quality ? "override" : "app",
            [SettingId.Perf_AnisotropicLevel] = "16x",
            [SettingId.Perf_ThreadedOptimization] = "auto",
            [SettingId.Perf_TripleBuffering] = "off",
            [SettingId.Perf_ShaderCache] = "on",
            [SettingId.Perf_PowerManagementMode] = esports ? "max" : "optimal"
        };
    }
    public static Recommendation? Get(SettingId id, RecoProfile profile) => Values(profile).TryGetValue(id, out var value)
        ? new(id, profile, value, Description(profile), "https://www.nvidia.com/content/Control-Panel-Help/vLatest/en-us/mergedProjects/3D%20Settings/Manage_3D_Settings_%28reference%29.htm", RecoConfidence.Moderate) : null;
}
