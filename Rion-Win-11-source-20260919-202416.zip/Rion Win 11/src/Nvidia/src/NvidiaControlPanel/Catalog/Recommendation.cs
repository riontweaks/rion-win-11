namespace Nvidia.Catalog;

public enum RecoConfidence
{
    /// <summary>NVIDIA / first-party guidance or long-standing consensus backs this value.</summary>
    Strong,
    /// <summary>Defensible default for the profile, but a real trade-off — not "always do this".</summary>
    Moderate,
}

/// <summary>
/// A tuning intent. Each profile is just an override map over the base catalog:
/// a setting with no entry for the active profile shows no recommendation.
/// </summary>
public enum RecoProfile
{
    Balanced,
    Esports,
    Quality,
    Efficiency,
}

/// <summary>
/// One curated recommendation. <see cref="Value"/> matches a <see cref="SettingOption.Value"/>
/// for Choice/Toggle rows ("on" / "off" for toggles), or is a number formatted as a string
/// for Slider rows.
/// </summary>
public sealed record Recommendation(
    SettingId Setting,
    RecoProfile Profile,
    string Value,
    string Rationale,
    string Source,
    RecoConfidence Confidence);
