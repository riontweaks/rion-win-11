using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Nvidia.ViewModels;

namespace Nvidia.Controls;

/// <summary>Small dial: a 270° ring that fills with <see cref="MetricsVm.Gauge.Fraction"/>.</summary>
public partial class Gauge : UserControl
{
    private MetricsVm.Gauge? _model;

    public Gauge()
    {
        InitializeComponent();
        DataContextChanged += (_, _) => Bind(DataContext as MetricsVm.Gauge);
        Loaded += (_, _) => Redraw();
    }

    private void Bind(MetricsVm.Gauge? g)
    {
        if (_model != null) _model.PropertyChanged -= OnModelChanged;
        _model = g;
        if (_model != null) _model.PropertyChanged += OnModelChanged;
        Refresh();
    }

    private void OnModelChanged(object? sender, PropertyChangedEventArgs e) => Refresh();

    private void Refresh()
    {
        if (_model is null) return;
        LabelText.Text = _model.Label;
        ValueText.Text = _model.Value;
        UnitText.Text = _model.Unit;
        Redraw();
    }

    private void Redraw()
    {
        double frac = Math.Clamp(_model?.Fraction ?? 0, 0, 1);
        const double start = 135, sweepMax = 270;
        double sweep = sweepMax * frac;

        double r = 13, cx = 15, cy = 15;
        Point P(double deg)
        {
            double a = deg * Math.PI / 180.0;
            return new Point(cx + r * Math.Cos(a), cy + r * Math.Sin(a));
        }

        if (frac <= 0.001) { Arc.Data = Geometry.Empty; return; }

        var fig = new PathFigure { StartPoint = P(start), IsClosed = false };
        fig.Segments.Add(new ArcSegment(P(start + sweep), new Size(r, r), 0, sweep > 180,
            SweepDirection.Clockwise, true));
        Arc.Data = new PathGeometry(new[] { fig });
    }
}
