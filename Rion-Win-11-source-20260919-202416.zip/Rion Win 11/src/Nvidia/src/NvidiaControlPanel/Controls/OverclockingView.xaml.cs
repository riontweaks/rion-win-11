using System.Windows.Controls;

namespace Nvidia.Controls;

public partial class OverclockingView : UserControl
{
    public OverclockingView() => InitializeComponent();
    private void OpenNvidia_Click(object sender, System.Windows.RoutedEventArgs e)
    {
        try
        {
            string path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                "NVIDIA Corporation", "NVIDIA app", "CEF", "NVIDIA app.exe");
            if (!System.IO.File.Exists(path)) { LaunchStatus.Text = "NVIDIA app is not installed in its standard location. Install it using the driver package, or open your installed copy manually."; return; }
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(path) { UseShellExecute = true });
            LaunchStatus.Text = "Open System → Performance in NVIDIA app.";
        }
        catch (Exception ex) { LaunchStatus.Text = "Could not open NVIDIA app: " + ex.Message; }
    }
}
