using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Nvidia.ViewModels;

namespace Nvidia.Controls;

public partial class FanCurveEditor : UserControl
{
    private FanCurveVm? _vm;
    private readonly List<FanPointVm> _subscribed=new();
    private readonly List<Thumb> _thumbs=new();
    private readonly List<TextBlock> _labels=new();
    private readonly Polyline _line=new(){StrokeThickness=2};
    private readonly Polygon _fill=new();
    private readonly Line _crossX=new(){StrokeDashArray=new DoubleCollection{3,3}},_crossY=new(){StrokeDashArray=new DoubleCollection{3,3}};
    private int _selected;
    private bool _syncing, _discardEntry;
    private Point _dragOrigin;
    private double _dragTemp,_dragDuty;
    private const double Left=42,Right=16,Top=22,Bottom=26;
    private double PlotWidth=>Math.Max(1,Plot.ActualWidth-Left-Right);
    private double PlotHeight=>Math.Max(1,Plot.ActualHeight-Top-Bottom);
    public FanCurveEditor()
    {
        InitializeComponent();
        _line.Stroke=(Brush)FindResource("Accent");
        _fill.Fill=_line.Stroke;_fill.Opacity=.16;
        _crossX.Stroke=_crossY.Stroke=(Brush)FindResource("TextTertiary");
        _crossX.Opacity=_crossY.Opacity=.5;
        DataContextChanged+=(_,_)=>Bind(DataContext as FanCurveVm);
        Unloaded+=(_,_)=>Bind(null);
        Loaded+=(_,_)=>{if(_vm==null)Bind(DataContext as FanCurveVm);};
    }
    private void Bind(FanCurveVm? vm)
    {
        if(_vm!=null)_vm.Points.CollectionChanged-=PointsChanged;
        foreach(var point in _subscribed)point.PropertyChanged-=PointChanged;
        _subscribed.Clear();_vm=vm;
        if(_vm!=null){_vm.Points.CollectionChanged+=PointsChanged;Subscribe();}
        PointPicker.ItemsSource=_vm?.Points;
        _selected=Math.Clamp(_selected,0,Math.Max(0,(_vm?.Points.Count??0)-1));
        PointPicker.SelectedIndex=_selected;Rebuild();
    }
    private void Subscribe()
    {
        foreach(var point in _subscribed)point.PropertyChanged-=PointChanged;
        _subscribed.Clear();if(_vm==null)return;
        foreach(var point in _vm.Points){point.PropertyChanged+=PointChanged;_subscribed.Add(point);}
    }
    private void PointsChanged(object? sender,NotifyCollectionChangedEventArgs args)
    {Subscribe();_selected=Math.Clamp(_selected,0,Math.Max(0,_vm!.Points.Count-1));PointPicker.SelectedIndex=_selected;Rebuild();}
    private void PointChanged(object? sender,PropertyChangedEventArgs args)=>Redraw();
    private void Plot_SizeChanged(object sender,SizeChangedEventArgs args)=>Rebuild();
    private Point Pixel(double temperature,double duty)=>new(Left+(temperature-_vm!.TempRange.Min)/Math.Max(1,_vm.TempRange.Max-_vm.TempRange.Min)*PlotWidth,Top+(1-duty/100)*PlotHeight);
    private void Rebuild()
    {
        Plot.Children.Clear();_thumbs.Clear();_labels.Clear();
        if(_vm==null||Plot.ActualWidth<80||Plot.ActualHeight<60)return;
        var divider=(Brush)FindResource("Divider");
        for(int percent=0;percent<=100;percent+=25)
        {
            double y=Top+(1-percent/100d)*PlotHeight;
            Plot.Children.Add(new Line{X1=Left,X2=Left+PlotWidth,Y1=y,Y2=y,Stroke=divider});
            Label(percent+"%",0,y-8);
        }
        int divisions=PlotWidth<320?3:5;
        for(int i=0;i<=divisions;i++)
        {
            double x=Left+PlotWidth*i/divisions,temperature=_vm.TempRange.Min+(_vm.TempRange.Max-_vm.TempRange.Min)*i/divisions;
            Plot.Children.Add(new Line{X1=x,X2=x,Y1=Top,Y2=Top+PlotHeight,Stroke=divider});
            Label($"{temperature:0.#}°",x-12,Top+PlotHeight+7);
        }
        Plot.Children.Add(_fill);Plot.Children.Add(_line);Plot.Children.Add(_crossX);Plot.Children.Add(_crossY);
        for(int i=0;i<_vm.Points.Count;i++)
        {
            int index=i;
            var label=new TextBlock{FontSize=11,Foreground=(Brush)FindResource("Text"),Background=(Brush)FindResource("SurfaceSunk"),Padding=new Thickness(3,1,3,1),IsHitTestVisible=false};
            _labels.Add(label);Plot.Children.Add(label);
            var thumb=new Thumb{IsEnabled=_vm.CanEdit,Width=22,Height=22,Focusable=true,Cursor=Cursors.Hand,Template=KnobTemplate()};
            thumb.GotKeyboardFocus+=(_,_)=>Select(index);
            thumb.DragStarted+=(_,_)=>{Select(index);thumb.Focus();_dragOrigin=Mouse.GetPosition(Plot);_dragTemp=_vm.Points[index].TempC;_dragDuty=_vm.Points[index].SpeedPercent;};
            thumb.DragDelta+=(_,_)=>
            {
                if(_vm==null||index>=_vm.Points.Count)return;
                var current=Mouse.GetPosition(Plot);
                _vm.EditPoint(_vm.Points[index],_dragTemp+(current.X-_dragOrigin.X)/PlotWidth*(_vm.TempRange.Max-_vm.TempRange.Min),_dragDuty-(current.Y-_dragOrigin.Y)/PlotHeight*100);
            };
            thumb.KeyDown+=(_,args)=>Nudge(index,args);
            _thumbs.Add(thumb);Plot.Children.Add(thumb);
        }
        Redraw();
    }
    private void Label(string text,double x,double y)
    {
        var label=new TextBlock{Text=text,FontSize=11,Foreground=(Brush)FindResource("TextDim"),IsHitTestVisible=false};Canvas.SetLeft(label,x);Canvas.SetTop(label,y);Plot.Children.Add(label);
    }
    private void Select(int index){_selected=index;PointPicker.SelectedIndex=index;EntryStatus.Text="";Redraw();}
    private void Selection_Changed(object sender,SelectionChangedEventArgs args){if(PointPicker.SelectedIndex>=0){_selected=PointPicker.SelectedIndex;Redraw();}}
    private void Nudge(int index,KeyEventArgs args)
    {
        if(_vm==null||index>=_vm.Points.Count)return;
        double multiplier=(Keyboard.Modifiers&ModifierKeys.Shift)!=0?10:1;
        var p=_vm.Points[index];double t=p.TempC,s=p.SpeedPercent;
        switch(args.Key){case Key.Left:t-=_vm.TemperatureStep*multiplier;break;case Key.Right:t+=_vm.TemperatureStep*multiplier;break;case Key.Up:s+=_vm.DutyStep*multiplier;break;case Key.Down:s-=_vm.DutyStep*multiplier;break;default:return;}
        _vm.EditPoint(p,t,s);args.Handled=true;
    }
    private void Redraw()
    {
        if(_vm==null||_thumbs.Count!=_vm.Points.Count)return;
        PointPicker.IsEnabled=Duty.IsEnabled=_vm.CanEdit;
        if(!_vm.CanEdit){Temperature.IsEnabled=false;Temperature.Text=Duty.Text="";Precision.Text="No curve returned by the backend.";EntryStatus.Text="Refresh the device before editing fan controls.";return;}
        _selected=Math.Clamp(_selected,0,_vm.Points.Count-1);
        var pixels=new PointCollection();
        for(int i=0;i<_vm.Points.Count;i++)
        {
            var p=_vm.Points[i];var pixel=Pixel(p.TempC,p.SpeedPercent);pixels.Add(pixel);
            Canvas.SetLeft(_thumbs[i],pixel.X-11);Canvas.SetTop(_thumbs[i],pixel.Y-11);
            _thumbs[i].ToolTip=$"Point {i+1}: {p.Label}";AutomationProperties.SetName(_thumbs[i],$"Fan point {i+1}: {p.Label}. Use arrow keys to adjust.");
            var label=_labels[i];label.Text=$"{p.TempC:0.#}° · {p.SpeedPercent:0.#}%";label.FontWeight=i==_selected?FontWeights.SemiBold:FontWeights.Normal;
            label.Measure(new Size(double.PositiveInfinity,double.PositiveInfinity));
            double x=Math.Clamp(pixel.X-label.DesiredSize.Width/2,Left,Math.Max(Left,Plot.ActualWidth-label.DesiredSize.Width));
            double y=pixel.Y+(i%2==0?-27:13);y=Math.Clamp(y,0,Math.Max(0,Top+PlotHeight-20));
            Canvas.SetLeft(label,x);Canvas.SetTop(label,y);
        }
        _line.Points=pixels;
        _fill.Points=new PointCollection(pixels){new Point(pixels[^1].X,Top+PlotHeight),new Point(pixels[0].X,Top+PlotHeight)};
        var active=pixels[_selected];_crossX.X1=_crossX.X2=active.X;_crossX.Y1=Top;_crossX.Y2=Top+PlotHeight;_crossY.X1=Left;_crossY.X2=Left+PlotWidth;_crossY.Y1=_crossY.Y2=active.Y;
        var point=_vm.Points[_selected];_syncing=true;
        if(!Temperature.IsKeyboardFocusWithin)Temperature.Text=point.TempC.ToString("0.##",CultureInfo.CurrentCulture);
        if(!Duty.IsKeyboardFocusWithin)Duty.Text=point.SpeedPercent.ToString("0.##",CultureInfo.CurrentCulture);
        Temperature.IsEnabled=_vm.CanEdit&&!point.IsEndpoint;
        Precision.Text=$"Step: {_vm.TemperatureStep:0.##}°C / {_vm.DutyStep:0.##}% · duty {_vm.SpeedRange.Min:0.##}–{_vm.SpeedRange.Max:0.##}%";
        if(!_vm.CanEdit)EntryStatus.Text="The driver curve has invalid or duplicate points. Refresh before editing.";
        else if(EntryStatus.Text.Length==0)EntryStatus.Text=point.IsEndpoint?"Endpoint temperature locked. Drag vertically or use ↑ / ↓.":"Drag or use arrow keys. Shift = 10 steps. Enter commits numeric edits.";
        _syncing=false;
    }
    private void Commit_Entry(object sender,KeyboardFocusChangedEventArgs args)=>Commit();
    private void Entry_KeyDown(object sender,KeyEventArgs args)
    {
        if(args.Key==Key.Enter){Commit();args.Handled=true;}
        else if(args.Key==Key.Escape){_discardEntry=true;Keyboard.ClearFocus();_discardEntry=false;Redraw();args.Handled=true;}
    }
    private void Commit()
    {
        if(_syncing||_discardEntry||_vm==null||_selected>=_vm.Points.Count)return;
        if(!double.TryParse(Temperature.Text,out var t)||!double.TryParse(Duty.Text,out var s)||!double.IsFinite(t)||!double.IsFinite(s)){EntryStatus.Text="Enter finite numeric values for temperature and duty.";return;}
        var point=_vm.Points[_selected];_vm.EditPoint(point,t,s);
        Temperature.Text=point.TempC.ToString("0.##",CultureInfo.CurrentCulture);Duty.Text=point.SpeedPercent.ToString("0.##",CultureInfo.CurrentCulture);
        EntryStatus.Text=$"Point {_selected+1}: {point.Label} · constrained to supported increments and neighbours.";
    }
    private ControlTemplate KnobTemplate()
    {
        var grid=new FrameworkElementFactory(typeof(Grid));grid.SetValue(BackgroundProperty,Brushes.Transparent);
        var circle=new FrameworkElementFactory(typeof(Ellipse));circle.SetValue(WidthProperty,12d);circle.SetValue(HeightProperty,12d);circle.SetValue(Shape.FillProperty,(Brush)FindResource("Accent"));circle.SetValue(Shape.StrokeProperty,(Brush)FindResource("Text"));circle.SetValue(Shape.StrokeThicknessProperty,2d);grid.AppendChild(circle);
        return new ControlTemplate(typeof(Thumb)){VisualTree=grid};
    }
}



