using System.Windows.Controls;

namespace Nvidia.Views;

/// <summary>
/// NVIDIA control-panel section body, hosted inside NVIDIA GPU Manager. DataContext is the
/// shared <see cref="ViewModels.ShellViewModel"/>; the section list (System / Display /
/// Performance / Overclocking) lives in the merged module's second sidebar.
/// </summary>
public partial class NvidiaSectionView : UserControl
{
    public NvidiaSectionView() => InitializeComponent();
}
