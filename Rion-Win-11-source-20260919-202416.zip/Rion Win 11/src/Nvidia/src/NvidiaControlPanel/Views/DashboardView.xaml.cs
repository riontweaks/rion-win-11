using System.Windows.Controls;

namespace Nvidia.Views;

/// <summary>
/// The Dashboard module's view — a wall of live GPU gauges. Hosted in the
/// Rion Win 11 sidebar; shares <see cref="ViewModels.NvapiHost"/> with the settings sections.
/// </summary>
public partial class DashboardView : UserControl
{
    public DashboardView() => InitializeComponent();
}
