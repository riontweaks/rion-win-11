using Nvidia.Infra;
using Nvidia.Nvapi;

namespace Nvidia.ViewModels;

/// <summary>Live performance-monitoring readout, shared by the metrics strip and the tuning gauges.</summary>
public sealed class MetricsVm : ObservableObject
{
    public sealed class Gauge : ObservableObject
    {
        public Gauge(string label, string unit) { Label = label; Unit = unit; }
        public string Label { get; }
        public string Unit { get; }
        public string Hint => Label == "Memory clock (driver)"
            ? "Current driver-reported memory clock in MHz. This is not the physical oscillator clock or effective data rate; tools may use different conventions."
            : Label == "GPU core activity" ? "Driver-sampled GPU core utilization; Task Manager may show a different engine or sample interval."
            : "Current driver reading. A dash means unavailable or unsupported; it does not mean zero.";

        private string _value = "—";
        public string Value { get => _value; set => Set(ref _value, value); }

        private double _fraction;               // 0..1 for the ring fill
        public double Fraction { get => _fraction; set => Set(ref _fraction, value); }
    }

    public Gauge GpuClock { get; }   = new("GPU Clock Speed", "MHz");
    public Gauge VramClock { get; }  = new("Memory clock (driver)", "MHz");
    public Gauge Voltage { get; }    = new("Voltage", "mV");
    public Gauge BoardPower { get; } = new("Total Board Power", "W");
    public Gauge FanSpeed { get; }   = new("Fan Speed", "RPM");
    public Gauge FanDuty { get; }    = new("Fan speed", "%");
    public Gauge GpuTemp { get; }    = new("GPU Temperature", "°C");
    public Gauge Hotspot { get; }    = new("GPU Hotspot Temperature", "°C");
    public Gauge GpuLoad { get; }    = new("GPU core activity", "%");
    public Gauge Fps { get; }        = new("FPS", "");

    public IReadOnlyList<Gauge> TuningGauges => new[] { GpuClock, VramClock, Voltage, BoardPower, FanSpeed, GpuTemp };

    private string _updated = "—";
    public string Updated { get => _updated; private set => Set(ref _updated, value); }

    public void Update(GpuMetricsSample s)
    {
        void Set1(Gauge g, double? v, double max, string fmt = "0")
        {
            if (v.HasValue && (!double.IsFinite(v.Value) || v.Value < 0)) v = null;
            g.Value = v is null ? "—" : v.Value.ToString(fmt);
            g.Fraction = v is null || max <= 0 ? 0 : Math.Clamp(v.Value / max, 0, 1);
        }

        Set1(GpuClock, s.GpuClockMhz, 3000);
        Set1(VramClock, s.VramClockMhz, 12000);
        Set1(Voltage, s.VoltageMv, 1200);
        Set1(BoardPower, s.BoardPowerW, 350);
        Set1(FanSpeed, s.FanRpm, 3500);
        Set1(FanDuty, s.FanPercent, 100);
        Set1(GpuTemp, s.EdgeTempC, 100);
        Set1(Hotspot, s.HotspotTempC, 110);
        Set1(GpuLoad, s.GpuUsagePercent, 100);
        Set1(Fps, s.Fps, 360);

        Updated = $"{s.Source} · updated {s.TimestampLocal:HH:mm:ss}";
    }
    public void MarkUnavailable(string reason)
    {
        Update(new GpuMetricsSample());
        Updated = reason;
    }
}
