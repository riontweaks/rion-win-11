using Rion.Telemetry;
using Nvidia.Nvapi;

namespace Nvidia.ViewModels;

/// <summary>
/// One NVAPI provider and one metrics poll for the whole process. The Dashboard page and
/// the settings sections both bind the same <see cref="Metrics"/> instance, so
/// <c>nvapi64.dll</c> is initialised once and read once per second — not once per view.
/// </summary>
public sealed class NvapiHost
{
    private static NvapiHost? _instance;

    /// <summary>Lazily created on first use (always the UI thread — views build there).</summary>
    public static NvapiHost Instance => _instance ??= new NvapiHost();

    private readonly DispatcherTelemetryPoller _poller;
    private static bool _pollingRequested = true;
    public static bool IsPolling => _instance?._poller.IsEnabled == true;

    /// <summary>UI-thread host policy; does not initialize an unused provider.</summary>
    public static void SetPollingEnabled(bool enabled)
    {
        _pollingRequested = enabled;
        _instance?._poller.SetEnabled(enabled);
    }

    private NvapiHost() : this(NvapiProviderFactory.Create()) { }
    internal NvapiHost(INvapiProvider provider)
    {
        Provider = provider;
        Metrics = new MetricsVm();

        _poller = new DispatcherTelemetryPoller(RequestMetrics);
        _poller.SetEnabled(_pollingRequested);
    }

    public INvapiProvider Provider { get; private set; }
    private bool _sampling;
    private DateTime _sampleStarted;
    private async void RequestMetrics()
    {
        if (_sampling)
        {
            if (DateTime.UtcNow - _sampleStarted > TimeSpan.FromSeconds(3))
                Metrics.MarkUnavailable("Waiting for NVIDIA driver — readings unavailable");
            return;
        }
        _sampling = true;
        _sampleStarted = DateTime.UtcNow;
        var provider = Provider;
        try
        {
            var sample = await Task.Run(provider.ReadMetrics);
            if (_poller.IsEnabled && ReferenceEquals(provider, Provider)) Metrics.Update(sample);
        }
        catch (Exception ex) { Metrics.MarkUnavailable("NVIDIA telemetry unavailable: " + ex.Message); }
        finally { _sampling = false; }
    }
    public void RefreshAfterInstallation()
    {
        if (!Provider.IsMock && Provider.IsAvailable) return;
        var replacement = NvapiProviderFactory.Create();
        if (replacement.IsMock) { replacement.Dispose(); return; }
        Provider.Dispose();
        Provider = replacement;
        _poller.RequestSample();
    }
    public MetricsVm Metrics { get; }

    public bool IsMock => Provider.IsMock;

}
