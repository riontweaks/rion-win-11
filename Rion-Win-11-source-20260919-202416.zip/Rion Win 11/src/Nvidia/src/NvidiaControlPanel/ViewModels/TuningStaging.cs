using System.IO;
using Nvidia.Nvapi;
using Nvidia.Infra;
namespace Nvidia.ViewModels;
public sealed partial class TuningVm
{
    public Task Initialization {get;private set;}=Task.CompletedTask;
    public RelayCommand ApplyManualCommand {get;private set;}=null!;
    public RelayCommand DiscardManualCommand {get;private set;}=null!;
    public event Action? DraftChanged;
    bool manualPending, resetPending;
    public bool HasPending=>manualPending;
    public string ManualStatus {get;private set;}="Manual changes are staged until Apply.";
    void MarkManual()
    {
        if(_loading)return;
        manualPending=true;Raise(nameof(HasPending));Raise(nameof(ReviewSummary));DraftChanged?.Invoke();
        ApplyManualCommand.RaiseCanExecuteChanged();DiscardManualCommand.RaiseCanExecuteChanged();
    }
    public void DiscardManual()
    {
        _loading=true;_info=_sessionBaseline;FanCurve.Load(_info);_loading=false;
        manualPending=false;resetPending=false;
        foreach(var p in typeof(TuningVm).GetProperties())Raise(p.Name);
        DraftChanged?.Invoke();ApplyManualCommand.RaiseCanExecuteChanged();DiscardManualCommand.RaiseCanExecuteChanged();
    }
    public async Task LoadAsync()
    {
        try { var fresh=await Task.Run(()=>_nvapi.GetGpuTuning());
            if(HasPending)return;
            _loading=true;_info=fresh;_sessionBaseline=fresh;FanCurve.Load(fresh);_loading=false;
            foreach(var p in typeof(TuningVm).GetProperties())Raise(p.Name);
        }catch(Exception e){LastError=e.Message;}
    }
    static bool SameTuning(GpuTuningInfo a,GpuTuningInfo b)=>a.Available&&b.Available&&a.GpuName==b.GpuName&&
        a.SystemMode==b.SystemMode&&a.AutoMode==b.AutoMode&&a.ManualCustom==b.ManualCustom&&
        (!b.SupportsManualGpuClock||(a.GpuMinClockMhz==b.GpuMinClockMhz&&a.GpuMaxClockMhz==b.GpuMaxClockMhz&&a.GpuVoltageMv==b.GpuVoltageMv))&&
        (!b.SupportsManualVram||a.VramClockMhz==b.VramClockMhz)&&
        (!b.SupportsPowerTuning||Math.Abs(a.PowerLimitPercent-b.PowerLimitPercent)<.001)&&
        (!b.SupportsFanTuning||a.FanCurve.SequenceEqual(b.FanCurve));
    WriteResult WriteManual(GpuTuningInfo target)
    {
        // Apply only changed controls, stop at the first rejection. The transaction restores the full snapshot.
        var current=_nvapi.GetGpuTuning();
        var actions=new List<Func<WriteResult>>();
        if(target.SupportsManualGpuClock&&(current.GpuMinClockMhz!=target.GpuMinClockMhz||current.GpuMaxClockMhz!=target.GpuMaxClockMhz))actions.Add(()=>_nvapi.SetGpuClockRange(target.GpuMinClockMhz,target.GpuMaxClockMhz));
        if(target.SupportsManualGpuClock&&target.GpuVoltageMv>0&&current.GpuVoltageMv!=target.GpuVoltageMv)actions.Add(()=>_nvapi.SetGpuVoltage(target.GpuVoltageMv));
        if(target.SupportsManualVram&&current.VramClockMhz!=target.VramClockMhz)actions.Add(()=>_nvapi.SetVramClock(target.VramClockMhz));
        if(target.SupportsPowerTuning&&current.PowerLimitPercent!=target.PowerLimitPercent)actions.Add(()=>_nvapi.SetPowerLimitPercent(target.PowerLimitPercent));
        if(target.SupportsFanTuning&&!current.FanCurve.SequenceEqual(target.FanCurve))actions.Add(()=>_nvapi.SetFanCurve(target.FanCurve));
        foreach(var action in actions){var result=action();if(!result.Ok)return result;}
        return WriteResult.Success;
    }
    public async Task ApplyManualAsync(bool interactive=true)
    {
        if(!HasPending||!TuningIdle)return;
        if(_sessionBaseline.AutoMode is not (GpuAutoMode.None)) {LastError="Exact recovery of automatic tuning is unavailable. Choose a driver default or preset before manual editing.";return;}
        if(interactive&&!GpuApplyPrompt.Review(resetPending?"Reset manual tuning to driver defaults":ReviewSummary))return;
        _activeWrites++;Raise(nameof(TuningIdle));GpuApplyPrompt? prompt=null;
        try {
            var before=_sessionBaseline with {FanCurve=_sessionBaseline.FanCurve.ToArray()};
            var target=_info with {FanCurve=FanCurve.ToPoints().ToArray()};
            if(!resetPending)target=target with {SystemMode=SystemTuningMode.Custom,ManualCustom=true,AutoMode=GpuAutoMode.None};
            bool reset=resetPending;
            if(interactive)prompt=new GpuApplyPrompt();
            var result=await GpuTransaction.Run(new[]{new GpuEdit<GpuTuningInfo>("manual","Manual GPU tuning",before,target)},
                async (_,value)=>{var r=await Task.Run(()=>ReferenceEquals(value,before)?_nvapi.ApplyTuningSnapshot(value):reset?_nvapi.SetSystemTuningMode(SystemTuningMode.Default):WriteManual(value));return r.Ok?null:r.Error;},
                _=>Task.Run(()=>_nvapi.GetGpuTuning()),
                (actual,expected)=>reset&&ReferenceEquals(expected,target)?actual.SystemMode==SystemTuningMode.Default&&!actual.ManualCustom:SameTuning(actual,expected),v=>v,
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"RionWin11","GPU","Nvidia","Tuning"),
                prompt==null?()=>Task.FromResult(true):prompt.Delay,prompt==null?()=>Task.FromResult(true):prompt.Keep);
            if(prompt!=null)prompt.RestoreFailed=result.RestoreFailed;
            ManualStatus=result.Status;LastError=result.RestoreFailed?result.Status:"";Raise(nameof(ManualStatus));
            if(!result.RestoreFailed){manualPending=false;resetPending=false;await LoadAsync();}
        } catch(Exception e){LastError=e.Message;}
        finally {_activeWrites--;Raise(nameof(TuningIdle));Raise(nameof(HasPending));DraftChanged?.Invoke();prompt?.Dispose();}
    }
}
