using Nvidia.Infra;

namespace Nvidia.ViewModels;

/// <summary>
/// The Dashboard page — a read-only wall of live GPU telemetry. Binds the process-wide
/// <see cref="NvapiHost.Metrics"/>, so it moves in lock-step with the settings-section gauges.
/// </summary>
public sealed class DashboardViewModel : ObservableObject
{
    private readonly NvapiHost _host = NvapiHost.Instance;

    public DashboardViewModel()
    {
        try { GpuName = _host.Provider.DisplayName; }
        catch { GpuName = "Graphics processor"; }
    }

    public MetricsVm Metrics => _host.Metrics;

    public string GpuName { get; }

    public bool IsMock => _host.IsMock;

    /// <summary>True when NVAPI bound to a real GeForce driver (drives the green indicator light).</summary>
    public bool Connected => _host.Provider.IsAvailable && !_host.IsMock;

    public string ConnectionText => Connected
        ? "Connected to the NVIDIA driver"
        : _host.IsMock ? "Demo mode — simulated readings" : "NVIDIA driver unavailable — no live readings";
}
