using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;
using Nvidia.Catalog;
using Nvidia.Infra;

namespace Nvidia.ViewModels;

/// <summary>A label/value pair shown on the read-only System tab.</summary>
public sealed record InfoRow(string Label, string Value);

/// <summary>One left-rail entry: a settings tab with its rows grouped by sub-header.</summary>
public sealed class TabVm : ObservableObject
{
    public TabVm(SettingTab kind, string title, string glyph, string blurb, IEnumerable<SettingVm> settings,
                 IEnumerable<InfoRow>? infoRows = null)
    {
        Kind = kind;
        Title = title;
        Glyph = glyph;
        Blurb = blurb;
        InfoRows = (infoRows ?? Array.Empty<InfoRow>()).ToList();
        Settings = new ObservableCollection<SettingVm>(settings);

        View = CollectionViewSource.GetDefaultView(Settings);
        View.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SettingVm.Group)));
        View.Filter = o => o is SettingVm s && s.Matches(_filter) && (ShowUnavailable || s.Supported);
    }

    public SettingTab Kind { get; }
    public string Title { get; }
    public string Glyph { get; }
    public string Blurb { get; }

    public ObservableCollection<SettingVm> Settings { get; }
    public IReadOnlyList<InfoRow> InfoRows { get; private set; }
    public void SetInfoRows(IEnumerable<InfoRow> rows) { InfoRows = rows.ToArray(); Raise(nameof(InfoRows)); }
    public ICollectionView View { get; }

    public int Count => Settings.Count;
    public int RecommendedCount => Settings.Count(s => s.HasRecommendation);
    public int DeviationCount => Settings.Count(s => s.ShowDeviationGlow);
    public int PendingCount => Settings.Count(s => s.IsDirty);
    public bool ShowUnavailable {get;set;}
    public bool IsOverclocking => Kind == SettingTab.Overclocking;
    public bool IsSystem => Kind == SettingTab.System;
    public bool IsSettingsList => Kind is SettingTab.Display or SettingTab.Performance;

    private string _filter = "";
    public void SetFilter(string q)
    {
        _filter = q ?? "";
        View.Refresh();
    }

    public void RefreshCounters()
    {
        View.Refresh();
        Raise(nameof(RecommendedCount));
        Raise(nameof(DeviationCount));
        Raise(nameof(PendingCount));
    }
}
