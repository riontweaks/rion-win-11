using System.Collections.ObjectModel;
using Nvidia.Nvapi;
using Nvidia.Infra;

namespace Nvidia.ViewModels;

public sealed class FanPointVm : ObservableObject
{
    private readonly FanCurveVm _owner;
    private double _tempC, _speedPct;
    public FanPointVm(FanCurveVm owner,double tempC,double speedPct,bool isEndpoint)
    { _owner=owner;_tempC=tempC;_speedPct=speedPct;IsEndpoint=isEndpoint; }
    public bool IsEndpoint { get; }
    public double TempC { get=>_tempC;set=>_owner.EditPoint(this,value,_speedPct); }
    public double SpeedPercent { get=>_speedPct;set=>_owner.EditPoint(this,_tempC,value); }
    public string Label=>$"{TempC:0.#}°C · {SpeedPercent:0.#}%";
    internal bool SetSilently(double temperature,double speed)
    {
        if(Math.Abs(_tempC-temperature)<.0001&&Math.Abs(_speedPct-speed)<.0001)return false;
        _tempC=temperature;_speedPct=speed;
        Raise(nameof(TempC));Raise(nameof(SpeedPercent));Raise(nameof(Label));return true;
    }
}

public sealed class FanCurveVm : ObservableObject
{
    public event Action? Changed;
    public ObservableCollection<FanPointVm> Points {get;}=new();
    public ValueRange TempRange {get;private set;}=new(20,100,1);
    public ValueRange SpeedRange {get;private set;}=new(0,100,1);
    public double TemperatureStep=>TempRange.Step>0?TempRange.Step:1;
    public double DutyStep=>SpeedRange.Step>0?SpeedRange.Step:1;
    private bool _validRanges;
    public bool CanEdit=>_validRanges && Points.Count>=2 && Points.All(p=>double.IsFinite(p.TempC)&&double.IsFinite(p.SpeedPercent)) && Points.Zip(Points.Skip(1),(a,b)=>b.TempC>a.TempC).All(valid=>valid);
    public void Load(GpuTuningInfo info)
    {
        _validRanges=ValidRange(info.FanTempRange)&&ValidRange(info.FanSpeedRange);
        TempRange=info.FanTempRange.IsValid?info.FanTempRange:new(20,100,1);
        SpeedRange=info.FanSpeedRange.IsValid?info.FanSpeedRange:new(0,100,1);
        // Missing readback is not permission to invent a five-point hardware curve.
        var source=info.FanCurve.ToList();
        Points.Clear();
        for(int i=0;i<source.Count;i++)Points.Add(new(this,source[i].TempC,source[i].SpeedPercent,i==0||i==source.Count-1));
        Raise(nameof(Points));Raise(nameof(TemperatureStep));Raise(nameof(DutyStep));
    }
    public IReadOnlyList<FanPoint> ToPoints()=>Points.Select(p=>new FanPoint(p.TempC,p.SpeedPercent)).ToList();
    public void EditPoint(FanPointVm point,double temperature,double duty)
    {
        if(!CanEdit||!double.IsFinite(temperature)||!double.IsFinite(duty))return;
        int index=Points.IndexOf(point);if(index<0)return;
        double t=point.TempC;
        if(!point.IsEndpoint)
        {
            double low=Math.Max(TempRange.Min,Points[index-1].TempC+TemperatureStep);
            double high=Math.Min(TempRange.Max,Points[index+1].TempC-TemperatureStep);
            // Constrain to actual API increments, including when adjacent points are off-grid.
            low=TempRange.Min+Math.Ceiling((low-TempRange.Min)/TemperatureStep)*TemperatureStep;
            high=TempRange.Min+Math.Floor((high-TempRange.Min)/TemperatureStep)*TemperatureStep;
            if(low>high)return;
            t=Math.Clamp(Snap(temperature,TempRange,TemperatureStep),low,high);
        }
        // Endpoints retain their detected temperatures; editing duty must not relocate them.
        double speed=Snap(duty,SpeedRange,DutyStep);
        if(point.SetSilently(t,speed))Changed?.Invoke();
    }
    private static bool ValidRange(ValueRange range)=>range.IsValid&&double.IsFinite(range.Min)&&double.IsFinite(range.Max)&&double.IsFinite(range.Step)&&range.Step>0;
    private static double Snap(double value,ValueRange range,double step)
    {
        double last=range.Min+Math.Floor((range.Max-range.Min)/step)*step;
        return Math.Clamp(range.Min+Math.Round((value-range.Min)/step)*step,range.Min,last);
    }
}


