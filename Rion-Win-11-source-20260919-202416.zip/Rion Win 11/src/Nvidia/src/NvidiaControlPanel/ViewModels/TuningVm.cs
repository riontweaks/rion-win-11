using System.Windows.Threading;
using Nvidia.Infra;
using Nvidia.Nvapi;

namespace Nvidia.ViewModels;

/// <summary>
/// The Overclocking tab (system-level + GPU auto/preset/manual + fan curve + power limit).
/// Manual controls stage changes for review and verified application. A baseline is captured on
/// load; the first manual GPU / VRAM / power change in a session raises a 15-second
/// keep-or-revert bar. Mirrors <c>Aldx.ViewModels.TuningVm</c> exactly — see that file's
/// comments for the reasoning behind the safety model.
/// </summary>
public sealed partial class TuningVm : ObservableObject
{
    private readonly INvapiProvider _nvapi;
    private int _activeWrites;
    public bool TuningIdle=>_activeWrites==0;
    private readonly Dispatcher _ui;
    private readonly DispatcherTimer _debounce;
    private readonly DispatcherTimer _confirm;

    private GpuTuningInfo _info = new() { GpuName = "GPU", Available = false };
    private GpuTuningInfo _sessionBaseline = new() { GpuName = "GPU", Available = false };
    private GpuTuningInfo? _revertPoint;
    private bool _firstRiskyDone;
    private bool _loading;
    private Action? _pendingPush;

    /// <summary>Live gauges shared with the shell — bound directly by OverclockingView
    /// so it no longer needs a Window-ancestor RelativeSource to reach them.</summary>
    public MetricsVm Metrics { get; }

    public TuningVm(INvapiProvider nvapi, MetricsVm metrics)
    {
        _nvapi = nvapi;
        Metrics = metrics;
        _ui = Dispatcher.CurrentDispatcher;
        FanCurve = new FanCurveVm();
        FanCurve.Changed += () => QueuePush(() => _nvapi.SetFanCurve(FanCurve.ToPoints()), risky: true);

        _debounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
        _debounce.Tick += (_, _) => { _debounce.Stop(); FlushPush(); };

        _confirm = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _confirm.Tick += (_, _) => Tick();

        KeepCommand = new RelayCommand(Keep);
        RevertNowCommand = new RelayCommand(RevertNow);
        ResetGpuCommand = new RelayCommand(ResetGpu, () => Available);
        NextStepCommand = new RelayCommand(NextStep, () => CanNext);
        BackStepCommand = new RelayCommand(BackStep, () => CanBack);
        ApplyDefaultCommand = new RelayCommand(ResetGpu, () => Available);

        ApplyManualCommand=new RelayCommand(async()=>await ApplyManualAsync(),()=>HasPending&&TuningIdle);
        DiscardManualCommand=new RelayCommand(DiscardManual,()=>HasPending&&TuningIdle);
        Initialization=LoadAsync();
    }

    // ---------------------------------------------------------------- load
    public void Load(){Initialization=LoadAsync();}

    public bool Available => _info.Available;
    public string Unavailable => _info.Unavailable;
    public string GpuName => _info.GpuName;

    // ---------------------------------------------------------------- system
    public SystemTuningMode SystemMode
    {
        get => _info.SystemMode;
        set
        {
            if (_loading || HasPending || _info.SystemMode == value) return;
            _info = _info with { SystemMode = value };
            Raise();
            PushAutomatic(() => _nvapi.SetSystemTuningMode(value), risky: value == SystemTuningMode.AutoOverclock);
            if (value == SystemTuningMode.Custom) GpuManualCustom = true;
            if (value == SystemTuningMode.Default) ResetGpu();
        }
    }

    // ---------------------------------------------------------------- GPU auto / manual
    // NVIDIA's real automatic tuning is one unified "Scanner" pass (core + memory together) —
    // no separate undervolt/overclock-GPU/overclock-VRAM modes and no built-in presets the way
    // AMD Adrenalin has. See GpuAutoMode's doc comment.
    public GpuAutoMode GpuAuto
    {
        get => _info.AutoMode;
        set
        {
            if (_loading || HasPending || _info.AutoMode == value) return;
            _info = _info with { AutoMode = value, ManualCustom = false };
            RaiseGpuModeGroup();
            PushAutomatic(() => _nvapi.SetGpuAutoMode(value), risky: value == GpuAutoMode.AutoTune);
        }
    }

    public bool GpuManualCustom
    {
        get => _info.ManualCustom;
        set
        {
            if (_loading || _info.ManualCustom == value) return;
            _info = _info with { ManualCustom = value, AutoMode = value ? GpuAutoMode.None : _info.AutoMode };
            RaiseGpuModeGroup();
            Raise(nameof(ShowManualGpu));
            Push(() => _nvapi.SetGpuManualCustom(value), risky: false);
        }
    }

    private void RaiseGpuModeGroup()
    {
        Raise(nameof(GpuAuto)); Raise(nameof(GpuManualCustom)); Raise(nameof(ShowManualGpu));
        RaiseStepFlags();   // picking auto-tune on the Choose step enables Next
    }

    public bool ShowManualGpu => _info.ManualCustom && (_info.SupportsManualGpuClock || _info.SupportsManualVram);

    public bool SupportsAutoTune => _info.SupportsAutoTune;

    // manual GPU clock / voltage / vram
    public double GpuMinClock { get => _info.GpuMinClockMhz; set => SetNum(v => _info = _info with { GpuMinClockMhz = (int)v }, _info.GpuMinClockMhz, value, () => _nvapi.SetGpuClockRange((int)value, _info.GpuMaxClockMhz)); }
    public double GpuMaxClock { get => _info.GpuMaxClockMhz; set => SetNum(v => _info = _info with { GpuMaxClockMhz = (int)v }, _info.GpuMaxClockMhz, value, () => _nvapi.SetGpuClockRange(_info.GpuMinClockMhz, (int)value)); }
    public double GpuVoltage { get => _info.GpuVoltageMv; set => SetNum(v => _info = _info with { GpuVoltageMv = (int)v }, _info.GpuVoltageMv, value, () => _nvapi.SetGpuVoltage((int)value)); }
    public double VramClock { get => _info.VramClockMhz; set => SetNum(v => _info = _info with { VramClockMhz = (int)v }, _info.VramClockMhz, value, () => _nvapi.SetVramClock((int)value)); }

    public ValueRange GpuClockRange => _info.GpuClockRange;
    public ValueRange GpuVoltageRange => _info.GpuVoltageRange;
    public ValueRange VramClockRange => _info.VramClockRange;
    public bool SupportsManualGpuClock => _info.SupportsManualGpuClock;
    public bool SupportsManualVram => _info.SupportsManualVram;

    // ---------------------------------------------------------------- fan
    public bool SupportsFanTuning => _info.SupportsFanTuning;
    public FanCurveVm FanCurve { get; }

    public bool FanTuningEnabled
    {
        get => _info.FanTuningEnabled;
        set { if (_loading || _info.FanTuningEnabled == value) return; _info = _info with { FanTuningEnabled = value }; Raise(); Push(() => _nvapi.SetFanTuningEnabled(value), risky: false); }
    }

    public bool FanAdvancedControl
    {
        get => _info.FanAdvancedControl;
        set { if (_loading || _info.FanAdvancedControl == value) return; _info = _info with { FanAdvancedControl = value }; Raise(); Raise(nameof(ShowFanCurve)); Push(() => _nvapi.SetFanAdvancedControl(value), risky: false); }
    }

    public bool ShowFanCurve => _info.FanTuningEnabled && _info.FanAdvancedControl;

    // ---------------------------------------------------------------- power
    public bool SupportsPowerTuning => _info.SupportsPowerTuning;
    public ValueRange PowerLimitRange => _info.PowerLimitRange.IsValid ? _info.PowerLimitRange : new(50, 125, 1);

    public bool PowerTuningEnabled
    {
        get => _info.PowerTuningEnabled;
        set { if (_loading || _info.PowerTuningEnabled == value) return; _info = _info with { PowerTuningEnabled = value }; Raise(); Push(() => _nvapi.SetPowerTuningEnabled(value), risky: false); }
    }

    public double PowerLimitPercent
    {
        get => _info.PowerLimitPercent;
        set => SetNum(v => _info = _info with { PowerLimitPercent = v }, _info.PowerLimitPercent, PowerLimitRange.Clamp(value),
                      () => _nvapi.SetPowerLimitPercent(PowerLimitRange.Clamp(value)));
    }

    // ---------------------------------------------------------------- reset + confirm bar
    public RelayCommand ResetGpuCommand { get; }
    public RelayCommand KeepCommand { get; }
    public RelayCommand RevertNowCommand { get; }

    private bool _confirmActive;
    public bool ConfirmActive { get => _confirmActive; private set => Set(ref _confirmActive, value); }

    private int _confirmSeconds;
    public int ConfirmSeconds { get => _confirmSeconds; private set { if (Set(ref _confirmSeconds, value)) Raise(nameof(ConfirmText)); } }
    public string ConfirmText => $"Keep these tuning changes? Reverting in {ConfirmSeconds}s";

    private void ResetGpu()
    {
        _ = RunAsync(() =>
        {
            _nvapi.SetGpuManualCustom(false);
            _nvapi.SetGpuAutoMode(GpuAutoMode.None);
            if (_info.SupportsPowerTuning) _nvapi.SetPowerLimitPercent(100);
            _nvapi.SetSystemTuningMode(SystemTuningMode.Default);
            return WriteResult.Success;
        });
    }

    private void Tick()
    {
        ConfirmSeconds--;
        if (ConfirmSeconds <= 0) RevertNow();
    }

    private void Keep()
    {
        _confirm.Stop();
        ConfirmActive = false;
        _revertPoint = null;
        _sessionBaseline = _info;
    }

    private void RevertNow()
    {
        _confirm.Stop();
        ConfirmActive = false;
        var target = _revertPoint;
        _revertPoint = null;
        _firstRiskyDone = false;
        if (target is { } t)
            _ = RunAsync(() => _nvapi.ApplyTuningSnapshot(t));
    }

    // ---------------------------------------------------------------- push plumbing
    private void SetNum(Action<double> assign, double current, double next, Func<WriteResult> push)
    {
        if (_loading || Math.Abs(current - next) < 0.001) return;
        assign(next);
        Raise();
        QueuePush(() => push(), risky: true);
    }

    private void QueuePush(Func<WriteResult> push, bool risky)=>MarkManual();

    private void FlushPush()
    {
        var p = _pendingPush;
        _pendingPush = null;
        p?.Invoke();
    }

    private void Push(Func<WriteResult> work, bool risky)=>MarkManual();

    private void PushAutomatic(Func<WriteResult> work, bool risky)
    {
        if (risky && !_firstRiskyDone)
        {
            _firstRiskyDone = true;
            _revertPoint = _sessionBaseline;
            ConfirmSeconds = 15;
            ConfirmActive = true;
            _confirm.Start();
        }
        _ = RunAsync(work);
    }

    private async Task RunAsync(Func<WriteResult> work)
    {
        WriteResult res;
        try { res = await Task.Run(work); }
        catch (Exception ex) { res = WriteResult.Fail(ex.Message); }

        var fresh=await Task.Run(()=>_nvapi.GetGpuTuning());
        _ui.Invoke(() =>
        {
            LastError = res.Ok ? "" : res.Error;
            // re-read driver truth without disturbing the confirm bar

            _info = _info with
            {
                PowerLimitPercent = fresh.PowerLimitPercent,
                GpuMinClockMhz = fresh.GpuMinClockMhz,
                GpuMaxClockMhz = fresh.GpuMaxClockMhz,
                GpuVoltageMv = fresh.GpuVoltageMv,
                VramClockMhz = fresh.VramClockMhz,
            };
            Raise(nameof(PowerLimitPercent)); Raise(nameof(GpuMinClock)); Raise(nameof(GpuMaxClock));
            Raise(nameof(GpuVoltage)); Raise(nameof(VramClock));
        });
    }

    private string _lastError = "";
    public string LastError { get => _lastError; private set => Set(ref _lastError, value); }

    // ================================================================ stepped wizard
    // The Overclocking tab is a Next/Back flow over this same VM. Writes still go to the
    // driver immediately (see the push plumbing above) with the 15-second keep-or-revert;
    // the steps just stage which controls are on screen.

    public enum OcStep { Choose, Gpu, Vram, Fan, Power, Review, AutoConfirm }
    public enum TuningIntent { Default, Automatic, Manual }

    public RelayCommand NextStepCommand { get; }
    public RelayCommand BackStepCommand { get; }
    public RelayCommand ApplyDefaultCommand { get; }

    private OcStep _step = OcStep.Choose;
    public OcStep Step { get => _step; private set { if (Set(ref _step, value)) RaiseStepFlags(); } }

    private TuningIntent _intent = TuningIntent.Manual;
    public TuningIntent Intent
    {
        get => _intent;
        set
        {
            if (_loading || !Set(ref _intent, value)) return;
            if (value == TuningIntent.Manual) GpuManualCustom = true;
            RaiseStepFlags();
        }
    }

    public bool IsDefaultIntent => _intent == TuningIntent.Default;
    public bool IsAutomaticIntent => _intent == TuningIntent.Automatic;
    public bool IsManualIntent => _intent == TuningIntent.Manual;

    public bool IsChoose => _step == OcStep.Choose;
    public bool IsGpuStep => _step == OcStep.Gpu;
    public bool IsVramStep => _step == OcStep.Vram;
    public bool IsFanStep => _step == OcStep.Fan;
    public bool IsPowerStep => _step == OcStep.Power;
    public bool IsReviewStep => _step == OcStep.Review;
    public bool IsAutoConfirmStep => _step == OcStep.AutoConfirm;

    public string StepTitle => _step switch
    {
        OcStep.Choose => "Tuning Control",
        OcStep.Gpu => "GPU Tuning",
        OcStep.Vram => "VRAM Tuning",
        OcStep.Fan => "Fan Tuning",
        OcStep.Power => "Power Tuning",
        OcStep.Review => "Review",
        OcStep.AutoConfirm => AutoModeLabel,
        _ => "",
    };

    public string StepCaption => _step switch
    {
        OcStep.Choose => "Pick how you want to tune this GPU. Automatic lets NVIDIA's scanner find the numbers; Manual walks you through each control.",
        OcStep.Gpu => "Core clock offset and voltage. Changes are staged until Apply.",
        OcStep.Vram => "Memory clock offset. Changes are staged until Apply.",
        OcStep.Fan => "A custom fan curve under Advanced Control.",
        OcStep.Power => "Raise or lower the board power limit.",
        OcStep.Review => "Review pending manual values, then choose Apply.",
        OcStep.AutoConfirm => "NVIDIA's scanner is auto-tuning in the background. You have 15 seconds to keep or revert once it starts.",
        _ => "",
    };

    private string AutoModeLabel => "Auto-Tune (Scanner)";

    public string NextLabel => _step is OcStep.Gpu or OcStep.Vram or OcStep.Fan or OcStep.Power ? "Next"
        : _step == OcStep.Choose && _intent == TuningIntent.Automatic ? "Apply" : "Next";

    public bool CanBack => _step != OcStep.Choose;

    public bool CanNext => _step switch
    {
        OcStep.Choose => _intent == TuningIntent.Manual
                         || (_intent == TuningIntent.Automatic && GpuAuto != GpuAutoMode.None),
        OcStep.Gpu or OcStep.Vram or OcStep.Fan or OcStep.Power => true,
        _ => false,
    };

    public string ReviewSummary
    {
        get
        {
            var parts = new List<string>();
            if (_info.SupportsManualGpuClock)
                parts.Add($"GPU clock offset {GpuMaxClock:+0;-0;0} MHz · {GpuVoltage:0} mV");
            if (_info.SupportsManualVram)
                parts.Add($"VRAM offset {VramClock:+0;-0;0} MHz");
            if (_info.SupportsFanTuning)
                parts.Add(FanTuningEnabled ? (FanAdvancedControl ? "Custom fan curve" : "Fan tuning on") : "Fan tuning off");
            if (_info.SupportsPowerTuning)
                parts.Add(PowerTuningEnabled ? $"Power limit {PowerLimitPercent:0}%" : "Stock power limit");
            return parts.Count == 0 ? "No manual tuning controls on this GPU." : string.Join("\n", parts);
        }
    }

    private List<OcStep> ManualOrder
    {
        get
        {
            var l = new List<OcStep> { OcStep.Gpu };
            if (_info.SupportsManualVram) l.Add(OcStep.Vram);
            if (_info.SupportsFanTuning) l.Add(OcStep.Fan);
            if (_info.SupportsPowerTuning) l.Add(OcStep.Power);
            l.Add(OcStep.Review);
            return l;
        }
    }

    private void NextStep()
    {
        if (!CanNext) return;
        if (_step == OcStep.Choose)
        {
            Step = _intent == TuningIntent.Automatic ? OcStep.AutoConfirm : ManualOrder[0];
            return;
        }
        var order = ManualOrder;
        int i = order.IndexOf(_step);
        if (i >= 0 && i < order.Count - 1) Step = order[i + 1];
    }

    private void BackStep()
    {
        if (_step is OcStep.AutoConfirm) { Step = OcStep.Choose; return; }
        var order = ManualOrder;
        int i = order.IndexOf(_step);
        if (i > 0) Step = order[i - 1];
        else Step = OcStep.Choose;
    }

    private void RaiseStepFlags()
    {
        foreach (var n in new[]
        {
            nameof(Step), nameof(Intent), nameof(IsDefaultIntent), nameof(IsAutomaticIntent), nameof(IsManualIntent),
            nameof(IsChoose), nameof(IsGpuStep), nameof(IsVramStep), nameof(IsFanStep), nameof(IsPowerStep),
            nameof(IsReviewStep), nameof(IsAutoConfirmStep), nameof(StepTitle), nameof(StepCaption),
            nameof(NextLabel), nameof(CanBack), nameof(CanNext), nameof(ReviewSummary),
        }) Raise(n);
        NextStepCommand.RaiseCanExecuteChanged();
        BackStepCommand.RaiseCanExecuteChanged();
    }
}
