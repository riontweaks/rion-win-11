using System.Text;
using Nvidia.Catalog;
using Nvidia.Nvapi.Native;

namespace Nvidia.Nvapi;

/// <summary>NVAPI graphics settings and telemetry. Unsupported tuning operations return explicit failures.</summary>
public sealed partial class NativeNvapiProvider : INvapiProvider
{
    private readonly object _gate = new();

    private IntPtr _gpu;
    private bool _singleGpu;
    private readonly NvmlTelemetry _nvml = new();
    private string _name = "NVIDIA GPU";
    private string _initNote = "";
    private uint _deviceId, _subSystemId, _revisionId;

    public string DisplayName => _name;
    public bool IsAvailable { get; private set; }
    public bool IsMock => false;

    public void Initialize()
    {
        lock (_gate)
        {
            if (!NvapiApi.LoadLibraryAndExports(out var err)) { _initNote = err; return; }

            int r = NvapiApi.Initialize!();
            if (!NvapiApi.Ok(r)) { _initNote = $"NvAPI_Initialize returned {r}."; return; }

            var handles = new IntPtr[NvapiApi.MaxPhysicalGpus];
            r = NvapiApi.EnumPhysicalGPUs!(handles, out uint count);
            if (!NvapiApi.Ok(r) || count == 0)
            {
                _initNote = $"NvAPI_EnumPhysicalGPUs found no GPUs (status {r}).";
                return;
            }

            _gpu = handles[0]; // first GPU only — multi-GPU selection is future work
            _singleGpu = count == 1;

            var nameBuf = new byte[64];
            if (NvapiApi.Ok(NvapiApi.GetFullName!(_gpu, nameBuf)))
            {
                int len = Array.IndexOf(nameBuf, (byte)0);
                _name = Encoding.ASCII.GetString(nameBuf, 0, len < 0 ? nameBuf.Length : len).Trim();
            }

            NvapiApi.GetPciIdentifiers?.Invoke(_gpu, out _deviceId, out _subSystemId, out _revisionId, out _);

            IsAvailable = true;
            _initNote = "Live — connected via NVAPI.";
        }
    }

    public GpuInfo GetGpuInfo() => new()
    {
        Name = _name,
        AsicFamily = "Unknown (not yet queried)",
        VramType = "Unknown (not yet queried)",
        VramSizeMb = 0,
        CoreClockMhz = ReadClockMhzOrZero(NvapiApi.ClockFrequenciesV3.GraphicsClockIndex, clockType: 1), // 1 = base
        MemoryClockMhz = ReadClockMhzOrZero(NvapiApi.ClockFrequenciesV3.MemoryClockIndex, clockType: 1),
        BusInterface = "Unknown (not yet queried)",
        VbiosVersion = "",
        DriverVersion = "Unknown (not yet queried)",
        DriverDate = "",
        VendorId = "0x10DE",
        DeviceId = "0x" + _deviceId.ToString("X"),
        IsExternal = false,
        HasDesktop = true,
        TotalBoardPowerW = 0,
        NvapiVersion = "Unknown (not yet queried)",
        NvapiDllPath = "nvapi64.dll",
        NvapiInitialized = IsAvailable,
        InitNote = _initNote,
    };

    public SettingValue Read(SettingId id)
    {
        lock (_gate) return ReadCore(id);
    }

    private IntPtr _readSession, _readProfile;
    public IReadOnlyDictionary<SettingId, SettingValue> ReadMany(IEnumerable<SettingId> ids)
    {
        var keys = ids.Distinct().ToArray();
        lock (_gate)
        {
            if (!IsAvailable || !NvapiApi.DrsAvailable) return keys.ToDictionary(id => id, ReadCore);
            return WithSession<IReadOnlyDictionary<SettingId, SettingValue>>(false, (session, profile) =>
            {
                _readSession = session; _readProfile = profile;
                try { return keys.ToDictionary(id => id, ReadCore); }
                finally { _readSession = IntPtr.Zero; _readProfile = IntPtr.Zero; }
            }, error => keys.ToDictionary(id => id, id => SettingValue.Unsupported(error)));
        }
    }

    public WriteResult Write(SettingId id, SettingValue value)
    {
        lock (_gate) return WriteCore(id, value);
    }

    /// <summary>
    /// Reads one DRS setting off the base (global) profile. A setting the driver has never been
    /// given reads back as its predefined default, which is the value the control panel shows too.
    /// </summary>
    private SettingValue ReadCore(SettingId id)
    {
        if (id is SettingId.Display_GpuScaling or SettingId.Display_ScalingMode or SettingId.Display_IntegerScaling) return ReadScaling(id);
        if (id is SettingId.Display_ColorDepth or SettingId.Display_ColorFormat or SettingId.Display_DynamicRange) return ReadColor(id);
        if (id == SettingId.Display_Hdcp) return ReadHdcpSupport();
        if (!IsAvailable) return SettingValue.Unsupported("No NVIDIA driver detected.");
        if (!NvapiApi.DrsAvailable) return SettingValue.Unsupported("This driver does not expose the DRS settings API.");

        uint? drsId = Native.DrsSettingMap.DrsId(id);
        if (drsId == null) return SettingValue.Unsupported(UnavailableSettingReason(id));

        return WithSession(false, (session, profile) =>
        {
            var setting = NvapiApi.DrsSetting.Create();
            int r = NvapiApi.DrsGetSetting!(session, profile, drsId.Value, ref setting);
            if (!NvapiApi.Ok(r)) return SettingValue.Unsupported($"NvAPI_DRS_GetSetting returned {r}.");
            if (setting.SettingType != NvapiApi.DrsDwordType)
                return SettingValue.Unsupported("This setting is not a DWORD value.");

            uint raw = setting.CurrentValue;
            SettingValue Preserve(SettingValue v) => setting.IsCurrentPredefined != 0 && NvapiApi.DrsRestoreDefault == null
                ? SettingValue.Unsupported("This driver does not expose exact restoration of its predefined setting.")
                : v with { NativeDword = raw, NativePredefined = setting.IsCurrentPredefined != 0 };

            if (Native.DrsSettingMap.Toggle(id) is { } toggle)
                return raw == toggle.On ? Preserve(SettingValue.Of(true)) : raw == toggle.Off ? Preserve(SettingValue.Of(false))
                    : SettingValue.Unsupported($"Unrecognized driver value ({raw}).");

            if (Native.DrsSettingMap.Range(id) is { } range)
                return Preserve(SettingValue.Of(raw, range.Min, range.Max));

            if (Native.DrsSettingMap.Choices(id) is { } choices)
            {
                foreach (var pair in choices)
                    if (pair.Value == raw)
                        return Preserve(SettingValue.Of(pair.Key));
                return SettingValue.Unsupported($"The driver reports a value ({raw}) this app has no name for.");
            }

            return SettingValue.Unsupported("No value mapping for this setting.");
        }, SettingValue.Unsupported);
    }

    private WriteResult WriteCore(SettingId id, SettingValue value)
    {
        if (id is SettingId.Display_GpuScaling or SettingId.Display_ScalingMode or SettingId.Display_IntegerScaling) return WriteScaling(id, value);
        if (id is SettingId.Display_ColorDepth or SettingId.Display_ColorFormat or SettingId.Display_DynamicRange) return WriteColor(id, value);
        if (!IsAvailable) return WriteResult.Fail("No NVIDIA driver detected.");
        if (!NvapiApi.DrsAvailable) return WriteResult.Fail("This driver does not expose the DRS settings API.");

        uint? drsId = Native.DrsSettingMap.DrsId(id);
        if (drsId == null) return WriteResult.Fail(UnavailableSettingReason(id));

        uint raw;
        if (value.RestoreNative && value.NativeDword is { } original) raw = original;
        else if (Native.DrsSettingMap.Toggle(id) is { } toggle)
        {
            if (value.Bool == null) return WriteResult.Fail("Expected an on/off value.");
            raw = value.Bool.Value ? toggle.On : toggle.Off;
        }
        else if (Native.DrsSettingMap.Range(id) is { } range)
        {
            if (value.Number == null || !double.IsFinite(value.Number.Value)) return WriteResult.Fail("Expected a finite number.");
            double clamped = Math.Clamp(value.Number.Value, range.Min, range.Max);
            raw = (uint)Math.Round(clamped);
        }
        else if (Native.DrsSettingMap.Choices(id) is { } choices)
        {
            if (value.Choice == null) return WriteResult.Fail("Expected a choice.");
            if (!choices.TryGetValue(value.Choice, out raw))
                return WriteResult.Fail($"“{value.Choice}” has no documented NVAPI value, so it was not written.");
        }
        else return WriteResult.Fail("No value mapping for this setting.");

        var written = WithSession(true, (session, profile) =>
        {
            var setting = NvapiApi.DrsSetting.Create();
            setting.SettingId = drsId.Value;
            setting.SettingType = NvapiApi.DrsDwordType;
            setting.CurrentValue = raw;

            int r;
            if (value.RestoreNative && value.NativePredefined)
            {
                if (NvapiApi.DrsRestoreDefault == null) return WriteResult.Fail("The driver does not expose restoration of predefined settings.");
                r = NvapiApi.DrsRestoreDefault(session, profile, drsId.Value);
            }
            else r = NvapiApi.DrsSetSetting!(session, profile, ref setting);
            if (!NvapiApi.Ok(r)) return WriteResult.Fail($"NvAPI_DRS_SetSetting returned {r}.");

            r = NvapiApi.DrsSaveSettings!(session);
            if (!NvapiApi.Ok(r)) return WriteResult.Fail($"NvAPI_DRS_SaveSettings returned {r}.");
            return WriteResult.Success;
        }, WriteResult.Fail);
        if (!written.Ok) return written;
        return WithSession(false, (verifySession, verifyProfile) =>
            {
                var actual = NvapiApi.DrsSetting.Create();
                int status = NvapiApi.DrsGetSetting!(verifySession, verifyProfile, drsId.Value, ref actual);
                return NvapiApi.Ok(status) && actual.SettingType == NvapiApi.DrsDwordType && actual.CurrentValue == raw && (!value.RestoreNative || (actual.IsCurrentPredefined != 0) == value.NativePredefined)
                    ? WriteResult.Success : WriteResult.Fail($"The saved NVIDIA setting could not be verified (NVAPI {status}). Refresh before retrying.");
            }, WriteResult.Fail);
    }

    /// <summary>
    /// Opens a DRS session, loads the current settings, hands the base profile to
    /// <paramref name="body"/>, and always destroys the session. A session left open holds the
    /// driver's settings database.
    /// </summary>
    private T WithSession<T>(bool forWrite, Func<IntPtr, IntPtr, T> body, Func<string, T> fail)
    {
        if (!forWrite && _readSession != IntPtr.Zero) return body(_readSession, _readProfile);
        IntPtr session = IntPtr.Zero;
        try
        {
            int r = NvapiApi.DrsCreateSession!(out session);
            if (!NvapiApi.Ok(r)) return fail($"NvAPI_DRS_CreateSession returned {r}.");

            r = NvapiApi.DrsLoadSettings!(session);
            if (!NvapiApi.Ok(r)) return fail($"NvAPI_DRS_LoadSettings returned {r}.");

            r = NvapiApi.DrsGetBaseProfile!(session, out IntPtr profile);
            if (!NvapiApi.Ok(r)) return fail($"NvAPI_DRS_GetBaseProfile returned {r}.");

            return body(session, profile);
        }
        catch (Exception ex) { return fail(ex.Message); }
        finally
        {
            if (session != IntPtr.Zero)
                try { NvapiApi.DrsDestroySession!(session); } catch { }
        }
    }

    public GpuMetricsSample ReadMetrics()
    {
        if (!IsAvailable) return new GpuMetricsSample();

        lock (_gate)
        {
            double? temp = null;
            var thermal = NvapiApi.ThermalSettingsV2.Create();
            if (NvapiApi.GetThermalSettings != null && NvapiApi.Ok(NvapiApi.GetThermalSettings(_gpu, NvapiApi.ThermalTargetAll, ref thermal))
                && thermal.Count > 0)
            {
                foreach (var sensor in thermal.Sensors.Take((int)Math.Min(thermal.Count, 3)))
                    if (sensor.Target == 1 && sensor.CurrentTemp is >= -40 and <= 150) { temp = sensor.CurrentTemp; break; }
            }

            int? gpuClock = null, vramClock = null;
            var clocks = NvapiApi.ClockFrequenciesV3.Create(clockType: 0); // 0 = current
            if (NvapiApi.GetAllClockFrequencies != null && NvapiApi.Ok(NvapiApi.GetAllClockFrequencies(_gpu, ref clocks)))
            {
                var g = clocks.Clocks[NvapiApi.ClockFrequenciesV3.GraphicsClockIndex];
                var m = clocks.Clocks[NvapiApi.ClockFrequenciesV3.MemoryClockIndex];
                if ((g.IsPresent & 1) != 0) gpuClock = (int)Math.Round(g.FrequencyKHz / 1000.0);
                if ((m.IsPresent & 1) != 0) vramClock = (int)Math.Round(m.FrequencyKHz / 1000.0);
            }

            double? usage = null;
            var pstates = NvapiApi.DynamicPerformanceStatesInfoV1.Create();
            if (NvapiApi.GetDynamicPstatesInfoEx != null && NvapiApi.Ok(NvapiApi.GetDynamicPstatesInfoEx(_gpu, ref pstates)))
            {
                var core = pstates.Domains[NvapiApi.DynamicPerformanceStatesInfoV1.GpuCoreIndex];
                if ((core.IsPresent & 1) != 0 && core.Percentage <= 100) usage = core.Percentage;
            }

            // Not yet wired: fan RPM/%, voltage, power draw — all sit behind private interfaces
            // that haven't had their struct layouts individually verified yet (see file header).
            return _nvml.Supplement(new GpuMetricsSample
            {
                FanRpm = NvapiApi.GetTachReading != null && NvapiApi.Ok(NvapiApi.GetTachReading(_gpu, out var rpm)) ? (int)rpm : null,
                GpuUsagePercent = usage,
                GpuClockMhz = gpuClock,
                VramClockMhz = vramClock,
                EdgeTempC = temp,
            }, _name, _singleGpu);
        }
    }

    private int ReadClockMhzOrZero(int clockIndex, uint clockType)
    {
        if (!IsAvailable || NvapiApi.GetAllClockFrequencies == null) return 0;
        var clocks = NvapiApi.ClockFrequenciesV3.Create(clockType);
        if (!NvapiApi.Ok(NvapiApi.GetAllClockFrequencies(_gpu, ref clocks))) return 0;
        var c = clocks.Clocks[clockIndex];
        return c.IsPresent != 0 ? (int)(c.FrequencyKHz / 1000) : 0;
    }

    // Tuning remains unavailable until the native operations can be verified.
    public GpuTuningInfo GetGpuTuning() => new()
    {
        GpuName = _name,
        Available = false,
        Unavailable = TuningUnavailable,
    };

    public WriteResult SetSystemTuningMode(SystemTuningMode mode) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetGpuAutoMode(GpuAutoMode mode) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetGpuManualCustom(bool on) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetFanTuningEnabled(bool on) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetFanAdvancedControl(bool on) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetFanCurve(IReadOnlyList<FanPoint> points) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetPowerTuningEnabled(bool on) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetPowerLimitPercent(double percent) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetGpuClockRange(int minMhz, int maxMhz) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetGpuVoltage(int mv) => WriteResult.Fail(TuningUnavailable);
    public WriteResult SetVramClock(int mhz) => WriteResult.Fail(TuningUnavailable);
    public WriteResult ApplyTuningSnapshot(GpuTuningInfo snapshot) => WriteResult.Fail(TuningUnavailable);

    public void Dispose() { }
}

