namespace Nvidia.Nvapi;

/// <summary>Top-level tuning intent, mirrors the NVIDIA app's "Performance" tuning row.</summary>
public enum SystemTuningMode { Default, AutoOverclock, Custom }

/// <summary>
/// NVIDIA's real automatic tuning is the "Scanner" in the NVIDIA app / GeForce Experience: one
/// unified stability-tested scan that produces a core-clock voltage/frequency curve AND a memory
/// clock offset together in a single pass — there is no separate "undervolt GPU" / "overclock
/// GPU" / "overclock VRAM" split the way AMD Adrenalin exposes three distinct auto-tuning
/// buttons. Deliberately just two states, not a copy of AMD's <c>GpuAutoMode</c>.
/// </summary>
public enum GpuAutoMode { None, AutoTune }

// No GpuPreset enum here: AMD Adrenalin ships built-in "Quiet"/"Balanced" tuning presets: NVIDIA
// has no first-party equivalent (confirmed — its own software offers only the Scanner above, a
// manual curve, or stock). Forcing a preset concept in here to match AMD's shape would just be
// a UI element with nothing real behind it, so it's omitted rather than faked.

public readonly record struct FanPoint(double TempC, double SpeedPercent);

public readonly record struct ValueRange(double Min, double Max, double Step)
{
    public double Clamp(double v) => Math.Min(Max, Math.Max(Min, v));
    public bool IsValid => Max > Min;
    public static readonly ValueRange None = new(0, 0, 1);
}

/// <summary>
/// Everything the Overclocking tab needs to render itself for the current GPU:
/// which capabilities exist, and the live ranges for each control.
/// Filled from NVAPI's (undocumented) GPU tuning / cooler-control interfaces.
/// </summary>
public sealed record GpuTuningInfo
{
    public required string GpuName { get; init; }
    public bool Available { get; init; }
    public string Unavailable { get; init; } = "";

    // current state
    public SystemTuningMode SystemMode { get; init; }
    public GpuAutoMode AutoMode { get; init; }
    public bool ManualCustom { get; init; }

    // capability flags
    public bool SupportsAutoTune { get; init; }
    public bool SupportsManualGpuClock { get; init; }
    public bool SupportsManualVram { get; init; }
    public bool SupportsFanTuning { get; init; }
    public bool SupportsPowerTuning { get; init; }
    public bool SupportsTdc { get; init; }

    // ranges
    public ValueRange GpuClockRange { get; init; } = ValueRange.None;
    public ValueRange GpuVoltageRange { get; init; } = ValueRange.None;
    public ValueRange VramClockRange { get; init; } = ValueRange.None;
    public ValueRange PowerLimitRange { get; init; } = ValueRange.None;   // percent, e.g. 50..125
    public ValueRange TdcRange { get; init; } = ValueRange.None;
    public ValueRange FanSpeedRange { get; init; } = new(0, 100, 1);
    public ValueRange FanTempRange { get; init; } = new(0, 100, 1);
    public int FanPointCount { get; init; } = 5;

    // live manual values
    public bool FanTuningEnabled { get; init; }
    public bool FanAdvancedControl { get; init; }
    public IReadOnlyList<FanPoint> FanCurve { get; init; } = Array.Empty<FanPoint>();

    public bool PowerTuningEnabled { get; init; }
    public double PowerLimitPercent { get; init; }

    public int GpuMinClockMhz { get; init; }
    public int GpuMaxClockMhz { get; init; }
    public int GpuVoltageMv { get; init; }
    public int VramClockMhz { get; init; }
}

public sealed record WriteResult(bool Ok, string Error = "")
{
    public static readonly WriteResult Success = new(true);
    public static WriteResult Fail(string why) => new(false, why);
}
