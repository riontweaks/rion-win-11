namespace Nvidia.Nvapi;

/// <summary>
/// Static description of one GPU, plus the environment facts the System tab shows.
/// Filled from <c>NvAPI_GPU_Get*</c> identity calls and the NVAPI version query.
/// </summary>
public sealed record GpuInfo
{
    public required string Name { get; init; }
    public required string AsicFamily { get; init; }          // e.g. "Ada Lovelace (AD104)"
    public required string VramType { get; init; }            // e.g. "GDDR6X"
    public required int VramSizeMb { get; init; }
    public required int CoreClockMhz { get; init; }           // rated
    public required int MemoryClockMhz { get; init; }         // rated (effective)
    public required string BusInterface { get; init; }        // e.g. "PCIe 4.0 x16"
    public required string VbiosVersion { get; init; }
    public required string DriverVersion { get; init; }       // GeForce driver package version
    public required string DriverDate { get; init; }
    public required string VendorId { get; init; }
    public required string DeviceId { get; init; }
    public required bool IsExternal { get; init; }
    public required bool HasDesktop { get; init; }
    public required int TotalBoardPowerW { get; init; }       // rated TGP

    // environment
    public required string NvapiVersion { get; init; }
    public required string NvapiDllPath { get; init; }
    public required bool NvapiInitialized { get; init; }
    public required string InitNote { get; init; }            // why it did / didn't initialise
}
