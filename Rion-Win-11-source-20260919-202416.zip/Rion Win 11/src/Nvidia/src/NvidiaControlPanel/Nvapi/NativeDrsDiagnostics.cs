using System.Buffers.Binary;
using System.Runtime.InteropServices;
using System.Text;
using Nvidia.Catalog;
using Nvidia.Nvapi.Native;

namespace Nvidia.Nvapi;

public sealed partial class NativeNvapiProvider
{
    public SettingValue ReadDefault(SettingId id)
    {
        lock (_gate)
        {
            if (!IsAvailable || !NvapiApi.DrsReadAvailable)
                return SettingValue.Unsupported("NVIDIA DRS defaults are unavailable.");
            if (DrsSettingMap.DrsId(id) is not { } nativeId)
                return SettingValue.Unsupported(UnavailableSettingReason(id));
            if (NvapiApi.DrsRestoreDefault == null)
                return SettingValue.Unsupported("The driver cannot restore a predefined setting exactly.");
            return WithSession(false, (session, profile) =>
            {
                var native = NvapiApi.DrsSetting.Create();
                int status = NvapiApi.DrsGetSetting!(session, profile, nativeId, ref native);
                if (!NvapiApi.Ok(status)) return SettingValue.Unsupported($"Reading the predefined value failed (NVAPI {status}).");
                return DecodeDefault(id, native);
            }, SettingValue.Unsupported);
        }
    }

    internal static SettingValue DecodeDefault(SettingId id, NvapiApi.DrsSetting native)
    {
        if (native.SettingType != NvapiApi.DrsDwordType || native.IsPredefinedValid == 0)
            return SettingValue.Unsupported("The driver did not return a valid predefined DWORD value.");
        uint raw = native.PredefinedValue;
        SettingValue? decoded = null;
        if (DrsSettingMap.Toggle(id) is { } toggle)
            decoded = raw == toggle.On ? SettingValue.Of(true) : raw == toggle.Off ? SettingValue.Of(false) : null;
        else if (DrsSettingMap.Range(id) is { } range && raw >= range.Min && raw <= range.Max)
            decoded = SettingValue.Of(raw, range.Min, range.Max);
        else if (DrsSettingMap.Choices(id) is { } choices)
        {
            foreach (var choice in choices)
                if (choice.Value == raw) { decoded = SettingValue.Of(choice.Key); break; }
        }
        return decoded is null ? SettingValue.Unsupported($"Unmapped predefined DWORD 0x{raw:X8}; no default was guessed.")
            : decoded with { NativeDword = raw, NativePredefined = true, RestoreNative = true };
    }

    /// <summary>Enumerates only the base profile. Call from a worker, not the WPF dispatcher.</summary>
    public DrsDiagnosticSnapshot ReadDrsDiagnostics(CancellationToken cancellationToken = default)
    {
        lock (_gate)
        {
            if (!IsAvailable || !NvapiApi.DrsReadAvailable || NvapiApi.DrsEnumSettings == null)
                return DrsDiagnosticSnapshot.Unavailable("The driver does not expose read-only DRS enumeration.");
            return WithSession(false, (session, profile) => EnumerateDrs(session, profile, cancellationToken), DrsDiagnosticSnapshot.Unavailable);
        }
    }

    private static DrsDiagnosticSnapshot EnumerateDrs(IntPtr session, IntPtr profile, CancellationToken token)
    {
        const int capacity = 32, maximum = 4096;
        int size = Marshal.SizeOf<NvapiApi.DrsSetting>();
        var rows = new List<DrsDiagnosticSetting>();
        var ids = new HashSet<uint>();
        IntPtr buffer = Marshal.AllocHGlobal(size * capacity);
        try
        {
            for (uint start = 0; start < maximum;)
            {
                if (token.IsCancellationRequested) return new("NVAPI/base-profile", false, rows.ToArray(), "Enumeration cancelled.");
                for (int i = 0; i < capacity; i++)
                {
                    var setting = NvapiApi.DrsSetting.Create();
                    // Each union begins with binary buffer capacity; the driver overwrites typed values.
                    setting.CurrentValue = setting.PredefinedValue = NvapiApi.BinaryDataMax;
                    Marshal.StructureToPtr(setting, buffer + i * size, false);
                }
                uint count = capacity;
                int status = NvapiApi.DrsEnumSettings!(session, profile, start, ref count, buffer);
                if (status == -7) return new("NVAPI/base-profile", true, rows.ToArray()); // NVAPI_END_ENUMERATION
                if (status != 0 || count > capacity)
                    return new("NVAPI/base-profile", false, rows.ToArray(), $"DRS enumeration failed (NVAPI {status}, count {count}).");
                if (count == 0) return new("NVAPI/base-profile", true, rows.ToArray());
                for (int i = 0; i < count; i++)
                {
                    var row = DecodeDiagnostic(Marshal.PtrToStructure<NvapiApi.DrsSetting>(buffer + i * size));
                    if (!ids.Add(row.SettingId)) return new("NVAPI/base-profile", false, rows.ToArray(), "Duplicate setting identity returned by the driver.");
                    rows.Add(row);
                }
                start += count;
            }
            return new("NVAPI/base-profile", false, rows.ToArray(), "Enumeration reached its 4096-setting safety limit.");
        }
        finally { Marshal.FreeHGlobal(buffer); }
    }

    internal static DrsDiagnosticSetting DecodeDiagnostic(NvapiApi.DrsSetting native)
    {
        string name = new((native.SettingName ?? []).TakeWhile(c => c != 0).Select(c => (char)c).ToArray());
        return new(native.SettingId, name, native.SettingType, native.SettingLocation,
            native.IsCurrentPredefined, native.IsPredefinedValid,
            DecodeRaw(native.SettingType, native.CurrentValue, native.CurrentPadding),
            native.IsPredefinedValid != 0 ? DecodeRaw(native.SettingType, native.PredefinedValue, native.PredefinedPadding) : null);
    }

    private static DrsRawValue DecodeRaw(uint type, uint first, byte[]? rest)
    {
        byte[] union = new byte[4 + NvapiApi.BinaryDataMax];
        BinaryPrimitives.WriteUInt32LittleEndian(union, first);
        if (rest == null || rest.Length != NvapiApi.BinaryDataMax)
            return new(type, Convert.ToHexString(union), null, false, "Incomplete native value storage.");
        rest.CopyTo(union, 4);
        string hex = Convert.ToHexString(union);
        return type switch
        {
            0 => new(type, Convert.ToHexString(union.AsSpan(0, 4)), $"0x{first:X8}", true),
            1 when first <= NvapiApi.BinaryDataMax => new(type, Convert.ToHexString(union.AsSpan(0, checked(4 + (int)first))), Convert.ToHexString(rest.AsSpan(0, (int)first)), true),
            1 => new(type, hex, null, false, "Binary length exceeds the documented buffer."),
            2 => StringValue(type, union, false),
            3 => StringValue(type, union, true),
            4 => new(type, Convert.ToHexString(union.AsSpan(0, 8)), $"0x{BinaryPrimitives.ReadUInt64LittleEndian(union):X16}", true),
            _ => new(type, hex, null, false, "Unknown setting type; raw storage retained without interpretation."),
        };
    }

    private static DrsRawValue StringValue(uint type, byte[] union, bool wide)
    {
        int max = NvapiApi.UnicodeStringMax * 2;
        int end = 0;
        while (end < max && (union[end] != 0 || wide && union[end + 1] != 0)) end += wide ? 2 : 1;
        if (end == max) return new(type, Convert.ToHexString(union.AsSpan(0, max)), null, false, "String is not terminated.");
        // Narrow strings have no documented encoding guarantee; retain exact bytes, do not invent Unicode text.
        return new(type, Convert.ToHexString(union.AsSpan(0, end + (wide ? 2 : 1))),
            wide ? Encoding.Unicode.GetString(union, 0, end) : null, true);
    }
}
