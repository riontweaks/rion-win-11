using Nvidia.Catalog;
using Nvidia.Nvapi.Native;
namespace Nvidia.Nvapi;
public sealed partial class NativeNvapiProvider
{
    private SettingValue ReadHdcpSupport()
    {
        if (!IsAvailable || NvapiApi.GetHdcpSupport == null)
            return SettingValue.Unsupported("The NVIDIA driver does not expose GPU HDCP capability detection.");
        var status = NvapiApi.HdcpSupport.Create();
        int result = NvapiApi.GetHdcpSupport(_gpu, ref status);
        if (!NvapiApi.Ok(result)) return SettingValue.Unsupported($"GPU HDCP capability query returned NVAPI {result}.");
        return status.FuseState == 2 && status.KeySourceState == 2 ? SettingValue.Of("Supported (GPU capability)")
            : status.FuseState == 1 || status.KeySourceState == 1 ? SettingValue.Of("Not supported (GPU capability)")
            : SettingValue.Unsupported("GPU HDCP capability is unknown; this does not report active display-link protection.");
    }

    private uint? _colorDisplay;
    private uint? ColorDisplay
    {
        get
        {
            var active = NvapiApi.ActiveDisplays(_gpu);
            _colorDisplay ??= active.Select(id => (uint?)id).FirstOrDefault();
            return _colorDisplay is { } selected && active.Contains(selected) ? selected : null;
        }
    }
    public string SelectedDisplayId { get { lock (_gate) return _colorDisplay?.ToString() ?? ""; } }
    public IReadOnlyList<DisplayInfo> GetDisplays()
    {
        lock (_gate)
        {
            var active = NvapiApi.ActiveDisplays(_gpu);
            _colorDisplay ??= active.Select(id => (uint?)id).FirstOrDefault();
            return active.Select(id => new DisplayInfo(id.ToString(), $"NVIDIA display · {id}")).ToArray();
        }
    }
    public WriteResult SelectDisplay(string id)
    {
        lock (_gate)
        {
            if (!uint.TryParse(id, out var display) || !NvapiApi.ActiveDisplays(_gpu).Contains(display))
                return WriteResult.Fail("The display is no longer active. Re-detect displays.");
            _colorDisplay = display;
            return WriteResult.Success;
        }
    }
    private SettingValue ReadColor(SettingId id)
    {
        if (!IsAvailable || NvapiApi.ColorControl == null || ColorDisplay is not { } display)
            return SettingValue.Unsupported("No active display connected to this NVIDIA GPU.");
        var data = NvapiApi.ColorData.Create();
        int status = NvapiApi.ColorControl(display, ref data);
        if (!NvapiApi.Ok(status)) return SettingValue.Unsupported($"NVAPI colour query returned {status}.");
        string? value = id == SettingId.Display_DynamicRange
            ? data.DynamicRange switch { 0 => "full", 1 => "limited", _ => null }
            : id == SettingId.Display_ColorDepth
            ? data.Bpc switch { 1 => "6", 2 => "8", 3 => "10", 4 => "12", 5 => "16", _ => null }
            : data.Format switch { 0 => "rgb", 1 => "ycbcr422", 2 => "ycbcr444", 3 => "ycbcr420", _ => null };
        return value == null ? SettingValue.Unsupported("Driver-selected automatic colour mode.") : SettingValue.Of(value) with { NativeColorPolicy = data.SelectionPolicy };
    }
    private WriteResult WriteColor(SettingId id, SettingValue value)
    {
        if (!IsAvailable || NvapiApi.ColorControl == null || ColorDisplay is not { } display)
            return WriteResult.Fail("No active NVIDIA display.");
        var data = NvapiApi.ColorData.Create();
        if (!NvapiApi.Ok(NvapiApi.ColorControl(display, ref data))) return WriteResult.Fail("Could not read the current display colour state.");
        if (id == SettingId.Display_DynamicRange)
        {
            byte? range = value.Choice switch { "full" => 0, "limited" => 1, _ => (byte?)null };
            if (!range.HasValue) return WriteResult.Fail("Unknown output dynamic range.");
            data.DynamicRange = range.Value;
        }
        else if (id == SettingId.Display_ColorDepth)
        {
            uint? bpc = value.Choice switch { "6" => 1u, "8" => 2u, "10" => 3u, "12" => 4u, "16" => 5u, _ => null };
            if (!bpc.HasValue) return WriteResult.Fail("Unknown colour depth.");
            data.Bpc = bpc.Value;
        }
        else
        {
            byte? format = value.Choice switch { "rgb" => 0, "ycbcr422" => 1, "ycbcr444" => 2, "ycbcr420" => 3, _ => (byte?)null };
            if (!format.HasValue) return WriteResult.Fail("Unknown colour format.");
            data.Format = format.Value;
        }
        data.SelectionPolicy = value.RestoreNative && value.NativeColorPolicy is { } policy ? policy : 0; // USER
        data.Command = 3; // IS_SUPPORTED_COLOR: check this exact combination before setting it.
        if (!NvapiApi.Ok(NvapiApi.ColorControl(display, ref data))) return WriteResult.Fail("This display does not support that colour combination at its current refresh rate.");
        data.Command = 2;
        int result = NvapiApi.ColorControl(display, ref data);
        if (!NvapiApi.Ok(result)) return WriteResult.Fail($"NVAPI colour change returned {result}.");
        var actual = ReadColor(id);
        return actual.Supported && actual.Choice == value.Choice && actual.NativeColorPolicy == data.SelectionPolicy
            ? WriteResult.Success : WriteResult.Fail("Colour readback did not match. Restore the previous value.");
    }
}
