using Nvidia.Catalog;

namespace Nvidia.Nvapi;

/// <summary>
/// Driver access used by the UI. Unsupported reads and rejected writes carry a reason.
/// Mock providers are injected explicitly by tests; production uses native or unavailable providers.
/// </summary>
public interface INvapiProvider : IDisposable
{
    string DisplayName { get; }
    bool IsAvailable { get; }
    bool IsMock { get; }
    IReadOnlyList<DisplayInfo> GetDisplays() => Array.Empty<DisplayInfo>();
    string SelectedDisplayId => "";
    WriteResult SelectDisplay(string id) => WriteResult.Fail("Display selection is unavailable.");

    void Initialize();

    GpuInfo GetGpuInfo();

    // ---- discrete settings (Display + Performance tabs) --------------------
    SettingValue Read(SettingId id);
    SettingValue ReadDefault(SettingId id) => SettingValue.Unsupported("Driver defaults are unavailable from this provider.");
    DrsDiagnosticSnapshot ReadDrsDiagnostics(CancellationToken cancellationToken = default) =>
        DrsDiagnosticSnapshot.Unavailable("Read-only DRS diagnostics are unavailable from this provider.");
    IReadOnlyDictionary<SettingId, SettingValue> ReadMany(IEnumerable<SettingId> ids) => ids.Distinct().ToDictionary(id => id, Read);
    WriteResult Write(SettingId id, SettingValue value);

    // ---- performance monitoring ------------------------------------------
    GpuMetricsSample ReadMetrics();

    // ---- GPU tuning (Overclocking tab) ----------------------------------
    GpuTuningInfo GetGpuTuning();
    WriteResult SetSystemTuningMode(SystemTuningMode mode);
    WriteResult SetGpuAutoMode(GpuAutoMode mode);
    WriteResult SetGpuManualCustom(bool on);

    WriteResult SetFanTuningEnabled(bool on);
    WriteResult SetFanAdvancedControl(bool on);
    WriteResult SetFanCurve(IReadOnlyList<FanPoint> points);

    WriteResult SetPowerTuningEnabled(bool on);
    WriteResult SetPowerLimitPercent(double percent);

    WriteResult SetGpuClockRange(int minMhz, int maxMhz);
    WriteResult SetGpuVoltage(int mv);
    WriteResult SetVramClock(int mhz);

    /// <summary>Re-apply a captured snapshot (used by "Reset to default" / first-touch revert).</summary>
    WriteResult ApplyTuningSnapshot(GpuTuningInfo snapshot);
}
