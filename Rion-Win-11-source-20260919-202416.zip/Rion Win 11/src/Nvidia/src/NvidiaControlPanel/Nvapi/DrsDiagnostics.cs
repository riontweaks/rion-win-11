namespace Nvidia.Nvapi;

/// <summary>Read-only DRS metadata. Numeric type/location fields retain unknown future values.</summary>
public sealed record DrsRawValue(uint Type, string RawHex, string? Display, bool Valid, string Error = "");
public sealed record DrsDiagnosticSetting(uint SettingId, string Name, uint Type, uint Location,
    uint IsCurrentPredefined, uint IsPredefinedValid, DrsRawValue Current, DrsRawValue? Predefined);
public sealed record DrsDiagnosticSnapshot(string ProfileIdentity, bool Complete,
    IReadOnlyList<DrsDiagnosticSetting> Settings, string Error = "")
{
    public static DrsDiagnosticSnapshot Unavailable(string error) => new("NVAPI/base-profile", false, [], error);
}
public sealed record DrsSettingDifference(uint SettingId, DrsDiagnosticSetting? Before, DrsDiagnosticSetting? After);
public sealed record DrsDiagnosticComparison(bool Comparable, IReadOnlyList<DrsSettingDifference> Changes, string Error = "");

public static class DrsDiagnostics
{
    /// <summary>Compare by profile scope and numeric setting identity, never friendly names or order.</summary>
    public static DrsDiagnosticComparison Compare(DrsDiagnosticSnapshot before, DrsDiagnosticSnapshot after)
    {
        if (!before.Complete || !after.Complete)
            return new(false, [], "Incomplete snapshots cannot prove additions or removals.");
        if (before.ProfileIdentity != after.ProfileIdentity)
            return new(false, [], "The snapshots have different profile identities.");
        if (before.Settings.GroupBy(s => s.SettingId).Any(g => g.Count() != 1) ||
            after.Settings.GroupBy(s => s.SettingId).Any(g => g.Count() != 1))
            return new(false, [], "Duplicate setting identities make this comparison ambiguous.");
        var left = before.Settings.ToDictionary(s => s.SettingId);
        var right = after.Settings.ToDictionary(s => s.SettingId);
        var changes = left.Keys.Union(right.Keys).OrderBy(id => id)
            .Select(id => new DrsSettingDifference(id, left.GetValueOrDefault(id), right.GetValueOrDefault(id)))
            .Where(d => d.Before != d.After).ToArray();
        return new(true, changes);
    }
}
