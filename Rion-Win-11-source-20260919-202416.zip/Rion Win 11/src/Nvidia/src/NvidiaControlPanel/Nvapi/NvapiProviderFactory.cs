namespace Nvidia.Nvapi;

/// <summary>Connects to the installed driver; unavailable hardware never becomes a simulated GPU.</summary>
public static class NvapiProviderFactory
{
    public static INvapiProvider Create()
    {
        var native = new NativeNvapiProvider();
        string reason;
        try
        {
            native.Initialize();
            if (native.IsAvailable) return native;
            reason = native.GetGpuInfo().InitNote;
        }
        catch (Exception ex)
        {
            reason = "NVAPI initialization failed: " + ex.Message;
        }
        try { native.Dispose(); }
        catch (Exception ex) { reason += " Cleanup failed: " + ex.Message; }
        return new UnavailableNvapiProvider(string.IsNullOrWhiteSpace(reason)
            ? "No compatible NVIDIA driver connection." : reason);
    }
}
