using Nvidia.Catalog;

namespace Nvidia.Nvapi;

/// <summary>
/// Hardware-free stand-in: models a desktop GeForce RTX 4070 on a recent Game Ready driver.
/// Writes mutate in-memory state and are echoed straight back on the next read,
/// so the whole immediate-apply / snapshot / revert flow is exercised with no driver.
/// </summary>
public sealed class MockNvapiProvider : INvapiProvider
{
    private readonly Random _rng = new(20260903);
    private readonly Dictionary<SettingId, SettingValue> _v = new();
    private readonly Dictionary<SettingId, SettingValue> _defaults = new();

    private SystemTuningMode _sysMode = SystemTuningMode.Default;
    private GpuAutoMode _autoMode = GpuAutoMode.None;
    private bool _manualCustom;
    private bool _fanEnabled, _fanAdvanced;
    private bool _powerEnabled;
    private double _powerPct = 100;
    private int _gpuOffset, _gpuMv = 1050, _vramOffset;
    private List<FanPoint> _fan = new()
    {
        new(30, 0), new(50, 25), new(65, 45), new(80, 68), new(90, 100),
    };

    public string DisplayName => "Mock device — GeForce RTX 4070 (no driver)";
    public bool IsAvailable { get; private set; }
    public bool IsMock => true;

    public void Initialize()
    {
        IsAvailable = true; Seed(); _defaults.Clear();
        foreach (var pair in _v) _defaults[pair.Key] = pair.Value;
    }

    public SettingValue ReadDefault(SettingId id) => _defaults.TryGetValue(id, out var value)
        && Native.DrsSettingMap.DrsId(id) != null ? value
        : SettingValue.Unsupported("No initialized, mapped mock default for this setting.");

    public GpuInfo GetGpuInfo() => new()
    {
        Name = "NVIDIA GeForce RTX 4070",
        AsicFamily = "Ada Lovelace (AD104)",
        VramType = "GDDR6X",
        VramSizeMb = 12288,
        CoreClockMhz = 2475,
        MemoryClockMhz = 21000,
        BusInterface = "PCIe 4.0 x16",
        VbiosVersion = "95.07.1B.40.92",
        DriverVersion = "566.14 (Game Ready Driver)",
        DriverDate = "2026-08-20",
        VendorId = "0x10DE",
        DeviceId = "0x2786",
        IsExternal = false,
        HasDesktop = true,
        TotalBoardPowerW = 200,
        NvapiVersion = "R560 (mock)",
        NvapiDllPath = @"(mock) C:\Windows\System32\nvapi64.dll",
        NvapiInitialized = true,
        InitNote = "Mock provider — no native NVAPI call has been made. Real hardware validation is a later build stage.",
    };

    public SettingValue Read(SettingId id) =>
        _v.TryGetValue(id, out var v) ? v : SettingValue.Unsupported("Not modelled by the mock provider.");

    public WriteResult Write(SettingId id, SettingValue value)
    {
        if (!_v.TryGetValue(id, out var cur) || !cur.Supported)
            return WriteResult.Fail("Setting not supported on this device.");
        _v[id] = cur with { Bool = value.Bool ?? cur.Bool, Choice = value.Choice ?? cur.Choice, Number = value.Number ?? cur.Number };
        return WriteResult.Success;
    }

    public GpuMetricsSample ReadMetrics()
    {
        double J(double mid, double spread) => mid + (_rng.NextDouble() - 0.5) * spread;
        var loadFactor = _powerEnabled ? _powerPct / 100.0 : 1;
        double edgeTemp = J(56, 6);

        // No explicit "Zero RPM" toggle exists on NVIDIA — fan stop is just what happens when
        // the curve's lowest point is 0%. Simulate it the same way here instead of a flag.
        double fanFloorSpeed = _fan.OrderBy(p => p.TempC).First().SpeedPercent;
        bool fanStopped = fanFloorSpeed <= 0 && edgeTemp < _fan.Min(p => p.TempC) + 15;

        return new GpuMetricsSample
        {
            GpuUsagePercent = Math.Clamp(J(38, 30), 0, 100),
            GpuClockMhz = (int)J(2475 * loadFactor, 140),
            VramClockMhz = 10500 + _vramOffset,
            EdgeTempC = edgeTemp,
            HotspotTempC = J(70, 8),
            PowerW = J(150 * loadFactor, 35),
            BoardPowerW = J(170 * loadFactor, 38),
            FanRpm = fanStopped ? 0 : (int)J(1450, 220),
            FanPercent = fanStopped ? 0 : J(38, 12),
            VoltageMv = (int)J(_gpuMv - 100, 35),
            VramUsedMb = J(6200, 1100),
            Fps = (int)J(146, 26),
            CpuUsagePercent = Math.Clamp(J(19, 15), 0, 100),
            SystemRamUsedMb = J(17800, 1400),
        };
    }

    // ---- tuning ----------------------------------------------------------
    public GpuTuningInfo GetGpuTuning() => new()
    {
        GpuName = "NVIDIA GeForce RTX 4070 (Primary)",
        Available = true,
        SystemMode = _sysMode,
        AutoMode = _autoMode,
        ManualCustom = _manualCustom,
        SupportsAutoTune = true,
        SupportsManualGpuClock = true,
        SupportsManualVram = true,
        SupportsFanTuning = true,
        SupportsPowerTuning = true,
        SupportsTdc = false,
        GpuClockRange = new(-250, 300, 5),     // NVIDIA exposes an offset, not an absolute range
        GpuVoltageRange = new(900, 1100, 5),
        VramClockRange = new(-500, 1500, 10),  // offset, effective MHz
        PowerLimitRange = new(50, 125, 1),     // percent of rated TGP
        FanSpeedRange = new(0, 100, 1),
        FanTempRange = new(20, 100, 1),
        FanPointCount = 5,
        FanTuningEnabled = _fanEnabled,
        FanAdvancedControl = _fanAdvanced,
        FanCurve = _fan.ToArray(),
        PowerTuningEnabled = _powerEnabled,
        PowerLimitPercent = _powerPct,
        GpuMinClockMhz = _gpuOffset,
        GpuMaxClockMhz = _gpuOffset,
        GpuVoltageMv = _gpuMv,
        VramClockMhz = _vramOffset,
    };

    public WriteResult SetSystemTuningMode(SystemTuningMode mode)
    {
        _sysMode = mode;
        if (mode != SystemTuningMode.Custom) { _manualCustom = false; }
        return WriteResult.Success;
    }

    public WriteResult SetGpuAutoMode(GpuAutoMode mode)
    {
        _autoMode = mode;
        if (mode != GpuAutoMode.None) { _manualCustom = false; }
        return WriteResult.Success;
    }

    public WriteResult SetGpuManualCustom(bool on)
    {
        _manualCustom = on;
        if (on) { _autoMode = GpuAutoMode.None; }
        return WriteResult.Success;
    }

    public WriteResult SetFanTuningEnabled(bool on) { _fanEnabled = on; return WriteResult.Success; }
    public WriteResult SetFanAdvancedControl(bool on) { _fanAdvanced = on; return WriteResult.Success; }

    public WriteResult SetFanCurve(IReadOnlyList<FanPoint> points)
    {
        if (points.Count < 2) return WriteResult.Fail("Need at least two points.");
        _fan = points.OrderBy(p => p.TempC).ToList();
        return WriteResult.Success;
    }

    public WriteResult SetPowerTuningEnabled(bool on) { _powerEnabled = on; return WriteResult.Success; }

    public WriteResult SetPowerLimitPercent(double percent)
    {
        _powerPct = new ValueRange(50, 125, 1).Clamp(percent);
        return WriteResult.Success;
    }

    public WriteResult SetGpuClockRange(int minMhz, int maxMhz)
    {
        _gpuOffset = maxMhz; // NVIDIA has a single core-clock offset, not a min/max pair
        return WriteResult.Success;
    }

    public WriteResult SetGpuVoltage(int mv) { _gpuMv = mv; return WriteResult.Success; }
    public WriteResult SetVramClock(int mhz) { _vramOffset = mhz; return WriteResult.Success; }

    public WriteResult ApplyTuningSnapshot(GpuTuningInfo s)
    {
        _sysMode = s.SystemMode; _autoMode = s.AutoMode; _manualCustom = s.ManualCustom;
        _fanEnabled = s.FanTuningEnabled; _fanAdvanced = s.FanAdvancedControl;
        _fan = s.FanCurve.OrderBy(p => p.TempC).ToList();
        _powerEnabled = s.PowerTuningEnabled; _powerPct = s.PowerLimitPercent;
        _gpuOffset = s.GpuMaxClockMhz; _gpuMv = s.GpuVoltageMv; _vramOffset = s.VramClockMhz;
        return WriteResult.Success;
    }

    public void Dispose() { }

    // ---- seed ----------------------------------------------------------
    private void Seed()
    {
        void S(SettingId id, SettingValue v) => _v[id] = v;

        S(SettingId.Display_GSync, SettingValue.Of("fullscreen"));
        S(SettingId.Display_Dsr, SettingValue.Of(false));
        S(SettingId.Display_DsrSmoothness, SettingValue.Of(33, 0, 100, 1));
        S(SettingId.Display_GpuScaling, SettingValue.Of(false));
        S(SettingId.Display_ScalingMode, SettingValue.Of("aspect"));
        S(SettingId.Display_IntegerScaling, SettingValue.Of(false));
        S(SettingId.Display_ColorDepth, SettingValue.Of("8"));
        S(SettingId.Display_ColorFormat, SettingValue.Of("rgb"));
        S(SettingId.Display_DynamicRange, SettingValue.Of("full"));
        foreach (var entry in AdditionalGraphicsSettings.Entries)
            S(entry.Definition.Id, SettingValue.Of(entry.Values.Keys.First()));
        S(SettingId.Display_Hdcp, SettingValue.Of(true));

        S(SettingId.Perf_LowLatencyMode, SettingValue.Of("on"));
        S(SettingId.Perf_ReflexBoost, SettingValue.Of(false));
        S(SettingId.Perf_ImageScaling, SettingValue.Of(false));
        S(SettingId.Perf_ImageScalingSharpness, SettingValue.Of(50, 0, 100, 1));
        S(SettingId.Perf_VerticalSync, SettingValue.Of("off"));
        S(SettingId.Perf_FrameRateLimiter, SettingValue.Of(0, 0, 360, 1));
        S(SettingId.Perf_AntiAliasingMode, SettingValue.Of("app"));
        S(SettingId.Perf_AntiAliasingLevel, SettingValue.Of("4x"));
        S(SettingId.Perf_AntiAliasingMethod, SettingValue.Of(false));
        S(SettingId.Perf_AnisotropicFiltering, SettingValue.Of("app"));
        S(SettingId.Perf_AnisotropicLevel, SettingValue.Of("8x"));
        S(SettingId.Perf_TextureFilteringQuality, SettingValue.Of("quality"));
        S(SettingId.Perf_ThreadedOptimization, SettingValue.Of("auto"));
        S(SettingId.Perf_TripleBuffering, SettingValue.Of(false));
        S(SettingId.Perf_ShaderCache, SettingValue.Of("on"));
        S(SettingId.Perf_PowerManagementMode, SettingValue.Of("adaptive"));
    }
}
