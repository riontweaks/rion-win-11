using System.Runtime.InteropServices;

namespace Nvidia.Nvapi.Native;

internal static partial class NvapiApi
{
    // nvapi.h NV_DISPLAYCONFIG_PATH_INFO_V2 / TARGET_INFO_V2, Windows x64 ABI.
    [StructLayout(LayoutKind.Sequential)]
    internal struct DisplayPath
    {
        public uint Version, SourceId, TargetCount;
        public IntPtr Targets, SourceMode;
        public uint Flags;
        public IntPtr OsAdapterId;
    }
    [StructLayout(LayoutKind.Sequential)]
    internal struct DisplayTarget
    {
        public uint DisplayId;
        public IntPtr Details;
        public uint TargetId;
    }
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate int GetDisplayConfigFn(ref uint count, IntPtr paths);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate int SetDisplayConfigFn(uint count, IntPtr paths, uint flags);
    internal static GetDisplayConfigFn? GetDisplayConfig;
    internal static SetDisplayConfigFn? SetDisplayConfig;

    /// <summary>Owns all buffers for a complete topology. Only the selected scaling DWORD is edited.</summary>
    internal sealed class DisplayConfiguration : IDisposable
    {
        internal const int AdvancedSize = 128, SourceSize = 32;
        private readonly List<IntPtr> _allocations = new();
        private readonly Dictionary<uint, IntPtr> _details = new();
        internal IntPtr Paths { get; private set; }
        internal uint Count { get; private set; }

        private IntPtr Allocate(int size)
        {
            var pointer = Marshal.AllocHGlobal(size);
            _allocations.Add(pointer);
            Marshal.Copy(new byte[size], 0, pointer, size);
            return pointer;
        }

        internal static DisplayConfiguration Read()
        {
            if (GetDisplayConfig == null) throw new InvalidOperationException("NVIDIA display configuration API is unavailable.");
            var result = new DisplayConfiguration();
            try { result.Load(); return result; }
            catch { result.Dispose(); throw; }
        }

        private void Load()
        {
            uint count = 0;
            Require(GetDisplayConfig!(ref count, IntPtr.Zero), "count display paths");
            if (count == 0 || count > 64) throw new InvalidOperationException("No usable NVIDIA display topology.");
            Count = count;
            int pathSize = Marshal.SizeOf<DisplayPath>(), targetSize = Marshal.SizeOf<DisplayTarget>();
            Paths = Allocate(checked((int)count * pathSize));
            for (int i = 0; i < Count; i++)
                Marshal.StructureToPtr(new DisplayPath { Version = (uint)pathSize | (2u << 16), OsAdapterId = Allocate(8) }, Paths + i * pathSize, false);
            Require(GetDisplayConfig!(ref count, Paths), "read display path sizes");
            if (count != Count) throw new InvalidOperationException("Display topology changed. Refresh before editing.");
            var expected = new DisplayPath[Count];
            var targetPointers = new IntPtr[Count][];
            for (int i = 0; i < Count; i++)
            {
                var path = Marshal.PtrToStructure<DisplayPath>(Paths + i * pathSize);
                if (path.TargetCount == 0 || path.TargetCount > 64) throw new InvalidOperationException("Invalid display target count.");
                path.Targets = Allocate(checked((int)path.TargetCount * targetSize));
                path.SourceMode = Allocate(SourceSize);
                targetPointers[i] = new IntPtr[path.TargetCount];
                for (int j = 0; j < path.TargetCount; j++)
                {
                    IntPtr details = (path.Flags & 1) == 0 ? Allocate(AdvancedSize) : IntPtr.Zero;
                    if (details != IntPtr.Zero) Marshal.WriteInt32(details, AdvancedSize | (1 << 16));
                    targetPointers[i][j] = details;
                    Marshal.StructureToPtr(new DisplayTarget { Details = details }, path.Targets + j * targetSize, false);
                }
                expected[i] = path;
                Marshal.StructureToPtr(path, Paths + i * pathSize, false);
            }
            Require(GetDisplayConfig!(ref count, Paths), "read display configuration");
            if (count != Count) throw new InvalidOperationException("Display topology changed. Refresh before editing.");
            for (int i = 0; i < Count; i++)
            {
                var path = Marshal.PtrToStructure<DisplayPath>(Paths + i * pathSize);
                if (path.TargetCount != expected[i].TargetCount || path.Targets != expected[i].Targets ||
                    path.SourceMode != expected[i].SourceMode || path.OsAdapterId != expected[i].OsAdapterId)
                    throw new InvalidOperationException("Display topology changed during detection.");
                for (int j = 0; j < path.TargetCount; j++)
                {
                    var target = Marshal.PtrToStructure<DisplayTarget>(path.Targets + j * targetSize);
                    if (target.Details != targetPointers[i][j]) throw new InvalidOperationException("Display target changed during detection.");
                    if (target.Details != IntPtr.Zero && !_details.TryAdd(target.DisplayId, target.Details))
                        throw new InvalidOperationException("Ambiguous display target identity.");
                }
            }
        }

        internal int Scaling(uint displayId) => _details.TryGetValue(displayId, out var details)
            ? Marshal.ReadInt32(details, 8) : throw new InvalidOperationException("Selected NVIDIA display is no longer active.");
        internal void SetScaling(uint displayId, int value)
        {
            _ = Scaling(displayId);
            Marshal.WriteInt32(_details[displayId], 8, value);
        }
        internal void Apply()
        {
            if (SetDisplayConfig == null) throw new InvalidOperationException("NVIDIA display configuration writes are unavailable.");
            Require(SetDisplayConfig(Count, Paths, 1), "validate scaling with the current topology");
            Require(SetDisplayConfig(Count, Paths, 2), "apply scaling");
        }
        private static void Require(int status, string operation)
        {
            if (!Ok(status)) throw new InvalidOperationException($"Could not {operation} (NVAPI {status}).");
        }
        public void Dispose()
        {
            foreach (var pointer in _allocations) Marshal.FreeHGlobal(pointer);
            _allocations.Clear();
        }
    }
}
