using System.Runtime.InteropServices;
using System.Text;

namespace Nvidia.Nvapi.Native;

/// <summary>Optional, read-only NVML telemetry. Never combines readings from different adapters.</summary>
internal sealed class NvmlTelemetry
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int Init();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int Count(out uint count);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int Handle(uint index, out IntPtr device);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int Name(IntPtr device, StringBuilder name, uint size);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int ReadUInt(IntPtr device, out uint value);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int ReadDomain(IntPtr device, uint domain, out uint value);
    [StructLayout(LayoutKind.Sequential)] private struct Utilization { public uint Gpu, Memory; }
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int ReadUtilization(IntPtr device, out Utilization value);
    private IntPtr _library, _device;
    private bool _attempted;
    private ReadDomain? _clock, _temperature;
    private ReadUInt? _power, _fan;
    private ReadUtilization? _utilization;
    private T? Export<T>(string name) where T:Delegate => NativeLibrary.TryGetExport(_library, name, out var address) ? Marshal.GetDelegateForFunctionPointer<T>(address) : null;

    private void Initialize(string expectedName, bool singleNvapiGpu)
    {
        if (_attempted) return;
        _attempted = true;
        // Without a verified PCI identity bridge, refuse ambiguous multi-adapter systems.
        if (!singleNvapiGpu || !NativeLibrary.TryLoad(System.IO.Path.Combine(Environment.SystemDirectory, "nvml.dll"), out _library)) return;
        if (Export<Init>("nvmlInit_v2")?.Invoke() != 0) return;
        var count = Export<Count>("nvmlDeviceGetCount_v2");
        var handle = Export<Handle>("nvmlDeviceGetHandleByIndex_v2");
        var name = Export<Name>("nvmlDeviceGetName");
        if (count == null || handle == null || name == null || count(out var total) != 0 || total != 1 || handle(0, out var candidate) != 0) return;
        var buffer = new StringBuilder(128);
        if (name(candidate, buffer, 128) != 0 || !string.Equals(buffer.ToString(), expectedName, StringComparison.OrdinalIgnoreCase)) return;
        _device = candidate;
        _clock = Export<ReadDomain>("nvmlDeviceGetClockInfo");
        _temperature = Export<ReadDomain>("nvmlDeviceGetTemperature");
        _power = Export<ReadUInt>("nvmlDeviceGetPowerUsage");
        _fan = Export<ReadUInt>("nvmlDeviceGetFanSpeed");
        _utilization = Export<ReadUtilization>("nvmlDeviceGetUtilizationRates");
        // Driver library remains loaded for process lifetime; delegates must never outlive it.
    }
    internal GpuMetricsSample Supplement(GpuMetricsSample sample, string name, bool singleGpu)
    {
        try
        {
            Initialize(name, singleGpu);
            if (_device == IntPtr.Zero) return sample;
            int? Clock(uint domain) => _clock != null && _clock(_device, domain, out var value) == 0 && value <= int.MaxValue ? (int)value : null;
            double? temperature = _temperature != null && _temperature(_device, 0, out var t) == 0 && t <= 150 ? t : null;
            double? power = _power != null && _power(_device, out var p) == 0 ? p / 1000.0 : null;
            double? fan = _fan != null && _fan(_device, out var f) == 0 && f <= 100 ? f : null;
            double? usage = _utilization != null && _utilization(_device, out var u) == 0 && u.Gpu <= 100 ? u.Gpu : null;
            return sample with { Source = "NVAPI / NVML", GpuClockMhz = Clock(0) ?? sample.GpuClockMhz,
                VramClockMhz = Clock(2) ?? sample.VramClockMhz, GpuUsagePercent = usage ?? sample.GpuUsagePercent,
                EdgeTempC = temperature ?? sample.EdgeTempC, BoardPowerW = power, FanPercent = fan };
        }
        catch (Exception) { return sample; }
    }
}
