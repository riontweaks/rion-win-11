using System.Runtime.InteropServices;

namespace Nvidia.Nvapi.Native;

internal static partial class NvapiApi
{
    // NVIDIA nvapi.h / nvapi_interface.h; existing NVIDIA-NVAPI license applies.
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsEnumSettingsFn(IntPtr session, IntPtr profile, uint startIndex,
        ref uint settingsCount, IntPtr settings);
    public static DrsEnumSettingsFn? DrsEnumSettings;
    public static bool DrsReadAvailable => DrsCreateSession != null && DrsDestroySession != null &&
        DrsLoadSettings != null && DrsGetBaseProfile != null && DrsGetSetting != null;
}
