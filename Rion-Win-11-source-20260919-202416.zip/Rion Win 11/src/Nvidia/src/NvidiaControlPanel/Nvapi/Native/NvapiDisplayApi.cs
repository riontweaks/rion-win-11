using System.Runtime.InteropServices;
namespace Nvidia.Nvapi.Native;
internal static partial class NvapiApi
{
    // NVIDIA nvapi.h: NV_GPU_DISPLAYIDS (version 3) and NV_COLOR_DATA_V4.
    [StructLayout(LayoutKind.Sequential)]
    public struct DisplayId { public uint Version, ConnectorType, Id, Flags; }
    [StructLayout(LayoutKind.Explicit, Size = 20)]
    public struct ColorData
    {
        [FieldOffset(0)] public uint Version;
        [FieldOffset(4)] public ushort Size;
        [FieldOffset(6)] public byte Command;
        [FieldOffset(8)] public byte Format;
        [FieldOffset(9)] public byte Colorimetry;
        [FieldOffset(10)] public byte DynamicRange;
        [FieldOffset(12)] public uint Bpc;
        [FieldOffset(16)] public uint SelectionPolicy;
        public static ColorData Create() => new() { Version = 20 | (4u << 16), Size = 20, Command = 1 };
    }
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetConnectedDisplayIdsFn(IntPtr gpu, IntPtr ids, ref uint count, uint flags);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int ColorControlFn(uint displayId, ref ColorData data);
    public static GetConnectedDisplayIdsFn? GetConnectedDisplayIds;
    public static ColorControlFn? ColorControl;
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetTachReadingFn(IntPtr gpu, out uint rpm);
    public static GetTachReadingFn? GetTachReading;

    [StructLayout(LayoutKind.Sequential)]
    public struct HdcpSupport
    {
        public uint Version, FuseState, KeySource, KeySourceState;
        public static HdcpSupport Create() => new() { Version = 16 | (1u << 16) };
    }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetHdcpSupportFn(IntPtr gpu, ref HdcpSupport status);
    public static GetHdcpSupportFn? GetHdcpSupport;

    public static uint? ActiveDisplay(IntPtr gpu) => ActiveDisplays(gpu).Select(id => (uint?)id).FirstOrDefault();
    public static IReadOnlyList<uint> ActiveDisplays(IntPtr gpu)
    {
        if (GetConnectedDisplayIds == null) return Array.Empty<uint>();
        uint count = 0;
        if (!Ok(GetConnectedDisplayIds(gpu, IntPtr.Zero, ref count, 0)) || count == 0 || count > 256) return Array.Empty<uint>();
        int size = Marshal.SizeOf<DisplayId>();
        uint capacity = count;
        var buffer = Marshal.AllocHGlobal(checked((int)count * size));
        try
        {
            for (int i = 0; i < count; i++) Marshal.StructureToPtr(new DisplayId { Version = (uint)size | (3u << 16) }, buffer + i * size, false);
            if (!Ok(GetConnectedDisplayIds(gpu, buffer, ref count, 0)) || count > capacity) return Array.Empty<uint>();
            var active = new List<uint>();
            for (int i = 0; i < count; i++)
            {
                var display = Marshal.PtrToStructure<DisplayId>(buffer + i * size);
                if ((display.Flags & 4) != 0) active.Add(display.Id);
            }
            return active;
        }
        finally { Marshal.FreeHGlobal(buffer); }
    }
}
