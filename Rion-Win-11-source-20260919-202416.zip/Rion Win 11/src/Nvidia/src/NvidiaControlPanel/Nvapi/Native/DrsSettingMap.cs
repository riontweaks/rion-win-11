using System.Collections.Generic;
using Nvidia.Catalog;

namespace Nvidia.Nvapi.Native;

/// <summary>
/// Maps the app's <see cref="SettingId"/> onto NVIDIA DRS setting ids and their permitted DWORD
/// values. Every id and value here is transcribed from NvApiDriverSettings.h in NVIDIA's published
/// header repo (github.com/NVIDIA/nvapi); the header's own constant name is quoted beside each one.
///
/// A setting the header does not define an unambiguous value for is left out entirely rather than
/// guessed at. <see cref="Choices"/> returning null for an id means "not wired", and the provider
/// reports it unsupported instead of writing something it cannot justify.
/// </summary>
internal static class DrsSettingMap
{
    /// <summary>DRS setting id for an app setting, or null when it isn't wired.</summary>
    public static uint? DrsId(SettingId id) => id switch
    {
        SettingId.Display_GSync => 0x1194F158,             // VRR_MODE_ID
        SettingId.Perf_AntiAliasingMethod => 0x1074C972,   // FXAA_ENABLE_ID
        SettingId.Perf_VerticalSync => 0x00A879CF,          // VSYNCMODE_ID
        SettingId.Perf_LowLatencyMode => 0x007BA09E,        // PRERENDERLIMIT_ID
        SettingId.Perf_FrameRateLimiter => 0x10835002,      // FRL_FPS_ID
        SettingId.Perf_AntiAliasingMode => 0x107EFC5B,      // AA_MODE_SELECTOR_ID
        SettingId.Perf_AntiAliasingLevel => 0x10D773D2,     // AA_MODE_METHOD_ID
        SettingId.Perf_AnisotropicFiltering => 0x10D2BB16,  // ANISO_MODE_SELECTOR_ID
        SettingId.Perf_AnisotropicLevel => 0x101E61A9,      // ANISO_MODE_LEVEL_ID
        SettingId.Perf_ThreadedOptimization => 0x20C1221E,  // OGL_THREAD_CONTROL_ID
        SettingId.Perf_TripleBuffering => 0x20FDD1F9,       // OGL_TRIPLE_BUFFER_ID
        SettingId.Perf_ShaderCache => 0x00198FFF,           // PS_SHADERDISKCACHE_ID
        SettingId.Perf_PowerManagementMode => 0x1057EB71,   // PREFERRED_PSTATE_ID
        SettingId.Perf_TextureFilteringQuality => 0x00CE2691,
        _ => AdditionalGraphicsSettings.Find(id)?.DriverId,
    };

    /// <summary>
    /// Catalog choice key to DWORD, for Choice-style settings. Null means the setting is not a
    /// choice; a key missing from a returned map means that particular option can't be expressed.
    /// </summary>
    public static IReadOnlyDictionary<string, uint>? Choices(SettingId id) => id switch
    {
        SettingId.Perf_TextureFilteringQuality => new Dictionary<string, uint>
        {
            ["high_quality"] = 0xfffffff6,
            ["quality"] = 0,
            ["performance"] = 10,
            ["high_performance"] = 20,
        },
        SettingId.Display_GSync => new Dictionary<string, uint>
        { ["off"] = 0, ["fullscreen"] = 1, ["windowed"] = 2 },
        SettingId.Perf_AnisotropicLevel => new Dictionary<string, uint>
        { ["app"] = 0, ["linear"] = 1, ["2x"] = 2, ["4x"] = 4, ["8x"] = 8, ["16x"] = 16 },
        SettingId.Perf_ShaderCache => new Dictionary<string, uint>
        { ["off"] = 0, ["on"] = 1 },
        // Adaptive tear control is exposed separately, preserving both underlying values.
        SettingId.Perf_VerticalSync => new Dictionary<string, uint>
        {
            ["off"] = 0x08416747,
            ["on"] = 0x47814940,
            ["app"] = 0x60925292,
            ["fast"] = 0x18888888,
            ["half"] = 0x32610244,
        },

        // PRERENDERLIMIT controls queue depth. This is not the separate Ultra latency mechanism.
        SettingId.Perf_LowLatencyMode => new Dictionary<string, uint>
        {
            ["off"] = 0x00,
            ["on"] = 0x01,
        },

        // AA_MODE_SELECTOR_APP_CONTROL / _OVERRIDE / _ENHANCE
        SettingId.Perf_AntiAliasingMode => new Dictionary<string, uint>
        {
            ["app"] = 0x00,
            ["override"] = 0x01,
            ["enhance"] = 0x02,
        },

        // The 2x choice is explicitly labelled diagonal to match its public enum.
        SettingId.Perf_AntiAliasingLevel => new Dictionary<string, uint>
        {
            ["none"] = 0x00,
            ["2x"] = 0x0e, // AA_MODE_METHOD_MULTISAMPLE_2X_DIAGONAL
            ["4x"] = 0x10,
            ["8x"] = 0x25,
        },

        // ANISO_MODE_SELECTOR_APP / _USER
        SettingId.Perf_AnisotropicFiltering => new Dictionary<string, uint>
        {
            ["app"] = 0x00,
            ["override"] = 0x01,
        },

        // OGL_THREAD_CONTROL_DEFAULT / _ENABLE / _DISABLE
        SettingId.Perf_ThreadedOptimization => new Dictionary<string, uint>
        {
            ["auto"] = 0x00,
            ["on"] = 0x01,
            ["off"] = 0x02,
        },

        // PREFERRED_PSTATE_OPTIMAL_POWER / _ADAPTIVE / _PREFER_CONSISTENT_PERFORMANCE / _PREFER_MAX
        SettingId.Perf_PowerManagementMode => new Dictionary<string, uint>
        {
            ["optimal"] = 0x05,
            ["adaptive"] = 0x00,
            ["consistent"] = 0x03,
            ["max"] = 0x01,
            ["driver"] = 0x02,
            ["minimum"] = 0x04,
        },

        _ => AdditionalGraphicsSettings.Find(id)?.Values,
    };

    /// <summary>Toggle settings: the DWORD written for off and on.</summary>
    public static (uint Off, uint On)? Toggle(SettingId id) => id switch
    {
        SettingId.Perf_TripleBuffering => (0x00, 0x01),  // OGL_TRIPLE_BUFFER_DISABLED / _ENABLED
        SettingId.Perf_AntiAliasingMethod => (0x00, 0x01), // FXAA_ENABLE_OFF / _ON
        _ => null,
    };

    /// <summary>Numeric settings and the range the header permits.</summary>
    public static (double Min, double Max)? Range(SettingId id) => id switch
    {
        SettingId.Perf_FrameRateLimiter => (0, 1000),      // FRL_FPS: 0 disables the limiter
        _ => null,
    };
}
