using System.Runtime.InteropServices;

namespace Nvidia.Nvapi.Native;

/// <summary>
/// Hand-rolled interop for NVIDIA's NVAPI in <c>nvapi64.dll</c> (shipped by the GeForce driver).
/// NVAPI exports one function, <c>nvapi_QueryInterface</c>, taking a numeric interface ID and
/// returning a function pointer — no vtable tree to walk the way ADLX has.
///
/// Function IDs and ABI layouts are checked against NVIDIA's public nvapi_interface.h and nvapi.h.
/// DRS uses the documented settings API; unavailable private tuning calls are not guessed.
/// </summary>
internal static partial class NvapiApi
{
    public const int MaxPhysicalGpus = 64;
    public const int MaxThermalSensorsPerGpu = 3;
    public const int MaxClocksPerGpu = 32;
    public const int MaxUtilizationDomains = 8;

    /// <summary>NVAPI_THERMAL_TARGET_ALL — query every sensor on the GPU in one call.</summary>
    public const int ThermalTargetAll = 15;

    public static bool Ok(int status) => status == 0;

    // -------------------------------------------------- struct versioning
    // NVAPI's own convention (from the public SDK headers): every struct's first field is a
    // version DWORD encoding sizeof(struct) in the low 16 bits and the struct version in the
    // high 16 bits. The driver rejects calls where this doesn't match what it expects.
    private static uint MakeVersion<T>(uint structVersion) where T : struct =>
        (uint)Marshal.SizeOf<T>() | (structVersion << 16);

    // -------------------------------------------------- structs (verified against
    // falahati/NvAPIWrapper's published struct layouts — see the file header)
    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct ThermalSensor
    {
        public int Controller;
        public int DefaultMinTemp;
        public int DefaultMaxTemp;
        public int CurrentTemp;
        public int Target;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct ThermalSettingsV2
    {
        public uint Version;
        public uint Count;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MaxThermalSensorsPerGpu)]
        public ThermalSensor[] Sensors;

        public static ThermalSettingsV2 Create() => new()
        {
            Version = MakeVersion<ThermalSettingsV2>(2),
            Sensors = new ThermalSensor[MaxThermalSensorsPerGpu],
        };
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct ClockDomainInfo
    {
        public uint IsPresent;
        public uint FrequencyKHz;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct ClockFrequenciesV3
    {
        public uint Version;
        /// <summary>Low bits select which clock type to report: 0 = current, 1 = base, 2 = boost.</summary>
        public uint ClockType;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MaxClocksPerGpu)]
        public ClockDomainInfo[] Clocks;

        public static ClockFrequenciesV3 Create(uint clockType) => new()
        {
            Version = MakeVersion<ClockFrequenciesV3>(3),
            ClockType = clockType,
            Clocks = new ClockDomainInfo[MaxClocksPerGpu],
        };

        // Index 0 = graphics/core clock, index 4 = memory clock — per NvAPIWrapper's
        // PublicClockDomain enum ordering (GPU=0, Memory=4).
        public const int GraphicsClockIndex = 0;
        public const int MemoryClockIndex = 4;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct UtilizationDomainInfo
    {
        public uint IsPresent;
        public uint Percentage;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct DynamicPerformanceStatesInfoV1
    {
        public uint Version;
        public uint Flags;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = MaxUtilizationDomains)]
        public UtilizationDomainInfo[] Domains;

        // Index 0 = GPU core, 1 = frame buffer / memory controller, 2 = video engine, 3 = bus.
        public const int GpuCoreIndex = 0;

        public static DynamicPerformanceStatesInfoV1 Create() => new()
        {
            Version = MakeVersion<DynamicPerformanceStatesInfoV1>(1),
            Domains = new UtilizationDomainInfo[MaxUtilizationDomains],
        };
    }

    // -------------------------------------------------- delegates (verified signatures)
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int InitializeFn();

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int EnumPhysicalGPUsFn(
        [In, Out, MarshalAs(UnmanagedType.LPArray, SizeConst = MaxPhysicalGpus)] IntPtr[] gpuHandles,
        out uint gpuCount);

    /// <summary>NVAPI_SHORT_STRING_MAX = 64. Pass a pre-allocated 64-byte array; the driver writes
    /// a null-terminated ASCII string into it. No MarshalAs needed — a byte[] parameter already
    /// marshals as a pointer to the pinned managed buffer.</summary>
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetFullNameFn(IntPtr physicalGpu, byte[] name);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetPciIdentifiersFn(IntPtr physicalGpu,
        out uint deviceId, out uint subSystemId, out uint revisionId, out uint extDeviceId);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetThermalSettingsFn(IntPtr physicalGpu, int sensorIndex, ref ThermalSettingsV2 settings);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetAllClockFrequenciesFn(IntPtr physicalGpu, ref ClockFrequenciesV3 clocks);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int GetDynamicPstatesInfoExFn(IntPtr physicalGpu, ref DynamicPerformanceStatesInfoV1 info);

    // -------------------------------------------------- DRS (Driver Settings)
    // Unlike the GPU functions above, DRS is public and documented. Every constant in this section
    // is transcribed from NVIDIA's own published headers (github.com/NVIDIA/nvapi):
    // function IDs from nvapi_interface.h, struct layout from nvapi.h, setting IDs and their
    // permitted values from NvApiDriverSettings.h.

    /// <summary>NVAPI_UNICODE_STRING_MAX (nvapi.h).</summary>
    public const int UnicodeStringMax = 2048;

    /// <summary>NVAPI_BINARY_DATA_MAX (nvapi.h).</summary>
    public const int BinaryDataMax = 4096;

    /// <summary>NVDRS_SETTING_TYPE. Only DWORD settings are wired.</summary>
    public const uint DrsDwordType = 0;

    /// <summary>
    /// NVDRS_SETTING_V1 from nvapi.h, declared there under <c>#pragma pack(push, 4)</c>.
    /// The two trailing unions are each sized by their largest member, NVDRS_BINARY_SETTING
    /// (NvU32 valueLength + NvU8[4096]), so 4100 bytes apiece. Only the leading DWORD of each is
    /// read or written here, but the padding must still be present or the version DWORD — which
    /// encodes sizeof — will not match what the driver expects and every call fails.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct DrsSetting
    {
        public uint Version;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = UnicodeStringMax)]
        public ushort[] SettingName;
        public uint SettingId;
        public uint SettingType;
        public uint SettingLocation;
        public uint IsCurrentPredefined;
        public uint IsPredefinedValid;

        public uint PredefinedValue;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = BinaryDataMax)]
        public byte[] PredefinedPadding;

        public uint CurrentValue;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = BinaryDataMax)]
        public byte[] CurrentPadding;

        public static DrsSetting Create() => new()
        {
            Version = MakeVersion<DrsSetting>(1),
            SettingName = new ushort[UnicodeStringMax],
            PredefinedPadding = new byte[BinaryDataMax],
            CurrentPadding = new byte[BinaryDataMax],
        };
    }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsCreateSessionFn(out IntPtr session);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsDestroySessionFn(IntPtr session);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsLoadSettingsFn(IntPtr session);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsSaveSettingsFn(IntPtr session);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsGetBaseProfileFn(IntPtr session, out IntPtr profile);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsGetSettingFn(IntPtr session, IntPtr profile, uint settingId, ref DrsSetting setting);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsSetSettingFn(IntPtr session, IntPtr profile, ref DrsSetting setting);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int DrsRestoreDefaultFn(IntPtr session, IntPtr profile, uint settingId);
    public static DrsRestoreDefaultFn? DrsRestoreDefault;

    // nvapi_interface.h
    private const uint Id_DRS_CreateSession = 0x0694D52E;
    private const uint Id_DRS_DestroySession = 0xDAD9CFF8;
    private const uint Id_DRS_LoadSettings = 0x375DBD6B;
    private const uint Id_DRS_SaveSettings = 0xFCBC7E14;
    private const uint Id_DRS_GetBaseProfile = 0xDA8466A0;
    private const uint Id_DRS_GetSetting = 0x73BF8338;
    private const uint Id_DRS_SetSetting = 0x577DD202;

    public static DrsCreateSessionFn? DrsCreateSession;
    public static DrsDestroySessionFn? DrsDestroySession;
    public static DrsLoadSettingsFn? DrsLoadSettings;
    public static DrsSaveSettingsFn? DrsSaveSettings;
    public static DrsGetBaseProfileFn? DrsGetBaseProfile;
    public static DrsGetSettingFn? DrsGetSetting;
    public static DrsSetSettingFn? DrsSetSetting;

    public static bool DrsAvailable =>
        DrsCreateSession != null && DrsDestroySession != null && DrsLoadSettings != null
        && DrsSaveSettings != null && DrsGetBaseProfile != null && DrsGetSetting != null
        && DrsSetSetting != null;

    // -------------------------------------------------- library + exports
    private static IntPtr _lib;
    private delegate IntPtr QueryInterfaceFn(uint interfaceId);
    private static QueryInterfaceFn? _queryInterface;

    // Interface IDs cross-referenced from falahati/NvAPIWrapper's FunctionId enum (MIT-licensed,
    // published source — see the file header for how these are attributed).
    private const uint Id_Initialize = 0x0150E828;
    private const uint Id_EnumPhysicalGPUs = 0xE5AC921F;
    private const uint Id_GPU_GetFullName = 0xCEEE8E9F;
    private const uint Id_GPU_GetPCIIdentifiers = 0x2DDFB66E;
    private const uint Id_GPU_GetThermalSettings = 0xE3640A56;
    private const uint Id_GPU_GetAllClockFrequencies = 0xDCB616C3;
    private const uint Id_GPU_GetDynamicPstatesInfoEx = 0x60DED2ED;

    public static InitializeFn? Initialize;
    public static EnumPhysicalGPUsFn? EnumPhysicalGPUs;
    public static GetFullNameFn? GetFullName;
    public static GetPciIdentifiersFn? GetPciIdentifiers;
    public static GetThermalSettingsFn? GetThermalSettings;
    public static GetAllClockFrequenciesFn? GetAllClockFrequencies;
    public static GetDynamicPstatesInfoExFn? GetDynamicPstatesInfoEx;

    public static bool LoadLibraryAndExports(out string error)
    {
        error = "";
        try
        {
            // Never resolve an elevated GPU library beside the app or through PATH.
            string driverLibrary = System.IO.Path.Combine(Environment.SystemDirectory, "nvapi64.dll");
            if (_lib == IntPtr.Zero && !NativeLibrary.TryLoad(driverLibrary,
                    typeof(NvapiApi).Assembly, DllImportSearchPath.System32, out _lib))
            {
                error = "nvapi64.dll not found — install the NVIDIA GeForce driver.";
                return false;
            }

            if (_queryInterface == null)
            {
                IntPtr export = NativeLibrary.GetExport(_lib, "nvapi_QueryInterface");
                _queryInterface = Marshal.GetDelegateForFunctionPointer<QueryInterfaceFn>(export);
            }

            T? Get<T>(uint id) where T : Delegate
            {
                IntPtr fp = _queryInterface!(id);
                return fp == IntPtr.Zero ? null : Marshal.GetDelegateForFunctionPointer<T>(fp);
            }

            Initialize = Get<InitializeFn>(Id_Initialize);
            EnumPhysicalGPUs = Get<EnumPhysicalGPUsFn>(Id_EnumPhysicalGPUs);
            GetFullName = Get<GetFullNameFn>(Id_GPU_GetFullName);
            GetConnectedDisplayIds = Get<GetConnectedDisplayIdsFn>(0x0078dba2);
            ColorControl = Get<ColorControlFn>(0x92f9d80d);
            GetDisplayConfig = Get<GetDisplayConfigFn>(0x11abccf8);
            SetDisplayConfig = Get<SetDisplayConfigFn>(0x5d8cf8de);
            GetTachReading = Get<GetTachReadingFn>(0x5f608315);
            GetHdcpSupport = Get<GetHdcpSupportFn>(0xf089eef5);
            GetPciIdentifiers = Get<GetPciIdentifiersFn>(Id_GPU_GetPCIIdentifiers);
            GetThermalSettings = Get<GetThermalSettingsFn>(Id_GPU_GetThermalSettings);
            GetAllClockFrequencies = Get<GetAllClockFrequenciesFn>(Id_GPU_GetAllClockFrequencies);
            GetDynamicPstatesInfoEx = Get<GetDynamicPstatesInfoExFn>(Id_GPU_GetDynamicPstatesInfoEx);

            DrsCreateSession = Get<DrsCreateSessionFn>(Id_DRS_CreateSession);
            DrsDestroySession = Get<DrsDestroySessionFn>(Id_DRS_DestroySession);
            DrsLoadSettings = Get<DrsLoadSettingsFn>(Id_DRS_LoadSettings);
            DrsSaveSettings = Get<DrsSaveSettingsFn>(Id_DRS_SaveSettings);
            DrsGetBaseProfile = Get<DrsGetBaseProfileFn>(Id_DRS_GetBaseProfile);
            DrsGetSetting = Get<DrsGetSettingFn>(Id_DRS_GetSetting);
            DrsSetSetting = Get<DrsSetSettingFn>(Id_DRS_SetSetting);
            DrsRestoreDefault = Get<DrsRestoreDefaultFn>(0x53f0381e);
            DrsEnumSettings = Get<DrsEnumSettingsFn>(0xae3039da);

            if (Initialize == null || EnumPhysicalGPUs == null)
            {
                error = "nvapi_QueryInterface resolved but core functions were missing — driver may be too old/new for these IDs.";
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            error = "Loading nvapi64.dll failed: " + ex.Message;
            return false;
        }
    }
}
