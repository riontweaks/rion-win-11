using Nvidia.Catalog;

namespace Nvidia.Nvapi;

public sealed partial class NativeNvapiProvider
{
    private const string TuningUnavailable = "NVIDIA tuning is unavailable: this integration has no verified public API for GeForce voltage/clock offsets, automatic OC or fan curves. Private API calls are not guessed. Use a supported vendor tuning utility.";

    private static string UnavailableSettingReason(SettingId id) => id switch
    {
        SettingId.Perf_ReflexBoost => "Reflex + Boost is configured inside supported games, not through a global DRS on/off setting.",
        SettingId.Display_Dsr or SettingId.Display_DsrSmoothness => "DSR factors/smoothness have no verified public DRS mapping in this integration. Use NVIDIA Control Panel.",
        SettingId.Perf_ImageScaling or SettingId.Perf_ImageScalingSharpness => "NVIDIA Image Scaling and its sharpening amount have no verified public mapping in this integration. Use NVIDIA App or Control Panel.",
        SettingId.Display_Hdcp => "HDCP status detection is not implemented for this display; it is not a writable setting.",
        _ => "No verified native mapping for this setting; no driver change was made.",
    };
}
