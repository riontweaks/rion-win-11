using Nvidia.Catalog;
using Nvidia.Nvapi.Native;

namespace Nvidia.Nvapi;

public sealed partial class NativeNvapiProvider
{
    private static bool KnownScaling(int value) => value is 1 or 2 or 3 or 5 or 6 or 7 or 8;
    private SettingValue ReadScaling(SettingId id)
    {
        if (!IsAvailable || ColorDisplay is not { } display) return SettingValue.Unsupported("No selected NVIDIA display.");
        try
        {
            using var config = NvapiApi.DisplayConfiguration.Read();
            int raw = config.Scaling(display);
            if (!KnownScaling(raw)) return SettingValue.Unsupported($"The current scaling mode ({raw}) cannot be restored by this integration.");
            var value = id switch
            {
                SettingId.Display_GpuScaling => SettingValue.Of(raw is 2 or 3 or 5 or 8),
                SettingId.Display_IntegerScaling => SettingValue.Of(raw == 8),
                _ => SettingValue.Of(raw switch { 1 or 2 => "full", 3 or 7 => "center", 8 => "integer", _ => "aspect" }),
            };
            return value with { NativeValue = raw };
        }
        catch (Exception ex) { return SettingValue.Unsupported(ex.Message); }
    }

    private WriteResult WriteScaling(SettingId id, SettingValue value)
    {
        if (!IsAvailable || ColorDisplay is not { } display) return WriteResult.Fail("No selected NVIDIA display.");
        try
        {
            using var config = NvapiApi.DisplayConfiguration.Read();
            int old = config.Scaling(display);
            if (!KnownScaling(old)) return WriteResult.Fail("The current scaling mode cannot be preserved. No changes were made.");
            bool gpu = old is 2 or 3 or 5 or 8;
            int requested;
            if (value.RestoreNative && value.NativeValue is { } saved && KnownScaling(saved)) requested = saved;
            else if (id == SettingId.Display_GpuScaling && value.Bool is { } on)
                requested = old switch { 1 or 2 => on ? 2 : 1, 3 or 7 => on ? 3 : 7, _ => on ? 5 : 6 };
            else if (id == SettingId.Display_IntegerScaling && value.Bool is { } integer)
                requested = integer ? 8 : 5;
            else if (id == SettingId.Display_ScalingMode)
                requested = value.Choice switch { "full" => gpu ? 2 : 1, "center" => gpu ? 3 : 7, "aspect" => gpu ? 5 : 6, "integer" => 8, _ => -1 };
            else return WriteResult.Fail("Expected a scaling choice or on/off value.");
            if (!KnownScaling(requested)) return WriteResult.Fail("Unknown scaling mode.");
            config.SetScaling(display, requested);
            config.Apply();
            using var actual = NvapiApi.DisplayConfiguration.Read();
            return actual.Scaling(display) == requested ? WriteResult.Success : WriteResult.Fail("Scaling readback did not match. Restore the previous setting.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
    }
}
