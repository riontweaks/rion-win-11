namespace Nvidia.Nvapi;
public sealed record DisplayInfo(string Id, string Name)
{
    public override string ToString() => Name;
}
