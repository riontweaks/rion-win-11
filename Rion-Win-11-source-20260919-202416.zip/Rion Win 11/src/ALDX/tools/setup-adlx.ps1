# =====================================================================
#  setup-adlx.ps1  —  generate the ADLX C# bindings for ALDX
#
#  Run this ON THE RADEON PC (the machine with the RX 7700 XT + Adrenalin).
#  It clones the ADLX SDK, builds the SWIG-generated C# binding, and drops
#  the results where ALDX.App.csproj picks them up automatically.
#
#  Requirements:
#    * git
#    * Visual Studio 2019 or 2022 with the C++ "Desktop development" workload
#      (provides MSBuild + the v14x toolset used by ADLXCSharpBind.vcxproj)
#    * swigwin 4.0.2   ->   https://www.swig.org/download.html
#                          unzip it and either add its folder to PATH or pass -SwigDir
#
#  Usage:
#    pwsh tools/setup-adlx.ps1
#    pwsh tools/setup-adlx.ps1 -SwigDir "C:\tools\swigwin-4.0.2" -Config Release
# =====================================================================
[CmdletBinding()]
param(
    [string]$SwigDir = "",
    [ValidateSet("Debug","Release")] [string]$Config = "Release",
    [string]$AdlxRepo = "https://github.com/GPUOpen-LibrariesAndSDKs/ADLX.git"
)

$ErrorActionPreference = "Stop"
$root      = Split-Path -Parent $PSScriptRoot
$thirdParty= Join-Path $root "third_party\ADLX"
$sdkDir    = Join-Path $thirdParty "sdk"
$bindOut   = Join-Path $thirdParty "bindings"
$nativeOut = Join-Path $thirdParty "native"

function Find-Swig {
    if ($SwigDir -and (Test-Path (Join-Path $SwigDir "swig.exe"))) { return (Join-Path $SwigDir "swig.exe") }
    $cmd = Get-Command swig.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw "swig.exe not found. Install swigwin 4.0.2 and add it to PATH, or pass -SwigDir."
}

function Find-MSBuild {
    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        $p = & $vswhere -latest -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe | Select-Object -First 1
        if ($p) { return $p }
    }
    $cmd = Get-Command MSBuild.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw "MSBuild.exe not found. Install Visual Studio 2019/2022 with the C++ workload."
}

Write-Host "== ADLX SDK ==" -ForegroundColor Cyan
if (-not (Test-Path $sdkDir)) {
    New-Item -ItemType Directory -Force -Path $thirdParty | Out-Null
    git clone --depth 1 $AdlxRepo $sdkDir
} else {
    Write-Host "  already present: $sdkDir"
}

$swig = Find-Swig
$msbuild = Find-MSBuild
Write-Host "  swig    : $swig"
Write-Host "  msbuild : $msbuild"

# The SDK ships the C# binding sample. Path has moved across SDK versions — probe.
$candidates = @(
    "SDK\ADLXCSharpBind\ADLXCSharpBind.vcxproj",
    "SDK\Samples\CSharp\ADLXCSharpBind\ADLXCSharpBind.vcxproj",
    "Samples\CSharp\ADLXCSharpBind\ADLXCSharpBind.vcxproj"
)
$vcxproj = $null
foreach ($c in $candidates) { $p = Join-Path $sdkDir $c; if (Test-Path $p) { $vcxproj = $p; break } }
if (-not $vcxproj) {
    $vcxproj = Get-ChildItem -Path $sdkDir -Recurse -Filter "ADLXCSharpBind.vcxproj" | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $vcxproj) { throw "Could not locate ADLXCSharpBind.vcxproj under $sdkDir — check the SDK layout." }
Write-Host "  binding project: $vcxproj"

Write-Host "== building C# binding ($Config x64) ==" -ForegroundColor Cyan
$env:PATH = (Split-Path $swig) + ";" + $env:PATH
& $msbuild $vcxproj /p:Configuration=$Config /p:Platform=x64 /verbosity:minimal
if ($LASTEXITCODE -ne 0) { throw "MSBuild failed ($LASTEXITCODE)." }

Write-Host "== collecting output ==" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $bindOut, $nativeOut | Out-Null
Remove-Item "$bindOut\*.cs" -ErrorAction SilentlyContinue

$bindRoot = Split-Path $vcxproj
# generated managed wrappers: *.cs next to the .i / in an output folder
$csFiles = Get-ChildItem -Path $bindRoot -Recurse -Filter *.cs |
    Where-Object { $_.FullName -notmatch '\\(obj|Properties)\\' }
if (-not $csFiles) { throw "No generated .cs files found — did SWIG run? Check $bindRoot." }
$csFiles | Copy-Item -Destination $bindOut -Force
Write-Host ("  {0} .cs files -> {1}" -f $csFiles.Count, $bindOut)

$nativeDll = Get-ChildItem -Path $bindRoot -Recurse -Filter "ADLXCSharpBind*_x64.dll" -ErrorAction SilentlyContinue |
    Select-Object -First 1
if (-not $nativeDll) {
    $nativeDll = Get-ChildItem -Path $bindRoot -Recurse -Filter "ADLXCSharpBind*.dll" | Select-Object -First 1
}
if (-not $nativeDll) { throw "ADLXCSharpBind native DLL not found under $bindRoot." }
Copy-Item $nativeDll.FullName (Join-Path $nativeOut "ADLXCSharpBind_x64.dll") -Force
Write-Host ("  native  -> {0}" -f (Join-Path $nativeOut "ADLXCSharpBind_x64.dll"))

# keep the SDK licence beside the vendored output
$lic = Get-ChildItem -Path $sdkDir -Recurse -Include "*LICENSE*","*License*" -File | Select-Object -First 1
if ($lic) { Copy-Item $lic.FullName (Join-Path $thirdParty ("ADLX-SDK-" + $lic.Name)) -Force }

Write-Host ""
Write-Host "Done. Rebuild ALDX:  dotnet build ALDX.sln -c Debug" -ForegroundColor Green
Write-Host "ALDX.App.csproj auto-detects third_party\ADLX\bindings and defines ADLX_SWIG."
Write-Host "If SwigAdlxProvider.cs then fails to compile, the generated API names differ slightly"
Write-Host "from AMD's documented sample — fix them in the helper methods at the bottom of that file."
