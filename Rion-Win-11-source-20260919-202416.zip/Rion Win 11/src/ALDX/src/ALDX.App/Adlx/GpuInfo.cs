namespace Aldx.Adlx;

/// <summary>
/// Static description of one GPU, plus the environment facts the System tab shows.
/// Read from <c>IADLXGPU</c> / <c>IADLXGPU1/2</c> and the ADLX version query.
/// </summary>
public sealed record GpuInfo
{
    public required string Name { get; init; }
    public string AdapterId { get; init; } = "";
    public string DriverRegistryPath { get; init; } = "";
    public required string AsicFamily { get; init; }          // e.g. "RDNA 3 (Navi 32)"
    public required string VramType { get; init; }            // e.g. "GDDR6"
    public required int VramSizeMb { get; init; }
    public required int CoreClockMhz { get; init; }           // rated
    public required int MemoryClockMhz { get; init; }         // rated (effective)
    public required string BusInterface { get; init; }        // e.g. "PCIe 4.0 x16"
    public required string VbiosVersion { get; init; }
    public required string DriverVersion { get; init; }       // Adrenalin package version
    public required string DriverDate { get; init; }
    public required string VendorId { get; init; }
    public required string DeviceId { get; init; }
    public required bool IsExternal { get; init; }
    public required bool HasDesktop { get; init; }
    public required int TotalBoardPowerW { get; init; }       // rated TBP

    // environment
    public required string AdlxVersion { get; init; }
    public required string AdlxDllPath { get; init; }
    public required bool AdlxInitialized { get; init; }
    public required string InitNote { get; init; }            // why it did / didn't initialise
}
