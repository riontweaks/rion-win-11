using Aldx.Catalog;

namespace Aldx.Adlx;

/// <summary>No driver connection: measurements are absent and every write is rejected.</summary>
public sealed class UnavailableAdlxProvider(string reason) : IAdlxProvider
{
    public string DisplayName => "AMD connection unavailable";
    public bool IsAvailable => false;
    public bool IsMock => false;
    public void Initialize() { }
    public void Dispose() { }
    public GpuInfo GetGpuInfo() => new()
    {
        Name = DisplayName,
        AsicFamily = "Unavailable",
        VramType = "Unavailable",
        VramSizeMb = 0,
        CoreClockMhz = 0,
        MemoryClockMhz = 0,
        BusInterface = "Unavailable",
        VbiosVersion = "Unavailable",
        DriverVersion = "Unavailable",
        DriverDate = "Unavailable",
        VendorId = "Unavailable",
        DeviceId = "Unavailable",
        IsExternal = false,
        HasDesktop = false,
        TotalBoardPowerW = 0,
        AdlxVersion = "Unavailable",
        AdlxDllPath = "Unavailable",
        AdlxInitialized = false,
        InitNote = reason,
    };
    public SettingValue Read(SettingId id) => SettingValue.Unsupported(reason);
    public GpuMetricsSample ReadMetrics() => new();
    public GpuTuningInfo GetGpuTuning() => new()
    {
        GpuName = DisplayName, Available = false, Unavailable = reason,
        FanSpeedRange = ValueRange.None, FanTempRange = ValueRange.None, FanPointCount = 0
    };
    public WriteResult Write(SettingId id, SettingValue value) => WriteResult.Fail(reason);
    public WriteResult SetSystemTuningMode(SystemTuningMode mode) => WriteResult.Fail(reason);
    public WriteResult SetGpuAutoMode(GpuAutoMode mode) => WriteResult.Fail(reason);
    public WriteResult SetGpuPreset(GpuPreset preset) => WriteResult.Fail(reason);
    public WriteResult SetGpuManualCustom(bool on) => WriteResult.Fail(reason);
    public WriteResult SetFanTuningEnabled(bool on) => WriteResult.Fail(reason);
    public WriteResult SetZeroRpm(bool on) => WriteResult.Fail(reason);
    public WriteResult SetFanAdvancedControl(bool on) => WriteResult.Fail(reason);
    public WriteResult SetFanCurve(IReadOnlyList<FanPoint> points) => WriteResult.Fail(reason);
    public WriteResult SetPowerTuningEnabled(bool on) => WriteResult.Fail(reason);
    public WriteResult SetPowerLimitPercent(double percent) => WriteResult.Fail(reason);
    public WriteResult SetGpuClockRange(int minMhz, int maxMhz) => WriteResult.Fail(reason);
    public WriteResult SetGpuVoltage(int mv) => WriteResult.Fail(reason);
    public WriteResult SetVramClock(int mhz) => WriteResult.Fail(reason);
    public WriteResult ApplyTuningSnapshot(GpuTuningInfo snapshot) => WriteResult.Fail(reason);
}
