namespace Aldx.Adlx;

/// <summary>
/// The live value of one setting, as read from ADLX. A setting is either
/// a boolean (toggle), a discrete choice (string key matching a
/// <c>SettingOption.Value</c>), or a number (slider). <see cref="Supported"/> == false
/// means the current GPU/driver does not expose the feature at all.
/// </summary>
public sealed record SettingValue
{
    public required bool Supported { get; init; }

    /// <summary>Human-readable reason shown when <see cref="Supported"/> is false.</summary>
    public string UnsupportedReason { get; init; } = "";

    public bool? Bool { get; init; }
    public string? Choice { get; init; }
    public double? Number { get; init; }

    // ranged settings can report a live min/max/step that overrides the catalog defaults
    public double? Min { get; init; }
    public double? Max { get; init; }
    public double? Step { get; init; }

    public static SettingValue Unsupported(string reason) => new() { Supported = false, UnsupportedReason = reason };
    public static SettingValue Of(bool value) => new() { Supported = true, Bool = value };
    public static SettingValue Of(string choice) => new() { Supported = true, Choice = choice };
    public static SettingValue Of(double number, double? min = null, double? max = null, double? step = null) =>
        new() { Supported = true, Number = number, Min = min, Max = max, Step = step };
}
