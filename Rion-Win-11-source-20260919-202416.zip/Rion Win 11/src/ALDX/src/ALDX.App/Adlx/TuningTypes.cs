namespace Aldx.Adlx;

/// <summary>Top-level tuning intent, mirrors Adrenalin's "Tuning Control" row.</summary>
public enum SystemTuningMode { Default, AutoOverclock, Custom }

/// <summary>GPU "Automatic Tuning" buttons in Adrenalin.</summary>
public enum GpuAutoMode { None, Default, UndervoltGpu, OverclockGpu, OverclockVram }

/// <summary>GPU "Tuning Preset" chips in Adrenalin.</summary>
public enum GpuPreset { None, Quiet, Balanced }

public readonly record struct FanPoint(double TempC, double SpeedPercent);

public readonly record struct ValueRange(double Min, double Max, double Step)
{
    public double Clamp(double v) => Math.Min(Max, Math.Max(Min, v));
    public bool IsValid => Max > Min;
    public static readonly ValueRange None = new(0, 0, 1);
}

/// <summary>
/// Everything the Overclocking tab needs to render itself for the current GPU:
/// which capabilities exist, and the live ranges for each control.
/// Filled from <c>IADLXGPUTuningServices</c> + the manual-tuning interfaces.
/// </summary>
public sealed record GpuTuningInfo
{
    public required string GpuName { get; init; }
    public bool Available { get; init; }
    public string Unavailable { get; init; } = "";

    // current state
    public SystemTuningMode SystemMode { get; init; }
    public GpuAutoMode AutoMode { get; init; }
    public GpuPreset Preset { get; init; }
    public bool ManualCustom { get; init; }

    // capability flags
    public bool SupportsAutoUndervolt { get; init; }
    public bool SupportsAutoOverclock { get; init; }
    public bool SupportsAutoOverclockVram { get; init; }
    public bool SupportsPresets { get; init; }
    public bool SupportsQuiet { get; init; }
    public bool SupportsBalanced { get; init; }
    public bool SupportsManualGpuClock { get; init; }
    public bool SupportsManualVram { get; init; }
    public bool SupportsFanTuning { get; init; }
    public bool SupportsZeroRpm { get; init; }
    public bool SupportsPowerTuning { get; init; }
    public bool SupportsTdc { get; init; }

    // ranges
    public ValueRange GpuClockRange { get; init; } = ValueRange.None;
    public ValueRange GpuVoltageRange { get; init; } = ValueRange.None;
    public ValueRange VramClockRange { get; init; } = ValueRange.None;
    public ValueRange PowerLimitRange { get; init; } = ValueRange.None;   // percent, e.g. -30..+15
    public ValueRange TdcRange { get; init; } = ValueRange.None; // ADLX percent units
    public ValueRange FanSpeedRange { get; init; } = new(0, 100, 1);
    public ValueRange FanTempRange { get; init; } = new(0, 100, 1);
    public int FanPointCount { get; init; } = 5;

    // live manual values
    public bool FanTuningEnabled { get; init; }
    public bool ZeroRpm { get; init; }
    public bool FanAdvancedControl { get; init; }
    public IReadOnlyList<FanPoint> FanCurve { get; init; } = Array.Empty<FanPoint>();

    public bool PowerTuningEnabled { get; init; }
    public double PowerLimitPercent { get; init; }
    public double? TdcLimitPercent { get; init; }
    public string TdcUnavailable { get; init; } = "This GPU/driver does not expose a readable TDC limit.";

    public int GpuMinClockMhz { get; init; }
    public int GpuMaxClockMhz { get; init; }
    public int GpuVoltageMv { get; init; }
    public int VramClockMhz { get; init; }
}

public sealed record WriteResult(bool Ok, string Error = "")
{
    public static readonly WriteResult Success = new(true);
    public static WriteResult Fail(string why) => new(false, why);
}
