using Aldx.Adlx.Native;

namespace Aldx.Adlx;

public sealed partial class NativeAdlxProvider
{
    // AMD IGPUManualPowerTuning.h defines GetTDCLimit and its range in percent.
    // TDC setters require application validation; this path deliberately reads only.
    private SettingValue ReadTdcCore()
    {
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualPowerTuning, out var power))
            return SettingValue.Unsupported("Manual power tuning is unavailable on this GPU/driver.");
        try { return ReadTdcFromInterface(power); }
        catch (Exception ex) { return SettingValue.Unsupported("TDC could not be read: " + ex.Message); }
        finally { Rel(power); }
    }

    private static SettingValue ReadTdcFromInterface(IntPtr power)
    {
        if (BoolAt(power, AdlxApi.PowerTune.IsSupportedTDCLimit) != true)
            return TdcReading(false, null, null);
        var range = Range1(power, AdlxApi.PowerTune.GetTDCLimitRange);
        return TdcReading(true, IntAt(power, AdlxApi.PowerTune.GetTDCLimit),
            range is { } r ? new ValueRange(r.min, r.max, r.step) : null);
    }

    internal static SettingValue TdcReading(bool supported, int? current, ValueRange? range)
    {
        if (!supported) return SettingValue.Unsupported("This GPU/driver does not support TDC readings.");
        if (current is not { } value || range is not { } r ||
            !double.IsFinite(r.Min) || !double.IsFinite(r.Max) || !double.IsFinite(r.Step) ||
            r.Max < r.Min || r.Step <= 0 || value < r.Min || value > r.Max ||
            Math.Abs((value - r.Min) / r.Step - Math.Round((value - r.Min) / r.Step)) > 0.000001)
            return SettingValue.Unsupported("The driver did not return a valid TDC value and range.");
        return SettingValue.Of(value, r.Min, r.Max, r.Step);
    }
}
