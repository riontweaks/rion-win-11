using Aldx.Adlx.Native;
using Aldx.Catalog;

namespace Aldx.Adlx;

/// <summary>ADLX settings, telemetry and tuning with runtime capability checks.</summary>
public sealed partial class NativeAdlxProvider : IAdlxProvider
{
    private static bool _terminated;   // ADLX cannot be re-initialised in-process after Terminate

    // ADLX interfaces are not documented as thread-safe. The 1 s metrics timer, user edits,
    // and the profile "apply all" can overlap, so every public entry point serialises here.
    private readonly object _gate = new();

    private IntPtr _system;
    private IntPtr _gpu;
    private IntPtr _perf;
    private IntPtr _svc3d;
    private IntPtr _tuning;    // IADLXGPUTuningServices
    private IntPtr _dispSvc;   // IADLXDisplayServices
    private IntPtr _display;   // primary IADLXDisplay
    private string _name = "AMD GPU";
    private string _initNote = "";
    private int _gpuType;

    public string DisplayName => _name;
    public bool IsAvailable { get; private set; }
    public bool IsMock => false;

    public void Initialize()
    {
        if (_terminated) { _initNote = "ADLX already terminated in this process."; return; }
        if (!AdlxApi.LoadLibraryAndExports(out var err)) { _initNote = err; return; }

        int r = AdlxApi.Initialize!(AdlxApi.ADLX_FULL_VERSION, out _system);
        if (r == AdlxApi.ADLX_BAD_VER && AdlxApi.InitializeWithIncompatibleDriver != null)
            r = AdlxApi.InitializeWithIncompatibleDriver(AdlxApi.ADLX_FULL_VERSION, out _system);

        if (!AdlxApi.OK(r) || _system == IntPtr.Zero)
        {
            _initNote = $"ADLXInitialize returned {r}.";
            return;
        }

        // enumerate GPUs, prefer the discrete card (skip the APU / iGPU)
        if (AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutPtr>(_system, AdlxApi.Sys.GetGPUs)(_system, out var gpuList))
            && gpuList != IntPtr.Zero)
        {
            uint begin = AdlxApi.Fn<AdlxApi.RRetUint>(gpuList, AdlxApi.GpuList.Begin)(gpuList);
            uint end = AdlxApi.Fn<AdlxApi.RRetUint>(gpuList, AdlxApi.GpuList.End)(gpuList);
            var at = AdlxApi.Fn<AdlxApi.RAtGpu>(gpuList, AdlxApi.GpuList.At_GPUList);
            IntPtr firstAny = IntPtr.Zero;

            for (uint i = begin; i != end; i++)
            {
                if (!AdlxApi.OK(at(gpuList, i, out var g)) || g == IntPtr.Zero) continue;
                int type = 0;
                AdlxApi.Fn<AdlxApi.ROutInt>(g, AdlxApi.Gpu.Type)(g, out type);

                if (type == AdlxApi.GPUTYPE_DISCRETE && _gpu == IntPtr.Zero)
                {
                    _gpu = g; _gpuType = type;
                }
                else if (firstAny == IntPtr.Zero)
                {
                    firstAny = g;
                }
                else
                {
                    AdlxApi.Fn<AdlxApi.RVoid>(g, AdlxApi.Iface.Release)(g);
                }
            }

            if (_gpu == IntPtr.Zero && firstAny != IntPtr.Zero) { _gpu = firstAny; AdlxApi.Fn<AdlxApi.ROutInt>(_gpu, AdlxApi.Gpu.Type)(_gpu, out _gpuType); }
            else if (firstAny != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(firstAny, AdlxApi.Iface.Release)(firstAny);

            AdlxApi.Fn<AdlxApi.RVoid>(gpuList, AdlxApi.Iface.Release)(gpuList);
        }

        // perf-monitoring services
        AdlxApi.Fn<AdlxApi.ROutPtr>(_system, AdlxApi.Sys.GetPerformanceMonitoringServices)(_system, out _perf);

        // 3D (Performance-tab) settings services
        try { AdlxApi.Fn<AdlxApi.ROutPtr>(_system, AdlxApi.Sys.Get3DSettingsServices)(_system, out _svc3d); }
        catch { _svc3d = IntPtr.Zero; }

        // GPU tuning services (Overclocking tab)
        try { AdlxApi.Fn<AdlxApi.ROutPtr>(_system, AdlxApi.Sys.GetGPUTuningServices)(_system, out _tuning); }
        catch { _tuning = IntPtr.Zero; }

        // Enumerate displays by stable ADLX identity; the UI explicitly selects the target.
        if (AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutPtr>(_system, AdlxApi.Sys.GetDisplaysServices)(_system, out _dispSvc)))
            RefreshDisplaysCore();
        if (_gpu != IntPtr.Zero)
        {
            _name = Str(_gpu, AdlxApi.Gpu.Name) ?? "AMD GPU";
            IsAvailable = true;
            _initNote = _gpuType == AdlxApi.GPUTYPE_DISCRETE ? "Live ADLX (discrete GPU)." : "Live ADLX (integrated GPU).";
        }
        else _initNote = "ADLX initialised but no GPU was enumerated.";
    }

    // ---------------------------------------------------------------- info
    public GpuInfo GetGpuInfo() { lock (_gate) return GetGpuInfoCore(); }
    private GpuInfo GetGpuInfoCore()
    {
        string asic = "";
        if (_gpu != IntPtr.Zero &&
            AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutInt>(_gpu, AdlxApi.Gpu.ASICFamilyType)(_gpu, out var a)))
            asic = AsicName(a);

        int vramMb = 0;
        if (_gpu != IntPtr.Zero)
        {
            AdlxApi.Fn<AdlxApi.ROutInt>(_gpu, AdlxApi.Gpu.TotalVRAM)(_gpu, out vramMb);
        }

        byte ext = 0, desk = 0;
        if (_gpu != IntPtr.Zero)
        {
            AdlxApi.Fn<AdlxApi.ROutByte>(_gpu, AdlxApi.Gpu.IsExternal)(_gpu, out ext);
            AdlxApi.Fn<AdlxApi.ROutByte>(_gpu, AdlxApi.Gpu.HasDesktops)(_gpu, out desk);
        }

        string ver = "";
        if (AdlxApi.QueryFullVersion != null && AdlxApi.QueryFullVersion(out var fv) == AdlxApi.ADLX_OK)
            ver = $"{(fv >> 48) & 0xFFFF}.{(fv >> 32) & 0xFFFF}.{(fv >> 16) & 0xFFFF}.{fv & 0xFFFF}";

        string driverPath = Str(_gpu, AdlxApi.Gpu.DriverPath) ?? "";
        return new GpuInfo
        {
            Name = _name,
            AdapterId = IntAt(_gpu, AdlxApi.Gpu.UniqueId)?.ToString() ?? "",
            DriverRegistryPath = driverPath,
            AsicFamily = asic,
            VramType = Str(_gpu, AdlxApi.Gpu.VRAMType) ?? "",
            VramSizeMb = vramMb,
            CoreClockMhz = 0,
            MemoryClockMhz = 0,
            BusInterface = "PCIe",
            VbiosVersion = BiosVersion(),
            DriverVersion = ReadDriverRegistryVersion(driverPath),
            DriverDate = "",
            VendorId = Str(_gpu, AdlxApi.Gpu.VendorId) ?? "",
            DeviceId = Str(_gpu, AdlxApi.Gpu.DeviceId) ?? "",
            IsExternal = ext != 0,
            HasDesktop = desk != 0,
            TotalBoardPowerW = 0,
            AdlxVersion = ver,
            AdlxDllPath = Str(_gpu, AdlxApi.Gpu.DriverPath) ?? "amdadlx64.dll",
            AdlxInitialized = IsAvailable,
            InitNote = _initNote,
        };
    }

    private static string ReadDriverRegistryVersion(string path)
    {
        try
        {
            string? key = NormalizeDriverRegistryPath(path);
            return key == null ? "" : Microsoft.Win32.Registry.GetValue(key, "DriverVersion", null) as string ?? "";
        }
        catch { return ""; }
    }

    internal static string? NormalizeDriverRegistryPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;
        path = path.Trim();
        const string machine = "\\Registry\\Machine\\";
        const string hive = "HKEY_LOCAL_MACHINE\\";
        if (path.StartsWith(machine, StringComparison.OrdinalIgnoreCase)) path = path[machine.Length..];
        if (path.StartsWith(hive, StringComparison.OrdinalIgnoreCase)) path = path[hive.Length..];
        path = path.TrimStart('\\');
        // ADLX commonly returns the display class-relative adapter key, e.g. {GUID}\0000.
        var parts = path.Split('\\');
        if (parts.Length == 2 && Guid.TryParse(parts[0], out _) && parts[1].Length == 4 && parts[1].All(char.IsDigit))
            path = "SYSTEM\\CurrentControlSet\\Control\\Class\\" + path;
        return path.StartsWith("SYSTEM\\", StringComparison.OrdinalIgnoreCase) ? hive + path : null;
    }

    private string BiosVersion()
    {
        if (_gpu == IntPtr.Zero) return "";
        try
        {
            var d = AdlxApi.Fn<BiosFn>(_gpu, AdlxApi.Gpu.BIOSInfo);
            if (d(_gpu, out var part, out var ver, out var date) == AdlxApi.ADLX_OK)
                return System.Runtime.InteropServices.Marshal.PtrToStringAnsi(ver) ?? "";
        }
        catch { }
        return "";
    }

    [System.Runtime.InteropServices.UnmanagedFunctionPointer(System.Runtime.InteropServices.CallingConvention.Cdecl)]
    private delegate int BiosFn(IntPtr t, out IntPtr part, out IntPtr ver, out IntPtr date);

    // ---------------------------------------------------------------- metrics
    public GpuMetricsSample ReadMetrics()
    {
        lock (_gate) return ReadMetricsCore();
    }

    private GpuMetricsSample ReadMetricsCore()
    {
        if (_perf == IntPtr.Zero || _gpu == IntPtr.Zero) return new GpuMetricsSample();

        var get = AdlxApi.Fn<AdlxApi.RGpuOutPtr>(_perf, AdlxApi.Perf.GetCurrentGPUMetrics);
        if (!AdlxApi.OK(get(_perf, _gpu, out var m)) || m == IntPtr.Zero) return new GpuMetricsSample();

        try
        {
            double? D(int idx) => AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutDouble>(m, idx)(m, out var v)) ? v : null;
            int? N(int idx) => AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutInt>(m, idx)(m, out var v)) ? v : null;

            return new GpuMetricsSample
            {
                GpuUsagePercent = D(AdlxApi.GpuMetrics.GPUUsage),
                GpuClockMhz = N(AdlxApi.GpuMetrics.GPUClockSpeed),
                VramClockMhz = N(AdlxApi.GpuMetrics.GPUVRAMClockSpeed),
                EdgeTempC = D(AdlxApi.GpuMetrics.GPUTemperature),
                HotspotTempC = D(AdlxApi.GpuMetrics.GPUHotspotTemperature),
                PowerW = D(AdlxApi.GpuMetrics.GPUPower),
                BoardPowerW = D(AdlxApi.GpuMetrics.GPUTotalBoardPower),
                FanRpm = N(AdlxApi.GpuMetrics.GPUFanSpeed),
                VoltageMv = N(AdlxApi.GpuMetrics.GPUVoltage),
                VramUsedMb = N(AdlxApi.GpuMetrics.GPUVRAM) is { } u ? u : null,
            };
        }
        finally
        {
            AdlxApi.Fn<AdlxApi.RVoid>(m, AdlxApi.Iface.Release)(m);
        }
    }

    // ---------------------------------------------------------------- settings (Performance / 3D)
    //
    // Every Perf_* row maps to an IADLX3D* feature interface reached through
    // IADLX3DSettingsServices. We acquire the feature, read IsSupported / IsEnabled /
    // Get<value> / Get<value>Range, then Release. Writes acquire, call Set*, Release.

    private bool Acquire3d(int svcIndex, bool noGpu, out IntPtr feat)
    {
        feat = IntPtr.Zero;
        if (_svc3d == IntPtr.Zero) return false;
        try
        {
            int r = noGpu
                ? AdlxApi.Fn<AdlxApi.ROutPtr>(_svc3d, svcIndex)(_svc3d, out feat)
                : (_gpu == IntPtr.Zero ? -1 : AdlxApi.Fn<AdlxApi.RGpuOutPtr>(_svc3d, svcIndex)(_svc3d, _gpu, out feat));
            return AdlxApi.OK(r) && feat != IntPtr.Zero;
        }
        catch { feat = IntPtr.Zero; return false; }
    }

    private static bool? BoolAt(IntPtr f, int idx)
    {
        try { return AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutByte>(f, idx)(f, out var b)) ? b != 0 : null; }
        catch { return null; }
    }
    private static int? IntAt(IntPtr f, int idx)
    {
        try { return AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutInt>(f, idx)(f, out var v)) ? v : null; }
        catch { return null; }
    }
    private static AdlxIntRange? RangeAt(IntPtr f, int idx)
    {
        try { return AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutIntRange>(f, idx)(f, out var r)) ? r : null; }
        catch { return null; }
    }
    private static bool SetBoolAt(IntPtr f, int idx, bool on)
    {
        try { return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RByte>(f, idx)(f, (byte)(on ? 1 : 0))); }
        catch { return false; }
    }
    private static bool SetIntAt(IntPtr f, int idx, int v)
    {
        try { return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RInt>(f, idx)(f, v)); }
        catch { return false; }
    }
    private static void Rel(IntPtr f)
    {
        try { if (f != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(f, AdlxApi.Iface.Release)(f); } catch { }
    }

    // (svc getter index, noGpu, IsSupported idx, IsEnabled idx, SetEnabled idx)
    private readonly record struct BoolFeat(int Svc, bool NoGpu, int Sup, int En, int Set);

    private static readonly Dictionary<SettingId, BoolFeat> BoolFeats = new()
    {
        [SettingId.Perf_AntiLag]               = new(AdlxApi.Svc3d.GetAntiLag, false, 3, 4, 5),
        [SettingId.Perf_EnhancedSync]          = new(AdlxApi.Svc3d.GetEnhancedSync, false, 3, 4, 5),
        [SettingId.Perf_MorphologicalAa]       = new(AdlxApi.Svc3d.GetMorphologicalAntiAliasing, false, 3, 4, 5),
        [SettingId.Perf_Chill]                 = new(AdlxApi.Svc3d.GetChill, false, AdlxApi.Chill.IsSupported, AdlxApi.Chill.IsEnabled, AdlxApi.Chill.SetEnabled),
        [SettingId.Perf_Boost]                 = new(AdlxApi.Svc3d.GetBoost, false, AdlxApi.Boost.IsSupported, AdlxApi.Boost.IsEnabled, AdlxApi.Boost.SetEnabled),
        [SettingId.Perf_ImageSharpening]       = new(AdlxApi.Svc3d.GetImageSharpening, false, AdlxApi.Sharpen.IsSupported, AdlxApi.Sharpen.IsEnabled, AdlxApi.Sharpen.SetEnabled),
        [SettingId.Perf_RadeonSuperResolution] = new(AdlxApi.Svc3d.GetRadeonSuperResolution, true, AdlxApi.Rsr.IsSupported, AdlxApi.Rsr.IsEnabled, AdlxApi.Rsr.SetEnabled),
        [SettingId.Perf_FrameRateTargetControl]= new(AdlxApi.Svc3d.GetFrameRateTargetControl, false, AdlxApi.Frtc.IsSupported, AdlxApi.Frtc.IsEnabled, AdlxApi.Frtc.SetEnabled),
        [SettingId.Perf_AnisotropicFiltering]  = new(AdlxApi.Svc3d.GetAnisotropicFiltering, false, AdlxApi.Aniso.IsSupported, AdlxApi.Aniso.IsEnabled, AdlxApi.Aniso.SetEnabled),
    };

    // (svc getter index, noGpu, IsSupported idx, Get<value> idx, Get<value>Range idx, Set<value> idx)
    private readonly record struct IntFeat(int Svc, bool NoGpu, int Sup, int Get, int Range, int Set);

    private static readonly Dictionary<SettingId, IntFeat> IntFeats = new()
    {
        [SettingId.Perf_ChillMinFps]          = new(AdlxApi.Svc3d.GetChill, false, AdlxApi.Chill.IsSupported, AdlxApi.Chill.GetMinFPS, AdlxApi.Chill.GetFPSRange, AdlxApi.Chill.SetMinFPS),
        [SettingId.Perf_ChillMaxFps]          = new(AdlxApi.Svc3d.GetChill, false, AdlxApi.Chill.IsSupported, AdlxApi.Chill.GetMaxFPS, AdlxApi.Chill.GetFPSRange, AdlxApi.Chill.SetMaxFPS),
        [SettingId.Perf_BoostResolution]      = new(AdlxApi.Svc3d.GetBoost, false, AdlxApi.Boost.IsSupported, AdlxApi.Boost.GetResolution, AdlxApi.Boost.GetResolutionRange, AdlxApi.Boost.SetResolution),
        [SettingId.Perf_RsrSharpness]         = new(AdlxApi.Svc3d.GetRadeonSuperResolution, true, AdlxApi.Rsr.IsSupported, AdlxApi.Rsr.GetSharpness, AdlxApi.Rsr.GetSharpnessRange, AdlxApi.Rsr.SetSharpness),
        [SettingId.Perf_ImageSharpeningAmount]= new(AdlxApi.Svc3d.GetImageSharpening, false, AdlxApi.Sharpen.IsSupported, AdlxApi.Sharpen.GetSharpness, AdlxApi.Sharpen.GetSharpnessRange, AdlxApi.Sharpen.SetSharpness),
        [SettingId.Perf_FrtcTargetFps]        = new(AdlxApi.Svc3d.GetFrameRateTargetControl, false, AdlxApi.Frtc.IsSupported, AdlxApi.Frtc.GetFPS, AdlxApi.Frtc.GetFPSRange, AdlxApi.Frtc.SetFPS),
    };

    public SettingValue Read(SettingId id)
    {
        lock (_gate) return ReadCore(id);
    }

    private SettingValue ReadCore(SettingId id)
    {
        if (id == SettingId.Oc_TdcLimitAmps) return ReadTdcCore();
        if (id is >= SettingId.Display_FreeSync and <= SettingId.Display_Contrast)
            return ReadDisplayCore(id);

        if (_svc3d == IntPtr.Zero)
            return SettingValue.Unsupported("ADLX 3D-settings service unavailable on this driver.");

        if (BoolFeats.TryGetValue(id, out var bf))
        {
            if (!Acquire3d(bf.Svc, bf.NoGpu, out var f)) return SettingValue.Unsupported("Not exposed by this driver / GPU.");
            try
            {
                if (BoolAt(f, bf.Sup) != true) return SettingValue.Unsupported("Not supported on this GPU.");
                return BoolAt(f, bf.En) is { } v ? SettingValue.Of(v) : SettingValue.Unsupported("State unavailable.");
            }
            finally { Rel(f); }
        }

        if (IntFeats.TryGetValue(id, out var nf))
        {
            if (!Acquire3d(nf.Svc, nf.NoGpu, out var f)) return SettingValue.Unsupported("Not exposed by this driver / GPU.");
            try
            {
                if (BoolAt(f, nf.Sup) != true) return SettingValue.Unsupported("Not supported on this GPU.");
                if (IntAt(f, nf.Get) is not { } cur) return SettingValue.Unsupported("Value unavailable.");
                var r = RangeAt(f, nf.Range);
                return r is { } rr
                    ? SettingValue.Of(cur, rr.minValue, rr.maxValue, rr.step <= 0 ? 1 : rr.step)
                    : SettingValue.Of(cur);
            }
            finally { Rel(f); }
        }

        return id switch
        {
            SettingId.Perf_WaitForVerticalRefresh => ReadChoice(AdlxApi.Svc3d.GetWaitForVerticalRefresh, false,
                AdlxApi.WaitVSync.IsSupported, AdlxApi.WaitVSync.GetMode, VsyncFromEnum),
            SettingId.Perf_AntiAliasingMode => ReadChoice(AdlxApi.Svc3d.GetAntiAliasing, false,
                AdlxApi.AntiAlias.IsSupported, AdlxApi.AntiAlias.GetMode, AaModeFromEnum),
            SettingId.Perf_AntiAliasingLevel => ReadChoice(AdlxApi.Svc3d.GetAntiAliasing, false,
                AdlxApi.AntiAlias.IsSupported, AdlxApi.AntiAlias.GetLevel, AaLevelFromEnum),
            SettingId.Perf_AntiAliasingMethod => ReadChoice(AdlxApi.Svc3d.GetAntiAliasing, false,
                AdlxApi.AntiAlias.IsSupported, AdlxApi.AntiAlias.GetMethod, AaMethodFromEnum),
            SettingId.Perf_AnisotropicLevel => ReadChoice(AdlxApi.Svc3d.GetAnisotropicFiltering, false,
                AdlxApi.Aniso.IsSupported, AdlxApi.Aniso.GetLevel, LevelXFromEnum),
            SettingId.Perf_TessellationMode => ReadChoice(AdlxApi.Svc3d.GetTessellation, false,
                AdlxApi.Tess.IsSupported, AdlxApi.Tess.GetMode, TessModeFromEnum),
            SettingId.Perf_TessellationLevel => ReadChoice(AdlxApi.Svc3d.GetTessellation, false,
                AdlxApi.Tess.IsSupported, AdlxApi.Tess.GetLevel, TessLevelFromEnum),

            SettingId.Perf_TextureFilteringQuality or SettingId.Perf_SurfaceFormatOptimization
                or SettingId.Perf_OpenGlTripleBuffering or SettingId.Perf_ShaderCache
                => SettingValue.Unsupported("No matching setting interface in the public ADLX SDK. Configure this in AMD Software; shader-cache reset is a separate action, not an on/off setting."),

            _ => SettingValue.Unsupported("Live detection for this setting is not wired up yet."),
        };
    }

    public WriteResult Write(SettingId id, SettingValue value)
    {
        lock (_gate) return WriteCore(id, value);
    }

    private WriteResult WriteCore(SettingId id, SettingValue value)
    {
        if (id == SettingId.Oc_TdcLimitAmps)
            return WriteResult.Fail("TDC is read-only. AMD requires application validation before changing this limit.");
        if (id is >= SettingId.Display_FreeSync and <= SettingId.Display_Contrast)
            return WriteDisplayCore(id, value);

        if (_svc3d == IntPtr.Zero) return WriteResult.Fail("ADLX 3D-settings service unavailable.");

        if (BoolFeats.TryGetValue(id, out var bf))
        {
            if (!Acquire3d(bf.Svc, bf.NoGpu, out var f)) return WriteResult.Fail("Feature not available.");
            try
            {
                return SetBoolAt(f, bf.Set, value.Bool ?? false)
                    ? WriteResult.Success : WriteResult.Fail("Driver rejected the change.");
            }
            finally { Rel(f); }
        }

        if (IntFeats.TryGetValue(id, out var nf))
        {
            if (value.Number is not { } n) return WriteResult.Fail("No value.");
            if (!Acquire3d(nf.Svc, nf.NoGpu, out var f)) return WriteResult.Fail("Feature not available.");
            try
            {
                return SetIntAt(f, nf.Set, (int)Math.Round(n))
                    ? WriteResult.Success : WriteResult.Fail("Driver rejected the value (feature may need to be enabled first).");
            }
            finally { Rel(f); }
        }

        (int svc, bool noGpu, int setIdx, int? enumVal) plan = id switch
        {
            SettingId.Perf_WaitForVerticalRefresh => (AdlxApi.Svc3d.GetWaitForVerticalRefresh, false, AdlxApi.WaitVSync.SetMode, VsyncToEnum(value.Choice)),
            SettingId.Perf_AntiAliasingMode       => (AdlxApi.Svc3d.GetAntiAliasing, false, AdlxApi.AntiAlias.SetMode, AaModeToEnum(value.Choice)),
            SettingId.Perf_AntiAliasingLevel      => (AdlxApi.Svc3d.GetAntiAliasing, false, AdlxApi.AntiAlias.SetLevel, LevelXToEnum(value.Choice)),
            SettingId.Perf_AntiAliasingMethod     => (AdlxApi.Svc3d.GetAntiAliasing, false, AdlxApi.AntiAlias.SetMethod, AaMethodToEnum(value.Choice)),
            SettingId.Perf_AnisotropicLevel       => (AdlxApi.Svc3d.GetAnisotropicFiltering, false, AdlxApi.Aniso.SetLevel, LevelXToEnum(value.Choice)),
            SettingId.Perf_TessellationMode       => (AdlxApi.Svc3d.GetTessellation, false, AdlxApi.Tess.SetMode, TessModeToEnum(value.Choice)),
            SettingId.Perf_TessellationLevel      => (AdlxApi.Svc3d.GetTessellation, false, AdlxApi.Tess.SetLevel, TessLevelToEnum(value.Choice)),
            _ => (0, false, 0, null),
        };
        if (plan.svc != 0)
        {
            if (plan.enumVal is not { } ev) return WriteResult.Fail("Unrecognised option.");
            if (!Acquire3d(plan.svc, plan.noGpu, out var f)) return WriteResult.Fail("Feature not available.");
            try
            {
                return SetIntAt(f, plan.setIdx, ev) ? WriteResult.Success : WriteResult.Fail("Driver rejected the change.");
            }
            finally { Rel(f); }
        }

        return WriteResult.Fail("This setting is read-only or not wired for live writes yet.");
    }

    private SettingValue ReadChoice(int svc, bool noGpu, int supIdx, int getIdx, Func<int, string?> map)
    {
        if (!Acquire3d(svc, noGpu, out var f)) return SettingValue.Unsupported("Not exposed by this driver / GPU.");
        try
        {
            if (BoolAt(f, supIdx) != true) return SettingValue.Unsupported("Not supported on this GPU.");
            if (IntAt(f, getIdx) is not { } raw) return SettingValue.Unsupported("Value unavailable.");
            return map(raw) is { } key ? SettingValue.Of(key) : SettingValue.Unsupported($"Unmapped driver value ({raw}).");
        }
        finally { Rel(f); }
    }

    // enum <-> option-key maps (option keys match SettingCatalog)
    private static string? VsyncFromEnum(int v) => v switch
    { 0 => "always_off", 1 => "off_unless_app", 2 => "on_unless_app", 3 => "always_on", _ => null };
    private static int? VsyncToEnum(string? k) => k switch
    { "always_off" => 0, "off_unless_app" => 1, "on_unless_app" => 2, "always_on" => 3, _ => null };

    private static string? AaModeFromEnum(int v) => v switch
    { 0 => "app", 1 => "enhance", 2 => "override", _ => null };
    private static int? AaModeToEnum(string? k) => k switch
    { "app" => 0, "enhance" => 1, "override" => 2, _ => null };

    private static string? AaLevelFromEnum(int v) => v switch
    { 2 or 3 => "2x", 4 or 5 => "4x", 8 or 9 => "8x", _ => null };

    private static string? AaMethodFromEnum(int v) => v switch
    { 0 => "multisampling", 1 => "adaptive", 2 => "supersampling", _ => null };
    private static int? AaMethodToEnum(string? k) => k switch
    { "multisampling" => 0, "adaptive" => 1, "supersampling" => 2, _ => null };

    private static string? LevelXFromEnum(int v) => v switch
    { 2 => "2x", 4 => "4x", 8 => "8x", 16 => "16x", _ => null };
    private static int? LevelXToEnum(string? k) => k switch
    { "2x" => 2, "4x" => 4, "8x" => 8, "16x" => 16, _ => null };

    private static string? TessModeFromEnum(int v) => v switch
    { 0 => "amd", 1 => "app", 2 => "override", _ => null };
    private static int? TessModeToEnum(string? k) => k switch
    { "amd" => 0, "app" => 1, "override" => 2, _ => null };

    private static string? TessLevelFromEnum(int v) => v switch
    { 1 => "off", 2 => "2x", 4 => "4x", 6 => "6x", 8 => "8x", 16 => "16x", 32 => "32x", 64 => "64x", _ => null };
    private static int? TessLevelToEnum(string? k) => k switch
    { "off" => 1, "2x" => 2, "4x" => 4, "6x" => 6, "8x" => 8, "16x" => 16, "32x" => 32, "64x" => 64, _ => null };

    // ---------------------------------------------------------------- Display settings
    //
    // IADLXDisplayServices -> per-feature interface reached with the primary IADLXDisplay.
    // Same acquire / IsSupported / Get / Set / Release shape as the 3D features above.
    // Display edits use the shell's saved original value and keep-or-revert confirmation.

    private bool AcquireDisp(int svcIdx, out IntPtr feat)
    {
        feat = IntPtr.Zero;
        if (_dispSvc == IntPtr.Zero || _display == IntPtr.Zero) return false;
        try
        {
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RGpuOutPtr>(_dispSvc, svcIdx)(_dispSvc, _display, out feat))
                   && feat != IntPtr.Zero;
        }
        catch { feat = IntPtr.Zero; return false; }
    }

    private SettingValue ReadDisplayCore(SettingId id)
    {
        if (_dispSvc == IntPtr.Zero || _display == IntPtr.Zero)
            return SettingValue.Unsupported("No display detected on this GPU.");

        return id switch
        {
            SettingId.Display_FreeSync               => ReadDispBool(AdlxApi.DispSvc.GetFreeSync),
            SettingId.Display_VirtualSuperResolution => ReadDispBool(AdlxApi.DispSvc.GetVirtualSuperResolution),
            SettingId.Display_GpuScaling            => ReadDispBool(AdlxApi.DispSvc.GetGPUScaling),
            SettingId.Display_IntegerScaling        => ReadDispBool(AdlxApi.DispSvc.GetIntegerScaling),
            SettingId.Display_VariBright            => ReadDispBool(AdlxApi.DispSvc.GetVariBright),
            SettingId.Display_VariBrightLevel       => ReadVariBrightLevel(),
            SettingId.Display_ColorTemperatureControl or SettingId.Display_Hue or SettingId.Display_Saturation
                or SettingId.Display_Brightness or SettingId.Display_Contrast => ReadCustomColor(id),
            SettingId.Display_Hdcp                  => ReadDispBool(AdlxApi.DispSvc.GetHDCP),
            SettingId.Display_ScalingMode           => ReadDispChoice(AdlxApi.DispSvc.GetScalingMode, ScaleModeFromEnum),
            SettingId.Display_ColorDepth            => ReadDispChoice(AdlxApi.DispSvc.GetColorDepth, ColorDepthFromEnum),
            SettingId.Display_PixelFormat           => ReadDispChoice(AdlxApi.DispSvc.GetPixelFormat, PixelFormatFromEnum),
            _ => SettingValue.Unsupported("Not exposed by this ADLX version."),
        };
    }

    private SettingValue ReadDispBool(int svcIdx)
    {
        if (!AcquireDisp(svcIdx, out var f)) return SettingValue.Unsupported("Not exposed by this driver / display.");
        try
        {
            if (BoolAt(f, AdlxApi.Feat3dBool.IsSupported) != true) return SettingValue.Unsupported("Not supported on this display.");
            return BoolAt(f, AdlxApi.Feat3dBool.IsEnabled) is { } v ? SettingValue.Of(v) : SettingValue.Unsupported("State unavailable.");
        }
        finally { Rel(f); }
    }

    private SettingValue ReadDispChoice(int svcIdx, Func<int, string?> map)
    {
        if (!AcquireDisp(svcIdx, out var f)) return SettingValue.Unsupported("Not exposed by this driver / display.");
        try
        {
            if (BoolAt(f, AdlxApi.DispEnum.IsSupported) != true) return SettingValue.Unsupported("Not supported on this display.");
            if (IntAt(f, AdlxApi.DispEnum.GetValue) is not { } raw) return SettingValue.Unsupported("Value unavailable.");
            return map(raw) is { } key ? SettingValue.Of(key) : SettingValue.Unsupported($"Unmapped driver value ({raw}).");
        }
        finally { Rel(f); }
    }

    private WriteResult WriteDisplayCore(SettingId id, SettingValue value)
    {
        if (_dispSvc == IntPtr.Zero || _display == IntPtr.Zero)
            return WriteResult.Fail("No display detected on this GPU.");

        switch (id)
        {
            case SettingId.Display_FreeSync:               return WriteDispBool(AdlxApi.DispSvc.GetFreeSync, value);
            case SettingId.Display_VirtualSuperResolution: return WriteDispBool(AdlxApi.DispSvc.GetVirtualSuperResolution, value);
            case SettingId.Display_GpuScaling:            return WriteDispBool(AdlxApi.DispSvc.GetGPUScaling, value);
            case SettingId.Display_IntegerScaling:        return WriteDispBool(AdlxApi.DispSvc.GetIntegerScaling, value);
            case SettingId.Display_VariBright:            return WriteDispBool(AdlxApi.DispSvc.GetVariBright, value);
            case SettingId.Display_VariBrightLevel:       return WriteVariBrightLevel(value);
            case SettingId.Display_ColorTemperatureControl: case SettingId.Display_Hue: case SettingId.Display_Saturation:
            case SettingId.Display_Brightness: case SettingId.Display_Contrast: return WriteCustomColor(id, value);
            case SettingId.Display_ScalingMode:           return WriteDispEnum(AdlxApi.DispSvc.GetScalingMode, ScaleModeToEnum(value.Choice));
            case SettingId.Display_ColorDepth:             return WriteDispEnum(AdlxApi.DispSvc.GetColorDepth, ColorDepthToEnum(value.Choice));

            case SettingId.Display_PixelFormat:
                return WriteDispEnum(AdlxApi.DispSvc.GetPixelFormat, value.Choice switch
                {
                    "rgb_full" => AdlxApi.PF_RGB444_FULL, "rgb_limited" => AdlxApi.PF_RGB444_LIMITED,
                    "ycbcr444" => AdlxApi.PF_YCBCR444, "ycbcr422" => AdlxApi.PF_YCBCR422,
                    "ycbcr420" => AdlxApi.PF_YCBCR420, _ => null
                });
            case SettingId.Display_Hdcp: return WriteDispBool(AdlxApi.DispSvc.GetHDCP, value);

            default:
                return WriteResult.Fail("This display setting is not wired for live writes yet.");
        }
    }

    private static readonly string[] VariBrightModes = { "brightness", "optimize_brightness", "balanced", "optimize_battery", "battery" };
    private SettingValue ReadVariBrightLevel()
    {
        if (!AcquireDisp(AdlxApi.DispSvc.GetVariBright, out var feature)) return SettingValue.Unsupported("Vari-Bright is unavailable on this display.");
        try
        {
            if (BoolAt(feature, 3) != true) return SettingValue.Unsupported("Vari-Bright is not supported.");
            for (int i = 0; i < VariBrightModes.Length; i++)
                if (BoolAt(feature, 6 + i) == true) return SettingValue.Of(VariBrightModes[i]);
            return SettingValue.Unsupported("The current Vari-Bright preset is unavailable.");
        }
        finally { Rel(feature); }
    }
    private WriteResult WriteVariBrightLevel(SettingValue value)
    {
        int index = Array.IndexOf(VariBrightModes, value.Choice);
        if (index < 0) return WriteResult.Fail("Unknown Vari-Bright preset.");
        if (!AcquireDisp(AdlxApi.DispSvc.GetVariBright, out var feature)) return WriteResult.Fail("Vari-Bright is unavailable.");
        try { return BoolAt(feature, 3) == true && AdlxApi.OK(AdlxApi.Fn<AdlxApi.RVoid>(feature, 11 + index)(feature))
                ? WriteResult.Success : WriteResult.Fail("Driver rejected the Vari-Bright preset."); }
        finally { Rel(feature); }
    }
    private static int CustomColorSlot(SettingId id) => id switch
    {
        SettingId.Display_Hue => AdlxApi.CustomColor.Hue,
        SettingId.Display_Saturation => AdlxApi.CustomColor.Saturation,
        SettingId.Display_Brightness => AdlxApi.CustomColor.Brightness,
        SettingId.Display_Contrast => AdlxApi.CustomColor.Contrast,
        SettingId.Display_ColorTemperatureControl => AdlxApi.CustomColor.Temperature,
        _ => throw new ArgumentOutOfRangeException(nameof(id)),
    };

    private SettingValue ReadCustomColor(SettingId id)
    {
        if (!AcquireDisp(AdlxApi.DispSvc.GetCustomColor, out var feature)) return SettingValue.Unsupported("The driver did not expose custom colour for the selected display.");
        try
        {
            int slot = CustomColorSlot(id);
            if (BoolAt(feature, slot) != true)
                return SettingValue.Unsupported("The driver reports this colour control unavailable on the selected display.");
            if (IntAt(feature, slot + 2) is not { } value || RangeAt(feature, slot + 1) is not { } range || range.step <= 0 || range.minValue > range.maxValue)
                return SettingValue.Unsupported("Could not read the colour value and its valid range. Refresh detection.");
            return SettingValue.Of(value, range.minValue, range.maxValue, range.step);
        }
        finally { Rel(feature); }
    }
    private WriteResult WriteCustomColor(SettingId id, SettingValue value)
    {
        if (value.Number is not { } requested || !double.IsFinite(requested) || requested != Math.Truncate(requested)) return WriteResult.Fail("Expected a whole-number colour value.");
        if (!AcquireDisp(AdlxApi.DispSvc.GetCustomColor, out var feature)) return WriteResult.Fail("Custom colour is unavailable.");
        try
        {
            int slot = CustomColorSlot(id);
            if (BoolAt(feature, slot) != true || RangeAt(feature, slot + 1) is not { } range || range.step <= 0 || requested < range.minValue || requested > range.maxValue || (requested - range.minValue) % range.step != 0)
                return WriteResult.Fail("The colour value is outside the driver's supported range or step.");
            if (!SetIntAt(feature, slot + 3, (int)requested)) return WriteResult.Fail("The driver rejected the colour change.");
            return IntAt(feature, slot + 2) == (int)requested ? WriteResult.Success : WriteResult.Fail("The colour change could not be verified. Inspect the current value before retrying.");
        }
        finally { Rel(feature); }
    }

    private WriteResult WriteDispBool(int svcIdx, SettingValue value)
    {
        if (!AcquireDisp(svcIdx, out var f)) return WriteResult.Fail("Feature not available on this display.");
        try
        {
            if (BoolAt(f, AdlxApi.Feat3dBool.IsSupported) != true) return WriteResult.Fail("Not supported on this display.");
            return SetBoolAt(f, AdlxApi.Feat3dBool.SetEnabled, value.Bool ?? false)
                ? WriteResult.Success : WriteResult.Fail("Driver rejected the change.");
        }
        finally { Rel(f); }
    }

    private WriteResult WriteDispEnum(int svcIdx, int? enumVal)
    {
        if (enumVal is not { } ev) return WriteResult.Fail("Unrecognised option.");
        if (!AcquireDisp(svcIdx, out var f)) return WriteResult.Fail("Feature not available on this display.");
        try
        {
            if (BoolAt(f, AdlxApi.DispEnum.IsSupported) != true) return WriteResult.Fail("Not supported on this display.");
            return SetIntAt(f, AdlxApi.DispEnum.SetValue, ev)
                ? WriteResult.Success : WriteResult.Fail("Driver rejected the change.");
        }
        finally { Rel(f); }
    }

    private static string? ScaleModeFromEnum(int v) => v switch
    { AdlxApi.SCALE_ASPECT => "aspect", AdlxApi.SCALE_FULL => "full", AdlxApi.SCALE_CENTER => "center", _ => null };
    private static int? ScaleModeToEnum(string? k) => k switch
    { "aspect" => AdlxApi.SCALE_ASPECT, "full" => AdlxApi.SCALE_FULL, "center" => AdlxApi.SCALE_CENTER, _ => null };

    private static string? ColorDepthFromEnum(int v) => v switch
    { AdlxApi.BPC_6 => "6", AdlxApi.BPC_8 => "8", AdlxApi.BPC_10 => "10", AdlxApi.BPC_12 => "12",
      AdlxApi.BPC_14 => "14", AdlxApi.BPC_16 => "16", _ => null };
    private static int? ColorDepthToEnum(string? k) => k switch
    { "6" => AdlxApi.BPC_6, "8" => AdlxApi.BPC_8, "10" => AdlxApi.BPC_10, "12" => AdlxApi.BPC_12,
      "14" => AdlxApi.BPC_14, "16" => AdlxApi.BPC_16, _ => null };

    private static string? PixelFormatFromEnum(int v) => v switch
    { AdlxApi.PF_RGB444_FULL => "rgb_full", AdlxApi.PF_YCBCR444 => "ycbcr444", AdlxApi.PF_YCBCR422 => "ycbcr422",
      AdlxApi.PF_RGB444_LIMITED => "rgb_limited", AdlxApi.PF_YCBCR420 => "ycbcr420", _ => null };

    // ---------------------------------------------------------------- GPU tuning (Overclocking tab)
    //
    private bool AcquireTune(int svcIdx, out IntPtr iface)
    {
        iface = IntPtr.Zero;
        if (_tuning == IntPtr.Zero || _gpu == IntPtr.Zero) return false;
        IntPtr unknown = IntPtr.Zero;
        try
        {
            if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.RGpuOutPtr>(_tuning, svcIdx)(_tuning, _gpu, out unknown)) || unknown == IntPtr.Zero)
                return false;
            string? interfaceId = svcIdx switch
            {
                AdlxApi.TuningSvc.GetAutoTuning => "IADLXGPUAutoTuning",
                AdlxApi.TuningSvc.GetPresetTuning => "IADLXGPUPresetTuning",
                AdlxApi.TuningSvc.GetManualGFXTuning => "IADLXManualGraphicsTuning2",
                AdlxApi.TuningSvc.GetManualVRAMTuning => "IADLXManualVRAMTuning2",
                AdlxApi.TuningSvc.GetManualFanTuning => "IADLXManualFanTuning",
                AdlxApi.TuningSvc.GetManualPowerTuning => "IADLXManualPowerTuning",
                _ => null,
            };
            return interfaceId != null && AdlxApi.OK(AdlxApi.Fn<AdlxApi.QueryInterfaceFn>(unknown, AdlxApi.Iface.QueryInterface)(unknown, interfaceId, out iface))
                && iface != IntPtr.Zero;
        }
        catch { iface = IntPtr.Zero; return false; }
        finally { Rel(unknown); }
    }

    private bool TuneSupported(int isSupportedIdx)
    {
        try
        {
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RGpuOutByte>(_tuning, isSupportedIdx)(_tuning, _gpu, out var b)) && b != 0;
        }
        catch { return false; }
    }

    private static (int min, int max, int step)? Range1(IntPtr f, int idx)
    {
        try
        {
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutIntRange>(f, idx)(f, out var r))
                ? (r.minValue, r.maxValue, r.step <= 0 ? 1 : r.step) : null;
        }
        catch { return null; }
    }

    public GpuTuningInfo GetGpuTuning()
    {
        lock (_gate) return GetGpuTuningCore();
    }

    private GpuTuningInfo GetGpuTuningCore()
    {
        if (_tuning == IntPtr.Zero)
            return new GpuTuningInfo
            {
                GpuName = _name, Available = false,
                Unavailable = "This driver does not expose IADLXGPUTuningServices.",
            };

        bool atFactory = true;
        try { if (AdlxApi.OK(AdlxApi.Fn<AdlxApi.RGpuOutByte>(_tuning, AdlxApi.TuningSvc.IsAtFactory)(_tuning, _gpu, out var af))) atFactory = af != 0; }
        catch { }

        bool supPower = TuneSupported(AdlxApi.TuningSvc.IsSupportedManualPowerTuning);
        bool supFan = TuneSupported(AdlxApi.TuningSvc.IsSupportedManualFanTuning);
        bool supGfx = TuneSupported(AdlxApi.TuningSvc.IsSupportedManualGFXTuning);
        bool supVram = TuneSupported(AdlxApi.TuningSvc.IsSupportedManualVRAMTuning);
        bool supAuto = TuneSupported(AdlxApi.TuningSvc.IsSupportedAutoTuning);
        bool supPreset = TuneSupported(AdlxApi.TuningSvc.IsSupportedPresetTuning);

        bool HasInterface(int index)
        {
            if (!AcquireTune(index, out var feature)) return false;
            Rel(feature);
            return true;
        }
        supGfx &= HasInterface(AdlxApi.TuningSvc.GetManualGFXTuning);
        supVram &= HasInterface(AdlxApi.TuningSvc.GetManualVRAMTuning);
        supPower &= HasInterface(AdlxApi.TuningSvc.GetManualPowerTuning);
        supFan &= HasInterface(AdlxApi.TuningSvc.GetManualFanTuning);

        var info = new GpuTuningInfo
        {
            GpuName = _name,
            Available = supPower || supFan || supGfx || supVram || supAuto || supPreset,
            SystemMode = atFactory ? SystemTuningMode.Default : SystemTuningMode.Custom,
            ManualCustom = !atFactory,
            SupportsPowerTuning = supPower,
            SupportsFanTuning = supFan,
            FanSpeedRange = ValueRange.None,
            FanTempRange = ValueRange.None,
            FanPointCount = 0,
            SupportsZeroRpm = false,
            SupportsManualGpuClock = supGfx,
            SupportsManualVram = supVram,
            SupportsAutoOverclock = false,
            SupportsAutoUndervolt = false,
            SupportsAutoOverclockVram = false,
            SupportsPresets = false,
            FanTuningEnabled = supFan,
            FanAdvancedControl = supFan,
            PowerTuningEnabled = supPower,
        };

        info = ReadVendorModes(info);
        info = info with
        {
            Available = supPower || supFan || supGfx || supVram || info.SupportsAutoUndervolt
                || info.SupportsAutoOverclock || info.SupportsAutoOverclockVram || info.SupportsPresets,
        };
        if (!info.Available)
            info = info with { Unavailable = "No manual tuning capability on this GPU." };

        // ---- power limit (percent offset) ----
        if (supPower && AcquireTune(AdlxApi.TuningSvc.GetManualPowerTuning, out var pf))
        {
            try
            {
                var r = Range1(pf, AdlxApi.PowerTune.GetPowerLimitRange);
                int cur = IntAt(pf, AdlxApi.PowerTune.GetPowerLimit) ?? 0;
                if (r is { } rr) info = info with { PowerLimitRange = new(rr.min, rr.max, rr.step) };
                info = info with { PowerLimitPercent = cur };

                var tdc = ReadTdcFromInterface(pf);
                info = info with
                {
                    SupportsTdc = tdc.Supported,
                    TdcLimitPercent = tdc.Number,
                    TdcUnavailable = tdc.UnsupportedReason,
                    TdcRange = tdc.Supported ? new(tdc.Min!.Value, tdc.Max!.Value, tdc.Step!.Value) : ValueRange.None,
                };
            }
            finally { Rel(pf); }
        }

        // ---- manual GPU clock / voltage ----
        if (supGfx && AcquireTune(AdlxApi.TuningSvc.GetManualGFXTuning, out var gf))
        {
            try
            {
                var rmin = Range1(gf, AdlxApi.GfxTune2.GetGPUMinFrequencyRange);
                var rmax = Range1(gf, AdlxApi.GfxTune2.GetGPUMaxFrequencyRange);
                var rv = Range1(gf, AdlxApi.GfxTune2.GetGPUVoltageRange);
                int cmin = IntAt(gf, AdlxApi.GfxTune2.GetGPUMinFrequency) ?? 0;
                int cmax = IntAt(gf, AdlxApi.GfxTune2.GetGPUMaxFrequency) ?? 0;
                int cv = IntAt(gf, AdlxApi.GfxTune2.GetGPUVoltage) ?? 0;

                var clockR = rmax ?? rmin;
                if (clockR is { } cr) info = info with { GpuClockRange = new(rmin?.min ?? cr.min, cr.max, cr.step) };
                if (rv is { } vr) info = info with { GpuVoltageRange = new(vr.min, vr.max, vr.step) };
                info = info with { GpuMinClockMhz = cmin, GpuMaxClockMhz = cmax, GpuVoltageMv = cv };
            }
            finally { Rel(gf); }
        }

        // ---- VRAM clock ----
        if (supVram && AcquireTune(AdlxApi.TuningSvc.GetManualVRAMTuning, out var vf))
        {
            try
            {
                var r = Range1(vf, AdlxApi.VramTune2.GetMaxVRAMFrequencyRange);
                int cur = IntAt(vf, AdlxApi.VramTune2.GetMaxVRAMFrequency) ?? 0;
                if (r is { } rr) info = info with { VramClockRange = new(rr.min, rr.max, rr.step) };
                info = info with { VramClockMhz = cur };
            }
            finally { Rel(vf); }
        }

        // ---- fan tuning: ranges, zero-RPM, current curve ----
        if (supFan && AcquireTune(AdlxApi.TuningSvc.GetManualFanTuning, out var ff))
        {
            try
            {
                if (AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutRange2>(ff, AdlxApi.FanTune.GetFanTuningRanges)(ff, out var speedR, out var tempR)))
                {
                    info = info with
                    {
                        FanSpeedRange = new(speedR.minValue, speedR.maxValue, speedR.step),
                        FanTempRange = new(tempR.minValue, tempR.maxValue, tempR.step),
                    };
                }

                var zeroSupport = BoolAt(ff, AdlxApi.FanTune.IsSupportedZeroRPM);
                if (zeroSupport == null) return info;
                if (zeroSupport == true)
                {
                    info = info with { SupportsZeroRpm = true };
                    if (BoolAt(ff, AdlxApi.FanTune.GetZeroRPMState) is not { } zr) return info;
                    info = info with { ZeroRpm = zr };
                }

                var curve = ReadFanCurve(ff, AdlxApi.FanTune.GetFanTuningStates);
                if (curve.Count >= 2) info = info with { FanCurve = curve, FanPointCount = curve.Count };
            }
            finally { Rel(ff); }
        }

        return info;
    }

    private static List<FanPoint> ReadFanCurve(IntPtr fanIface, int getStatesIdx)
    {
        var points = new List<FanPoint>();
        IntPtr list = IntPtr.Zero;
        try
        {
            if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutPtr>(fanIface, getStatesIdx)(fanIface, out list)) || list == IntPtr.Zero)
                return points;

            uint begin = 0, end = 0;
            try { begin = AdlxApi.Fn<AdlxApi.RRetUint>(list, AdlxApi.FanStateList.Begin)(list); } catch { }
            try { end = AdlxApi.Fn<AdlxApi.RRetUint>(list, AdlxApi.FanStateList.End)(list); } catch { }

            if (end < begin || end - begin < 2 || end - begin > 32) return new();
            for (uint i = begin; i < end; i++)
            {
                if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.RAtGpu>(list, AdlxApi.FanStateList.At_FanStateList)(list, i, out var st)) || st == IntPtr.Zero)
                    return new();
                int? t = IntAt(st, AdlxApi.FanState.GetTemperature);
                int? s = IntAt(st, AdlxApi.FanState.GetFanSpeed);
                Rel(st);
                if (t == null || s == null) return new();
                points.Add(new FanPoint(t.Value, s.Value));
            }
        }
        catch { points.Clear(); }
        finally { Rel(list); }
        return points;
    }

    public WriteResult SetSystemTuningMode(SystemTuningMode mode)
    {
        if (mode == SystemTuningMode.AutoOverclock) return SetGpuAutoMode(GpuAutoMode.OverclockGpu);
        lock (_gate) return SetSystemTuningModeCore(mode);
    }
    private WriteResult SetSystemTuningModeCore(SystemTuningMode mode)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (_tuning == IntPtr.Zero) return WriteResult.Fail("Tuning services unavailable.");
        if (mode == SystemTuningMode.Default)
        {
            try
            {
                return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RPtrIn>(_tuning, AdlxApi.TuningSvc.ResetToFactory)(_tuning, _gpu))
                    ? WriteResult.Success : WriteResult.Fail("ResetToFactory failed.");
            }
            catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        }
        return mode == SystemTuningMode.Custom ? WriteResult.Success : WriteResult.Fail("Choose a specific GPU automatic tuning mode.");
    }


    public WriteResult SetGpuManualCustom(bool on) =>
        on ? WriteResult.Success : SetSystemTuningMode(SystemTuningMode.Default);

    public WriteResult SetFanTuningEnabled(bool on) => WriteResult.Fail("ADLX exposes fan-curve writes, not a separate fan-tuning enable switch. Edit the curve or explicitly reset tuning to factory defaults.");
    public WriteResult SetFanAdvancedControl(bool on) => WriteResult.Fail("Advanced fan control is an editor mode, not a driver setting. Edit the supported fan curve directly.");
    public WriteResult SetPowerTuningEnabled(bool on) =>
        on ? WriteResult.Success : SetPowerLimitPercent(0);

    public WriteResult SetZeroRpm(bool on) { lock (_gate) return SetZeroRpmCore(on); }
    private WriteResult SetZeroRpmCore(bool on)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualFanTuning, out var ff)) return WriteResult.Fail("Fan tuning unavailable.");
        try
        {
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RByte>(ff, AdlxApi.FanTune.SetZeroRPMState)(ff, (byte)(on ? 1 : 0)))
                ? WriteResult.Success : WriteResult.Fail("Driver rejected Zero RPM change.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        finally { Rel(ff); }
    }

    public WriteResult SetPowerLimitPercent(double percent) { lock (_gate) return SetPowerLimitPercentCore(percent); }
    private WriteResult SetPowerLimitPercentCore(double percent)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualPowerTuning, out var pf)) return WriteResult.Fail("Power tuning unavailable.");
        try
        {
            var r = Range1(pf, AdlxApi.PowerTune.GetPowerLimitRange);
            int v = (int)Math.Round(percent);
            if (r is { } rr) v = Math.Clamp(v, rr.min, rr.max);
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RInt>(pf, AdlxApi.PowerTune.SetPowerLimit)(pf, v))
                ? WriteResult.Success : WriteResult.Fail("Driver rejected the power limit.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        finally { Rel(pf); }
    }

    public WriteResult SetGpuClockRange(int minMhz, int maxMhz) { lock (_gate) return SetGpuClockRangeCore(minMhz, maxMhz); }
    private WriteResult SetGpuClockRangeCore(int minMhz, int maxMhz)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualGFXTuning, out var gf)) return WriteResult.Fail("GPU tuning unavailable.");
        try
        {
            bool ok = true;
            if (minMhz > 0) ok &= AdlxApi.OK(AdlxApi.Fn<AdlxApi.RInt>(gf, AdlxApi.GfxTune2.SetGPUMinFrequency)(gf, minMhz));
            if (maxMhz > 0) ok &= AdlxApi.OK(AdlxApi.Fn<AdlxApi.RInt>(gf, AdlxApi.GfxTune2.SetGPUMaxFrequency)(gf, maxMhz));
            return ok ? WriteResult.Success : WriteResult.Fail("Driver rejected the clock range.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        finally { Rel(gf); }
    }

    public WriteResult SetGpuVoltage(int mv) { lock (_gate) return SetGpuVoltageCore(mv); }
    private WriteResult SetGpuVoltageCore(int mv)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualGFXTuning, out var gf)) return WriteResult.Fail("GPU tuning unavailable.");
        try
        {
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RInt>(gf, AdlxApi.GfxTune2.SetGPUVoltage)(gf, mv))
                ? WriteResult.Success : WriteResult.Fail("Driver rejected the voltage.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        finally { Rel(gf); }
    }

    public WriteResult SetVramClock(int mhz) { lock (_gate) return SetVramClockCore(mhz); }
    private WriteResult SetVramClockCore(int mhz)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualVRAMTuning, out var vf)) return WriteResult.Fail("VRAM tuning unavailable.");
        try
        {
            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RInt>(vf, AdlxApi.VramTune2.SetMaxVRAMFrequency)(vf, mhz))
                ? WriteResult.Success : WriteResult.Fail("Driver rejected the memory clock.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        finally { Rel(vf); }
    }

    public WriteResult SetFanCurve(IReadOnlyList<FanPoint> points) { lock (_gate) return SetFanCurveCore(points); }
    private WriteResult SetFanCurveCore(IReadOnlyList<FanPoint> points)
    {
        if (AutoTuningRunning) return AutoBusy();
        var invalid = RecommendedFanCurve.Validate(GetGpuTuning(), points);
        if (invalid.Length > 0) return WriteResult.Fail(invalid);
        if (!AcquireTune(AdlxApi.TuningSvc.GetManualFanTuning, out var ff)) return WriteResult.Fail("Fan tuning unavailable.");

        IntPtr list = IntPtr.Zero;
        try
        {
            if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutPtr>(ff, AdlxApi.FanTune.GetEmptyFanTuningStates)(ff, out list)) || list == IntPtr.Zero)
                return WriteResult.Fail("Could not get an empty fan-state list.");

            uint begin = AdlxApi.Fn<AdlxApi.RRetUint>(list, AdlxApi.FanStateList.Begin)(list);
            uint end = AdlxApi.Fn<AdlxApi.RRetUint>(list, AdlxApi.FanStateList.End)(list);
            if (end < begin || end - begin != points.Count)
                return WriteResult.Fail("The driver's fan-state count changed. Refresh before applying.");
            var ordered = points;

            uint slot = begin;
            for (int i = 0; i < ordered.Count && slot < end; i++, slot++)
            {
                if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.RAtGpu>(list, AdlxApi.FanStateList.At_FanStateList)(list, slot, out var st)) || st == IntPtr.Zero)
                    return WriteResult.Fail($"Could not access fan point {i + 1}.");
                try
                {
                    if (AdlxApi.Fn<AdlxApi.RInt>(st, AdlxApi.FanState.SetTemperature)(st, (int)ordered[i].TempC) != AdlxApi.ADLX_OK ||
                        AdlxApi.Fn<AdlxApi.RInt>(st, AdlxApi.FanState.SetFanSpeed)(st, (int)ordered[i].SpeedPercent) != AdlxApi.ADLX_OK)
                        return WriteResult.Fail($"Driver rejected fan point {i + 1}.");
                }
                finally { Rel(st); }
            }

            int errIdx = -1;
            int validation = AdlxApi.Fn<AdlxApi.RPtrOutInt>(ff, AdlxApi.FanTune.IsValidFanTuningStates)(ff, list, out errIdx);
            if (validation != AdlxApi.ADLX_OK || errIdx != -1)
                return WriteResult.Fail($"Driver fan-curve validation failed (code {validation}, point index {errIdx}).");

            return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RPtrIn>(ff, AdlxApi.FanTune.SetFanTuningStates)(ff, list))
                ? WriteResult.Success
                : WriteResult.Fail("Driver rejected the fan curve. Active automatic tuning may require a factory reset in AMD Software; Rion will not reset other tuning automatically.");
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
        finally { Rel(list); Rel(ff); }
    }

    public WriteResult ApplyTuningSnapshot(GpuTuningInfo s) { lock (_gate) return ApplyTuningSnapshotCore(s); }
    private WriteResult ApplyTuningSnapshotCore(GpuTuningInfo s)
    {
        if (AutoTuningRunning) return AutoBusy();
        if (_tuning == IntPtr.Zero) return WriteResult.Fail("Tuning services unavailable.");
        if (s.AutoMode is not (GpuAutoMode.None or GpuAutoMode.Default))
            return WriteResult.Fail("The previous state used AMD automatic tuning. Rerunning its algorithm cannot guarantee the exact previous result; restore that mode explicitly in AMD Software. No approximate manual restore was applied.");
        if (s.Preset != GpuPreset.None) return SetGpuPreset(s.Preset);
        try
        {
            if (s.SystemMode == SystemTuningMode.Default && !s.ManualCustom)
            {
                return AdlxApi.OK(AdlxApi.Fn<AdlxApi.RPtrIn>(_tuning, AdlxApi.TuningSvc.ResetToFactory)(_tuning, _gpu))
                    ? WriteResult.Success : WriteResult.Fail("Factory reset failed; the previous tuning state was not restored.");
            }
            var failures = new List<string>();
            void Record(string setting, WriteResult result)
            {
                if (!result.Ok) failures.Add($"{setting}: {result.Error}");
            }
            if (s.SupportsManualGpuClock) Record("GPU clocks", SetGpuClockRangeCore(s.GpuMinClockMhz, s.GpuMaxClockMhz));
            if (s.SupportsManualGpuClock && s.GpuVoltageMv > 0) Record("GPU voltage", SetGpuVoltageCore(s.GpuVoltageMv));
            if (s.SupportsManualVram && s.VramClockMhz > 0) Record("VRAM clock", SetVramClockCore(s.VramClockMhz));
            if (s.SupportsPowerTuning) Record("Power limit", SetPowerLimitPercentCore(s.PowerLimitPercent));
            if (s.SupportsZeroRpm) Record("Zero RPM", SetZeroRpmCore(s.ZeroRpm));
            if (s.SupportsFanTuning && s.FanCurve.Count >= 2) Record("Fan curve", SetFanCurveCore(s.FanCurve));
            return failures.Count == 0 ? WriteResult.Success
                : WriteResult.Fail("Tuning was only partially restored. " + string.Join("; ", failures));
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
    }

    // ---------------------------------------------------------------- helpers
    private static string? Str(IntPtr obj, int index)
    {
        if (obj == IntPtr.Zero) return null;
        try
        {
            int r = AdlxApi.Fn<AdlxApi.ROutStr>(obj, index)(obj, out var p);
            return AdlxApi.OK(r) && p != IntPtr.Zero
                ? System.Runtime.InteropServices.Marshal.PtrToStringAnsi(p)
                : null;
        }
        catch { return null; }
    }

    private string AsicName(int t)
    {
        string fam = t switch
        {
            1 => "Radeon", 2 => "FirePro", 5 => "APU", 6 => "Embedded", _ => $"type {t}",
        };
        string kind = _gpuType == AdlxApi.GPUTYPE_DISCRETE ? "Discrete" : _gpuType == AdlxApi.GPUTYPE_INTEGRATED ? "Integrated" : "";
        return string.IsNullOrEmpty(kind) ? fam : $"{kind} · {fam}";
    }

    public void Dispose()
    {
        lock (_gate)
        {
            if (_terminated || AutoTuningRunning) return;
            _terminated = true;
            foreach (var display in _displays.Values) { try { Rel(display.Pointer); } catch { } }
            _displays.Clear();
            try { if (_dispSvc != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(_dispSvc, AdlxApi.Iface.Release)(_dispSvc); } catch { }
            try { if (_tuning != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(_tuning, AdlxApi.Iface.Release)(_tuning); } catch { }
            try { if (_svc3d != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(_svc3d, AdlxApi.Iface.Release)(_svc3d); } catch { }
            try { if (_perf != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(_perf, AdlxApi.Iface.Release)(_perf); } catch { }
            try { if (_gpu != IntPtr.Zero) AdlxApi.Fn<AdlxApi.RVoid>(_gpu, AdlxApi.Iface.Release)(_gpu); } catch { }
            try
            {
                if (AdlxApi.Terminate is { } terminate && AdlxApi.OK(terminate()))
                {
                    foreach (var listener in _autoListeners) listener.Dispose();
                    _autoListeners.Clear();
                }
            }
            catch { }
            _perf = _gpu = _system = _svc3d = _tuning = _dispSvc = _display = IntPtr.Zero;
        }
    }
}
