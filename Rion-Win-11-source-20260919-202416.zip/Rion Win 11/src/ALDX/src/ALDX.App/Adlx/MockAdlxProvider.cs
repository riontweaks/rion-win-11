using Aldx.Catalog;

namespace Aldx.Adlx;

/// <summary>
/// Hardware-free stand-in: models a desktop Radeon RX 7700 XT on a recent Adrenalin
/// build. Writes mutate in-memory state and are echoed straight back on the next read,
/// so the whole immediate-apply / snapshot / revert flow is exercised with no driver.
/// </summary>
public sealed class MockAdlxProvider : IAdlxProvider
{
    private readonly Random _rng = new(20260902);
    private readonly Dictionary<SettingId, SettingValue> _v = new();

    private SystemTuningMode _sysMode = SystemTuningMode.Default;
    private GpuAutoMode _autoMode = GpuAutoMode.Default;
    private GpuPreset _preset = GpuPreset.None;
    private bool _manualCustom;
    private bool _fanEnabled, _zeroRpm = true, _fanAdvanced;
    private bool _powerEnabled;
    private double _powerPct;
    private int _gpuMin = 500, _gpuMax = 2544, _gpuMv = 1150, _vram = 2500;
    private List<FanPoint> _fan = new()
    {
        new(25, 0), new(45, 18), new(62, 40), new(80, 62), new(100, 100),
    };

    public string DisplayName => "Mock device — Radeon RX 7700 XT (no driver)";
    public bool IsAvailable { get; private set; }
    public bool IsMock => true;

    public void Initialize() { IsAvailable = true; Seed(); }

    public GpuInfo GetGpuInfo() => new()
    {
        Name = "AMD Radeon RX 7700 XT",
        AsicFamily = "RDNA 3 (Navi 32)",
        VramType = "GDDR6",
        VramSizeMb = 12288,
        CoreClockMhz = 2544,
        MemoryClockMhz = 18000,
        BusInterface = "PCIe 4.0 x16",
        VbiosVersion = "022.013.000.043.000000",
        DriverVersion = "26.8.1 (Adrenalin Edition)",
        DriverDate = "2026-08-18",
        VendorId = "0x1002",
        DeviceId = "0x747E",
        IsExternal = false,
        HasDesktop = true,
        TotalBoardPowerW = 245,
        AdlxVersion = "1.5 (mock)",
        AdlxDllPath = @"(mock) C:\Windows\System32\amdadlx64.dll",
        AdlxInitialized = true,
        InitNote = "Mock provider — no native ADLX. Run setup-adlx.ps1 on the Radeon PC for live data.",
    };

    public SettingValue Read(SettingId id) =>
        _v.TryGetValue(id, out var v) ? v : SettingValue.Unsupported("Not modelled by the mock provider.");

    public WriteResult Write(SettingId id, SettingValue value)
    {
        if (!_v.TryGetValue(id, out var cur) || !cur.Supported)
            return WriteResult.Fail("Setting not supported on this device.");
        _v[id] = cur with { Bool = value.Bool ?? cur.Bool, Choice = value.Choice ?? cur.Choice, Number = value.Number ?? cur.Number };
        return WriteResult.Success;
    }

    public GpuMetricsSample ReadMetrics()
    {
        double J(double mid, double spread) => mid + (_rng.NextDouble() - 0.5) * spread;
        var loadFactor = _powerEnabled ? 1 + _powerPct / 100.0 : 1;
        return new GpuMetricsSample
        {
            GpuUsagePercent = Math.Clamp(J(40, 30), 0, 100),
            GpuClockMhz = (int)J(2400 * loadFactor, 160),
            VramClockMhz = _vram,
            EdgeTempC = J(59, 6),
            HotspotTempC = J(74, 9),
            PowerW = J(165 * loadFactor, 40),
            BoardPowerW = J(190 * loadFactor, 42),
            FanRpm = _zeroRpm && J(59, 6) < 50 ? 0 : (int)J(1500, 240),
            FanPercent = J(40, 12),
            VoltageMv = (int)J(_gpuMv - 130, 40),
            VramUsedMb = J(5200, 900),
            Fps = (int)J(138, 28),
            CpuUsagePercent = Math.Clamp(J(20, 16), 0, 100),
            SystemRamUsedMb = J(17800, 1400),
        };
    }

    // ---- tuning ----------------------------------------------------------
    public GpuTuningInfo GetGpuTuning() => new()
    {
        GpuName = "AMD Radeon RX 7700 XT (Primary/Discrete)",
        Available = true,
        SystemMode = _sysMode,
        AutoMode = _autoMode,
        Preset = _preset,
        ManualCustom = _manualCustom,
        SupportsAutoUndervolt = true,
        SupportsAutoOverclock = true,
        SupportsAutoOverclockVram = true,
        SupportsPresets = true,
        SupportsQuiet = true,
        SupportsBalanced = true,
        SupportsManualGpuClock = true,
        SupportsManualVram = true,
        SupportsFanTuning = true,
        SupportsZeroRpm = true,
        SupportsPowerTuning = true,
        SupportsTdc = false,
        GpuClockRange = new(500, 2900, 5),
        GpuVoltageRange = new(950, 1200, 5),
        VramClockRange = new(2000, 2800, 5),
        PowerLimitRange = new(-30, 15, 1),
        FanSpeedRange = new(0, 100, 1),
        FanTempRange = new(20, 100, 1),
        FanPointCount = 5,
        FanTuningEnabled = _fanEnabled,
        ZeroRpm = _zeroRpm,
        FanAdvancedControl = _fanAdvanced,
        FanCurve = _fan.ToArray(),
        PowerTuningEnabled = _powerEnabled,
        PowerLimitPercent = _powerPct,
        GpuMinClockMhz = _gpuMin,
        GpuMaxClockMhz = _gpuMax,
        GpuVoltageMv = _gpuMv,
        VramClockMhz = _vram,
    };

    public WriteResult SetSystemTuningMode(SystemTuningMode mode)
    {
        _sysMode = mode;
        if (mode != SystemTuningMode.Custom) { _manualCustom = false; }
        return WriteResult.Success;
    }

    public WriteResult SetGpuAutoMode(GpuAutoMode mode)
    {
        _autoMode = mode;
        if (mode != GpuAutoMode.None) { _preset = GpuPreset.None; _manualCustom = false; }
        // Mirrors NativeAdlxProvider's real behavior — actually moves the clock/voltage fields
        // (not just the highlighted-toggle enum) so mock mode demonstrates real effect too.
        switch (mode)
        {
            case GpuAutoMode.UndervoltGpu: _gpuMv = (int)new ValueRange(950, 1200, 5).Clamp(_gpuMv - 50); break;
            case GpuAutoMode.OverclockGpu: _gpuMax = (int)new ValueRange(500, 2900, 5).Clamp(_gpuMax + 50); break;
            case GpuAutoMode.OverclockVram: _vram = (int)new ValueRange(2000, 2800, 5).Clamp(_vram + 100); break;
            case GpuAutoMode.Default: _gpuMin = 500; _gpuMax = 2544; _gpuMv = 1150; _vram = 2500; break;
        }
        return WriteResult.Success;
    }

    public WriteResult SetGpuPreset(GpuPreset preset)
    {
        _preset = preset;
        if (preset != GpuPreset.None) { _autoMode = GpuAutoMode.None; _manualCustom = false; }
        switch (preset)
        {
            case GpuPreset.Balanced: _gpuMin = 500; _gpuMax = 2544; _gpuMv = 1150; _vram = 2500; _powerPct = 0; break;
            case GpuPreset.Quiet: _powerPct = new ValueRange(-30, 15, 1).Clamp(-10); break;
        }
        return WriteResult.Success;
    }

    public WriteResult SetGpuManualCustom(bool on)
    {
        _manualCustom = on;
        if (on) { _autoMode = GpuAutoMode.None; _preset = GpuPreset.None; }
        return WriteResult.Success;
    }

    public WriteResult SetFanTuningEnabled(bool on) { _fanEnabled = on; return WriteResult.Success; }
    public WriteResult SetZeroRpm(bool on) { _zeroRpm = on; return WriteResult.Success; }
    public WriteResult SetFanAdvancedControl(bool on) { _fanAdvanced = on; return WriteResult.Success; }

    public WriteResult SetFanCurve(IReadOnlyList<FanPoint> points)
    {
        if (points.Count < 2) return WriteResult.Fail("Need at least two points.");
        _fan = points.OrderBy(p => p.TempC).ToList();
        return WriteResult.Success;
    }

    public WriteResult SetPowerTuningEnabled(bool on) { _powerEnabled = on; return WriteResult.Success; }

    public WriteResult SetPowerLimitPercent(double percent)
    {
        _powerPct = new ValueRange(-30, 15, 1).Clamp(percent);
        return WriteResult.Success;
    }

    public WriteResult SetGpuClockRange(int minMhz, int maxMhz)
    {
        if (maxMhz <= minMhz) return WriteResult.Fail("Max clock must exceed min clock.");
        _gpuMin = minMhz; _gpuMax = maxMhz; return WriteResult.Success;
    }

    public WriteResult SetGpuVoltage(int mv) { _gpuMv = mv; return WriteResult.Success; }
    public WriteResult SetVramClock(int mhz) { _vram = mhz; return WriteResult.Success; }

    public WriteResult ApplyTuningSnapshot(GpuTuningInfo s)
    {
        _sysMode = s.SystemMode; _autoMode = s.AutoMode; _preset = s.Preset; _manualCustom = s.ManualCustom;
        _fanEnabled = s.FanTuningEnabled; _zeroRpm = s.ZeroRpm; _fanAdvanced = s.FanAdvancedControl;
        _fan = s.FanCurve.OrderBy(p => p.TempC).ToList();
        _powerEnabled = s.PowerTuningEnabled; _powerPct = s.PowerLimitPercent;
        _gpuMin = s.GpuMinClockMhz; _gpuMax = s.GpuMaxClockMhz; _gpuMv = s.GpuVoltageMv; _vram = s.VramClockMhz;
        return WriteResult.Success;
    }

    public void Dispose() { }

    // ---- seed ----------------------------------------------------------
    private void Seed()
    {
        void S(SettingId id, SettingValue v) => _v[id] = v;

        S(SettingId.Display_FreeSync, SettingValue.Of(true));
        S(SettingId.Display_VirtualSuperResolution, SettingValue.Of(false));
        S(SettingId.Display_GpuScaling, SettingValue.Of(false));
        S(SettingId.Display_ScalingMode, SettingValue.Of("aspect"));
        S(SettingId.Display_IntegerScaling, SettingValue.Of(false));
        S(SettingId.Display_ColorDepth, SettingValue.Of("8"));
        S(SettingId.Display_PixelFormat, SettingValue.Of("rgb_full"));
        S(SettingId.Display_VariBright, SettingValue.Unsupported("Vari-Bright applies to laptop panels."));
        S(SettingId.Display_VariBrightLevel, SettingValue.Unsupported("Vari-Bright not supported on this display."));
        S(SettingId.Display_ColorTemperatureControl, SettingValue.Of(6500, 1000, 10000, 100));
        S(SettingId.Display_Hue, SettingValue.Of(0, -30, 30, 1));
        S(SettingId.Display_Saturation, SettingValue.Of(100, 0, 200, 1));
        S(SettingId.Display_Brightness, SettingValue.Of(0, -100, 100, 1));
        S(SettingId.Display_Contrast, SettingValue.Of(100, 0, 200, 1));
        S(SettingId.Display_Hdcp, SettingValue.Of(true));

        S(SettingId.Perf_AntiLag, SettingValue.Of(false));
        S(SettingId.Perf_Chill, SettingValue.Of(false));
        S(SettingId.Perf_ChillMinFps, SettingValue.Of(60, 30, 300, 1));
        S(SettingId.Perf_ChillMaxFps, SettingValue.Of(144, 30, 300, 1));
        S(SettingId.Perf_Boost, SettingValue.Of(false));
        S(SettingId.Perf_BoostResolution, SettingValue.Of(66, 50, 100, 1));
        S(SettingId.Perf_RadeonSuperResolution, SettingValue.Of(false));
        S(SettingId.Perf_RsrSharpness, SettingValue.Of(75, 0, 100, 1));
        S(SettingId.Perf_ImageSharpening, SettingValue.Of(false));
        S(SettingId.Perf_ImageSharpeningAmount, SettingValue.Of(50, 0, 100, 1));
        S(SettingId.Perf_EnhancedSync, SettingValue.Of(false));
        S(SettingId.Perf_WaitForVerticalRefresh, SettingValue.Of("off_unless_app"));
        S(SettingId.Perf_FrameRateTargetControl, SettingValue.Of(false));
        S(SettingId.Perf_FrtcTargetFps, SettingValue.Of(141, 30, 300, 1));
        S(SettingId.Perf_AntiAliasingMode, SettingValue.Of("app"));
        S(SettingId.Perf_AntiAliasingLevel, SettingValue.Of("4x"));
        S(SettingId.Perf_AntiAliasingMethod, SettingValue.Of("multisampling"));
        S(SettingId.Perf_MorphologicalAa, SettingValue.Of(false));
        S(SettingId.Perf_AnisotropicFiltering, SettingValue.Of(false));
        S(SettingId.Perf_AnisotropicLevel, SettingValue.Of("8x"));
        S(SettingId.Perf_TextureFilteringQuality, SettingValue.Of("standard"));
        S(SettingId.Perf_SurfaceFormatOptimization, SettingValue.Of(true));
        S(SettingId.Perf_TessellationMode, SettingValue.Of("amd"));
        S(SettingId.Perf_TessellationLevel, SettingValue.Of("64x"));
        S(SettingId.Perf_OpenGlTripleBuffering, SettingValue.Of(false));
        S(SettingId.Perf_ShaderCache, SettingValue.Of("amd"));
    }
}
