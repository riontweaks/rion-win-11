using System.Runtime.InteropServices;

namespace Aldx.Adlx.Native;

internal sealed class AutoTuningCompletion : IDisposable
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate byte CompleteFn(IntPtr listener, IntPtr notification);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate byte EventFlagFn(IntPtr notification);

    private readonly CompleteFn _callback;
    private readonly ManualResetEventSlim _completed = new(false);
    private readonly int _eventIndex;
    private readonly IntPtr _vtable;
    private GCHandle _root;
    public IntPtr Pointer { get; }
    public bool Completed => _completed.IsSet;
    public bool Matched { get; private set; }

    public AutoTuningCompletion(int eventIndex)
    {
        _eventIndex = eventIndex;
        _callback = OnComplete;
        _vtable = Marshal.AllocHGlobal(IntPtr.Size);
        Pointer = Marshal.AllocHGlobal(IntPtr.Size);
        Marshal.WriteIntPtr(_vtable, Marshal.GetFunctionPointerForDelegate(_callback));
        Marshal.WriteIntPtr(Pointer, _vtable);
        _root = GCHandle.Alloc(this);
    }

    private byte OnComplete(IntPtr listener, IntPtr notification)
    {
        try
        {
            Matched = notification != IntPtr.Zero && AdlxApi.Fn<EventFlagFn>(notification, _eventIndex)(notification) != 0;
        }
        catch { Matched = false; }
        finally { _completed.Set(); }
        return 1;
    }

    public bool Wait(TimeSpan timeout) => _completed.Wait(timeout);

    public void Dispose()
    {
        Marshal.FreeHGlobal(Pointer);
        Marshal.FreeHGlobal(_vtable);
        _completed.Dispose();
        if (_root.IsAllocated) _root.Free();
        GC.KeepAlive(_callback);
    }
}
