using System.Runtime.InteropServices;

namespace Aldx.Adlx.Native;

/// <summary>
/// Hand-rolled interop for AMD's ADLX C interface, straight into <c>amdadlx64.dll</c>
/// (shipped by the Radeon driver). No SWIG, no C++ toolchain.
///
/// ADLX C "interfaces" are structs whose first field is a pointer to a vtable —
/// an array of function pointers in declaration order. Every interface derived
/// from IADLXInterface begins with Acquire, Release, QueryInterface (indices 0,1,2);
/// IADLXSystem is the one root object that does NOT (its layout starts at 0).
///
/// Indices below are transcribed from the SDK headers in third_party/ADLX/sdk/SDK/Include.
/// x64 has a single calling convention, so Cdecl/StdCall are interchangeable here.
/// </summary>
internal static class AdlxApi
{
    // ADLX_VER 1.5.0.124  ->  (major<<48)|(minor<<32)|(release<<16)|build
    public const ulong ADLX_FULL_VERSION = (1UL << 48) | (5UL << 32) | (0UL << 16) | 124UL;

    // ADLX_RESULT ordinals (ADLXDefines.h)
    public const int ADLX_OK = 0;
    public const int ADLX_ALREADY_ENABLED = 1;
    public const int ADLX_ALREADY_INITIALIZED = 2;
    public const int ADLX_BAD_VER = 5;
    public const int ADLX_NOT_SUPPORTED = 12;

    public static bool OK(int r) => r == ADLX_OK || r == ADLX_ALREADY_ENABLED || r == ADLX_ALREADY_INITIALIZED;

    // -------------------------------------------------- library + exports
    private static IntPtr _lib;

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int InitializeFn(ulong version, out IntPtr ppSystem);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int TerminateFn();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    public delegate int QueryFullVersionFn(out ulong fullVersion);

    public static InitializeFn? Initialize;
    public static InitializeFn? InitializeWithIncompatibleDriver;
    public static TerminateFn? Terminate;
    public static QueryFullVersionFn? QueryFullVersion;

    public static bool LoadLibraryAndExports(out string error)
    {
        error = "";
        try
        {
            // Never resolve an elevated GPU library beside the app or through PATH.
            string driverLibrary = System.IO.Path.Combine(Environment.SystemDirectory, "amdadlx64.dll");
            if (_lib == IntPtr.Zero && !NativeLibrary.TryLoad(driverLibrary,
                    typeof(AdlxApi).Assembly, DllImportSearchPath.System32, out _lib))
            {
                error = "amdadlx64.dll not found — install AMD Software: Adrenalin Edition.";
                return false;
            }

            T Get<T>(string name) where T : Delegate =>
                Marshal.GetDelegateForFunctionPointer<T>(NativeLibrary.GetExport(_lib, name));

            Initialize = Get<InitializeFn>("ADLXInitialize");
            Terminate = Get<TerminateFn>("ADLXTerminate");
            QueryFullVersion = Get<QueryFullVersionFn>("ADLXQueryFullVersion");
            try { InitializeWithIncompatibleDriver = Get<InitializeFn>("ADLXInitializeWithIncompatibleDriver"); }
            catch { InitializeWithIncompatibleDriver = null; }
            return true;
        }
        catch (Exception ex)
        {
            error = "Loading amdadlx64.dll failed: " + ex.Message;
            return false;
        }
    }

    // -------------------------------------------------- vtable call helpers
    public static IntPtr VtblFn(IntPtr obj, int index)
    {
        IntPtr vtbl = Marshal.ReadIntPtr(obj);
        return Marshal.ReadIntPtr(vtbl, index * IntPtr.Size);
    }

    public static T Fn<T>(IntPtr obj, int index) where T : Delegate =>
        Marshal.GetDelegateForFunctionPointer<T>(VtblFn(obj, index));

    [UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
    public delegate int QueryInterfaceFn(IntPtr instance, [MarshalAs(UnmanagedType.LPWStr)] string id, out IntPtr result);

    // generic method shapes (Cdecl)
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutPtr(IntPtr t, out IntPtr p);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RGpuOutPtr(IntPtr t, IntPtr gpu, out IntPtr p);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutInt(IntPtr t, out int v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutUint(IntPtr t, out uint v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutDouble(IntPtr t, out double v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutByte(IntPtr t, out byte v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutLong(IntPtr t, out long v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutStr(IntPtr t, out IntPtr s);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutIntRange(IntPtr t, out AdlxIntRange r);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutInt2(IntPtr t, out int a, out int b);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RInt(IntPtr t, int v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RByte(IntPtr t, byte v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RVoid(IntPtr t);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RAtGpu(IntPtr t, uint loc, out IntPtr gpu);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate uint RRetUint(IntPtr t);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RRetLong(IntPtr t);
    // tuning shapes
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RGpuOutByte(IntPtr t, IntPtr gpu, out byte v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RPtrIn(IntPtr t, IntPtr p);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int RPtrOutInt(IntPtr t, IntPtr p, out int v);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] public delegate int ROutRange2(IntPtr t, out AdlxIntRange a, out AdlxIntRange b);

    // -------------------------------------------------- vtable indices
    // IADLXInterface base (present on every interface EXCEPT IADLXSystem)
    public static class Iface { public const int Acquire = 0, Release = 1, QueryInterface = 2; }

    // IADLXSystem (ISystem.h) — no IADLXInterface prefix
    public static class Sys
    {
        public const int GetHybridGraphicsType = 0, GetGPUs = 1, QueryInterface = 2,
            GetDisplaysServices = 3, GetDesktopsServices = 4, GetGPUsChangedHandling = 5, EnableLog = 6,
            Get3DSettingsServices = 7, GetGPUTuningServices = 8, GetPerformanceMonitoringServices = 9,
            TotalSystemRAM = 10, GetI2C = 11;
    }

    // IADLXGPUList (ISystem.h): base(3) + IADLXList(8) + At_GPUList, Add_Back_GPUList
    public static class GpuList { public const int Size = 3, Begin = 5, End = 6, At_GPUList = 11; }

    // ADLX_GPU_TYPE
    public const int GPUTYPE_INTEGRATED = 1, GPUTYPE_DISCRETE = 2;

    // IADLXGPU (ISystem.h)
    public static class Gpu
    {
        public const int VendorId = 3, ASICFamilyType = 4, Type = 5, IsExternal = 6, Name = 7,
            DriverPath = 8, PNPString = 9, HasDesktops = 10, TotalVRAM = 11, VRAMType = 12,
            BIOSInfo = 13, DeviceId = 14, RevisionId = 15, SubSystemId = 16, SubSystemVendorId = 17, UniqueId = 18;
    }

    // IADLXPerformanceMonitoringServices (IPerformanceMonitoring.h)
    public static class Perf
    {
        public const int SetSamplingInterval = 4, StartTracking = 11, StopTracking = 12,
            GetCurrentAllMetrics = 17, GetCurrentGPUMetrics = 18, GetCurrentSystemMetrics = 19,
            GetCurrentFPS = 20, GetSupportedGPUMetrics = 21, GetSupportedSystemMetrics = 22;
    }

    // IADLXGPUMetrics (IPerformanceMonitoring.h)
    public static class GpuMetrics
    {
        public const int TimeStamp = 3, GPUUsage = 4, GPUClockSpeed = 5, GPUVRAMClockSpeed = 6,
            GPUTemperature = 7, GPUHotspotTemperature = 8, GPUPower = 9, GPUTotalBoardPower = 10,
            GPUFanSpeed = 11, GPUVRAM = 12, GPUVoltage = 13, GPUIntakeTemperature = 14;
    }

    // IADLXGPUMetricsSupport (IPerformanceMonitoring.h)
    public static class GpuMetricsSupport
    {
        public const int IsSupportedGPUUsage = 3, IsSupportedGPUClockSpeed = 4, IsSupportedGPUVRAMClockSpeed = 5,
            IsSupportedGPUTemperature = 6, IsSupportedGPUHotspotTemperature = 7, IsSupportedGPUPower = 8,
            IsSupportedGPUTotalBoardPower = 9, IsSupportedGPUFanSpeed = 10, IsSupportedGPUVRAM = 11,
            IsSupportedGPUVoltage = 12;
    }

    // ============================================================ 3D settings
    // IADLX3DSettingsServices (I3DSettings.h). Every getter except RSR also takes an IADLXGPU*.
    public static class Svc3d
    {
        public const int GetAntiLag = 3, GetChill = 4, GetBoost = 5, GetImageSharpening = 6,
            GetEnhancedSync = 7, GetWaitForVerticalRefresh = 8, GetFrameRateTargetControl = 9,
            GetAntiAliasing = 10, GetMorphologicalAntiAliasing = 11, GetAnisotropicFiltering = 12,
            GetTessellation = 13, GetRadeonSuperResolution = 14 /* no GPU arg */, GetResetShaderCache = 15,
            Get3DSettingsChangedHandling = 16;
    }

    // Plain on/off feature: IADLX3DAntiLag, IADLX3DEnhancedSync, IADLX3DMorphologicalAntiAliasing
    public static class Feat3dBool { public const int IsSupported = 3, IsEnabled = 4, SetEnabled = 5; }

    // IADLX3DChill
    public static class Chill
    {
        public const int IsSupported = 3, IsEnabled = 4, GetFPSRange = 5, GetMinFPS = 6, GetMaxFPS = 7,
            SetEnabled = 8, SetMinFPS = 9, SetMaxFPS = 10;
    }

    // IADLX3DBoost
    public static class Boost
    {
        public const int IsSupported = 3, IsEnabled = 4, GetResolutionRange = 5, GetResolution = 6,
            SetEnabled = 7, SetResolution = 8;
    }

    // IADLX3DImageSharpening
    public static class Sharpen
    {
        public const int IsSupported = 3, IsEnabled = 4, GetSharpnessRange = 5, GetSharpness = 6,
            SetEnabled = 7, SetSharpness = 8;
    }

    // IADLX3DRadeonSuperResolution (note the different order: SetEnabled before the range/getters)
    public static class Rsr
    {
        public const int IsSupported = 3, IsEnabled = 4, SetEnabled = 5, GetSharpnessRange = 6,
            GetSharpness = 7, SetSharpness = 8;
    }

    // IADLX3DWaitForVerticalRefresh — GetMode/SetMode take ADLX_WAIT_FOR_VERTICAL_REFRESH_MODE (int)
    public static class WaitVSync { public const int IsSupported = 3, IsEnabled = 4, GetMode = 5, SetMode = 6; }

    // IADLX3DFrameRateTargetControl
    public static class Frtc
    {
        public const int IsSupported = 3, IsEnabled = 4, GetFPSRange = 5, GetFPS = 6, SetEnabled = 7, SetFPS = 8;
    }

    // IADLX3DAnisotropicFiltering — GetLevel/SetLevel take ADLX_ANISOTROPIC_FILTERING_LEVEL (int: 2/4/8/16)
    public static class Aniso
    {
        public const int IsSupported = 3, IsEnabled = 4, GetLevel = 5, SetEnabled = 6, SetLevel = 7;
    }

    // IADLX3DAntiAliasing — no IsEnabled; Mode/Level/Method getters then setters
    public static class AntiAlias
    {
        public const int IsSupported = 3, GetMode = 4, GetLevel = 5, GetMethod = 6,
            SetMode = 7, SetLevel = 8, SetMethod = 9;
    }

    // IADLX3DTessellation — no IsEnabled; Mode/Level
    public static class Tess
    {
        public const int IsSupported = 3, GetMode = 4, GetLevel = 5, SetMode = 6, SetLevel = 7;
    }

    // ADLX_WAIT_FOR_VERTICAL_REFRESH_MODE
    public const int WFVR_ALWAYS_OFF = 0, WFVR_OFF_UNLESS_APP = 1, WFVR_ON_UNLESS_APP = 2, WFVR_ALWAYS_ON = 3;
    // ADLX_ANTI_ALIASING_MODE
    public const int AA_MODE_APP = 0, AA_MODE_ENHANCE = 1, AA_MODE_OVERRIDE = 2;
    // ADLX_ANTI_ALIASING_METHOD
    public const int AA_METHOD_MULTISAMPLING = 0, AA_METHOD_ADAPTIVE = 1, AA_METHOD_SUPERSAMPLING = 2;

    // ============================================================ Display settings
    // IADLXDisplayServices (IDisplays.h). Reached via Sys.GetDisplaysServices (index 3).
    // Every Get<Feature> here takes an IADLXDisplay* (passed via the RGpuOutPtr "gpu" slot).
    public static class DispSvc
    {
        public const int GetNumberOfDisplays = 3, GetDisplays = 4,
            GetFreeSync = 9, GetVirtualSuperResolution = 10, GetGPUScaling = 11, GetScalingMode = 12,
            GetIntegerScaling = 13, GetColorDepth = 14, GetPixelFormat = 15, GetCustomColor = 16, GetHDCP = 17, GetVariBright = 19;
    }

    // IADLXDisplayCustomColor: each block is support, range, get, set.
    public static class CustomColor
    {
        public const int Hue = 3, Saturation = 7, Brightness = 11, Contrast = 15, Temperature = 19;
    }

    // IADLXDisplayList: base(3) + IADLXList, typed At at 11 (same layout as GpuList)
    public static class DispList { public const int Size = 3, Begin = 5, End = 6, At_DisplayList = 11; }

    // per-display enum-valued features (ScalingMode / ColorDepth / PixelFormat): IsSupported/GetValue/SetValue
    public static class DispEnum { public const int IsSupported = 3, GetValue = 4, SetValue = 5; }
    // bool display features (FreeSync / VSR / GPUScaling / IntegerScaling / HDCP / VariBright) reuse Feat3dBool (3/4/5).

    // ADLX_SCALE_MODE
    public const int SCALE_ASPECT = 0, SCALE_FULL = 1, SCALE_CENTER = 2;
    // ADLX_COLOR_DEPTH (BPC_UNKNOWN = 0)
    public const int BPC_6 = 1, BPC_8 = 2, BPC_10 = 3, BPC_12 = 4, BPC_14 = 5, BPC_16 = 6;
    // ADLX_PIXEL_FORMAT (FORMAT_UNKNOWN = 0)
    public const int PF_RGB444_FULL = 1, PF_YCBCR444 = 2, PF_YCBCR422 = 3, PF_RGB444_LIMITED = 4, PF_YCBCR420 = 5;

    // ============================================================ GPU tuning
    // IADLXGPUTuningServices (IGPUTuning.h). Every Is*/Get* here takes an IADLXGPU*.
    public static class TuningSvc
    {
        public const int GetGPUTuningChangedHandling = 3, IsAtFactory = 4, ResetToFactory = 5,
            IsSupportedAutoTuning = 6, IsSupportedPresetTuning = 7, IsSupportedManualGFXTuning = 8,
            IsSupportedManualVRAMTuning = 9, IsSupportedManualFanTuning = 10, IsSupportedManualPowerTuning = 11,
            GetAutoTuning = 12, GetPresetTuning = 13, GetManualGFXTuning = 14, GetManualVRAMTuning = 15,
            GetManualFanTuning = 16, GetManualPowerTuning = 17;
    }

    // IADLXManualPowerTuning (IGPUManualPowerTuning.h) — power limit is a percent offset for RDNA
    public static class PowerTune
    {
        public const int GetPowerLimitRange = 3, GetPowerLimit = 4, SetPowerLimit = 5,
            IsSupportedTDCLimit = 6, GetTDCLimitRange = 7, GetTDCLimit = 8, SetTDCLimit = 9;
    }

    // IADLXManualFanTuning (IGPUManualFanTuning.h)
    public static class FanTune
    {
        public const int GetFanTuningRanges = 3, GetFanTuningStates = 4, GetEmptyFanTuningStates = 5,
            IsValidFanTuningStates = 6, SetFanTuningStates = 7, IsSupportedZeroRPM = 8, GetZeroRPMState = 9,
            SetZeroRPMState = 10, IsSupportedMinAcousticLimit = 11, GetMinAcousticLimitRange = 12,
            GetMinAcousticLimit = 13, SetMinAcousticLimit = 14, IsSupportedMinFanSpeed = 15,
            GetMinFanSpeedRange = 16, GetMinFanSpeed = 17, SetMinFanSpeed = 18, IsSupportedTargetFanSpeed = 19,
            GetTargetFanSpeedRange = 20, GetTargetFanSpeed = 21, SetTargetFanSpeed = 22;
    }

    // IADLXManualFanTuningStateList (list; base IADLXInterface + IADLXList)
    public static class FanStateList
    {
        public const int Size = 3, Empty = 4, Begin = 5, End = 6, At = 7, Clear = 8,
            Remove_Back = 9, Add_Back = 10, At_FanStateList = 11, Add_Back_FanStateList = 12;
    }

    // IADLXManualFanTuningState
    public static class FanState
    {
        public const int GetFanSpeed = 3, SetFanSpeed = 4, GetTemperature = 5, SetTemperature = 6;
    }

    // IADLXManualGraphicsTuning2 (IGPUManualGFXTuning.h) — per-endpoint min/max/voltage
    public static class GfxTune2
    {
        public const int GetGPUMinFrequencyRange = 3, GetGPUMinFrequency = 4, SetGPUMinFrequency = 5,
            GetGPUMaxFrequencyRange = 6, GetGPUMaxFrequency = 7, SetGPUMaxFrequency = 8,
            GetGPUVoltageRange = 9, GetGPUVoltage = 10, SetGPUVoltage = 11;
    }

    // IADLXManualVRAMTuning2 (IGPUManualVRAMTuning.h)
    public static class VramTune2
    {
        public const int IsSupportedMemoryTiming = 3, GetSupportedMemoryTimingDescriptionList = 4,
            GetMemoryTimingDescription = 5, SetMemoryTimingDescription = 6,
            GetMaxVRAMFrequencyRange = 7, GetMaxVRAMFrequency = 8, SetMaxVRAMFrequency = 9;
    }
}

[StructLayout(LayoutKind.Sequential)]
internal struct AdlxIntRange
{
    public int minValue;
    public int maxValue;
    public int step;
}
