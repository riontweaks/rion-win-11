namespace Aldx.Adlx;

/// <summary>Connects to the installed driver; unavailable hardware never becomes a simulated GPU.</summary>
public static class AdlxProviderFactory
{
    public static IAdlxProvider Create()
    {
        var native = new NativeAdlxProvider();
        string reason;
        try
        {
            native.Initialize();
            if (native.IsAvailable) return native;
            reason = native.GetGpuInfo().InitNote;
        }
        catch (Exception ex)
        {
            reason = "ADLX initialization failed: " + ex.Message;
        }
        try { native.Dispose(); }
        catch (Exception ex) { reason += " Cleanup failed: " + ex.Message; }
        return new UnavailableAdlxProvider(string.IsNullOrWhiteSpace(reason)
            ? "No compatible AMD driver connection." : reason);
    }
}
