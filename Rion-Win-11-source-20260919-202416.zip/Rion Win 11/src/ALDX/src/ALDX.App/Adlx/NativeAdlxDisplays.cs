using Aldx.Adlx.Native;

namespace Aldx.Adlx;

public sealed partial class NativeAdlxProvider
{
    private Dictionary<string, (DisplayInfo Info, IntPtr Pointer)> _displays = new();
    private string _selectedDisplayId = "";
    public string SelectedDisplayId { get { lock (_gate) return _selectedDisplayId; } }
    public IReadOnlyList<DisplayInfo> GetDisplays()
    {
        lock (_gate)
        {
            RefreshDisplaysCore();
            return _displays.Values.Select(d => d.Info).ToArray();
        }
    }
    public WriteResult SelectDisplay(string id)
    {
        lock (_gate)
        {
            if (!_displays.TryGetValue(id, out var display)) return WriteResult.Fail("The display is no longer available. Re-detect displays.");
            _selectedDisplayId = id;
            _display = display.Pointer;
            return WriteResult.Success;
        }
    }
    private void RefreshDisplaysCore()
    {
        var next = new Dictionary<string, (DisplayInfo Info, IntPtr Pointer)>();
        IntPtr list = IntPtr.Zero;
        try
        {
            if (_dispSvc == IntPtr.Zero || !AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutPtr>(_dispSvc, AdlxApi.DispSvc.GetDisplays)(_dispSvc, out list)) || list == IntPtr.Zero)
                return;
            uint begin = AdlxApi.Fn<AdlxApi.RRetUint>(list, AdlxApi.DispList.Begin)(list);
            uint end = AdlxApi.Fn<AdlxApi.RRetUint>(list, AdlxApi.DispList.End)(list);
            if (end < begin || end - begin > 64) return;
            for (uint index = begin; index < end; index++)
            {
                if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.RAtGpu>(list, AdlxApi.DispList.At_DisplayList)(list, index, out var display)) || display == IntPtr.Zero) continue;
                bool retained = false;
                try
                {
                    if (!AdlxApi.OK(AdlxApi.Fn<AdlxApi.ROutLong>(display, 13)(display, out var unique))) continue;
                    string id = unique.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    var info = new DisplayInfo(id, $"{Str(display, 6) ?? "AMD display"} · {id}");
                    retained = next.TryAdd(id, (info, display));
                }
                finally { if (!retained) Rel(display); }
            }
            foreach (var old in _displays.Values) Rel(old.Pointer);
            _displays = next;
            next = new();
            if (_selectedDisplayId.Length == 0) _selectedDisplayId = _displays.Keys.FirstOrDefault() ?? "";
            _display = _displays.TryGetValue(_selectedDisplayId, out var selected) ? selected.Pointer : IntPtr.Zero;
        }
        finally
        {
            Rel(list);
            foreach (var unused in next.Values) Rel(unused.Pointer);
        }
    }
}
