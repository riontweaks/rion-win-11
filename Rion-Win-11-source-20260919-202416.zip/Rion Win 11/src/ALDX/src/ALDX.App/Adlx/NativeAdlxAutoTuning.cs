using Aldx.Adlx.Native;

namespace Aldx.Adlx;

public sealed partial class NativeAdlxProvider
{
    private readonly List<AutoTuningCompletion> _autoListeners = new();
    private AutoTuningCompletion? _autoPending;
    private string _tuningRecoveryDirectory = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "GpuTuningRecovery");
    private bool AutoTuningRunning => _autoPending is { Completed: false };
    private static WriteResult AutoBusy() => WriteResult.Fail("AMD automatic tuning is still running. Wait for completion before changing or restoring tuning.");

    private WriteResult SaveTuningRecovery(string requested)
    {
        try
        {
            var snapshot = GetGpuTuningCore();
            if (!snapshot.Available) return WriteResult.Fail("Cannot capture the current GPU tuning state; no tuning change was started.");
            var bytes = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(new
            {
                SchemaVersion = 1,
                CapturedUtc = DateTimeOffset.UtcNow,
                Requested = requested,
                State = snapshot,
                AutomaticReplayAllowed = false,
            });
            System.IO.Directory.CreateDirectory(_tuningRecoveryDirectory);
            string path = System.IO.Path.Combine(_tuningRecoveryDirectory, Guid.NewGuid().ToString("N") + ".json");
            using var stream = new System.IO.FileStream(path, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write, System.IO.FileShare.None);
            stream.Write(bytes);
            stream.Flush(true);
            return WriteResult.Success;
        }
        catch (Exception error) { return WriteResult.Fail("Could not persist the GPU tuning recovery snapshot; no change was started. " + error.Message); }
    }

    private GpuTuningInfo ReadVendorModes(GpuTuningInfo info)
    {
        if (AcquireTune(AdlxApi.TuningSvc.GetAutoTuning, out var automatic))
        {
            try
            {
                info = info with
                {
                    SupportsAutoUndervolt = BoolAt(automatic, 3) == true,
                    SupportsAutoOverclock = BoolAt(automatic, 4) == true,
                    SupportsAutoOverclockVram = BoolAt(automatic, 5) == true,
                    AutoMode = BoolAt(automatic, 6) == true ? GpuAutoMode.UndervoltGpu
                        : BoolAt(automatic, 7) == true ? GpuAutoMode.OverclockGpu
                        : BoolAt(automatic, 8) == true ? GpuAutoMode.OverclockVram : GpuAutoMode.None,
                };
            }
            finally { Rel(automatic); }
        }
        if (AcquireTune(AdlxApi.TuningSvc.GetPresetTuning, out var preset))
        {
            try
            {
                info = info with
                {
                    SupportsQuiet = BoolAt(preset, 4) == true,
                    SupportsBalanced = BoolAt(preset, 5) == true,
                    SupportsPresets = BoolAt(preset, 4) == true || BoolAt(preset, 5) == true,
                    Preset = BoolAt(preset, 9) == true ? GpuPreset.Quiet
                        : BoolAt(preset, 10) == true ? GpuPreset.Balanced : GpuPreset.None,
                };
            }
            finally { Rel(preset); }
        }
        return info with { ManualCustom = info.ManualCustom && info.AutoMode == GpuAutoMode.None && info.Preset == GpuPreset.None };
    }

    public WriteResult SetGpuAutoMode(GpuAutoMode mode)
    {
        AutoTuningCompletion completion;
        int currentIndex;
        lock (_gate)
        {
            if (AutoTuningRunning) return AutoBusy();
            if (mode is GpuAutoMode.None or GpuAutoMode.Default)
                return SetSystemTuningModeCore(SystemTuningMode.Default);
            int offset = mode switch
            {
                GpuAutoMode.UndervoltGpu => 0,
                GpuAutoMode.OverclockGpu => 1,
                GpuAutoMode.OverclockVram => 2,
                _ => -1,
            };
            if (offset < 0) return WriteResult.Fail("Unknown automatic tuning mode.");
            if (!AcquireTune(AdlxApi.TuningSvc.GetAutoTuning, out var automatic))
                return WriteResult.Fail("AMD automatic tuning is unavailable on this GPU/driver.");
            try
            {
                if (BoolAt(automatic, 3 + offset) != true) return WriteResult.Fail("This automatic tuning mode is not supported by the GPU.");
                var backup = SaveTuningRecovery(mode.ToString());
                if (!backup.Ok) return backup;
                currentIndex = 6 + offset;
                completion = new AutoTuningCompletion(3 + offset);
                _autoListeners.Add(completion);
                _autoPending = completion;
                int result = AdlxApi.Fn<AdlxApi.RPtrIn>(automatic, 9 + offset)(automatic, completion.Pointer);
                if (!AdlxApi.OK(result))
                {
                    _autoPending = null;
                    return WriteResult.Fail($"AMD could not start automatic tuning (ADLX {result}). If AMD requires factory defaults, explicitly reset tuning first; no automatic reset was performed.");
                }
            }
            finally { Rel(automatic); }
        }
        if (!completion.Wait(TimeSpan.FromMinutes(2)))
            return WriteResult.Fail("AMD has not reported automatic tuning completion within two minutes. It may still be running; further tuning writes are blocked until its completion callback. No success or stability result is assumed.");
        lock (_gate)
        {
            if (!completion.Matched) return WriteResult.Fail("AMD returned an unexpected tuning completion event.");
            if (!AcquireTune(AdlxApi.TuningSvc.GetAutoTuning, out var automatic)) return WriteResult.Fail("Could not verify the completed tuning mode.");
            try { return BoolAt(automatic, currentIndex) == true ? WriteResult.Success : WriteResult.Fail("AMD completed the request but did not report the requested tuning mode active."); }
            finally { Rel(automatic); }
        }
    }

    public WriteResult SetGpuPreset(GpuPreset preset)
    {
        lock (_gate)
        {
            if (AutoTuningRunning) return AutoBusy();
            if (preset == GpuPreset.None) return WriteResult.Fail("Select a tuning preset or explicitly reset to factory defaults.");
            int supported = preset switch { GpuPreset.Quiet => 4, GpuPreset.Balanced => 5, _ => -1 };
            if (supported < 0) return WriteResult.Fail("Unknown tuning preset.");
            if (!AcquireTune(AdlxApi.TuningSvc.GetPresetTuning, out var feature)) return WriteResult.Fail("AMD tuning presets are unavailable on this GPU/driver.");
            try
            {
                if (BoolAt(feature, supported) != true) return WriteResult.Fail("This preset is not supported by the GPU.");
                var backup = SaveTuningRecovery(preset.ToString());
                if (!backup.Ok) return backup;
                int result = AdlxApi.Fn<AdlxApi.RVoid>(feature, supported + 10)(feature);
                if (!AdlxApi.OK(result)) return WriteResult.Fail($"AMD rejected the tuning preset (ADLX {result}). A factory reset may be required; no automatic reset was performed.");
                return BoolAt(feature, supported + 5) == true ? WriteResult.Success : WriteResult.Fail("AMD did not report the requested preset active after applying it.");
            }
            finally { Rel(feature); }
        }
    }
}
