namespace Aldx.Adlx;
public sealed record DisplayInfo(string Id, string Name)
{
    public override string ToString() => Name;
}
