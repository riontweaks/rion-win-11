namespace Aldx.Adlx;

/// <summary>
/// One performance-monitoring sample from <c>IADLXGPUMetrics</c> /
/// <c>IADLXAllMetrics</c>; each field is gated by the matching <c>IsSupported*</c> call,
/// so a null means "this GPU/driver does not report it".
/// </summary>
public sealed record GpuMetricsSample
{
    public DateTime TimestampLocal { get; init; } = DateTime.Now;

    public double? GpuUsagePercent { get; init; }
    public int? GpuClockMhz { get; init; }
    public int? VramClockMhz { get; init; }
    public double? EdgeTempC { get; init; }
    public double? HotspotTempC { get; init; }
    public double? PowerW { get; init; }
    public double? BoardPowerW { get; init; }
    public int? FanRpm { get; init; }
    public double? FanPercent { get; init; }
    public int? VoltageMv { get; init; }
    public double? VramUsedMb { get; init; }
    public int? Fps { get; init; }

    public double? CpuUsagePercent { get; init; }
    public double? SystemRamUsedMb { get; init; }
}
