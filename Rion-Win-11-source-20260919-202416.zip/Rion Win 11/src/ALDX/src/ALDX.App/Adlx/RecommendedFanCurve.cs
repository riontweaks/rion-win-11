using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Aldx.Adlx;

/// <summary>App-curated cooling starter, not a vendor thermal target or auto-tuning scan.</summary>
public static class RecommendedFanCurve
{
    public static bool OnGrid(double value, ValueRange range) =>
        double.IsFinite(value) && double.IsFinite(range.Min) && double.IsFinite(range.Max) &&
        double.IsFinite(range.Step) && range.Step > 0 && range.Max > range.Min &&
        value >= range.Min && value <= range.Max &&
        Math.Abs((value - range.Min) / range.Step - Math.Round((value - range.Min) / range.Step)) < 0.000001;

    public static string Validate(GpuTuningInfo info, IReadOnlyList<FanPoint> points)
    {
        if (!info.Available || !info.SupportsFanTuning) return "This GPU does not expose manual fan tuning.";
        if (points.Count < 2 || points.Count > 32 || points.Count != info.FanPointCount)
            return "The driver did not return a complete fan-state list.";
        for (int i = 0; i < points.Count; i++)
        {
            var p = points[i];
            if (!OnGrid(p.TempC, info.FanTempRange) || !OnGrid(p.SpeedPercent, info.FanSpeedRange) ||
                p.TempC != Math.Round(p.TempC) || p.SpeedPercent != Math.Round(p.SpeedPercent))
                return $"Point {i + 1} is outside the driver's ranges or step sizes.";
            if (i > 0 && (p.TempC <= points[i - 1].TempC || p.SpeedPercent < points[i - 1].SpeedPercent))
                return "The curve must have increasing temperatures and nondecreasing fan speeds.";
        }
        return "";
    }

    public static FanPoint[] Create(GpuTuningInfo info)
    {
        string error = Validate(info, info.FanCurve);
        if (error.Length > 0) throw new InvalidOperationException(error);
        // At most five percentage points, rounded DOWN to a supported increment.
        // Preserve zero-duty points and every temperature anchor, including endpoints.
        double delta = Math.Floor(5 / info.FanSpeedRange.Step) * info.FanSpeedRange.Step;
        double ceiling = info.FanSpeedRange.Min + Math.Floor((info.FanSpeedRange.Max - info.FanSpeedRange.Min) / info.FanSpeedRange.Step) * info.FanSpeedRange.Step;
        return info.FanCurve.Select(p => p with { SpeedPercent = p.SpeedPercent == 0 ? 0 : Math.Min(ceiling, p.SpeedPercent + delta) }).ToArray();
    }
}

/// <summary>One undo journal for the bound provider; never replays settings at startup.</summary>
public sealed class FanCurveRecommendationSession(IAdlxProvider provider, string recoveryDirectory)
{
    public sealed record Recovery(string Identity, GpuTuningInfo Before, FanPoint[] Target, GpuTuningInfo? ObservedFailure = null);
    private Recovery? _recovery;
    private GpuTuningInfo? _preview;
    private string _identity = "";
    private string _path = "";
    public FanPoint[] Proposed { get; private set; } = [];
    public bool CanApply => _preview != null && _recovery == null && !Proposed.SequenceEqual(_preview.FanCurve);
    public bool CanRestore => _recovery != null;
    public string RecoveryPath => _path;
    private string Identity()
    {
        var g = provider.GetGpuInfo();
        if (!provider.IsMock && (string.IsNullOrWhiteSpace(g.AdapterId) || string.IsNullOrWhiteSpace(g.DriverRegistryPath) || string.IsNullOrWhiteSpace(g.DriverVersion)))
            throw new InvalidOperationException("The adapter identity or driver version could not be verified. Fan preset unavailable.");
        return JsonSerializer.Serialize(new { g.Name, g.AdapterId, g.DriverRegistryPath, g.VendorId, g.DeviceId, g.VbiosVersion, g.DriverVersion, Demo = provider.IsMock });
    }
    private static bool SameFan(GpuTuningInfo a, GpuTuningInfo b) =>
        a.Available && b.Available && a.SupportsFanTuning && b.SupportsFanTuning &&
        a.FanPointCount == b.FanPointCount && a.FanSpeedRange == b.FanSpeedRange && a.FanTempRange == b.FanTempRange &&
        a.SupportsZeroRpm == b.SupportsZeroRpm && a.ZeroRpm == b.ZeroRpm && a.FanCurve.SequenceEqual(b.FanCurve);

    public WriteResult Inspect()
    {
        _preview = null;
        Proposed = [];
        string identity = Identity();
        if (_recovery != null && identity != _identity) return WriteResult.Fail("GPU or driver changed. Return to the original device before restoring its curve.");
        _identity = identity;
        _path = Path.Combine(recoveryDirectory, Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(identity))) + ".json");
        if (_recovery == null && File.Exists(_path))
        {
            var saved = JsonSerializer.Deserialize<Recovery>(File.ReadAllText(_path));
            if (saved == null || saved.Identity != identity) return WriteResult.Fail("Fan recovery data is invalid. No settings were changed.");
            _recovery = saved;
        }
        if (_recovery != null) return WriteResult.Success;
        var current = provider.GetGpuTuning();
        Proposed = RecommendedFanCurve.Create(current);
        _preview = current with { FanCurve = current.FanCurve.ToArray() };
        return WriteResult.Success;
    }

    public WriteResult Apply()
    {
        if (!CanApply || _preview == null) return WriteResult.Fail("Preview the curve first, or restore the previous application.");
        if (Identity() != _identity || !SameFan(provider.GetGpuTuning(), _preview))
            return WriteResult.Fail("Fan settings or GPU changed since preview. Inspect again before applying.");
        var saved = new Recovery(_identity, _preview, Proposed.ToArray());
        Directory.CreateDirectory(recoveryDirectory);
        // CreateNew refuses to overwrite an earlier recovery record. Flush before any driver write.
        using (var stream = new FileStream(_path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            JsonSerializer.Serialize(stream, saved);
            stream.Flush(true);
        }
        _recovery = saved;
        WriteResult result;
        try
        {
            result = provider.SetFanCurve(saved.Target);
            if (result.Ok && !SameFan(provider.GetGpuTuning(), saved.Before with { FanCurve = saved.Target }))
                result = WriteResult.Fail("The driver readback does not match the proposed fan state.");
        }
        catch (Exception ex) { result = WriteResult.Fail(ex.Message); }
        if (result.Ok) return result;
        // A failed call may have partially changed the driver: attempt fan-only recovery.
        var rollback = RestoreCore(checkExternalChange: false);
        if (!rollback.Ok)
        {
            try
            {
                var observed = provider.GetGpuTuning();
                if (RecommendedFanCurve.Validate(observed, observed.FanCurve).Length == 0)
                {
                    var recovery = saved with { ObservedFailure = observed with { FanCurve = observed.FanCurve.ToArray() } };
                    string temp = _path + "." + Guid.NewGuid().ToString("N") + ".tmp";
                    using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        JsonSerializer.Serialize(stream, recovery);
                        stream.Flush(true);
                    }
                    File.Move(temp, _path, true);
                    _recovery = recovery;
                }
            }
            catch (Exception ex) { rollback = WriteResult.Fail(rollback.Error + " Could not record the partial state: " + ex.Message); }
        }
        return WriteResult.Fail(result.Error + (rollback.Ok ? " Previous fan state restored." : " Restoration failed: " + rollback.Error));
    }

    public WriteResult Restore() => RestoreCore(checkExternalChange: true);
    private WriteResult RestoreCore(bool checkExternalChange)
    {
        var saved = _recovery;
        if (saved == null) return WriteResult.Fail("No saved fan state is available.");
        try
        {
            if (Identity() != saved.Identity) return WriteResult.Fail("GPU or driver changed; restoration refused.");
            var current = provider.GetGpuTuning();
            if (checkExternalChange && !SameFan(current, saved.Before) && !SameFan(current, saved.Before with { FanCurve = saved.Target }) &&
                (saved.ObservedFailure == null || !SameFan(current, saved.ObservedFailure)))
                return WriteResult.Fail("Fan settings changed outside this preset. The saved recovery file is retained for review: " + _path);
            if (!SameFan(current, saved.Before))
            {
                var write = provider.SetFanCurve(saved.Before.FanCurve);
                if (!write.Ok) return write;
                if (saved.Before.SupportsZeroRpm && provider.GetGpuTuning().ZeroRpm != saved.Before.ZeroRpm)
                {
                    write = provider.SetZeroRpm(saved.Before.ZeroRpm);
                    if (!write.Ok) return write;
                }
                if (!SameFan(provider.GetGpuTuning(), saved.Before)) return WriteResult.Fail("Restored fan state could not be verified.");
            }
            File.Delete(_path);
            _recovery = null;
            _preview = null;
            Proposed = [];
            return WriteResult.Success;
        }
        catch (Exception ex) { return WriteResult.Fail(ex.Message); }
    }
}
