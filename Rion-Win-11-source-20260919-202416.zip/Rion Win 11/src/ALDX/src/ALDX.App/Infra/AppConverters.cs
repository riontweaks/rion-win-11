using System.Globalization;
using System.Windows.Data;

namespace Aldx.Infra;

/// <summary>bool -> "Enabled" / "Disabled" for the tuning section headers.</summary>
public sealed class EnabledTextConverter : IValueConverter
{
    public object Convert(object? value, Type t, object? p, CultureInfo c) => value is true ? "Enabled" : "Disabled";
    public object ConvertBack(object? value, Type t, object? p, CultureInfo c) => Binding.DoNothing;
}
