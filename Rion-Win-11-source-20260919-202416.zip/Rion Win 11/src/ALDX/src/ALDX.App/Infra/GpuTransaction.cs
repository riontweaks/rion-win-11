using System.IO;

using System.Text.Json;

using System.Windows;

using System.Windows.Controls;

using System.Windows.Media;



namespace Aldx.Infra;



public sealed record GpuEdit<T>(string Key, string Name, T Before, T After);

public sealed record GpuSettingResult(string Key,string Name,string Status,string? Error=null);
public sealed record GpuApplyResult(bool Kept, int Applied, int Unchanged, string Status, bool RestoreFailed = false)
{ public IReadOnlyList<GpuSettingResult> Settings {get;init;}=Array.Empty<GpuSettingResult>(); }



/// <summary>Persist first; every attempted write belongs to the rollback set, including rejected writes.</summary>

public static class GpuTransaction

{

    public static SemaphoreSlim SharedGate
    {
        get { lock(typeof(SemaphoreSlim)) { const string key="Rion.GpuTransaction.Gate";
            if(AppDomain.CurrentDomain.GetData(key) is not SemaphoreSlim gate) {gate=new(1,1);AppDomain.CurrentDomain.SetData(key,gate);} return gate; } }
    }
    public static async Task<GpuApplyResult> Run<T>(IReadOnlyList<GpuEdit<T>> edits,

        Func<string,T,Task<string?>> write, Func<string,Task<T>> read, Func<T,T,bool> equal,

        Func<T,T> restore, string directory, Func<Task<bool>> delay, Func<Task<bool>> keep)

    {

        await SharedGate.WaitAsync();
        try {
        if(edits.Count==0)return new(false,0,0,"No pending changes.");

        Directory.CreateDirectory(directory);

        string path=Path.Combine(directory,DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff")+".json");

        string temporary=path+".tmp";
        await File.WriteAllTextAsync(temporary,JsonSerializer.Serialize(edits,new JsonSerializerOptions{WriteIndented=true}));File.Move(temporary,path);
        var results=edits.ToDictionary(e=>e.Key,e=>new GpuSettingResult(e.Key,e.Name,"Pending"));
        async Task Journal(string state)=>await File.WriteAllTextAsync(path+".state",JsonSerializer.Serialize(new {State=state,UpdatedUtc=DateTime.UtcNow,Settings=results.Values}));
        await Journal("Prepared");

        if(!await delay()){await Journal("Cancelled");return new(false,0,0,"Apply cancelled. No settings changed."){Settings=results.Values.ToArray()};}

        var attempted=new List<GpuEdit<T>>();int unchanged=0;string failure="";

        try

        {

            foreach(var edit in edits)
                if(!equal(await read(edit.Key),restore(edit.Before)))throw new InvalidOperationException(edit.Name+" changed outside Rion. Refresh and review again.");
            await Journal("Applying");
            foreach(var edit in edits)

            {

                var current=await read(edit.Key);



                if(equal(current,edit.After)){unchanged++;results[edit.Key]=new(edit.Key,edit.Name,"Unchanged and verified");continue;}

                attempted.Add(edit);

                var error=await write(edit.Key,edit.After);

                if(error!=null)throw new InvalidOperationException(edit.Name+": "+error);

                if(!equal(await read(edit.Key),edit.After))throw new InvalidOperationException(edit.Name+": driver readback differs.");
                results[edit.Key]=new(edit.Key,edit.Name,"Applied and verified");

            }

            foreach(var edit in edits)if(!equal(await read(edit.Key),edit.After))throw new InvalidOperationException(edit.Name+": final readback changed after another setting was applied.");
            await Journal("Awaiting confirmation");
            if(await keep()){await Journal("Kept");return new(true,attempted.Count,unchanged,$"Kept {attempted.Count} changes; {unchanged} already matched. Readback verified. Backup: {path}"){Settings=results.Values.ToArray()};}

            failure="Changes reverted.";

        }

        catch(Exception ex){failure="Apply did not complete: "+ex.Message;}

        var errors=new List<string>();
        if(attempted.Count>0)foreach(var edit in edits.Where(e=>!attempted.Contains(e)))
        {
            try{if(!equal(await read(edit.Key),restore(edit.Before)))attempted.Add(edit);}
            catch{attempted.Add(edit);}
        }

        foreach(var edit in attempted.AsEnumerable().Reverse())

        {

            try { var error=await write(edit.Key,restore(edit.Before)); if(error!=null||!equal(await read(edit.Key),restore(edit.Before))){errors.Add(edit.Name+": "+(error??"restore readback differs"));results[edit.Key]=new(edit.Key,edit.Name,"Restore failed",error??"Readback differs");}else results[edit.Key]=new(edit.Key,edit.Name,"Restored and verified"); }

            catch(Exception ex){errors.Add(edit.Name+": "+ex.Message);results[edit.Key]=new(edit.Key,edit.Name,"Restore failed",ex.Message);}

        }

        foreach(var edit in attempted)
        {
            try{if(!equal(await read(edit.Key),restore(edit.Before))){errors.Add(edit.Name+": final restoration differs");results[edit.Key]=new(edit.Key,edit.Name,"Restore failed","Final readback differs");}}
            catch(Exception ex){errors.Add(edit.Name+": "+ex.Message);results[edit.Key]=new(edit.Key,edit.Name,"Restore failed",ex.Message);}
        }
        await Journal(errors.Count>0?"Restoration incomplete":"Restored");
        return new(false,attempted.Count,unchanged,failure+(errors.Count==0?" Previous values verified.":" Restore incomplete: "+string.Join("; ",errors))+" Backup: "+path,errors.Count>0){Settings=results.Values.ToArray()};
        } finally { SharedGate.Release(); }

    }

}



/// <summary>Owned modeless prompt stays visible across navigation; main-window close waits for rollback.</summary>

public sealed class GpuApplyPrompt : IDisposable

{

    readonly Window? owner=Application.Current?.MainWindow;

    readonly Window panel;

    readonly TextBlock message=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,12)};

    readonly Button action=new(){MinWidth=90,Margin=new Thickness(0,0,8,0)};

    readonly Button revert=new(){Content="Cancel",MinWidth=90};

    TaskCompletionSource<bool>? decision;

    bool closeRequested,disposing;

    public static bool Review(string text)=>MessageBox.Show(text+"\n\nApply these changes? You can cancel for three seconds, then Keep or Revert within 15 seconds.","Review GPU changes",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes;

    public GpuApplyPrompt()

    {

        var buttons=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right};buttons.Children.Add(action);buttons.Children.Add(revert);

        var layout=new StackPanel{Margin=new Thickness(16)};layout.Children.Add(message);layout.Children.Add(buttons);

        panel=new Window{Title="GPU changes",Width=360,SizeToContent=SizeToContent.Height,ResizeMode=ResizeMode.NoResize,ShowInTaskbar=false,Content=layout,Owner=owner};

        foreach(var (property,key) in new[]{(Window.BackgroundProperty,"Bg2"),(Window.ForegroundProperty,"Text"),(Window.FontFamilyProperty,"AppFont")})panel.SetResourceReference(property,key);

        action.Click+=(_,_)=>decision?.TrySetResult(true);revert.Click+=(_,_)=>{closeRequested=true;decision?.TrySetResult(false);};

        panel.Closing+=(_,e)=>{if(!disposing){e.Cancel=true;closeRequested=true;decision?.TrySetResult(false);}};

        if(owner!=null)owner.Closing+=OwnerClosing;

        panel.Loaded+=(_,_)=>Position();panel.Show();

    }

    void Position(){var area=SystemParameters.WorkArea;panel.Left=Math.Max(area.Left,Math.Min((owner?.Left??area.Right)+(owner?.ActualWidth??0)-panel.ActualWidth-24,area.Right-panel.ActualWidth-16));panel.Top=Math.Max(area.Top,Math.Min((owner?.Top??area.Bottom)+(owner?.ActualHeight??0)-panel.ActualHeight-24,area.Bottom-panel.ActualHeight-16));}

    bool ownerCloseRequested;

    void OwnerClosing(object? sender,System.ComponentModel.CancelEventArgs e){e.Cancel=true;ownerCloseRequested=true;closeRequested=true;decision?.TrySetResult(false);}

    public async Task<bool> Delay()

    {

        action.Visibility=Visibility.Collapsed;revert.Content="Cancel";

        for(int seconds=3;seconds>0;seconds--){message.Text=$"Applying in {seconds} seconds…";await Task.Delay(1000);if(closeRequested)return false;}

        revert.IsEnabled=false;message.Text="Applying and checking driver values…";return !closeRequested;

    }

    public async Task<bool> Keep()

    {

        if(closeRequested)return false;

        action.Content="Keep changes";action.Visibility=Visibility.Visible;revert.Content="Revert";revert.IsEnabled=true;

        decision=new(TaskCreationOptions.RunContinuationsAsynchronously);

        for(int seconds=15;seconds>0;seconds--){message.Text=$"Keep these changes? Reverting in {seconds} seconds.";if(await Task.WhenAny(decision.Task,Task.Delay(1000))==decision.Task)return await decision.Task;}

        return false;

    }

    public bool RestoreFailed {get;set;}

    public void Dispose(){disposing=true;if(owner!=null)owner.Closing-=OwnerClosing;panel.Close();if(ownerCloseRequested&&!RestoreFailed)owner?.Close();}

}

