using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace GpuUi;

internal static class DisplayConfirmation
{
    public static bool Keep()
    {
        var message = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 18) };
        var keep = new Button { Content = "Keep changes", MinWidth = 130, Margin = new Thickness(0, 0, 8, 0) };
        var revert = new Button { Content = "Revert", MinWidth = 100, IsCancel = true };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal };
        buttons.Children.Add(keep); buttons.Children.Add(revert);
        var panel = new StackPanel { Margin = new Thickness(24) };
        panel.Children.Add(message); panel.Children.Add(buttons);
        var dialog = new Window
        {
            Title = "Keep display changes?", Width = 440, SizeToContent = SizeToContent.Height,
            ResizeMode = ResizeMode.NoResize, WindowStartupLocation = WindowStartupLocation.CenterScreen,
            Content = panel, Topmost = true, UseLayoutRounding = true,
            Background = Application.Current.TryFindResource("Bg0") as Brush ?? Brushes.Black,
            Foreground = Application.Current.TryFindResource("Text") as Brush ?? Brushes.White,
        };
        dialog.SetResourceReference(Window.FontFamilyProperty, "AppFont");
        if (Application.Current.MainWindow?.IsVisible == true) dialog.Owner = Application.Current.MainWindow;
        int remaining = 15;
        var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        void Update() => message.Text = $"Keep these display settings? Reverting automatically in {remaining} seconds.";
        Update();
        timer.Tick += (_, _) => { if (--remaining <= 0) dialog.DialogResult = false; else Update(); };
        keep.Click += (_, _) => dialog.DialogResult = true;
        dialog.Loaded += (_, _) => timer.Start();
        dialog.Closed += (_, _) => timer.Stop();
        return dialog.ShowDialog() == true;
    }
}
