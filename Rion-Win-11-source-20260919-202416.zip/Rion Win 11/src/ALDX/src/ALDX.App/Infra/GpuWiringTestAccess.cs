using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("GpuWiring")]
