using System.Diagnostics;
using System.Windows.Threading;

namespace Rion.Telemetry;

/// <summary>
/// Coalesces telemetry requests below input/render priority without changing provider thread affinity.
/// A slow native call can still block its owner thread; duration is recorded for follow-up profiling.
/// </summary>
internal sealed class DispatcherTelemetryPoller
{
    private readonly Dispatcher _dispatcher;
    private readonly DispatcherTimer _timer;
    private readonly Action _sample;
    private DispatcherOperation? _pending;
    private bool _sampling;

    internal DispatcherTelemetryPoller(Action sample, TimeSpan? interval = null)
    {
        _dispatcher = Dispatcher.CurrentDispatcher;
        _sample = sample;
        _timer = new DispatcherTimer(DispatcherPriority.Background, _dispatcher)
        { Interval = interval ?? TimeSpan.FromSeconds(1) };
        _timer.Tick += (_, _) => RequestSample();
    }

    internal bool IsEnabled => _timer.IsEnabled;
    internal TimeSpan LastSampleDuration { get; private set; }

    internal void SetEnabled(bool enabled)
    {
        _dispatcher.VerifyAccess();
        if (enabled == IsEnabled) return;
        if (enabled)
        {
            _timer.Start();
            RequestSample();
        }
        else
        {
            _timer.Stop();
            _pending?.Abort();
            _pending = null;
        }
    }

    internal void RequestSample()
    {
        _dispatcher.VerifyAccess();
        if (!IsEnabled || _sampling || _pending != null || _dispatcher.HasShutdownStarted) return;
        _pending = _dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            _pending = null;
            if (!IsEnabled) return;
            _sampling = true;
            var started = Stopwatch.GetTimestamp();
            try { _sample(); }
            catch (Exception error) { Trace.WriteLine($"GPU telemetry sample failed: {error.Message}"); }
            finally
            {
                LastSampleDuration = Stopwatch.GetElapsedTime(started);
                _sampling = false;
                if (LastSampleDuration.TotalMilliseconds >= 50)
                    Trace.WriteLine($"GPU telemetry occupied its dispatcher for {LastSampleDuration.TotalMilliseconds:F1} ms.");
            }
        }));
    }
}
