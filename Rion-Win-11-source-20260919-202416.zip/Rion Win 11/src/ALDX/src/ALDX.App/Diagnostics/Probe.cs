using System;
using System.IO;
using System.Text;
using Aldx.Adlx;

namespace Aldx.Diagnostics;

/// <summary>
/// Diagnostic: exercise the live ADLX path with no UI and dump results to
/// <c>%TEMP%\aldx-probe.txt</c>. Invoked by the shell with <c>--probe</c>.
/// </summary>
public static class Probe
{
    public static void RunToTempFile()
    {
        var sb = new StringBuilder();
        var outPath = Path.Combine(Path.GetTempPath(), "aldx-probe.txt");
        try
        {
            var native = new NativeAdlxProvider();
            native.Initialize();
            sb.AppendLine($"NativeAdlxProvider.IsAvailable = {native.IsAvailable}");
            var info = native.GetGpuInfo();
            sb.AppendLine($"  Name        = {info.Name}");
            sb.AppendLine($"  ASIC        = {info.AsicFamily}");
            sb.AppendLine($"  VRAM        = {info.VramSizeMb} MB {info.VramType}");
            sb.AppendLine($"  Vendor/Dev  = {info.VendorId} / {info.DeviceId}");
            sb.AppendLine($"  ADLX ver    = {info.AdlxVersion}");
            sb.AppendLine($"  Driver path = {info.AdlxDllPath}");
            sb.AppendLine($"  VBIOS       = {info.VbiosVersion}");
            sb.AppendLine($"  Note        = {info.InitNote}");

            foreach (var id in new[]
            {
                Catalog.SettingId.Perf_AntiLag, Catalog.SettingId.Perf_Chill,
                Catalog.SettingId.Perf_RadeonSuperResolution, Catalog.SettingId.Perf_ImageSharpening,
                Catalog.SettingId.Perf_ImageSharpeningAmount, Catalog.SettingId.Perf_WaitForVerticalRefresh,
            })
            {
                var v = native.Read(id);
                sb.AppendLine($"  read {id,-28} supported={v.Supported} bool={v.Bool} choice={v.Choice} num={v.Number} ({v.UnsupportedReason})");
            }

            for (int i = 0; i < 3; i++)
            {
                var m = native.ReadMetrics();
                sb.AppendLine($"  metrics[{i}]  clk={m.GpuClockMhz} vramClk={m.VramClockMhz} " +
                              $"tEdge={m.EdgeTempC:0.#} tHot={m.HotspotTempC:0.#} " +
                              $"pwr={m.PowerW:0.#} board={m.BoardPowerW:0.#} fan={m.FanRpm} " +
                              $"mv={m.VoltageMv} use={m.GpuUsagePercent:0.#} vramUsed={m.VramUsedMb:0}");
                System.Threading.Thread.Sleep(700);
            }
            native.Dispose();
        }
        catch (Exception ex)
        {
            sb.AppendLine("EXCEPTION: " + ex);
        }
        File.WriteAllText(outPath, sb.ToString());
    }
}
