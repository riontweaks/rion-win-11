namespace Aldx.Catalog;

/// <summary>
/// The hand-maintained map of every setting the app surfaces, plus the curated
/// recommendation table. Mirrors the shape of Power Settings Explorer's
/// <c>RecommendationCatalog</c>: an entry earns its place only if the value is
/// backed by AMD guidance or clear consensus for that profile.
/// </summary>
public static class SettingCatalog
{
    private const string AdlxDoc = "AMD — ADLX GPU Tuning / 3D Settings reference (gpuopen.com/adlx)";
    private const string AmdGaming = "AMD — Radeon Software gaming/latency guidance";
    private const string Consensus = "Long-standing community consensus";

    // ============================================================= settings
    private static readonly SettingDef[] Defs =
    {
        // ---------------------------------------------------- Display
        new()
        {
            Id = SettingId.Display_FreeSync, Tab = SettingTab.Display, Group = "Adaptive sync",
            Name = "AMD FreeSync", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Variable refresh rate — the display refreshes in step with the GPU to remove tearing without the latency of V-Sync.",
            AdlxInterface = "IADLXDisplayFreeSync.SetEnabled",
        },
        new()
        {
            Id = SettingId.Display_VirtualSuperResolution, Tab = SettingTab.Display, Group = "Scaling",
            Name = "Virtual Super Resolution (VSR)", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Lets games render at a higher-than-native resolution and downscale to the panel for extra sharpness.",
            AdlxInterface = "IADLXDisplayVSR.SetEnabled",
        },
        new()
        {
            Id = SettingId.Display_GpuScaling, Tab = SettingTab.Display, Group = "Scaling",
            Name = "GPU scaling", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "The GPU (not the monitor) scales non-native resolutions. Required for the scaling-mode and integer-scaling options.",
            AdlxInterface = "IADLXDisplayGPUScaling.SetEnabled",
        },
        new()
        {
            Id = SettingId.Display_ScalingMode, Tab = SettingTab.Display, Group = "Scaling",
            Name = "Scaling mode", Control = ControlKind.Choice,
            Description = "How a non-native resolution fills the panel.",
            Options = new SettingOption[]
            {
                new("aspect", "Preserve aspect ratio"),
                new("full", "Full panel"),
                new("center", "Center"),
            },
            AdlxInterface = "IADLXDisplayScalingMode.SetMode",
        },
        new()
        {
            Id = SettingId.Display_IntegerScaling, Tab = SettingTab.Display, Group = "Scaling",
            Name = "Integer scaling", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Scales by whole multiples so low-res / pixel-art content stays crisp instead of blurred.",
            AdlxInterface = "IADLXDisplayIntegerScaling.SetEnabled",
        },
        new()
        {
            Id = SettingId.Display_ColorDepth, Tab = SettingTab.Display, Group = "Colour",
            Name = "Colour depth", Control = ControlKind.Choice,
            Description = "Bits per channel sent to the display. If your monitor/cable can't support a value, the driver will reject it or the display may need a re-detect.",
            Options = new SettingOption[]
            {
                new("6", "6 bpc"), new("8", "8 bpc"), new("10", "10 bpc"), new("12", "12 bpc"),
            },
            AdlxInterface = "IADLXDisplayColorDepth.SetValue",
        },
        new()
        {
            Id = SettingId.Display_PixelFormat, Tab = SettingTab.Display, Group = "Colour",
            Name = "Pixel format", Control = ControlKind.Choice,
            Description = "Colour encoding on the wire — RGB Full suits a desktop monitor. Changes require confirmation within 15 seconds.",
            Options = new SettingOption[]
            {
                new("rgb_full", "RGB 4:4:4 Full"),
                new("rgb_limited", "RGB 4:4:4 Limited"),
                new("ycbcr444", "YCbCr 4:4:4"),
                new("ycbcr422", "YCbCr 4:2:2"),
                new("ycbcr420", "YCbCr 4:2:0"),
            },
            AdlxInterface = "IADLXDisplayPixelFormat.SetValue",
        },
        new()
        {
            Id = SettingId.Display_VariBright, Tab = SettingTab.Display, Group = "Power",
            Name = "Vari-Bright", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Dims the backlight adaptively on laptops to save battery. Alters perceived brightness / contrast.",
            AdlxInterface = "IADLXDisplayVariBright.SetEnabled",
        },
        new()
        {
            Id = SettingId.Display_VariBrightLevel, Tab = SettingTab.Display, Group = "Power",
            Name = "Vari-Bright preset", Control = ControlKind.Choice,
            Options = new SettingOption[] { new("brightness", "Maximize brightness"), new("optimize_brightness", "Optimize brightness"), new("balanced", "Balanced"), new("optimize_battery", "Optimize battery"), new("battery", "Maximize battery") },
            Description = "Choose the display brightness and battery-life balance.",
            AdlxInterface = "IADLXDisplayVariBright preset getters/setters",
        },
        new()
        {
            Id = SettingId.Display_ColorTemperatureControl, Tab = SettingTab.Display, Group = "Colour",
            Name = "Colour temperature", Control = ControlKind.Slider, Min = 1000, Max = 10000, Unit = "K",
            Description = "Adjust the display's white point within the range reported by the driver.",
            AdlxInterface = "IADLXDisplayCustomColor.GetTemperature / SetTemperature",
        },
        new()
        {
            Id = SettingId.Display_Hdcp, Tab = SettingTab.Display, Group = "Protected content",
            Name = "HDCP support", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "High-bandwidth copy protection. Changes require confirmation within 15 seconds.",
            AdlxInterface = "IADLXDisplayHDCP.SetEnabled",
        },

        new()
        {
            Id = SettingId.Display_Hue, Tab = SettingTab.Display, Group = "Colour",
            Name = "Hue", Control = ControlKind.Slider, Min = -30, Max = 30,
            Description = "Adjust the display hue within the range reported by the driver.",
            AdlxInterface = "IADLXDisplayCustomColor.GetHue / SetHue",
        },
        new()
        {
            Id = SettingId.Display_Saturation, Tab = SettingTab.Display, Group = "Colour",
            Name = "Saturation", Control = ControlKind.Slider, Min = 0, Max = 200,
            Description = "Adjust colour intensity within the range reported by the driver.",
            AdlxInterface = "IADLXDisplayCustomColor.GetSaturation / SetSaturation",
        },
        new()
        {
            Id = SettingId.Display_Brightness, Tab = SettingTab.Display, Group = "Colour",
            Name = "Brightness", Control = ControlKind.Slider, Min = -100, Max = 100,
            Description = "Adjust the driver's colour brightness. This does not change the monitor's physical backlight.",
            AdlxInterface = "IADLXDisplayCustomColor.GetBrightness / SetBrightness",
        },
        new()
        {
            Id = SettingId.Display_Contrast, Tab = SettingTab.Display, Group = "Colour",
            Name = "Contrast", Control = ControlKind.Slider, Min = 0, Max = 200,
            Description = "Adjust the display contrast within the range reported by the driver.",
            AdlxInterface = "IADLXDisplayCustomColor.GetContrast / SetContrast",
        },

        // ---------------------------------------------------- Performance / 3D
        new()
        {
            Id = SettingId.Perf_AntiLag, Tab = SettingTab.Performance, Group = "Latency",
            Name = "Radeon Anti-Lag", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Paces the CPU so it doesn't run too far ahead of the GPU, cutting click-to-photon latency when GPU-bound.",
            AdlxInterface = "IADLX3DAntiLag.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_Chill, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "Radeon Chill", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Drops the frame rate when on-screen motion is low to cut power, heat and fan noise; ramps back up instantly on input.",
            AdlxInterface = "IADLX3DChill.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_ChillMinFps, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "Chill — minimum FPS", Control = ControlKind.Slider, Min = 30, Max = 300, Step = 1, Unit = "fps",
            Description = "Frame rate Chill idles at when the scene is still.",
            AdlxInterface = "IADLX3DChill.SetMinFPS",
        },
        new()
        {
            Id = SettingId.Perf_ChillMaxFps, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "Chill — maximum FPS", Control = ControlKind.Slider, Min = 30, Max = 300, Step = 1, Unit = "fps",
            Description = "Frame rate Chill allows during active motion.",
            AdlxInterface = "IADLX3DChill.SetMaxFPS",
        },
        new()
        {
            Id = SettingId.Perf_Boost, Tab = SettingTab.Performance, Group = "Latency",
            Name = "Radeon Boost", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Briefly lowers render resolution during fast motion for more FPS; snaps back when motion settles.",
            AdlxInterface = "IADLX3DBoost.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_BoostResolution, Tab = SettingTab.Performance, Group = "Latency",
            Name = "Boost — minimum resolution", Control = ControlKind.Slider, Min = 50, Max = 100, Step = 1, Unit = "%",
            Description = "Lowest resolution Boost will drop to during motion.",
            AdlxInterface = "IADLX3DBoost.SetResolution",
        },
        new()
        {
            Id = SettingId.Perf_RadeonSuperResolution, Tab = SettingTab.Performance, Group = "Upscaling",
            Name = "Radeon Super Resolution (RSR)", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Driver-level spatial upscaling for any fullscreen game — render lower, upscale to display resolution.",
            AdlxInterface = "IADLX3DRadeonSuperResolution.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_RsrSharpness, Tab = SettingTab.Performance, Group = "Upscaling",
            Name = "RSR sharpness", Control = ControlKind.Slider, Min = 0, Max = 100, Step = 1, Unit = "%",
            Description = "Sharpening applied after RSR upscaling.",
            AdlxInterface = "IADLX3DRadeonSuperResolution.SetSharpness",
        },
        new()
        {
            Id = SettingId.Perf_ImageSharpening, Tab = SettingTab.Performance, Group = "Upscaling",
            Name = "Radeon Image Sharpening (RIS)", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Contrast-adaptive sharpening with almost no performance cost; good for taking the softness off TAA.",
            AdlxInterface = "IADLX3DImageSharpening.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_ImageSharpeningAmount, Tab = SettingTab.Performance, Group = "Upscaling",
            Name = "Image Sharpening amount", Control = ControlKind.Slider, Min = 0, Max = 100, Step = 1, Unit = "%",
            Description = "Strength of RIS sharpening.",
            AdlxInterface = "IADLX3DImageSharpening.SetSharpness",
        },
        new()
        {
            Id = SettingId.Perf_EnhancedSync, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "Radeon Enhanced Sync", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "When FPS exceeds refresh, drops the extra frames instead of stalling — low latency, no tearing at high FPS. Not for use with FreeSync in-range.",
            AdlxInterface = "IADLX3DEnhancedSync.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_WaitForVerticalRefresh, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "Wait for vertical refresh (V-Sync)", Control = ControlKind.Choice,
            Description = "Global V-Sync policy when a game doesn't specify its own.",
            Options = new SettingOption[]
            {
                new("always_off", "Always off"),
                new("off_unless_app", "Off, unless application specifies"),
                new("on_unless_app", "On, unless application specifies"),
                new("always_on", "Always on"),
            },
            AdlxInterface = "IADLX3DWaitForVerticalRefresh.SetMode",
        },
        new()
        {
            Id = SettingId.Perf_FrameRateTargetControl, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "Frame Rate Target Control (FRTC)", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Hard FPS cap enforced by the driver — steadies frame times, power and temps.",
            AdlxInterface = "IADLX3DFrameRateTargetControl.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_FrtcTargetFps, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "FRTC — target FPS", Control = ControlKind.Slider, Min = 30, Max = 300, Step = 1, Unit = "fps",
            Description = "The cap FRTC enforces. Set a few FPS below your refresh rate to stay inside the FreeSync range.",
            AdlxInterface = "IADLX3DFrameRateTargetControl.SetFPS",
        },
        new()
        {
            Id = SettingId.Perf_AntiAliasingMode, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anti-aliasing mode", Control = ControlKind.Choice,
            Description = "Whether the driver leaves AA to the game, enhances it, or overrides it.",
            Options = new SettingOption[]
            {
                new("app", "Use application settings"),
                new("enhance", "Enhance application settings"),
                new("override", "Override application settings"),
            },
            AdlxInterface = "IADLX3DAntiAliasing.SetMode",
        },
        new()
        {
            Id = SettingId.Perf_AntiAliasingLevel, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anti-aliasing level", Control = ControlKind.Choice,
            Description = "Sample count when the driver applies AA.",
            Options = new SettingOption[] { new("2x", "2x"), new("4x", "4x"), new("8x", "8x") },
            AdlxInterface = "IADLX3DAntiAliasing.SetLevel",
        },
        new()
        {
            Id = SettingId.Perf_AntiAliasingMethod, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anti-aliasing method", Control = ControlKind.Choice,
            Description = "Multisampling is cheapest; supersampling is heaviest and sharpest.",
            Options = new SettingOption[]
            {
                new("multisampling", "Multisampling"),
                new("adaptive", "Adaptive multisampling"),
                new("supersampling", "Supersampling"),
            },
            AdlxInterface = "IADLX3DAntiAliasing.SetMethod",
        },
        new()
        {
            Id = SettingId.Perf_MorphologicalAa, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Morphological anti-aliasing (MLAA)", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Cheap post-process AA. Softens the whole image, including text/HUD.",
            AdlxInterface = "IADLX3DMorphologicalAntiAliasing.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_AnisotropicFiltering, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anisotropic filtering", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Keeps textures sharp at grazing angles. Near-free on modern GPUs.",
            AdlxInterface = "IADLX3DAnisotropicFiltering.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_AnisotropicLevel, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Anisotropic filtering level", Control = ControlKind.Choice,
            Description = "Higher = sharper oblique textures.",
            Options = new SettingOption[] { new("2x", "2x"), new("4x", "4x"), new("8x", "8x"), new("16x", "16x") },
            AdlxInterface = "IADLX3DAnisotropicFiltering.SetLevel",
        },
        new()
        {
            Id = SettingId.Perf_TextureFilteringQuality, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Texture filtering quality", Control = ControlKind.Choice,
            Description = "Trades texture-filtering precision for a little performance.",
            Options = new SettingOption[]
            {
                new("performance", "Performance"), new("standard", "Standard"), new("quality", "Quality"),
            },
            AdlxInterface = "IADLX3DImageQuality / texture-filtering capability",
        },
        new()
        {
            Id = SettingId.Perf_SurfaceFormatOptimization, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Surface format optimization", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Lets the driver substitute cheaper render-target formats. Small FPS gain, rare colour-banding.",
            AdlxInterface = "IADLX3DImageQuality / surface-format capability",
        },
        new()
        {
            Id = SettingId.Perf_TessellationMode, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Tessellation mode", Control = ControlKind.Choice,
            Description = "Whether the driver caps geometry tessellation.",
            Options = new SettingOption[]
            {
                new("amd", "AMD optimized"),
                new("app", "Use application settings"),
                new("override", "Override application settings"),
            },
            AdlxInterface = "IADLX3DTessellation.SetMode",
        },
        new()
        {
            Id = SettingId.Perf_TessellationLevel, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Maximum tessellation level", Control = ControlKind.Choice,
            Description = "Cap used when tessellation mode is Override.",
            Options = new SettingOption[]
            {
                new("off", "Off"), new("2x", "2x"), new("4x", "4x"), new("6x", "6x"),
                new("8x", "8x"), new("16x", "16x"), new("32x", "32x"), new("64x", "64x"),
            },
            AdlxInterface = "IADLX3DTessellation.SetLevel",
        },
        new()
        {
            Id = SettingId.Perf_OpenGlTripleBuffering, Tab = SettingTab.Performance, Group = "Frame pacing",
            Name = "OpenGL triple buffering", Control = ControlKind.Toggle, Options = SettingDef.OnOff,
            Description = "Smooths OpenGL frame delivery when V-Sync is on. No effect on D3D/Vulkan.",
            AdlxInterface = "IADLX3DOpenGLTripleBuffering.SetEnabled",
        },
        new()
        {
            Id = SettingId.Perf_ShaderCache, Tab = SettingTab.Performance, Group = "Image quality",
            Name = "Shader cache", Control = ControlKind.Choice,
            Description = "On-disk cache of compiled shaders — cuts traversal / first-run stutter.",
            Options = new SettingOption[]
            {
                new("amd", "AMD optimized"), new("on", "Always on"), new("off", "Off"),
            },
            AdlxInterface = "IADLX3DShaderCache.SetEnabled / mode",
        },

        // ---------------------------------------------------- Overclocking
        new()
        {
            Id = SettingId.Oc_TuningMode, Tab = SettingTab.Overclocking, Group = "Profile",
            Name = "Tuning control", Control = ControlKind.ReadOnly,
            Description = "Which tuning profile is active. Manual unlocks the GPU / VRAM / fan / power controls below.",
            Options = new SettingOption[]
            {
                new("default", "Default"), new("auto", "Automatic"), new("manual", "Manual"),
            },
            AdlxInterface = "IADLXGPUTuningServices — preset / manual / auto",
        },
        new()
        {
            Id = SettingId.Oc_PowerLimitPercent, Tab = SettingTab.Overclocking, Group = "Power tuning",
            Name = "Power limit", Control = ControlKind.ReadOnly, Min = -30, Max = 15, Step = 1, Unit = "%",
            Description = "Board-power budget offset. Raising it lets clocks hold higher under load (more heat / draw); lowering it caps them.",
            AdlxInterface = "IADLXManualPowerTuning.GetPowerLimitRange / SetPowerLimit",
        },
        new()
        {
            Id = SettingId.Oc_TdcLimitAmps, Tab = SettingTab.Overclocking, Group = "Power tuning",
            Name = "Thermal design current limit", Control = ControlKind.ReadOnly, Unit = "%",
            Description = "Driver-reported thermal design current limit in percent. AMD requires application validation for TDC controls; Rion displays supported readings only and does not change this limit.",
            AdlxInterface = "IADLXManualPowerTuning.IsSupportedTDCLimit / GetTDCLimitRange / GetTDCLimit (read-only)",
        },
        new()
        {
            Id = SettingId.Oc_GpuMinClockMhz, Tab = SettingTab.Overclocking, Group = "GPU tuning",
            Name = "GPU minimum clock", Control = ControlKind.ReadOnly, Min = 500, Max = 3000, Step = 5, Unit = "MHz",
            Description = "Lower bound of the frequency/voltage curve (RDNA).",
            AdlxInterface = "IADLXManualGraphicsTuning2.GetGPUTuningRanges / SetGPUTuningStates",
        },
        new()
        {
            Id = SettingId.Oc_GpuMaxClockMhz, Tab = SettingTab.Overclocking, Group = "GPU tuning",
            Name = "GPU maximum clock", Control = ControlKind.ReadOnly, Min = 500, Max = 3500, Step = 5, Unit = "MHz",
            Description = "Upper bound of the frequency/voltage curve (RDNA).",
            AdlxInterface = "IADLXManualGraphicsTuning2.GetGPUTuningRanges / SetGPUTuningStates",
        },
        new()
        {
            Id = SettingId.Oc_GpuVoltageMv, Tab = SettingTab.Overclocking, Group = "GPU tuning",
            Name = "GPU voltage", Control = ControlKind.ReadOnly, Min = 600, Max = 1200, Step = 5, Unit = "mV",
            Description = "Voltage at the top of the curve. Lowering it (undervolt) cuts heat; too low = instability.",
            AdlxInterface = "IADLXManualGraphicsTuning2 — voltage endpoint",
        },
        new()
        {
            Id = SettingId.Oc_VramClockMhz, Tab = SettingTab.Overclocking, Group = "VRAM tuning",
            Name = "Memory clock", Control = ControlKind.ReadOnly, Min = 1000, Max = 3000, Step = 5, Unit = "MHz",
            Description = "Maximum VRAM frequency.",
            AdlxInterface = "IADLXManualVRAMTuning2.GetMaxVRAMFrequencyRange / SetMaxVRAMFrequency",
        },
        new()
        {
            Id = SettingId.Oc_MemoryTiming, Tab = SettingTab.Overclocking, Group = "VRAM tuning",
            Name = "Memory timing", Control = ControlKind.ReadOnly,
            Description = "Memory timing preset. 'Fast' can add bandwidth; may reduce stability.",
            Options = new SettingOption[] { new("default", "Default"), new("fast", "Fast timing") },
            AdlxInterface = "IADLXManualVRAMTuning2 — memory timing description list",
        },
        new()
        {
            Id = SettingId.Oc_FanZeroRpm, Tab = SettingTab.Overclocking, Group = "Fan tuning",
            Name = "Zero RPM", Control = ControlKind.ReadOnly, Options = SettingDef.OnOff,
            Description = "Stops the fans entirely below a temperature threshold for silent idle.",
            AdlxInterface = "IADLXManualFanTuning.SetZeroRPMState",
        },
        new()
        {
            Id = SettingId.Oc_FanMinAcousticLimitMhz, Tab = SettingTab.Overclocking, Group = "Fan tuning",
            Name = "Minimum acoustic limit", Control = ControlKind.ReadOnly, Min = 300, Max = 3300, Step = 5, Unit = "MHz",
            Description = "Clock floor the fan controller keeps to for a quieter noise profile.",
            AdlxInterface = "IADLXManualFanTuning.SetMinAcousticLimit",
        },
        new()
        {
            Id = SettingId.Oc_FanTargetSpeedPercent, Tab = SettingTab.Overclocking, Group = "Fan tuning",
            Name = "Target fan speed", Control = ControlKind.ReadOnly, Min = 0, Max = 100, Step = 1, Unit = "%",
            Description = "Steady-state duty cycle the custom curve aims for.",
            AdlxInterface = "IADLXManualFanTuning — fan-tuning states (Temp -> Speed%)",
        },
        new()
        {
            Id = SettingId.Oc_FanMaxSpeedPercent, Tab = SettingTab.Overclocking, Group = "Fan tuning",
            Name = "Maximum fan speed", Control = ControlKind.ReadOnly, Min = 0, Max = 100, Step = 1, Unit = "%",
            Description = "Top of the custom fan curve.",
            AdlxInterface = "IADLXManualFanTuning — fan-tuning states (Temp -> Speed%)",
        },
        new()
        {
            Id = SettingId.Oc_FanTargetTempC, Tab = SettingTab.Overclocking, Group = "Fan tuning",
            Name = "Target temperature", Control = ControlKind.ReadOnly, Min = 50, Max = 110, Step = 1, Unit = "°C",
            Description = "Temperature the fan curve tries to hold.",
            AdlxInterface = "IADLXManualFanTuning — target temperature",
        },
        new()
        {
            Id = SettingId.Oc_FanMaxTempC, Tab = SettingTab.Overclocking, Group = "Fan tuning",
            Name = "Maximum temperature", Control = ControlKind.ReadOnly, Min = 50, Max = 115, Step = 1, Unit = "°C",
            Description = "Hard thermal ceiling before the card throttles hard.",
            AdlxInterface = "IADLXManualFanTuning — max temperature",
        },
    };

    public static IReadOnlyList<SettingDef> All => Defs;

    public static SettingDef Get(SettingId id) => Defs.First(d => d.Id == id);

    public static IEnumerable<SettingDef> ForTab(SettingTab tab) => Defs.Where(d => d.Tab == tab);

    // ======================================================= recommendations
    private static readonly Recommendation[] Recos =
    {
        // -------- Balanced ------------------------------------------------
        new(SettingId.Display_FreeSync, RecoProfile.Balanced, "on",
            "Removes tearing without V-Sync latency whenever the display supports it. No downside on a FreeSync panel.",
            AmdGaming, RecoConfidence.Strong),
        new(SettingId.Perf_ShaderCache, RecoProfile.Balanced, "amd",
            "\"AMD optimized\" keeps a persistent on-disk shader cache, which is the main defence against traversal stutter. Only set \"Off\" to troubleshoot.",
            AdlxDoc, RecoConfidence.Strong),
        new(SettingId.Perf_AnisotropicFiltering, RecoProfile.Balanced, "on",
            "Sharper textures at oblique angles for a fraction of a percent of performance on any modern Radeon.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_AnisotropicLevel, RecoProfile.Balanced, "16x",
            "16x is effectively free on current hardware; lower levels leave visible texture blur in the mid-distance.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_ImageSharpening, RecoProfile.Balanced, "on",
            "Contrast-adaptive sharpening costs ~1% and counteracts the softness of modern TAA. Amount ~50% is a safe default.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_ImageSharpeningAmount, RecoProfile.Balanced, "50",
            "AMD's default. Higher starts to over-sharpen edges and HUD text.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_WaitForVerticalRefresh, RecoProfile.Balanced, "off_unless_app",
            "Let each game decide. With FreeSync active you generally want an in-game FPS cap a few frames below refresh rather than driver V-Sync.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Display_ColorDepth, RecoProfile.Balanced, "8",
            "8 bpc is correct for SDR desktop use and never runs out of cable bandwidth. Use 10 bpc only for HDR or colour work.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Display_PixelFormat, RecoProfile.Balanced, "rgb_full",
            "RGB 4:4:4 Full range is the right choice for a computer monitor; limited range crushes blacks and whites.",
            Consensus, RecoConfidence.Strong),

        // -------- Esports (competitive, latency first) ------------------
        new(SettingId.Perf_AntiLag, RecoProfile.Esports, "on",
            "Cuts click-to-photon latency when GPU-bound with no image-quality cost. The single highest-value latency setting here.",
            AmdGaming, RecoConfidence.Strong),
        new(SettingId.Perf_Chill, RecoProfile.Esports, "off",
            "Chill deliberately lowers FPS between inputs — the opposite of what a competitive player wants. Keep it off.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_FrameRateTargetControl, RecoProfile.Esports, "off",
            "A driver-side cap adds a frame-pacing layer of its own. Cap in the game or leave it uncapped; this profile keeps the driver out of the frame path.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_EnhancedSync, RecoProfile.Esports, "off",
            "Only useful above the FreeSync range and can cause flicker on some panels. Prefer an FPS cap instead.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_RadeonSuperResolution, RecoProfile.Esports, "off",
            "Upscaling adds a little latency and a soft image. On a competitive title you usually have the headroom to run native.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_TextureFilteringQuality, RecoProfile.Esports, "performance",
            "Frees a sliver of GPU time; the visual difference is invisible in fast motion.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_MorphologicalAa, RecoProfile.Esports, "off",
            "Post-process AA blurs the image, including distant enemies. Leave AA to the game's own setting.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_ImageSharpening, RecoProfile.Esports, "off",
            "A post-process filter applied to every frame. It costs a little GPU time and exaggerates aliasing on thin geometry — fence wire, distant rails — which is the opposite of helpful when you are picking targets out of clutter.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Display_FreeSync, RecoProfile.Esports, "off",
            "Leaves the display path untouched so nothing sits between the rendered frame and the panel. Turn it back on if you see tearing — inside its range FreeSync costs no latency.",
            Consensus, RecoConfidence.Moderate),

        // -------- Quality (fidelity first) ----------------------------
        new(SettingId.Perf_RadeonSuperResolution, RecoProfile.Quality, "off",
            "Prefer a game's built-in FSR / temporal upscaler over the driver's spatial-only RSR when image quality is the priority.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_AnisotropicFiltering, RecoProfile.Quality, "on",
            "Non-negotiable for a clean image; near-zero cost.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_AnisotropicLevel, RecoProfile.Quality, "16x",
            "Maximum sharpness for oblique textures.",
            Consensus, RecoConfidence.Strong),
        new(SettingId.Perf_TextureFilteringQuality, RecoProfile.Quality, "quality",
            "Keeps full trilinear/aniso precision — no shimmering on high-contrast textures.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_SurfaceFormatOptimization, RecoProfile.Quality, "off",
            "Stops the driver swapping in lower-precision render targets, which can band gradients.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Perf_TessellationMode, RecoProfile.Quality, "app",
            "Let the game request the geometry detail its artists intended.",
            Consensus, RecoConfidence.Moderate),
        new(SettingId.Display_ColorDepth, RecoProfile.Quality, "10",
            "10 bpc for HDR and gradient-heavy content, provided the link has bandwidth for it at your refresh rate.",
            Consensus, RecoConfidence.Moderate),

        // -------- Efficiency (quiet / cool / laptop) -----------------
        new(SettingId.Perf_Chill, RecoProfile.Efficiency, "on",
            "The biggest single power/heat saver — caps FPS when nothing is moving. Set min/max around your comfortable range.",
            AmdGaming, RecoConfidence.Strong),
        new(SettingId.Perf_ChillMinFps, RecoProfile.Efficiency, "60",
            "Idle frame rate when the scene is still — 60 stays responsive while cutting draw.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_ChillMaxFps, RecoProfile.Efficiency, "120",
            "Upper bound during motion; lower it further to match your panel for more savings.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_FrameRateTargetControl, RecoProfile.Efficiency, "on",
            "A global cap stops the GPU rendering hundreds of pointless frames in menus and light scenes.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Perf_RadeonSuperResolution, RecoProfile.Efficiency, "on",
            "Rendering below native and upscaling is a large perf-per-watt win on a thermally limited laptop.",
            AmdGaming, RecoConfidence.Moderate),
        new(SettingId.Display_VariBright, RecoProfile.Efficiency, "on",
            "Meaningful battery saving on a laptop panel; leave off on a desktop where it just alters brightness.",
            AdlxDoc, RecoConfidence.Moderate),
        new(SettingId.Perf_AntiLag, RecoProfile.Efficiency, "off",
            "Anti-Lag can hold clocks higher to keep the CPU/GPU in lockstep — not what you want when minimising power.",
            Consensus, RecoConfidence.Moderate),
    };

    private static readonly Dictionary<(SettingId, RecoProfile), Recommendation> RecoByKey =
        Recos.ToDictionary(r => (r.Setting, r.Profile));

    public static Recommendation? For(SettingId id, RecoProfile profile) =>
        (int)id >= 200 && (int)id < 300 ? ProfileCatalog.Get(id, profile) : RecoByKey.TryGetValue((id, profile), out var r) ? r : null;

    public static int RecommendationCount => Recos.Length;
}


