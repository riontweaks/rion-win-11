namespace Aldx.Catalog;

public enum SettingTab { System, Display, Performance, Overclocking }

public enum ControlKind
{
    /// <summary>Enabled / disabled — rendered as a toggle switch.</summary>
    Toggle,
    /// <summary>One of a fixed option list — rendered as a dropdown.</summary>
    Choice,
    /// <summary>A number in a range — rendered as a slider with a value readout.</summary>
    Slider,
    /// <summary>Detected value shown as text without an editable control.</summary>
    ReadOnly,
}

public sealed record SettingOption(string Value, string Label)
{
    /// <summary>So a ComboBox that somehow renders the item directly (no DisplayMemberPath /
    /// template applied yet) still shows the friendly label, never "SettingOption { Value = … }".</summary>
    public override string ToString() => Label;
}

/// <summary>
/// One row in the catalog: what it is, how to render it, and which ADLX interface backs it.
/// The shell renders these definitions; the provider handles driver reads and writes.
/// </summary>
public sealed record SettingDef
{
    public required SettingId Id { get; init; }
    public required SettingTab Tab { get; init; }
    public required string Group { get; init; }          // sub-header within the tab
    public required string Name { get; init; }
    public required string Description { get; init; }
    public required ControlKind Control { get; init; }

    /// <summary>Options for <see cref="ControlKind.Choice"/>. Empty otherwise.</summary>
    public IReadOnlyList<SettingOption> Options { get; init; } = Array.Empty<SettingOption>();

    // slider metadata (fallbacks; a live SettingValue may override min/max/step)
    public double Min { get; init; }
    public double Max { get; init; }
    public double Step { get; init; } = 1;
    public string Unit { get; init; } = "";

    /// <summary>ADLX interface and accessor associated with this setting.</summary>
    public required string AdlxInterface { get; init; }

    /// <summary>
    /// False for rows the app will read but deliberately never write (e.g. HDCP).
    /// </summary>
    public bool Writable { get; init; } = true;

    public static readonly IReadOnlyList<SettingOption> OnOff = new SettingOption[]
    {
        new("on", "Enabled"),
        new("off", "Disabled"),
    };
}
