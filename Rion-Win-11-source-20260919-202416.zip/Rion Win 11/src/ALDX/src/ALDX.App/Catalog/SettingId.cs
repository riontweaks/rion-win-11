namespace Aldx.Catalog;

/// <summary>
/// Stable identifier for every setting the app knows about. The name is the contract
/// between <see cref="SettingCatalog"/>, the recommendation table, and the ADLX provider —
/// never renumber, only append.
/// </summary>
public enum SettingId
{
    // ---- Display (IADLXDisplaysServices) ----------------------------------
    Display_FreeSync = 100,
    Display_VirtualSuperResolution,
    Display_GpuScaling,
    Display_ScalingMode,
    Display_IntegerScaling,
    Display_ColorDepth,
    Display_PixelFormat,
    Display_VariBright,
    Display_VariBrightLevel,
    Display_ColorTemperatureControl,
    Display_Hdcp,
    Display_Hue,
    Display_Saturation,
    Display_Brightness,
    Display_Contrast,

    // ---- Performance / 3D (IADLX3DSettingsServices) ----------------------
    Perf_AntiLag = 200,
    Perf_Chill,
    Perf_ChillMinFps,
    Perf_ChillMaxFps,
    Perf_Boost,
    Perf_BoostResolution,
    Perf_RadeonSuperResolution,
    Perf_RsrSharpness,
    Perf_ImageSharpening,
    Perf_ImageSharpeningAmount,
    Perf_EnhancedSync,
    Perf_WaitForVerticalRefresh,
    Perf_FrameRateTargetControl,
    Perf_FrtcTargetFps,
    Perf_AntiAliasingMode,
    Perf_AntiAliasingLevel,
    Perf_AntiAliasingMethod,
    Perf_MorphologicalAa,
    Perf_AnisotropicFiltering,
    Perf_AnisotropicLevel,
    Perf_TextureFilteringQuality,
    Perf_SurfaceFormatOptimization,
    Perf_TessellationMode,
    Perf_TessellationLevel,
    Perf_OpenGlTripleBuffering,
    Perf_ShaderCache,

    // ---- Overclocking / GPU Tuning (IADLXGPUTuningServices) --------------
    Oc_TuningMode = 300,
    Oc_PowerLimitPercent,
    Oc_TdcLimitAmps, // Stable legacy ID; ADLX reports this value in percent, not amperes.
    Oc_GpuMinClockMhz,
    Oc_GpuMaxClockMhz,
    Oc_GpuVoltageMv,
    Oc_VramClockMhz,
    Oc_MemoryTiming,
    Oc_FanZeroRpm,
    Oc_FanMinAcousticLimitMhz,
    Oc_FanTargetSpeedPercent,
    Oc_FanMaxSpeedPercent,
    Oc_FanTargetTempC,
    Oc_FanMaxTempC,
}
