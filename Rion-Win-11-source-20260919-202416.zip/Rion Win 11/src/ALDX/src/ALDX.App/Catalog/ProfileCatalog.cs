namespace Aldx.Catalog;

/// <summary>App-curated global graphics presets, not vendor-certified performance guarantees.</summary>
public static class ProfileCatalog
{
    public static string Description(RecoProfile profile) => profile switch
    {
        RecoProfile.Esports => "Recommended starting point for competitive play: enable supported Radeon Anti-Lag and avoid extra image processing. Measure latency and frame times per game.",
        RecoProfile.Quality => "Prioritize texture clarity while leaving anti-aliasing to the game. Higher image quality can reduce frame rate.",
        RecoProfile.Efficiency => "Reduce rendering work with Radeon Chill targeting 60–120 FPS. Adjust its limits for your display and games after applying.",
        _ => "A general-purpose graphics baseline with application-controlled anti-aliasing and normal power behavior."
    };
    public static IReadOnlyDictionary<SettingId, string> Values(RecoProfile profile)
    {
        bool esports = profile == RecoProfile.Esports, quality = profile == RecoProfile.Quality, efficiency = profile == RecoProfile.Efficiency;
        return new Dictionary<SettingId, string>
        {
            [SettingId.Perf_BoostResolution] = "100",
            [SettingId.Perf_RsrSharpness] = "0",
            [SettingId.Perf_ImageSharpeningAmount] = "0",
            [SettingId.Perf_FrtcTargetFps] = "60",
            [SettingId.Perf_AntiAliasingLevel] = "2x",
            [SettingId.Perf_AntiAliasingMethod] = "multisampling",
            [SettingId.Perf_SurfaceFormatOptimization] = quality ? "off" : "on",
            [SettingId.Perf_TessellationMode] = "amd",
            [SettingId.Perf_TessellationLevel] = "64x",
            [SettingId.Perf_OpenGlTripleBuffering] = "off",
            [SettingId.Perf_ShaderCache] = "amd",
            [SettingId.Perf_AntiLag] = esports ? "on" : "off",
            [SettingId.Perf_Chill] = efficiency ? "on" : "off",
            [SettingId.Perf_ChillMinFps] = "60",
            [SettingId.Perf_ChillMaxFps] = "120",
            [SettingId.Perf_Boost] = "off",
            [SettingId.Perf_RadeonSuperResolution] = "off",
            [SettingId.Perf_ImageSharpening] = "off",
            [SettingId.Perf_EnhancedSync] = "off",
            [SettingId.Perf_FrameRateTargetControl] = "off",
            [SettingId.Perf_WaitForVerticalRefresh] = esports ? "always_off" : "off_unless_app",
            [SettingId.Perf_AntiAliasingMode] = "app",
            [SettingId.Perf_MorphologicalAa] = "off",
            [SettingId.Perf_AnisotropicFiltering] = quality ? "on" : "off",
            [SettingId.Perf_AnisotropicLevel] = "16x",
            [SettingId.Perf_TextureFilteringQuality] = quality ? "quality" : esports ? "performance" : "standard"
        };
    }
    public static Recommendation? Get(SettingId id, RecoProfile profile) => Values(profile).TryGetValue(id, out var value)
        ? new(id, profile, value, Description(profile), "https://www.amd.com/en/resources/support-articles/faqs/DH-033.html", RecoConfidence.Moderate) : null;
}

