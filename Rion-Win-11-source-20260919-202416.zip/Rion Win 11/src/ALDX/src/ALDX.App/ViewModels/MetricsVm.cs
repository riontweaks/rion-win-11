using Aldx.Adlx;
using Aldx.Infra;

namespace Aldx.ViewModels;

/// <summary>Live performance-monitoring readout, shared by the metrics strip and the tuning gauges.</summary>
public sealed class MetricsVm : ObservableObject
{
    public sealed class Gauge : ObservableObject
    {
        public Gauge(string label, string unit) { Label = label; Unit = unit; }
        public string Label { get; }
        public string Unit { get; }

        private string _value = "—";
        public string Value { get => _value; set => Set(ref _value, value); }

        private double _fraction;               // 0..1 for the ring fill
        public double Fraction { get => _fraction; set => Set(ref _fraction, value); }
    }

    public Gauge GpuClock { get; }   = new("GPU Clock Speed", "MHz");
    public Gauge VramClock { get; }  = new("VRAM Clock Speed", "MHz");
    public Gauge Voltage { get; }    = new("Voltage", "mV");
    public Gauge BoardPower { get; } = new("Total Board Power", "W");
    public Gauge FanSpeed { get; }   = new("Fan Speed", "RPM");
    public Gauge GpuTemp { get; }    = new("GPU Temperature", "°C");
    public Gauge Hotspot { get; }    = new("GPU Hotspot Temperature", "°C");
    public Gauge GpuLoad { get; }    = new("GPU Usage", "%");
    public Gauge Fps { get; }        = new("FPS", "");

    public IReadOnlyList<Gauge> TuningGauges => new[] { GpuClock, VramClock, Voltage, BoardPower, FanSpeed, GpuTemp };

    private string _updated = "—";
    public string Updated { get => _updated; private set => Set(ref _updated, value); }

    public void MarkUnavailable(string reason){Update(new GpuMetricsSample());Updated=reason;}

    public void Update(GpuMetricsSample s)
    {
        void Set1(Gauge g, double? v, double max, string fmt = "0")
        {
            g.Value = v is null ? "—" : v.Value.ToString(fmt);
            g.Fraction = v is null || max <= 0 ? 0 : Math.Clamp(v.Value / max, 0, 1);
        }

        Set1(GpuClock, s.GpuClockMhz, 3200);
        Set1(VramClock, s.VramClockMhz, 3000);
        Set1(Voltage, s.VoltageMv, 1300);
        Set1(BoardPower, s.BoardPowerW, 400);
        Set1(FanSpeed, s.FanRpm, 3500);
        Set1(GpuTemp, s.EdgeTempC, 110);
        Set1(Hotspot, s.HotspotTempC, 115);
        Set1(GpuLoad, s.GpuUsagePercent, 100);
        Set1(Fps, s.Fps, 360);

        Updated = $"updated {s.TimestampLocal:HH:mm:ss}";
    }
}
