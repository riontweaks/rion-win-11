using Rion.Telemetry;
using Aldx.Adlx;

namespace Aldx.ViewModels;

/// <summary>
/// One ADLX provider and one metrics poll for the whole process. The Dashboard page and
/// the Better Adrenaline sections both bind the same <see cref="Metrics"/> instance, so
/// <c>amdadlx64.dll</c> is initialised once and read once per second — not once per view.
/// </summary>
public sealed class AdlxHost
{
    private static AdlxHost? _instance;

    /// <summary>Lazily created on first use (always the UI thread — views build there).</summary>
    public static AdlxHost Instance => _instance ??= new AdlxHost();

    private readonly DispatcherTelemetryPoller _poller;
    private static bool _pollingRequested = true;
    public static bool IsPolling => _instance?._poller.IsEnabled == true;

    /// <summary>UI-thread host policy; does not initialize an unused provider.</summary>
    public static void SetPollingEnabled(bool enabled)
    {
        _pollingRequested = enabled;
        _instance?._poller.SetEnabled(enabled);
    }

    private AdlxHost()
    {
        Provider = AdlxProviderFactory.Create();
        Metrics = new MetricsVm();

        _poller = new DispatcherTelemetryPoller(RequestMetrics);
        _poller.SetEnabled(_pollingRequested);
    }

    bool sampling;DateTime started;
    async void RequestMetrics()
    {
        if(sampling){if(DateTime.UtcNow-started>TimeSpan.FromSeconds(3))Metrics.MarkUnavailable("Waiting for AMD driver");return;}
        sampling=true;started=DateTime.UtcNow;
        try{var sample=await Task.Run(Provider.ReadMetrics);if(_poller.IsEnabled)Metrics.Update(sample);}
        catch(Exception e){Metrics.MarkUnavailable("AMD telemetry unavailable: "+e.Message);}finally{sampling=false;}
    }
    public IAdlxProvider Provider { get; }
    public MetricsVm Metrics { get; }

    public bool IsMock => Provider.IsMock;

}
