using System.Collections.ObjectModel;

using System.IO;

using Aldx.Catalog;

using Aldx.Adlx;

using Aldx.Infra;

namespace Aldx.ViewModels;

public sealed class ShellViewModel : ObservableObject

{

    readonly IAdlxProvider _driver;

    readonly System.Threading.SemaphoreSlim gate=new(1,1);

    public ShellViewModel():this(null){}

    public ShellViewModel(IAdlxProvider? provider)

    {

        var host=provider==null?AdlxHost.Instance:null;

        _driver=provider??host!.Provider; Metrics=host?.Metrics??new MetricsVm();Tuning=new TuningVm(_driver,Metrics);

        Profiles=Enum.GetValues<RecoProfile>();Tabs=new(BuildTabs());_selectedTab=Tabs[0];

        foreach(var row in Rows){row.StageEdits=true;row.DraftChanged+=DraftChanged;}

        ApplyProfileCommand=new RelayCommand(StageProfile,()=>ProfileIdle);

        ApplyChangesCommand=new RelayCommand(async()=>await ApplyPendingAsync(),()=>ProfileIdle&&HasPending);

        DetectCommand=new RelayCommand(async()=>{if(DiscardForNavigation())await DetectAsync();},()=>ProfileIdle);

        RevertAllCommand=new RelayCommand(Discard,()=>ProfileIdle);

        Tuning.DraftChanged+=DraftChanged;Initialization=InitializeAsync();

    }

    IEnumerable<SettingVm> Rows=>Tabs.SelectMany(t=>t.Settings);

    public Task Initialization {get;}
    async Task InitializeAsync(){ProfileBusy=true;try{await Tuning.Initialization;}finally{ProfileBusy=false;}await DetectAsync();}

    public MetricsVm Metrics {get;}

    public TuningVm Tuning {get;}

    public ObservableCollection<TabVm> Tabs {get;}

    public ObservableCollection<DisplayInfo> Displays {get;}=new();

    public IReadOnlyList<RecoProfile> Profiles {get;}

    public RelayCommand ApplyProfileCommand {get;}

    public RelayCommand ApplyChangesCommand {get;}

    public RelayCommand DetectCommand {get;}

    public RelayCommand RevertAllCommand {get;}

    public string ProviderName=>_driver.DisplayName;

    public bool IsMock=>_driver.IsMock;

    public string ModeBanner=>IsMock?"Demo · no hardware changes":"Changes are staged until you choose Apply.";

    TabVm _selectedTab;

    public TabVm SelectedTab {get=>_selectedTab;set{if(Set(ref _selectedTab,value)){Raise(nameof(HeaderTitle));Raise(nameof(ShowProfilePanel));Raise(nameof(ShowDisplaySelector));}}}

    public string HeaderTitle=>SelectedTab.Title;

    public bool ShowProfilePanel=>SelectedTab.Kind==SettingTab.Performance;

    public bool ShowDisplaySelector=>SelectedTab.Kind==SettingTab.Display&&Displays.Count>0;

    DisplayInfo? _selectedDisplay;bool loading;

    public DisplayInfo? SelectedDisplay {get=>_selectedDisplay;set{if(loading||value==null||value.Id==_selectedDisplay?.Id)return;if(!ProfileIdle||!DiscardForNavigation()){Raise();return;}_=SelectDisplay(value);}}

    async Task SelectDisplay(DisplayInfo display){ProfileBusy=true;try{var result=await Task.Run(()=>_driver.SelectDisplay(display.Id));if(!result.Ok)throw new Exception(result.Error);}catch(Exception e){ProfileStatus=e.Message;}finally{ProfileBusy=false;}await DetectAsync();}

    bool _busy;

    public bool ProfileBusy {get=>_busy;private set{Set(ref _busy,value);Raise(nameof(ProfileIdle));ApplyChangesCommand?.RaiseCanExecuteChanged();ApplyProfileCommand?.RaiseCanExecuteChanged();DetectCommand?.RaiseCanExecuteChanged();RevertAllCommand?.RaiseCanExecuteChanged();}}

    public bool ProfileIdle=>!ProfileBusy;

    string _status="Choose a preset or edit settings, then Apply.";

    public string ProfileStatus {get=>_status;private set=>Set(ref _status,value);}

    string _last="";

    public string LastDetect {get=>_last;private set=>Set(ref _last,value);}

    string _search="";bool _showUnavailable;

    public string Search {get=>_search;set{Set(ref _search,value);Filter();}}

    public bool ShowUnavailable {get=>_showUnavailable;set{Set(ref _showUnavailable,value);Filter();}}

    void Filter(){foreach(var tab in Tabs){tab.ShowUnavailable=ShowUnavailable;tab.SetFilter(Search);}}

    RecoProfile _profile=RecoProfile.Balanced;

    public RecoProfile Profile {get=>_profile;set{if(!ProfileIdle||!Set(ref _profile,value))return;StageProfile();}}

    public string ProfileDescription=>ProfileCatalog.Description(Profile);

    public string ProfilePreview=>string.Join("\n",Rows.Where(r=>r.IsDirty).Select(r=>r.Name+" → "+r.CurrentText));

    bool profileStaged;
    readonly HashSet<SettingId> profileTargets=new();
    Task profileStageTask=Task.CompletedTask;

    int skipped;

    public bool HasPending=>profileStaged||Rows.Any(r=>r.IsDirty)||Tuning.HasPending;

    public string PendingSummary=>$"{Rows.Count(r=>r.IsDirty)} changes · {skipped} unavailable";

    void DraftChanged(){Raise(nameof(HasPending));Raise(nameof(PendingSummary));Raise(nameof(ProfilePreview));ApplyChangesCommand?.RaiseCanExecuteChanged();}

    public void Discard(){Tuning.DiscardManual();foreach(var row in Rows)row.Discard();profileStaged=false;profileTargets.Clear();skipped=0;DraftChanged();ProfileStatus="Pending edits discarded.";}

    bool DiscardForNavigation(){if(!HasPending)return true;if(System.Windows.MessageBox.Show("Discard pending GPU edits before refreshing or switching displays?","Pending changes",System.Windows.MessageBoxButton.YesNo)!=System.Windows.MessageBoxResult.Yes)return false;Discard();return true;}

    public void StageProfile(){profileStageTask=StageProfileAsync();}

    public async Task StageProfileAsync()

    {

        if(ProfileBusy){await profileStageTask;return;}ProfileBusy=true;skipped=0;profileTargets.Clear();

        try{var values=ProfileCatalog.Values(Profile);

        foreach(var row in Tabs.Where(t=>t.Kind==SettingTab.Performance).SelectMany(t=>t.Settings))

        {

            row.Discard();row.SetProfile(Profile);if(!row.Supported||row.IsReadOnly){skipped++;continue;}

            if(values.TryGetValue(row.Id,out var raw))

            {

                if(row.IsToggle){row.Stage(SettingValue.Of(raw=="on"));profileTargets.Add(row.Id);}

                else if(row.IsChoice&&row.Options.Any(o=>o.Value==raw)){row.Stage(SettingValue.Of(raw));profileTargets.Add(row.Id);}

                else if(row.IsSlider&&double.TryParse(raw,System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out var n)&&n>=row.SliderMin&&n<=row.SliderMax){row.Stage(SettingValue.Of(n));profileTargets.Add(row.Id);}

                else skipped++;

            }

            else skipped++;

        }

        profileStaged=true;ProfileStatus="Preset staged. Review changes before applying.";Raise(nameof(ProfileDescription));DraftChanged();}

        catch(Exception e){ProfileStatus="Could not stage preset: "+e.Message;}finally{ProfileBusy=false;}

    }

    public async Task ApplyProfileAsync(){await StageProfileAsync();await ApplyPendingAsync();}

    public async Task ApplyPendingAsync(bool interactive=true)

    {

        if(ProfileBusy||!HasPending)return;
        if(Tuning.HasPending){await Tuning.ApplyManualAsync(interactive);if(Tuning.HasPending)return;}

        bool graphicsDraft=!profileStaged&&Tabs.Single(t=>t.Kind==SettingTab.Performance).Settings.Any(r=>r.IsDirty);
        var targets=Rows.Where(r=>(graphicsDraft&&Tabs.Single(t=>t.Kind==SettingTab.Performance).Settings.Contains(r)&&r.Supported&&!r.IsReadOnly)||r.IsDirty||(profileStaged&&profileTargets.Contains(r.Id)&&r.Supported&&!r.IsReadOnly)).ToArray();

        if(interactive&&!GpuApplyPrompt.Review(string.Join("\n",targets.Select(r=>r.Name+" → "+r.CurrentText))))return;

        ProfileBusy=true;await gate.WaitAsync();GpuApplyPrompt? prompt=null;

        try

        {

            var edits=targets.OrderBy(r=>r.PendingValue.Bool==false||r.PendingValue.Choice=="off"?0:r.Id==SettingId.Perf_ChillMaxFps?1:r.PendingValue.Bool==true||r.PendingValue.Choice=="on"?3:2).Select(r=>new GpuEdit<SettingValue>(r.Id.ToString(),r.Name,r.Detected,r.PendingValue)).ToList();

            var min=edits.FindIndex(e=>e.Key==nameof(SettingId.Perf_ChillMinFps));var max=edits.FindIndex(e=>e.Key==nameof(SettingId.Perf_ChillMaxFps));

            // Lower the minimum before a maximum that would cross the old minimum;
            // otherwise set the maximum first so raising both endpoints is valid.
            if(min>=0&&max>=0)
            {
                bool minimumFirst=edits[max].After.Number<edits[min].Before.Number;
                if ((minimumFirst && min>max) || (!minimumFirst && max>min))
                    (edits[min],edits[max])=(edits[max],edits[min]);
            }

            if(interactive)prompt=new GpuApplyPrompt();

            var result=await GpuTransaction.Run(edits,async(key,value)=>{var wr=await Task.Run(()=>_driver.Write(Enum.Parse<SettingId>(key),value));return wr.Ok?null:wr.Error;},key=>Task.Run(()=>_driver.Read(Enum.Parse<SettingId>(key))),SettingVm.Same,v=>v,

                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"RionWin11","GPU", "Aldx",Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(ProviderName+"|"+_driver.SelectedDisplayId)))),

                prompt==null?()=>Task.FromResult(true):prompt.Delay,prompt==null?()=>Task.FromResult(true):prompt.Keep);

            if(prompt!=null)prompt.RestoreFailed=result.RestoreFailed;

            ProfileStatus=result.Status+" · "+skipped+" unavailable";

            profileStaged=false;await RefreshAsync();DraftChanged();

        }

        catch(Exception e){ProfileStatus="Apply failed: "+e.Message;}

        finally{gate.Release();ProfileBusy=false;prompt?.Dispose();}

    }

    public async Task DetectAsync(){if(ProfileBusy)return;if(HasPending){LastDetect="Discard or apply pending edits before refreshing.";return;}ProfileBusy=true;try{await RefreshAsync();}catch(Exception e){LastDetect="Detection failed: "+e.Message;}finally{ProfileBusy=false;}}

    async Task RefreshAsync()

    {

        LastDetect="Reading driver settings…";

        var data=await Task.Run(()=>(Displays:_driver.GetDisplays(),Selected:_driver.SelectedDisplayId,Values:Rows.ToDictionary(r=>r.Id,r=>_driver.Read(r.Id)),Info:BuildSystemRows().ToArray()));

        loading=true;try{Displays.Clear();foreach(var d in data.Displays)Displays.Add(d);_selectedDisplay=Displays.FirstOrDefault(d=>d.Id==data.Selected);Raise(nameof(SelectedDisplay));Raise(nameof(ShowDisplaySelector));}finally{loading=false;}

        foreach(var row in Rows)row.SetLive(data.Values[row.Id]);foreach(var tab in Tabs)tab.RefreshCounters();Tabs.Single(t=>t.IsSystem).SetInfoRows(data.Info);Filter();LastDetect=$"Detected {Rows.Count(r=>r.Supported)} settings · {DateTime.Now:HH:mm:ss}"+(IsMock?" · Demo":"");

    }

    IEnumerable<TabVm> BuildTabs()

    {

        SettingVm[] Make(SettingTab kind)=>SettingCatalog.ForTab(kind).Select(d=>new SettingVm(d,Profile,(_,_)=>Task.FromResult(WriteResult.Fail("Use Apply to write staged changes.")),_driver.Read)).ToArray();

        yield return new(SettingTab.System,"System","", "Detected GPU and driver",Array.Empty<SettingVm>());

        yield return new(SettingTab.Display,"Display","", "Scaling, colour and adaptive sync",Make(SettingTab.Display));

        yield return new(SettingTab.Performance,"Graphics","", "Global graphics settings",Make(SettingTab.Performance));

        yield return new(SettingTab.Overclocking,"Tuning","", "Manual tuning and automatic driver tools",Array.Empty<SettingVm>());

    }

    private IEnumerable<InfoRow> BuildSystemRows()


    {


        var g = _driver.GetGpuInfo();


        return new[]


        {


            new InfoRow("GPU", g.Name),


            new InfoRow("Architecture", g.AsicFamily),


            new InfoRow("Video memory", $"{g.VramSizeMb / 1024.0:0.#} GB {g.VramType}"),


            new InfoRow("Rated core clock", g.CoreClockMhz > 0 ? $"{g.CoreClockMhz} MHz" : "—"),


            new InfoRow("Bus interface", g.BusInterface),


            new InfoRow("Rated board power", g.TotalBoardPowerW > 0 ? $"{g.TotalBoardPowerW} W" : "—"),


            new InfoRow("VBIOS", string.IsNullOrEmpty(g.VbiosVersion) ? "—" : g.VbiosVersion),


            new InfoRow("Driver", string.IsNullOrWhiteSpace(g.DriverVersion) ? "Unavailable" : $"{g.DriverVersion} {(string.IsNullOrEmpty(g.DriverDate) ? "" : "(" + g.DriverDate + ")")}"),


            new InfoRow("PCI IDs", $"VEN {g.VendorId} · DEV {g.DeviceId}"),


            new InfoRow("Display attached", g.HasDesktop ? "Yes" : "No"),


            new InfoRow("ADLX version", g.AdlxVersion),


            new InfoRow("ADLX library", g.AdlxDllPath),


            new InfoRow("Status", g.InitNote),


        };


    }


}























