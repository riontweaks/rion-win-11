using System.Windows.Threading;
using Aldx.Adlx;
using Aldx.Infra;

namespace Aldx.ViewModels;

/// <summary>
/// The Overclocking tab — an Adrenalin-style "Tuning" page for the GPU
/// (system-level + GPU auto/preset/manual + fan curve + power limit).
/// Manual controls stage changes for review and verified application. A baseline is captured on
/// load; the first manual GPU / VRAM / power change in a session raises a 15-second
/// keep-or-revert bar.
/// </summary>
public sealed partial class TuningVm : ObservableObject
{
    private readonly IAdlxProvider _adlx;
    private readonly Dispatcher _ui;
    private readonly DispatcherTimer _debounce;
    private readonly DispatcherTimer _confirm;
    private readonly SemaphoreSlim _writeGate = new(1, 1);
    private readonly FanCurveRecommendationSession _fanRecommendation;
    private int _activeWrites;
    public bool TuningIdle => _activeWrites == 0;

    private GpuTuningInfo _info = new() { GpuName = "GPU", Available = false };
    private GpuTuningInfo _sessionBaseline = new() { GpuName = "GPU", Available = false };
    private GpuTuningInfo? _revertPoint;
    private bool _firstRiskyDone;
    private bool _loading;
    private Action? _pendingPush;

    /// <summary>Live gauges shared with the shell — bound directly by OverclockingView
    /// so it no longer needs a Window-ancestor RelativeSource to reach them.</summary>
    public MetricsVm Metrics { get; }

    public TuningVm(IAdlxProvider adlx, MetricsVm metrics)
    {
        _adlx = adlx;
        Metrics = metrics;
        _fanRecommendation = new(adlx, System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "FanRecovery"));
        PreviewFanCommand = new RelayCommand(async () => await FanRecommendationAction("preview"));
        ApplyFanRecommendationCommand = new RelayCommand(async () => await FanRecommendationAction("apply"));
        RestoreFanRecommendationCommand = new RelayCommand(async () => await FanRecommendationAction("restore"));
        _ui = Dispatcher.CurrentDispatcher;
        FanCurve = new FanCurveVm();
        FanCurve.Changed += () => QueuePush(() => _adlx.SetFanCurve(FanCurve.ToPoints()), risky: true);

        _debounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
        _debounce.Tick += (_, _) => { _debounce.Stop(); FlushPush(); };

        _confirm = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _confirm.Tick += (_, _) => Tick();

        KeepCommand = new RelayCommand(Keep);
        RevertNowCommand = new RelayCommand(RevertNow);
        ResetGpuCommand = new RelayCommand(ResetGpu, () => Available);
        NextStepCommand = new RelayCommand(NextStep, () => CanNext);
        BackStepCommand = new RelayCommand(BackStep, () => CanBack);
        ApplyDefaultCommand = new RelayCommand(ResetGpu, () => Available);

        ApplyManualCommand=new RelayCommand(async()=>await ApplyManualAsync(),()=>HasPending&&TuningIdle);
        DiscardManualCommand=new RelayCommand(DiscardManual,()=>HasPending&&TuningIdle);
        Initialization=LoadAsync();
    }

    // ---------------------------------------------------------------- load
    public void Load(){Initialization=LoadAsync();}

    public bool Available => _info.Available;
    public string Unavailable => _info.Unavailable;
    public string GpuName => _info.GpuName;

    // ---------------------------------------------------------------- system
    public SystemTuningMode SystemMode
    {
        get => _info.SystemMode;
        set
        {
            if (_loading || HasPending || _info.SystemMode == value) return;
            _info = _info with { SystemMode = value };
            Raise();
            PushAutomatic(() => _adlx.SetSystemTuningMode(value), risky: value == SystemTuningMode.AutoOverclock);
            if (value == SystemTuningMode.Custom) GpuManualCustom = true;
            if (value == SystemTuningMode.Default) ResetGpu();
        }
    }

    // ---------------------------------------------------------------- GPU auto / preset / manual
    public GpuAutoMode GpuAuto
    {
        get => _info.AutoMode;
        set
        {
            if (_loading || HasPending || _info.AutoMode == value) return;
            _info = _info with { AutoMode = value, Preset = GpuPreset.None, ManualCustom = false };
            RaiseGpuModeGroup();
            PushAutomatic(() => _adlx.SetGpuAutoMode(value),
                 risky: value is GpuAutoMode.OverclockGpu or GpuAutoMode.OverclockVram or GpuAutoMode.UndervoltGpu);
        }
    }

    public GpuPreset GpuPreset
    {
        get => _info.Preset;
        set
        {
            if (_loading || HasPending || _info.Preset == value) return;
            _info = _info with { Preset = value, AutoMode = GpuAutoMode.None, ManualCustom = false };
            RaiseGpuModeGroup();
            PushAutomatic(() => _adlx.SetGpuPreset(value), risky: false);
        }
    }

    public bool GpuManualCustom
    {
        get => _info.ManualCustom;
        set
        {
            if (_loading || _info.ManualCustom == value) return;
            _info = _info with { ManualCustom = value, AutoMode = value ? GpuAutoMode.None : _info.AutoMode, Preset = value ? GpuPreset.None : _info.Preset };
            RaiseGpuModeGroup();
            Raise(nameof(ShowManualGpu));
            if(!value){resetPending=true;MarkManual();}
        }
    }

    private void RaiseGpuModeGroup()
    {
        Raise(nameof(GpuAuto)); Raise(nameof(GpuPreset)); Raise(nameof(GpuManualCustom)); Raise(nameof(ShowManualGpu));
        RaiseStepFlags();   // picking an auto mode on the Choose step enables Next
    }

    public bool ShowManualGpu => _info.ManualCustom && (_info.SupportsManualGpuClock || _info.SupportsManualVram);

    public bool SupportsAutoUndervolt => _info.SupportsAutoUndervolt;
    public bool SupportsAutoOverclock => _info.SupportsAutoOverclock;
    public bool SupportsAutoOverclockVram => _info.SupportsAutoOverclockVram;
    public bool SupportsPresets => _info.SupportsPresets;
    public bool SupportsQuiet => _info.SupportsQuiet;
    public bool SupportsBalanced => _info.SupportsBalanced;

    // manual GPU clock / voltage / vram
    public double GpuMinClock { get => _info.GpuMinClockMhz; set => SetNum(v => _info = _info with { GpuMinClockMhz = (int)v }, _info.GpuMinClockMhz, value, () => _adlx.SetGpuClockRange((int)value, _info.GpuMaxClockMhz)); }
    public double GpuMaxClock { get => _info.GpuMaxClockMhz; set => SetNum(v => _info = _info with { GpuMaxClockMhz = (int)v }, _info.GpuMaxClockMhz, value, () => _adlx.SetGpuClockRange(_info.GpuMinClockMhz, (int)value)); }
    public double GpuVoltage { get => _info.GpuVoltageMv; set => SetNum(v => _info = _info with { GpuVoltageMv = (int)v }, _info.GpuVoltageMv, value, () => _adlx.SetGpuVoltage((int)value)); }
    public double VramClock { get => _info.VramClockMhz; set => SetNum(v => _info = _info with { VramClockMhz = (int)v }, _info.VramClockMhz, value, () => _adlx.SetVramClock((int)value)); }

    public ValueRange GpuClockRange => _info.GpuClockRange;
    public ValueRange GpuVoltageRange => _info.GpuVoltageRange;
    public ValueRange VramClockRange => _info.VramClockRange;
    public bool SupportsManualGpuClock => _info.SupportsManualGpuClock;
    public bool SupportsManualVram => _info.SupportsManualVram;

    // ---------------------------------------------------------------- fan
    public bool SupportsFanTuning => _info.SupportsFanTuning;
    public bool SupportsZeroRpm => _info.SupportsZeroRpm;
    public FanCurveVm FanCurve { get; }
    public RelayCommand PreviewFanCommand { get; }
    public RelayCommand ApplyFanRecommendationCommand { get; }
    public RelayCommand RestoreFanRecommendationCommand { get; }
    public bool CanApplyFanRecommendation => _fanRecommendation.CanApply && TuningIdle && !ConfirmActive;
    public bool CanRestoreFanRecommendation => _fanRecommendation.CanRestore && TuningIdle && !ConfirmActive;
    private string _fanRecommendationText = "Inspect to preview the recommendation for this GPU. No changes are made until Apply.";
    public string FanRecommendationText { get => _fanRecommendationText; private set => Set(ref _fanRecommendationText, value); }

    private async Task FanRecommendationAction(string action)
    {
        if (!TuningIdle || ConfirmActive || HasPending || _pendingPush != null)
        {
            FanRecommendationText = "Finish pending tuning changes and Keep or Revert them before using this preset.";
            return;
        }
        if(action=="apply") { _loading=true;FanCurve.Load(_info with {FanCurve=_fanRecommendation.Proposed.ToArray()});_loading=false;MarkManual();FanRecommendationText="Fan curve staged. Review changes and Apply.";return; }
        var result = await RunAsync(() => action switch
        {
            "apply" => _fanRecommendation.Apply(),
            "restore" => _fanRecommendation.Restore(),
            _ => _fanRecommendation.Inspect(),
        });
        string demo = _adlx.IsMock ? "Demo only. " : "";
        FanRecommendationText = demo + (!result.Ok ? result.Error : action switch
        {
            "apply" => "Applied and read back from the driver. Check temperature and fan noise under your usual workload. Restore previous curve remains available.",
            "restore" => "Previous fan curve and Zero RPM state verified. Inspect to create another preview.",
            _ => _fanRecommendation.CanRestore ? "A previous application has a saved recovery state. Restore it before applying again."
                : string.Join("  ·  ", _fanRecommendation.Proposed.Select(p => $"{p.TempC:0}°C / {p.SpeedPercent:0}%")) +
                  (_fanRecommendation.CanApply ? "\nPreview only — choose Apply to use these values." : "\nNo increase fits the current curve and driver step sizes."),
        });
        Raise(nameof(CanApplyFanRecommendation)); Raise(nameof(CanRestoreFanRecommendation));
    }

    public bool FanTuningEnabled
    {
        get => _info.FanTuningEnabled;
        set { if (_loading || _info.FanTuningEnabled == value) return; _info = _info with { FanTuningEnabled = value }; Raise(); Raise(nameof(ShowFanCurve));  }
    }

    public bool ZeroRpm
    {
        get => _info.ZeroRpm;
        set { if (_loading || _info.ZeroRpm == value) return; _info = _info with { ZeroRpm = value }; Raise(); Push(() => _adlx.SetZeroRpm(value), risky: false); }
    }

    public bool FanAdvancedControl
    {
        get => _info.FanAdvancedControl;
        set { if (_loading || _info.FanAdvancedControl == value) return; _info = _info with { FanAdvancedControl = value }; Raise(); Raise(nameof(ShowFanCurve));  }
    }

    public bool ShowFanCurve => _info.FanTuningEnabled && _info.FanAdvancedControl;

    // ---------------------------------------------------------------- power
    public bool SupportsPowerTuning => _info.SupportsPowerTuning;
    public string TdcReadout => _info.SupportsTdc && _info.TdcLimitPercent is { } value
        ? $"Thermal design current limit: {value:0}% (read-only)"
        : "Thermal design current limit unavailable. " + _info.TdcUnavailable;
    public ValueRange PowerLimitRange => _info.PowerLimitRange.IsValid ? _info.PowerLimitRange : new(0, 15, 1);

    public bool PowerTuningEnabled
    {
        get => _info.PowerTuningEnabled;
        set { if (_loading || _info.PowerTuningEnabled == value) return; _info = _info with { PowerTuningEnabled = value }; Raise(); if(!value){_info=_info with {PowerLimitPercent=0};Raise(nameof(PowerLimitPercent));MarkManual();} }
    }

    public double PowerLimitPercent
    {
        get => _info.PowerLimitPercent;
        set => SetNum(v => _info = _info with { PowerLimitPercent = v }, _info.PowerLimitPercent, PowerLimitRange.Clamp(value),
                      () => _adlx.SetPowerLimitPercent(PowerLimitRange.Clamp(value)));
    }

    // ---------------------------------------------------------------- reset + confirm bar
    public RelayCommand ResetGpuCommand { get; }
    public RelayCommand KeepCommand { get; }
    public RelayCommand RevertNowCommand { get; }

    private bool _confirmActive;
    public bool ConfirmActive { get => _confirmActive; private set => Set(ref _confirmActive, value); }

    private int _confirmSeconds;
    public int ConfirmSeconds { get => _confirmSeconds; private set { if (Set(ref _confirmSeconds, value)) Raise(nameof(ConfirmText)); } }
    public string ConfirmText => ConfirmSeconds <= 0
        ? "Restoration failed. Review the error and retry Revert now."
        : $"Keep these tuning changes? Reverting in {ConfirmSeconds}s";

    private void ResetGpu()
    {
        resetPending=true;MarkManual();
    }

    private void Tick()
    {
        ConfirmSeconds--;
        if (ConfirmSeconds <= 0) RevertNow();
    }

    private void Keep()
    {
        if (!string.IsNullOrEmpty(LastError)) return;
        _confirm.Stop();
        ConfirmActive = false;
        _revertPoint = null;
        _sessionBaseline = _info;
    }

    private async void RevertNow()
    {
        _confirm.Stop();
        _debounce.Stop();
        _pendingPush = null;
        ConfirmActive = false;
        var target = _revertPoint;
        if (target is { } t)
        {
            var result = await RunAsync(() => _adlx.ApplyTuningSnapshot(t));
            if (result.Ok)
            {
                _revertPoint = null;
                _firstRiskyDone = false;
            }
            else
            {
                ConfirmSeconds = 0;
                ConfirmActive = true;
            }
            // Keep the previous state available for retry after a failed restoration.
        }
    }

    // ---------------------------------------------------------------- push plumbing
    private void SetNum(Action<double> assign, double current, double next, Func<WriteResult> push)
    {
        if (_loading || Math.Abs(current - next) < 0.001) return;
        assign(next);
        Raise();
        QueuePush(() => push(), risky: true);
    }

    private void QueuePush(Func<WriteResult> push, bool risky)=>MarkManual();

    private void FlushPush()
    {
        var p = _pendingPush;
        _pendingPush = null;
        p?.Invoke();
    }

    private void Push(Func<WriteResult> work, bool risky)=>MarkManual();

    private async void PushAutomatic(Func<WriteResult> work, bool risky)
    {
        var result = await RunAsync(work);
        if (result.Ok && risky && !_firstRiskyDone)
        {
            _firstRiskyDone = true;
            _revertPoint = _sessionBaseline;
            ConfirmSeconds = 15;
            ConfirmActive = true;
            _confirm.Start();
        }
    }

    private async Task<WriteResult> RunAsync(Func<WriteResult> work)
    {
        _activeWrites++;
        Raise(nameof(TuningIdle));
        Raise(nameof(OperationStatus));
        await GpuTransaction.SharedGate.WaitAsync();
        await _writeGate.WaitAsync();
        try
        {
        WriteResult res;
        try { res = await Task.Run(work); }
        catch (Exception ex) { res = WriteResult.Fail(ex.Message); }

        try { var fresh = await Task.Run(()=>_adlx.GetGpuTuning()); _ui.Invoke(() =>
        {
            LastError = res.Ok ? "" : res.Error;
            // re-read driver truth without disturbing the confirm bar

            FanCurve.Load(fresh);
            _info = _info with
            {
                AutoMode = fresh.AutoMode,
                Preset = fresh.Preset,
                SystemMode = fresh.SystemMode,
                ManualCustom = fresh.ManualCustom,
                PowerLimitPercent = fresh.PowerLimitPercent,
                SupportsTdc = fresh.SupportsTdc,
                TdcLimitPercent = fresh.TdcLimitPercent,
                TdcUnavailable = fresh.TdcUnavailable,
                TdcRange = fresh.TdcRange,
                GpuMinClockMhz = fresh.GpuMinClockMhz,
                GpuMaxClockMhz = fresh.GpuMaxClockMhz,
                GpuVoltageMv = fresh.GpuVoltageMv,
                VramClockMhz = fresh.VramClockMhz,
                ZeroRpm = fresh.ZeroRpm,
            };
            Raise(nameof(TdcReadout)); Raise(nameof(PowerLimitPercent)); Raise(nameof(GpuMinClock)); Raise(nameof(GpuMaxClock));
            Raise(nameof(GpuVoltage)); Raise(nameof(VramClock)); Raise(nameof(ZeroRpm));
            RaiseGpuModeGroup();
        }); }
        catch (Exception ex)
        {
            res = WriteResult.Fail((res.Ok ? "Tuning state could not be verified. " : res.Error + " ") + ex.Message);
            LastError = res.Error;
        }
        return res;
        }
        finally
        {
            _writeGate.Release();GpuTransaction.SharedGate.Release();
            _activeWrites--;
            Raise(nameof(TuningIdle));
            Raise(nameof(OperationStatus));
            Raise(nameof(CanApplyFanRecommendation)); Raise(nameof(CanRestoreFanRecommendation));
        }
    }

    private string _lastError = "";
    public string LastError { get => _lastError; private set => Set(ref _lastError, value); }

    // ================================================================ stepped wizard
    // The Overclocking tab is a Next/Back flow over this same VM. Writes still go to the
    // driver immediately (see the push plumbing above) with the 15-second keep-or-revert;
    // the steps just stage which controls are on screen, Adrenalin-style.

    public enum OcStep { Choose, Gpu, Vram, Fan, Power, Review, AutoConfirm }
    public enum TuningIntent { Default, Automatic, Manual }

    public RelayCommand NextStepCommand { get; }
    public RelayCommand BackStepCommand { get; }
    public RelayCommand ApplyDefaultCommand { get; }

    private OcStep _step = OcStep.Choose;
    public OcStep Step { get => _step; private set { if (Set(ref _step, value)) RaiseStepFlags(); } }

    private TuningIntent _intent = TuningIntent.Manual;
    public TuningIntent Intent
    {
        get => _intent;
        set
        {
            if (_loading || !Set(ref _intent, value)) return;
            if (value == TuningIntent.Manual) GpuManualCustom = true;
            RaiseStepFlags();
        }
    }

    public bool IsDefaultIntent => _intent == TuningIntent.Default;
    public bool IsAutomaticIntent => _intent == TuningIntent.Automatic;
    public bool IsManualIntent => _intent == TuningIntent.Manual;

    public bool IsChoose => _step == OcStep.Choose;
    public bool IsGpuStep => _step == OcStep.Gpu;
    public bool IsVramStep => _step == OcStep.Vram;
    public bool IsFanStep => _step == OcStep.Fan;
    public bool IsPowerStep => _step == OcStep.Power;
    public bool IsReviewStep => _step == OcStep.Review;
    public bool IsAutoConfirmStep => _step == OcStep.AutoConfirm;

    public string StepTitle => _step switch
    {
        OcStep.Choose => "Tuning Control",
        OcStep.Gpu => "GPU Tuning",
        OcStep.Vram => "VRAM Tuning",
        OcStep.Fan => "Fan Tuning",
        OcStep.Power => "Power Tuning",
        OcStep.Review => "Review",
        OcStep.AutoConfirm => AutoModeLabel,
        _ => "",
    };

    public string StepCaption => _step switch
    {
        OcStep.Choose => "Automatic modes use AMD's driver tuning algorithm. Selecting a mode starts it immediately. Manual exposes individual controls. Test stability after any change.",
        OcStep.Gpu => "Core clock range and voltage. Changes are staged until Apply.",
        OcStep.Vram => "Memory clock. Changes are staged until Apply.",
        OcStep.Fan => "Zero RPM, and a custom fan curve under Advanced Control.",
        OcStep.Power => "Raise or lower the board power limit.",
        OcStep.Review => "Review pending manual values, then choose Apply.",
        OcStep.AutoConfirm => "Wait for AMD to report completion and check for errors. Driver completion is not a guarantee of stability. Keep or revert after completion.",
        _ => "",
    };

    public string OperationStatus => _activeWrites > 0 ? "Applying " + AutoModeLabel + " — waiting for driver completion…" : "";

    private string AutoModeLabel => GpuAuto switch
    {
        GpuAutoMode.UndervoltGpu => "AMD automatic GPU undervolting",
        GpuAutoMode.OverclockGpu => "AMD automatic GPU overclocking",
        GpuAutoMode.OverclockVram => "AMD automatic VRAM overclocking",
        _ => GpuPreset switch
        {
            GpuPreset.Quiet => "AMD Quiet preset",
            GpuPreset.Balanced => "AMD Balanced preset",
            _ => "Quick adjustments",
        },
    };

    public string NextLabel => _step is OcStep.Gpu or OcStep.Vram or OcStep.Fan or OcStep.Power ? "Next"
        : _step == OcStep.Choose && _intent == TuningIntent.Automatic ? "Apply" : "Next";

    public bool CanBack => _step != OcStep.Choose;

    public bool CanNext => _step switch
    {
        OcStep.Choose => _intent == TuningIntent.Manual
                         || (_intent == TuningIntent.Automatic && (GpuAuto != GpuAutoMode.None || GpuPreset != GpuPreset.None)),
        OcStep.Gpu or OcStep.Vram or OcStep.Fan or OcStep.Power => true,
        _ => false,
    };

    public string ReviewSummary
    {
        get
        {
            var parts = new List<string>();
            if (_info.SupportsManualGpuClock)
                parts.Add($"GPU clock {GpuMinClock:0}–{GpuMaxClock:0} MHz · {GpuVoltage:0} mV");
            if (_info.SupportsManualVram)
                parts.Add($"VRAM {VramClock:0} MHz");
            if (_info.SupportsFanTuning)
                parts.Add(FanTuningEnabled ? (FanAdvancedControl ? "Custom fan curve" : "Fan tuning on") : "Fan tuning off");
            if (_info.SupportsPowerTuning)
                parts.Add(PowerTuningEnabled ? $"Power limit {PowerLimitPercent:+0;-0;0}%" : "Stock power limit");
            return parts.Count == 0 ? "No manual tuning controls on this GPU." : string.Join("\n", parts);
        }
    }

    private List<OcStep> ManualOrder
    {
        get
        {
            var l = new List<OcStep> { OcStep.Gpu };
            if (_info.SupportsManualVram) l.Add(OcStep.Vram);
            if (_info.SupportsFanTuning) l.Add(OcStep.Fan);
            if (_info.SupportsPowerTuning) l.Add(OcStep.Power);
            l.Add(OcStep.Review);
            return l;
        }
    }

    private void NextStep()
    {
        if (!CanNext) return;
        if (_step == OcStep.Choose)
        {
            Step = _intent == TuningIntent.Automatic ? OcStep.AutoConfirm : ManualOrder[0];
            return;
        }
        var order = ManualOrder;
        int i = order.IndexOf(_step);
        if (i >= 0 && i < order.Count - 1) Step = order[i + 1];
    }

    private void BackStep()
    {
        if (_step is OcStep.AutoConfirm) { Step = OcStep.Choose; return; }
        var order = ManualOrder;
        int i = order.IndexOf(_step);
        if (i > 0) Step = order[i - 1];
        else Step = OcStep.Choose;
    }

    private void RaiseStepFlags()
    {
        foreach (var n in new[]
        {
            nameof(Step), nameof(Intent), nameof(IsDefaultIntent), nameof(IsAutomaticIntent), nameof(IsManualIntent),
            nameof(IsChoose), nameof(IsGpuStep), nameof(IsVramStep), nameof(IsFanStep), nameof(IsPowerStep),
            nameof(IsReviewStep), nameof(IsAutoConfirmStep), nameof(StepTitle), nameof(StepCaption),
            nameof(NextLabel), nameof(CanBack), nameof(CanNext), nameof(ReviewSummary),
        }) Raise(n);
        NextStepCommand.RaiseCanExecuteChanged();
        BackStepCommand.RaiseCanExecuteChanged();
    }
}
