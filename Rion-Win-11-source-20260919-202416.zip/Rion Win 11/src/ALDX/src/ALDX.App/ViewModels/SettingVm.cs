using System.Windows.Threading;
using Aldx.Adlx;
using Aldx.Catalog;
using Aldx.Infra;

namespace Aldx.ViewModels;

/// <summary>
/// One catalogue row. Editing a control writes to the driver immediately
/// (toggles/dropdowns at once; sliders coalesced while dragging). The row then re-reads to
/// show what the driver actually accepted.
/// </summary>
public sealed class SettingVm : ObservableObject
{
    private readonly SettingDef _def;
    private readonly Func<SettingId, SettingValue, Task<WriteResult>> _apply;
    private readonly Func<SettingId, SettingValue> _reread;
    private readonly DispatcherTimer _debounce;
    private bool _pending;
    private long _editVersion;
    private RecoProfile _profile;
    private SettingValue _live = SettingValue.Unsupported("Not detected yet.");
    private bool _suppress;

    public SettingVm(SettingDef def, RecoProfile profile,
                     Func<SettingId, SettingValue, Task<WriteResult>> apply,
                     Func<SettingId, SettingValue> reread)
    {
        _def = def;
        _profile = profile;
        _apply = apply;
        _reread = reread;
        Options = def.Options.ToList();
        _debounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(75) };
        _debounce.Tick += (_, _) => { _debounce.Stop(); _ = PushAsync(); };
    }

    public SettingId Id => _def.Id;
    public void CancelPendingEdit() { _debounce.Stop(); _pending=false; _editVersion++; }
    public bool StageEdits { get; set; }
    public event Action? DraftChanged;
    private SettingValue _detected = SettingValue.Unsupported("Not detected");
    public SettingValue Detected => _detected;
    public SettingValue PendingValue => _live;
    public bool IsDirty => !Same(_detected, _live);
    public static bool Same(SettingValue a, SettingValue b) => a.Supported == b.Supported && a.Bool == b.Bool && a.Choice == b.Choice && a.Number == b.Number;
    public void Stage(SettingValue value) { if (!Supported || IsReadOnly || !value.Supported) return; var detected=_detected; SetLive(value with {Min=_live.Min,Max=_live.Max,Step=_live.Step}); _detected=detected; ChangedDraft(); }
    public void Discard() { SetLive(_detected); ChangedDraft(); }
    private void ChangedDraft() { Raise(nameof(IsDirty)); DraftChanged?.Invoke(); }
    public string Name => _def.Name;
    public string Description => _def.Description;
    public string Group => _def.Group;
    public string Unit => _def.Unit;
    public IReadOnlyList<SettingOption> Options { get; }

    public bool IsToggle => _def.Writable && _def.Control == ControlKind.Toggle;
    public bool IsChoice => _def.Writable && _def.Control == ControlKind.Choice;
    public bool IsSlider => _def.Writable && _def.Control == ControlKind.Slider;
    public bool IsReadOnly => !_def.Writable || _def.Control == ControlKind.ReadOnly;

    // ------------------------------------------------ detected value
    public void SetLive(SettingValue v)
    {
        _suppress = true;
        _live = v; _detected = v; Raise(nameof(IsDirty));
        foreach (var p in new[]
        {
            nameof(Supported), nameof(UnsupportedReason), nameof(CurrentText), nameof(ToggleValue),
            nameof(SelectedOption), nameof(SliderValue), nameof(SliderMin), nameof(SliderMax), nameof(SliderStep),
        }) Raise(p);
        RaiseReco();
        _suppress = false;
    }

    public bool Supported => _live.Supported;
    public string UnsupportedReason => _live.UnsupportedReason;

    private bool _busy;
    public bool Busy { get => _busy; private set => Set(ref _busy, value); }

    private string _error = "";
    public string Error { get => _error; private set => Set(ref _error, value); }

    public string CurrentText
    {
        get
        {
            if (!_live.Supported) return "Unavailable";
            if (_live.Bool is { } b) return b ? "Enabled" : "Disabled";
            if (_live.Choice is { } c) return LabelFor(c);
            if (_live.Number is { } n) return $"{Fmt(n)}{UnitSuffix}";
            return "—";
        }
    }

    // ------------------------------------------------ control-bound state
    public bool ToggleValue
    {
        get => _live.Bool ?? false;
        set
        {
            if (_suppress || !Supported || !IsToggle || (_live.Bool ?? false) == value) return;
            _live = _live with { Bool = value };
            Raise(); Raise(nameof(CurrentText));
            if (!_suppress) { _pending=true; _editVersion++; _ = PushAsync(); }
        }
    }

    public SettingOption? SelectedOption
    {
        get => Options.FirstOrDefault(o => o.Value == _live.Choice);
        set
        {
            if (_suppress || !Supported || !IsChoice || value is null || value.Value == _live.Choice) return;
            _live = _live with { Choice = value.Value };
            Raise(); Raise(nameof(CurrentText));
            if (!_suppress) { _pending=true; _editVersion++; _ = PushAsync(); }
        }
    }

    public double SliderValue
    {
        get => _live.Number ?? _def.Min;
        set
        {
            if (_suppress || !Supported || !IsSlider) return;
            if (!double.IsFinite(value)) return;
            double step = SliderStep > 0 ? SliderStep : 1;
            var c = Math.Clamp(SliderMin + Math.Round((value - SliderMin) / step) * step, SliderMin, SliderMax);
            if (Math.Abs((_live.Number ?? _def.Min) - c) < 0.001) return;
            _live = _live with { Number = c };
            Raise(); Raise(nameof(CurrentText));
            if (!_suppress) { _pending=true; _editVersion++; if (StageEdits) { _pending=false; ChangedDraft(); } else if (!_debounce.IsEnabled) _debounce.Start(); }
        }
    }

    public double SliderMin => _live.Min ?? _def.Min;
    public double SliderMax => _live.Max ?? _def.Max;
    public double SliderStep => _live.Step ?? _def.Step;

    private async Task PushAsync()
    {
        if (StageEdits) { _pending=false; ChangedDraft(); return; }
        if (Busy || !_pending) return;
        _pending=false; var version=_editVersion; var requested=_live;
        Busy = true; Error = "";
        try
        {
            var res = await _apply(_def.Id, requested);
            if (!res.Ok) Error = res.Error;
            // A slow readback must not replace the newer value under the pointer.
            if (version == _editVersion) SetLive(_reread(_def.Id));
        }
        catch (Exception ex) { Error = "Could not refresh the driver setting: " + ex.Message; }
        finally { Busy = false; if (_pending && !_debounce.IsEnabled) _debounce.Start(); }
        RaiseReco();
    }

    // ------------------------------------------------ recommendation
    public void SetProfile(RecoProfile p) { if (_profile != p) { _profile = p; RaiseReco(); } }
    private Recommendation? Reco => SettingCatalog.For(_def.Id, _profile);

    public bool HasRecommendation => Supported && Reco is not null && !IsReadOnly && (!IsChoice || Options.Any(o => o.Value == Reco.Value));
    public string RecommendationChip => Reco?.Confidence == RecoConfidence.Strong ? "Recommended" : "Suggested";
    public string RecommendationValueText => Reco is null ? "" : DescribeValue(Reco.Value);
    public string RecommendationHeadline => HasRecommendation ? $"{RecommendationChip}: {RecommendationValueText}" : "";
    public string RecommendationRationale => Reco?.Rationale ?? "";
    public string RecommendationSource => Reco?.Source ?? "";
    public string RecommendationTooltip => HasRecommendation
        ? $"{RecommendationHeadline}\n\n{RecommendationRationale}\n\nSource: {RecommendationSource}" : "";

    public bool IsAtRecommended
    {
        get
        {
            if (Reco is null || !_live.Supported) return false;
            if (_live.Bool is { } b) return (Reco.Value == "on") == b;
            if (_live.Choice is { } c) return string.Equals(c, Reco.Value, StringComparison.OrdinalIgnoreCase);
            if (_live.Number is { } n) return double.TryParse(Reco.Value, out var w) && Math.Abs(w - n) < 0.5;
            return false;
        }
    }

    public bool ShowDeviationGlow => HasRecommendation && Supported && !IsAtRecommended;

    public RelayCommand ApplyRecommendedCommand => new(ApplyRecommended,
        () => HasRecommendation && Supported && !IsAtRecommended);

    /// <summary>Move this setting to its recommended value for the active profile (writes to the
    /// driver via the normal immediate-apply path). No-op if unsupported, already there, or
    /// there is no recommendation.</summary>
    public void ApplyRecommended()
    {
        if (!HasRecommendation || Reco is null || IsAtRecommended) return;
        if (IsToggle) ToggleValue = Reco.Value == "on";
        else if (IsChoice) SelectedOption = Options.FirstOrDefault(o => o.Value == Reco.Value);
        else if (IsSlider && double.TryParse(Reco.Value, out var n)) SliderValue = n;
    }

    private void RaiseReco()
    {
        foreach (var p in new[]
        {
            nameof(HasRecommendation), nameof(RecommendationChip), nameof(RecommendationValueText),
            nameof(RecommendationHeadline), nameof(RecommendationRationale), nameof(RecommendationSource),
            nameof(RecommendationTooltip), nameof(IsAtRecommended), nameof(ShowDeviationGlow),
        }) Raise(p);
        ApplyRecommendedCommand.RaiseCanExecuteChanged();
    }

    // ------------------------------------------------ helpers
    private string UnitSuffix => string.IsNullOrEmpty(Unit) ? "" : (Unit.StartsWith("°") ? Unit : " " + Unit);
    private static string Fmt(double n) => Math.Abs(n - Math.Round(n)) < 0.05 ? ((long)Math.Round(n)).ToString() : n.ToString("0.0");
    private string LabelFor(string v) => Options.FirstOrDefault(o => o.Value == v)?.Label ?? v;

    private string DescribeValue(string v)
    {
        if (IsToggle) return v == "on" ? "Enabled" : "Disabled";
        if (IsChoice) return LabelFor(v);
        if (double.TryParse(v, out var n)) return $"{Fmt(n)}{UnitSuffix}";
        return v;
    }

    public bool Matches(string q) =>
        string.IsNullOrWhiteSpace(q) ||
        Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
        Description.Contains(q, StringComparison.OrdinalIgnoreCase) ||
        Group.Contains(q, StringComparison.OrdinalIgnoreCase);
}



