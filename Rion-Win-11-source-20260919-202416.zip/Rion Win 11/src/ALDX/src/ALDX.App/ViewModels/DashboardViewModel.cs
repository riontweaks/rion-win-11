using Aldx.Infra;

namespace Aldx.ViewModels;

/// <summary>
/// The Dashboard page — a read-only wall of live GPU telemetry. Binds the process-wide
/// <see cref="AdlxHost.Metrics"/>, so it moves in lock-step with the Better Adrenaline gauges.
/// </summary>
public sealed class DashboardViewModel : ObservableObject
{
    private readonly AdlxHost _host = AdlxHost.Instance;

    public DashboardViewModel()
    {
        try { GpuName = _host.Provider.GetGpuInfo().Name; }
        catch { GpuName = "Graphics processor"; }
    }

    public MetricsVm Metrics => _host.Metrics;

    public string GpuName { get; }

    public bool IsMock => _host.IsMock;

    /// <summary>True when ADLX bound to a real Radeon driver (drives the green indicator light).</summary>
    public bool Connected => !_host.IsMock;

    public string ConnectionText => Connected
        ? "Connected to the Radeon driver"
        : "No AMD driver — showing simulated data";
}
