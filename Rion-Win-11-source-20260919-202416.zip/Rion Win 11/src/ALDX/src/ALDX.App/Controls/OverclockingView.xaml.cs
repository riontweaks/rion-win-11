using System.Windows.Controls;

namespace Aldx.Controls;

public partial class OverclockingView : UserControl
{
    public OverclockingView()
    {
        InitializeComponent();
        SizeChanged += (_, _) => TuningCards.Columns = ActualWidth >= 780 ? 2 : 1;
    }
}
