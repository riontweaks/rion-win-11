using System.Windows;
using System.Windows.Controls;
namespace Aldx.Controls;
public sealed class SettingRowPanel:Panel
{
 bool narrow;
 protected override Size MeasureOverride(Size size){narrow=size.Width<540;double width=double.IsInfinity(size.Width)?800:size.Width;if(Children.Count!=2)return new();Children[0].Measure(new Size(narrow?width:Math.Max(0,width-210),double.PositiveInfinity));Children[1].Measure(new Size(narrow?width:210,double.PositiveInfinity));return new(width,narrow?Children[0].DesiredSize.Height+Children[1].DesiredSize.Height+8:Math.Max(Children[0].DesiredSize.Height,Children[1].DesiredSize.Height));}
 protected override Size ArrangeOverride(Size size){if(Children.Count!=2)return size;if(narrow){var h=Children[0].DesiredSize.Height;Children[0].Arrange(new Rect(0,0,size.Width,h));Children[1].Arrange(new Rect(0,h+8,size.Width,Math.Max(0,size.Height-h-8)));}else{Children[0].Arrange(new Rect(0,0,Math.Max(0,size.Width-210),size.Height));Children[1].Arrange(new Rect(Math.Max(0,size.Width-210),0,Math.Min(210,size.Width),size.Height));}return size;}
}