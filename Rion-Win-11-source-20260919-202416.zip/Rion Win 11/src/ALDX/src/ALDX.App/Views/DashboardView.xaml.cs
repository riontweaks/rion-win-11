using System.Windows.Controls;

namespace Aldx.Views;

/// <summary>
/// The Dashboard module's view — a wall of live GPU gauges. Hosted first in the
/// Rion Win 11 sidebar; shares <see cref="ViewModels.AdlxHost"/> with Better Adrenaline.
/// </summary>
public partial class DashboardView : UserControl
{
    public DashboardView() => InitializeComponent();
}
