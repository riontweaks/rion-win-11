using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace Aldx.Views;

/// <summary>
/// Better Adrenaline section body, hosted inside AMD GPU Manager. DataContext is the
/// shared <see cref="ViewModels.ShellViewModel"/>; the section list (System / Display /
/// Performance / Overclocking) lives in the merged module's second sidebar.
/// </summary>
public partial class AdrenalineSectionView : UserControl
{
    public AdrenalineSectionView() => InitializeComponent();

}
