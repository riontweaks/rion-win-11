# ALDX — Radeon Control & Tuning

An AMD control panel built on the public **ADLX** SDK. It detects settings implemented
in this integration, shows the current value next to a curated **recommendation** (rationale +
source + confidence, per profile), and groups everything into **System / Display /
Performance / Overclocking** tabs. Every change is written to the driver **immediately**.

Black-glass WPF theme (custom chrome, DWM acrylic, Fluent controls).

> **Not owned, supported, or endorsed by AMD or Microsoft.** Low-level GPU changes
> carry real risk. Detection is safe; overclocking / fan / power writes apply live,
> with a snapshot on load and a 15-second keep-or-revert on the first manual change.

## Running it

.NET 8 SDK, Windows 10/11 x64.

```
dotnet run --project src/ALDX.App
```

Without the native ADLX bindings the app runs on a **mock device** (Radeon RX 7700 XT) —
the whole UI, immediate-apply, snapshot and revert flow work, but nothing reaches
hardware. The mode banner at the top of every tab says which provider is live.

## Going live (on the Radeon PC)

```
pwsh tools/setup-adlx.ps1
dotnet build ALDX.sln -c Debug
```

`setup-adlx.ps1` clones the ADLX SDK, builds the SWIG-generated C# binding, and drops
it in `third_party/ADLX/`. `ALDX.App.csproj` then auto-defines `ADLX_SWIG`, compiles
`SwigAdlxProvider`, and the app talks to `amdadlx64.dll` from the installed driver.

Needs: git · Visual Studio 2019/2022 with the C++ workload · swigwin 4.0.2 on PATH.
`amdadlx64.dll` is never shipped — it loads at runtime from the driver.

## What's wired

| Tab | State |
|---|---|
| **System** | GPU / driver / ADLX environment (read-only) |
| **Display** | FreeSync, VSR, GPU/integer scaling, scaling mode, colour depth, pixel format, Vari-Bright, HDCP(detect-only) — toggle / dropdown, live write |
| **Performance** | Anti-Lag, Chill (+min/max), Boost, RSR, Image Sharpening, Enhanced Sync, V-Sync mode, FRTC, AA mode/level/method, MLAA, aniso, texture filtering, tessellation, shader cache, … — toggle / dropdown / slider, live write |
| **Overclocking** | Adrenalin-style: system Default / Auto Overclock / Custom · GPU Default / Undervolt / Overclock / Overclock VRAM · Quiet / Balanced presets · manual GPU clock + voltage + VRAM sliders · **draggable fan curve** · **Power Limit % slider** · live metric gauges · snapshot + first-touch keep-or-revert. **CPU tuning is out of scope** (ADLX has no CPU knobs — that needs the Ryzen Master SDK). |

`SwigAdlxProvider` fully implements tuning (fan / power / clock / VRAM) + metrics +
the headline 3D toggles. The long tail of 3D image-quality settings has a `TODO` and a
copy-paste pattern — finish them on the rig against the ADLX 3D reference.

## Layout

| Path | Role |
|---|---|
| `GlassKit/` | the black-glass theme (`Glass.xaml`, `GlassWindow`, converters) |
| `Adlx/IAdlxProvider.cs` | the one seam; `MockAdlxProvider` / `SwigAdlxProvider` (`#if ADLX_SWIG`) |
| `Adlx/AdlxProviderFactory.cs` | picks live provider if bindings compiled in + ADLX inits, else mock |
| `Catalog/SettingCatalog.cs` | every Display/Performance setting + the recommendation table |
| `ViewModels/SettingVm.cs` | one row — detected value, immediate write (debounced sliders), reco |
| `ViewModels/TuningVm.cs` | the Overclocking page — modes, gauges, fan curve, power, snapshot/confirm |
| `Controls/FanCurveEditor.*` | the draggable temperature→PWM% graph |
| `Controls/OverclockingView.xaml` | the Adrenalin-style tuning layout |
| `tools/setup-adlx.ps1` | generates the ADLX C# bindings |

## Licensing

MIT (`LICENSE`). ADLX SDK used under AMD's *ADLX SDK License Agreement* (vendored under
`third_party/ADLX/` by the setup script, with its licence file kept alongside).
