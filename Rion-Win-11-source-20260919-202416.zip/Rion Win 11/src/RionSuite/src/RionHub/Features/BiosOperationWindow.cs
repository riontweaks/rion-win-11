using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace RionHub.Features;

public sealed class BiosOperationWindow : Window
{
    private readonly TextBox output=new(){IsReadOnly=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,AcceptsReturn=true};
    private readonly TextBlock status=new(){Text="Preparing",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,12)};
    private readonly Button close=new(){Content="Cancel before import",MinWidth=150,Margin=new Thickness(0,12,0,0),HorizontalAlignment=HorizontalAlignment.Right};
    private readonly CancellationTokenSource cancellation=new();
    private readonly Stopwatch elapsed=Stopwatch.StartNew();
    private readonly DispatcherTimer timer=new(){Interval=TimeSpan.FromSeconds(1)};
    private bool finished;
    public CancellationToken Cancellation=>cancellation.Token;
    public BiosOperationWindow(Window? owner,string intended)
    {
        Theme.WindowCaption.Attach(this);
        Owner=owner;Title="BIOS operation";Width=680;Height=500;MinWidth=480;MinHeight=320;WindowStartupLocation=WindowStartupLocation.CenterOwner;UseLayoutRounding=true;
        SetResourceReference(FontFamilyProperty,"AppFont");SetResourceReference(BackgroundProperty,"Bg1");SetResourceReference(ForegroundProperty,"Text");
        var layout=new DockPanel{Margin=new Thickness(20)};DockPanel.SetDock(status,Dock.Top);layout.Children.Add(status);DockPanel.SetDock(close,Dock.Bottom);layout.Children.Add(close);layout.Children.Add(output);Content=layout;
        output.Text=intended+Environment.NewLine;close.Click+=(_,_)=>{if(finished)Close();else if(!BiosOperations.FirmwareWriteActive)cancellation.Cancel();};
        timer.Tick+=(_,_)=>{status.Text=$"Elapsed {elapsed.Elapsed:mm\\:ss} · "+(finished?"Finished":BiosOperations.FirmwareWriteActive?"Writing firmware — wait for completion":"Working");close.IsEnabled=finished||!BiosOperations.FirmwareWriteActive;};timer.Start();
        Closing+=OnClosing;if(owner!=null)owner.Closing+=OnOwnerClosing;Closed+=(_,_)=>{timer.Stop();cancellation.Dispose();if(owner!=null)owner.Closing-=OnOwnerClosing;};
    }
    private void OnClosing(object? sender,CancelEventArgs e){if(!finished){e.Cancel=true;if(!BiosOperations.FirmwareWriteActive)cancellation.Cancel();}}
    private void OnOwnerClosing(object? sender,CancelEventArgs e){if(!finished){e.Cancel=true;Activate();}}
    public void Log(string line){Dispatcher.BeginInvoke(()=>{output.AppendText(line+Environment.NewLine);output.ScrollToEnd();});}
    public void Complete(string result){finished=true;timer.Stop();status.Text=$"Finished · {elapsed.Elapsed:mm\\:ss}";output.AppendText(result+Environment.NewLine);close.Content="Close";close.IsEnabled=true;}
}
