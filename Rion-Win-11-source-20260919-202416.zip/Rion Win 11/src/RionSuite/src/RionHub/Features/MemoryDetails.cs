using System.Globalization;
using System.Management;
using System.Text.RegularExpressions;

namespace RionHub.Features;

public sealed record MemoryField(string Name, string Value, string Source);
public sealed class MemoryModule
{
    public string Slot { get; set; } = "Unknown slot";
    public string PartNumber { get; set; } = "";
    public string Serial { get; set; } = "";
    public string Origin { get; set; } = "Windows firmware inventory";
    public List<MemoryField> Fields { get; } = new();
    public string MatchNote { get; set; } = "";
    public string Title => Slot + (PartNumber.Length == 0 ? "" : " · " + PartNumber);
    public void Add(string name, string? value, string? source = null) => Fields.Add(new(name, string.IsNullOrWhiteSpace(value) ? "Unknown" : value.Trim(), source ?? Origin));
}

public static class MemoryDetails
{
    public static IReadOnlyList<MemoryModule> ReadFirmware()
    {
        var modules = new List<MemoryModule>();
        using var query = new ManagementObjectSearcher("SELECT DeviceLocator, BankLabel, Capacity, Manufacturer, PartNumber, SerialNumber, Speed, ConfiguredClockSpeed, SMBIOSMemoryType FROM Win32_PhysicalMemory");
        using var records = query.Get();
        foreach (ManagementObject item in records)
        using (item)
        {
            string Read(string key) => Convert.ToString(item[key], CultureInfo.InvariantCulture)?.Trim() ?? "";
            var module = new MemoryModule { Slot = Read("DeviceLocator"), PartNumber = Read("PartNumber"), Serial = Read("SerialNumber") };
            if (module.Slot.Length == 0) module.Slot = Read("BankLabel");
            if (module.Slot.Length == 0) module.Slot = "Unknown slot";
            module.Add("Module manufacturer", Read("Manufacturer"));
            module.Add("Part number", module.PartNumber);
            module.Add("Capacity", ulong.TryParse(Read("Capacity"), out var capacity) && capacity > 0 ? $"{capacity / 1073741824d:0.##} GiB" : null);
            module.Add("Memory type", Read("SMBIOSMemoryType") switch { "26" => "DDR4", "34" => "DDR5", "24" => "DDR3", "30" => "LPDDR4", "35" => "LPDDR5", _ => "Unknown" });
            module.Add("Firmware speed", Speed(Read("Speed")), "SMBIOS via WMI Speed (reported MHz; not a live measurement)");
            module.Add("Configured speed", Speed(Read("ConfiguredClockSpeed")), "SMBIOS via WMI ConfiguredClockSpeed (reported MHz; not a live measurement)");
            module.Add("JEDEC / XMP / EXPO profiles", null, "Import an SPD report; firmware speed alone does not identify a profile");
            module.Add("DRAM manufacturer", null, "Not provided by this Windows query");
            module.Add("Die revision", null, "Not inferred from module brand, timings, or speed");
            modules.Add(module);
        }
        return modules;
    }

    private static string? Speed(string value) => uint.TryParse(value, out uint speed) && speed > 0 ? $"{speed} MHz (firmware reported)" : null;

    public static IReadOnlyList<MemoryModule> ParseCpuZ(string text)
    {
        if (text.Length > 8_000_000 || text.Contains('\0') || !text.Contains("CPU-Z", StringComparison.OrdinalIgnoreCase))
            throw new FormatException("Choose a CPU-Z text report, up to 8 MB.");
        var modules = new List<MemoryModule>();
        MemoryModule? current = null;
        bool inSpd = false;
        foreach (var raw in text.Split('\n'))
        {
            var line = raw.Trim();
            if (line.Equals("SPD", StringComparison.OrdinalIgnoreCase) || line.StartsWith("DIMM #", StringComparison.OrdinalIgnoreCase)) inSpd = true;
            if (!inSpd) continue;
            if (Regex.IsMatch(line, @"^(DIMM|Memory Module)\s*#?\s*\d+", RegexOptions.IgnoreCase))
            {
                current = new MemoryModule { Slot = line, Origin = "Imported CPU-Z text report" }; modules.Add(current); continue;
            }
            if (current == null) continue;
            if (Regex.IsMatch(line, @"^(Monitoring|Graphics|Display Adapters|Software|PCI Devices|DMI)\b", RegexOptions.IgnoreCase)) { current = null; inSpd = false; continue; }
            var pair = Regex.Match(raw.Trim(), @"^(.*?)\s*(?:\t+| {2,}|\s*:\s*)\s*(\S.*)$");
            if (!pair.Success) continue;
            var key = Regex.Replace(pair.Groups[1].Value, @"\s*\(ID\)$", "", RegexOptions.IgnoreCase).Trim(); var value = pair.Groups[2].Value.Trim();
            if (key.Equals("Part number", StringComparison.OrdinalIgnoreCase)) { current.PartNumber = value; current.Add("Part number", value); }
            else if (key.Equals("Serial number", StringComparison.OrdinalIgnoreCase)) current.Serial = value;
            else if (key.Equals("Module Manufacturer", StringComparison.OrdinalIgnoreCase)) current.Add("Module manufacturer", value);
            else if (key.Equals("DRAM Manufacturer", StringComparison.OrdinalIgnoreCase)) current.Add("DRAM manufacturer", value);
            else if (key.Equals("Die revision", StringComparison.OrdinalIgnoreCase) || key.Equals("DRAM die", StringComparison.OrdinalIgnoreCase)) current.Add("Die revision", value);
            else if (key.Equals("Size", StringComparison.OrdinalIgnoreCase) || key.Equals("Module Size", StringComparison.OrdinalIgnoreCase)) current.Add("Capacity", value);
            else if (key.Contains("JEDEC", StringComparison.OrdinalIgnoreCase) || key.Contains("XMP", StringComparison.OrdinalIgnoreCase) || key.Contains("EXPO", StringComparison.OrdinalIgnoreCase)) current.Add(key, value);
            else if (key.Equals("Max bandwidth", StringComparison.OrdinalIgnoreCase)) current.Add("SPD maximum bandwidth", value);
            else if (key.Equals("Memory type", StringComparison.OrdinalIgnoreCase)) current.Add("Memory type", value);
        }
        foreach (var module in modules)
        {
            if (!module.Fields.Any(f => f.Name == "DRAM manufacturer")) module.Add("DRAM manufacturer", null);
            if (!module.Fields.Any(f => f.Name == "Die revision")) module.Add("Die revision", null, "Report does not explicitly identify the die");
        }
        if (modules.Count == 0 || modules.All(m => m.PartNumber.Length == 0 && m.Fields.All(f => f.Value == "Unknown")))
            throw new FormatException("No supported SPD module records were found. Export CPU-Z's text report with memory/SPD information.");
        return modules;
    }

    public static void MatchReports(IReadOnlyList<MemoryModule> imported, IReadOnlyList<MemoryModule> firmware)
    {
        foreach (var report in imported)
        {
            bool usableSerial = report.Serial.Length > 0 && report.Serial.Any(c => c != '0' && c != ' ' && c != '-');
            var matches = firmware.Where(m => report.PartNumber.Length > 0 && m.PartNumber.Equals(report.PartNumber, StringComparison.OrdinalIgnoreCase)
                && (!usableSerial || m.Serial.Equals(report.Serial, StringComparison.OrdinalIgnoreCase))).ToList();
            report.MatchNote = matches.Count == 1
                ? "Matches " + matches[0].Slot + ". Imported values remain separate; the report may be older than this scan."
                : "Unmatched or ambiguous module. Imported data is shown separately from this PC's firmware data.";
            if (matches.Count == 1)
            {
                var conflicts = report.Fields.Where(f => matches[0].Fields.Any(w => w.Name == f.Name && w.Value != "Unknown" && f.Value != "Unknown" && !w.Value.Equals(f.Value, StringComparison.OrdinalIgnoreCase))).Select(f => f.Name).ToArray();
                if (conflicts.Length > 0) report.MatchNote += " Reported values differ: " + string.Join(", ", conflicts) + ".";
            }
        }
    }
}
