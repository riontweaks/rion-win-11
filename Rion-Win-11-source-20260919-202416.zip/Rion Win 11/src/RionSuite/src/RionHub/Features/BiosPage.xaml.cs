using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace RionHub.Features;

public partial class BiosPage : UserControl
{
    private BiosDocument? document;
    private bool busy;
    private readonly Stack<Dictionary<string,string>> undo = new();
    private bool boardDetected;
    private MotherboardInfo? detectedBoard;
    public BiosPage():this(BiosWorkspace.Instance,true){}
    public BiosPage(BiosWorkspace workspace,bool initialize)
    {
        this.workspace=workspace;InitializeComponent();
        if(initialize)Loaded+=async(_,_)=>{await DetectBoardAsync();await InitializeWorkspace();};
    }
    public void LoadWorkspacePreview(){WorkspaceChanged();}
    public async Task DetectBoardAsync()
    {
        if(boardDetected)return;boardDetected=true;
        try{var board=await MotherboardInfo.DetectAsync();await Dispatcher.InvokeAsync(()=>ShowBoard(board));}
        catch(Exception ex){await Dispatcher.InvokeAsync(()=>{BoardLabel.Text="Motherboard unavailable";BoardLabel.ToolTip=ex.Message;});}
    }
    private void ShowBoard(MotherboardInfo board)
    {
        detectedBoard=board;BrandLabel.Text=MotherboardBrand.Name(board.Manufacturer);
        BoardLabel.Text=string.IsNullOrWhiteSpace(board.Display)?"Motherboard unavailable":board.Display;
        BoardLabel.ToolTip="This PC · "+BoardLabel.Text+" · "+board.CpuName;
        CpuVendorLogo.Source=board.CpuBrand is string brand
            ?new System.Windows.Media.Imaging.BitmapImage(new Uri($"pack://application:,,,/Rion Win 11;component/Assets/CpuVendors/{brand.ToLowerInvariant()}.png"))
            :null;
        CpuVendorLogo.Visibility=board.CpuBrand==null?Visibility.Collapsed:Visibility.Visible;
        CpuVendorLogo.ToolTip=string.Join(" · ",new[]{board.CpuBrand,board.CpuName}.Where(s=>!string.IsNullOrWhiteSpace(s)));
        System.Windows.Automation.AutomationProperties.SetName(CpuVendorLogo,board.CpuBrand==null?"CPU vendor unavailable":board.CpuBrand+" CPU");
    }
    private void Report(string text) { StatusText.Text=text; StatusText.ToolTip=text; }
    private void Run(Action action) { try { action(); } catch(Exception e) { Report(e.Message); } }
    private async Task RunAsync(Func<Task> action)
    {
        if(busy)return; busy=true;ScanButton.IsEnabled=false;ApplyButton.IsEnabled=false;Toolbar.IsEnabled=WorkArea.IsEnabled=false;
        try {await action();} catch(Exception e){Report(e.Message);}
        finally {busy=false;ScanButton.IsEnabled=true;Toolbar.IsEnabled=WorkArea.IsEnabled=true;UpdateChangeCount();}
    }
    private void Require() { if(document==null)throw new InvalidOperationException("Scan BIOS or open an exported file first."); }
    private async void Scan_Click(object sender,RoutedEventArgs e) => await RunAsync(async()=>
    {
        if(!ConfirmDiscard())return;
        if(MessageBox.Show("Run SCEWIN Export.bat to read firmware settings? This loads the supplied firmware-access driver.","Scan BIOS",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
        var operation=new BiosOperationWindow(Window.GetWindow(this),"Read firmware settings with the verified Export.bat.");operation.Show();
        try{Report("Exporting NVRAM…");var fresh=await BiosOperations.ScanAsync(operation.Log,operation.Cancellation);offlineDocument=false;await workspace.AcceptAsync(fresh,"Fresh scan");SetDocument(fresh,"Fresh scan");operation.Complete("Fresh export loaded. No firmware values changed.");}catch(Exception ex){operation.Complete("Export failed: "+ex.Message);throw;}
    });
    private void Open_Click(object sender,RoutedEventArgs e)=>Run(()=>{var dlg=new Microsoft.Win32.OpenFileDialog{Filter="NVRAM text|*.txt"};if(dlg.ShowDialog()==true&&ConfirmDiscard()){offlineDocument=true;ImportOfflineFile(dlg.FileName);}});
    public void LoadPreview(byte[] bytes){offlineDocument=true;SetDocument(new(bytes),"Saved export · preview, not live state");}
    private void SetDocument(BiosDocument value,string source)
    {
        document=value;undo.Clear();SourceLabel.Text=source+" · "+value.Settings.Count.ToString("N0")+" settings";
        Requirements.Text=string.Join('\n',value.Prerequisites().Select(p=>$"{p.Name}: {p.Observed}. {p.State}. {p.Instructions}"));
        EmptyState.Visibility=Visibility.Collapsed;Refresh();BuildFans();BuildProfiles();Report("Edit values in the list. Select a row for setting details.");
    }
    private void Search_Changed(object sender,TextChangedEventArgs e){if(SearchHint!=null)SearchHint.Visibility=Search.Text.Length==0?Visibility.Visible:Visibility.Collapsed;Refresh();}
    private void Filter_Changed(object sender,RoutedEventArgs e)=>Refresh();
    private void Refresh()
    {
        if(document==null||SettingsGrid==null)return;
        var selected=SettingsGrid.SelectedItem;
        SettingsGrid.ItemsSource=document.Settings.Where(s=>(s.Name.Contains(Search.Text,StringComparison.OrdinalIgnoreCase)||s.Token.Equals(Search.Text,StringComparison.OrdinalIgnoreCase))&&(ChangedOnly.IsChecked!=true||s.Changed)).ToArray();
        if(selected!=null)SettingsGrid.SelectedItem=selected;
        int changes=document.Settings.Count(s=>s.Changed);ApplyButton.IsEnabled=!busy&&changes>0;
        ApplyButton.Content=changes>0?$"Review {changes} change{(changes==1?"":"s")}":"Review changes";
    }
    private void Remember()=>undo.Push(document!.Settings.Where(s=>s.Changed).ToDictionary(s=>s.Id,s=>s.Proposed));
    private void Stage(BiosSetting setting,string value)
    {
        if(document==null||busy||value==setting.Proposed)return;
        Run(()=>{var previous=document.Settings.Where(s=>s.Changed).ToDictionary(s=>s.Id,s=>s.Proposed);document.Set(setting,value);undo.Push(previous);UpdateChangeCount();Report("Change staged. Review changes before applying to firmware.");});
    }
    private void Value_Changed(object sender,SelectionChangedEventArgs e)
    {
        // Row virtualization and profile loads also update selection; only user input stages edits.
        if(sender is ComboBox {DataContext:BiosSetting s,SelectedValue:string value} box && box.IsKeyboardFocusWithin){Stage(s,value);box.GetBindingExpression(ComboBox.SelectedValueProperty)?.UpdateTarget();}
    }
    private void Number_Commit(object sender,System.Windows.Input.KeyboardFocusChangedEventArgs e)
    {
        if(sender is TextBox {DataContext:BiosSetting s} box){Stage(s,box.Text.Trim());box.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();}
    }
    private void Number_KeyDown(object sender,System.Windows.Input.KeyEventArgs e)
    {
        if(e.Key==System.Windows.Input.Key.Enter&&sender is TextBox {DataContext:BiosSetting s} box){Stage(s,box.Text.Trim());box.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();e.Handled=true;}
    }
    private void UpdateChangeCount()
    {
        int changes=document?.Settings.Count(s=>s.Changed)??0;
        ApplyButton.IsEnabled=!busy&&changes>0;ApplyButton.Content=changes>0?$"Review {changes} change{(changes==1?"":"s")}":"Review changes";
    }
    private void Undo_Click(object sender,RoutedEventArgs e)=>Run(()=>{if(document==null||undo.Count==0)return;document.Revert();foreach(var(id,v)in undo.Pop())document.Set(document.Settings.Single(s=>s.Id==id),v);Refresh();Report("Last edit undone.");});
    private void Revert_Click(object sender,RoutedEventArgs e)=>Run(()=>{Require();Remember();document!.Revert();Refresh();Report("All pending edits reverted.");});
    private void Export_Click(object sender,RoutedEventArgs e)=>Run(()=>{Require();var dlg=new Microsoft.Win32.SaveFileDialog{Filter="NVRAM text|*.txt",FileName="nvram-edited.txt"};if(dlg.ShowDialog()==true){File.WriteAllBytes(dlg.FileName,document!.Export());Report("Edited export saved. Firmware unchanged.");}});
    private void SaveProfile_Click(object sender,RoutedEventArgs e)=>Run(()=>{Require();var dlg=new Microsoft.Win32.SaveFileDialog{Filter="BIOS profile|*.json",FileName="Profile 1.json"};if(dlg.ShowDialog()==true){File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(document!.Profile(Path.GetFileNameWithoutExtension(dlg.FileName)),new JsonSerializerOptions{WriteIndented=true}));Report("Profile saved.");}});
    private void LoadProfile_Click(object sender,RoutedEventArgs e)=>Run(()=>{Require();var dlg=new Microsoft.Win32.OpenFileDialog{Filter="BIOS profile|*.json"};if(dlg.ShowDialog()!=true)return;var p=JsonSerializer.Deserialize<BiosProfile>(File.ReadAllText(dlg.FileName))??throw new InvalidDataException("Invalid profile.");Remember();document!.LoadProfile(p);Refresh();BuildFans();Report("Legacy changes-only profile loaded for review: "+p.Name);});
    private void Recommendations_Click(object sender,RoutedEventArgs e)=>Run(()=>
    {
        Require();var rows=BiosRecommendations.Resolve(document!,detectedBoard);var grid=new DataGrid{ItemsSource=rows,AutoGenerateColumns=false,CanUserAddRows=false,IsReadOnly=false,EnableRowVirtualization=true};
        grid.Columns.Add(new DataGridCheckBoxColumn{Header="Select",Binding=new System.Windows.Data.Binding("Selected"),Width=50});
        foreach(var name in new[]{"Name","Current","Proposed","Risk","Status"})grid.Columns.Add(new DataGridTextColumn{Header=name,Binding=new System.Windows.Data.Binding(name),IsReadOnly=true,Width=name is "Name" or "Status"?new DataGridLength(1,DataGridLengthUnitType.Star):DataGridLength.Auto});
        var layout=new DockPanel{Margin=new Thickness(16)};var notes=new TextBlock{Text=$"{BiosRecommendations.SourceFor(detectedBoard).Name} · {rows.Count} entries · {detectedBoard?.CpuBrand??"CPU unknown"}\nChoose individual changes. Unavailable, ambiguous and protected entries are excluded. Nothing imports until you review and Apply.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,12)};DockPanel.SetDock(notes,Dock.Top);layout.Children.Add(notes);
        var footer=new StackPanel{Margin=new Thickness(0,12,0,0)};var detail=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,8)};footer.Children.Add(detail);grid.SelectionChanged+=(_,_)=>detail.Text=(grid.SelectedItem as BiosSuggestion)?.Explanation??"";
        var consent=new CheckBox{Content="I reviewed each selected experimental change",Margin=new Thickness(0,0,0,8)};footer.Children.Add(consent);var stage=new Button{Content="Stage selected changes",HorizontalAlignment=HorizontalAlignment.Right};footer.Children.Add(stage);DockPanel.SetDock(footer,Dock.Bottom);layout.Children.Add(footer);layout.Children.Add(grid);
        var window=Dialog("Review Rion BIOS profile",layout);stage.Click+=(_,_)=>{try{grid.CommitEdit();grid.CommitEdit();Remember();BiosRecommendations.Stage(document!,detectedBoard,rows,consent.IsChecked==true);Refresh();BuildFans();Report("Selected draft changes staged for review; firmware unchanged.");window.Close();}catch(Exception ex){detail.Text=ex.Message;}};window.ShowDialog();
    });
    private Window Dialog(string title,object content)
    {
        var window=new Window{Title=title,Owner=Window.GetWindow(this),Width=1000,Height=660,MinWidth=600,MinHeight=400,Content=content,WindowStartupLocation=WindowStartupLocation.CenterOwner,UseLayoutRounding=true};window.SetResourceReference(FontFamilyProperty,"AppFont");window.SetResourceReference(BackgroundProperty,"Bg1");window.SetResourceReference(ForegroundProperty,"Text");return window;
    }
    private void Compare_Click(object sender,RoutedEventArgs e)=>Run(()=>
    {
        Require();var pick=new Microsoft.Win32.OpenFileDialog{Filter="NVRAM export|*.txt"};if(pick.ShowDialog()!=true)return;
        var other=new BiosDocument(File.ReadAllBytes(pick.FileName));var left=new BiosDocument(document!.Export());bool swapped=false;
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false,EnableRowVirtualization=true};var layout=new DockPanel{Margin=new Thickness(16)};var top=new StackPanel();var title=new TextBlock{TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,8)};top.Children.Add(title);var buttons=new WrapPanel();top.Children.Add(buttons);
        void RefreshComparison(){var differences=left.Compare(other);title.Text=$"{differences.Count} differences · {(swapped?"Other export → edited values":"Edited values → other export")}\n"+(left.SchemaHash==other.SchemaHash?"Same exported schema; codes are compared.":"Different schema or firmware. Comparison only; profile export blocked.");grid.ItemsSource=differences;}
        var swap=new Button{Content="Swap",Margin=new Thickness(0,0,8,8)};swap.Click+=(_,_)=>{(left,other)=(other,left);swapped=!swapped;RefreshComparison();};buttons.Children.Add(swap);
        var save=new Button{Content="Save diff as profile",Margin=new Thickness(0,0,8,8)};save.Click+=(_,_)=>Run(()=>{if(left.SchemaHash!=other.SchemaHash)throw new InvalidDataException("Diff profiles require identical firmware schemas.");var staged=new BiosDocument(left.Original);foreach(var difference in left.Compare(other)){if(difference.State!="Changed")throw new InvalidDataException("Added, removed or ambiguous fields cannot become a profile.");var target=other.Settings.Single(s=>s.Id==difference.Identity);staged.Set(staged.Settings.Single(s=>s.Id==difference.Identity),target.Current);}var output=new Microsoft.Win32.SaveFileDialog{Filter="BIOS profile|*.json",FileName="Compared changes.json"};if(output.ShowDialog()==true)File.WriteAllText(output.FileName,JsonSerializer.Serialize(staged.Profile(Path.GetFileNameWithoutExtension(output.FileName)),new JsonSerializerOptions{WriteIndented=true}));});buttons.Children.Add(save);
        DockPanel.SetDock(top,Dock.Top);layout.Children.Add(top);layout.Children.Add(grid);RefreshComparison();Dialog("Compare BIOS exports",layout).ShowDialog();
    });
    private void Documentation_Click(object sender,RoutedEventArgs e)=>Process.Start(new ProcessStartInfo(BiosOperations.Documentation){UseShellExecute=true});
    private void Menu_Click(object sender,RoutedEventArgs e){var b=(Button)sender;b.ContextMenu.PlacementTarget=b;b.ContextMenu.Placement=PlacementMode.Bottom;b.ContextMenu.IsOpen=true;}
    private async void Apply_Click(object sender,RoutedEventArgs e)=>await RunAsync(async()=>
    {
        Require();
        if(!document!.IsLiveScan){var staged=document.Profile("offline changes");var fresh=await BiosOperations.ScanAsync();BiosStore.Reconcile(fresh,staged);offlineDocument=false;SetDocument(fresh,"Fresh scan · reconciled offline edits");}
        var changed=document!.Settings.Where(s=>s.Changed).ToArray();if(changed.Length==0)return;
        var preview=string.Join('\n',changed.Select(s=>$"{s.Name} [{s.Token}/{s.Offset}]: {s.CurrentLabel} → {s.ProposedLabel}"));
        if(MessageBox.Show(preview+"\n\nRun Import.bat to write these values? Original exports will be retained; firmware recovery is not guaranteed.","Review BIOS changes",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        var operation=new BiosOperationWindow(Window.GetWindow(this),preview);operation.Show();
        try{Report("Importing reviewed changes…");var result=await BiosOperations.ImportAsync(document,operation.Log,operation.Cancellation);await workspace.AcceptAsync(result.Actual,result.Verified?"Verified import":"Import readback · partial/unverified");SetDocument(result.Actual,workspace.Source);Report(result.Message);operation.Complete(result.Message);await PromptRestartAsync(result);}catch(Exception ex){operation.Complete("Operation failed or incomplete: "+ex.Message);throw;}
    });
}
