using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace RionHub.Features;

public sealed record BiosSavedScan(string BoardKey, DateTime TimestampUtc, byte[] Bytes);
public sealed record BiosSavedProfile(string Name, string BoardKey, DateTime TimestampUtc, byte[] Bytes)
{
    public override string ToString()=>Name;
    public int SchemaVersion {get;init;}=1;
    public string FirmwareSchema {get;init;}="";
}
public sealed class BiosStore
{
    readonly string root;
    public BiosStore(string directory){root=directory;}
    public static string BoardKey(MotherboardInfo board)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(board.Manufacturer+"|"+board.Model+"|"+board.Firmware+"|"+board.CpuVendor)));
    string Folder(string board){if(board.Length!=64||board.Any(c=>!Uri.IsHexDigit(c)))throw new InvalidDataException("Invalid board identity.");return Path.Combine(root,board);}
    public BiosSavedScan? LoadScan(string board){var path=Path.Combine(Folder(board),"latest.json");if(!File.Exists(path))return null;var scan=JsonSerializer.Deserialize<BiosSavedScan>(File.ReadAllText(path));if(scan?.BoardKey!=board)throw new InvalidDataException("Cached scan identity differs.");_ = new BiosDocument(scan.Bytes);return scan;}
    public void SaveScan(string board,BiosDocument document){if(!document.IsLiveScan)throw new InvalidOperationException("Only live exports can replace the scan cache.");Atomic(Path.Combine(Folder(board),"latest.json"),new BiosSavedScan(board,DateTime.UtcNow,document.Original));}
    public IReadOnlyList<BiosSavedProfile?> Profiles(string board){var path=Path.Combine(Folder(board),"profiles.json");return File.Exists(path)?JsonSerializer.Deserialize<List<BiosSavedProfile?>>(File.ReadAllText(path))??new():new BiosSavedProfile?[4];}
    public void SaveProfiles(string board,IReadOnlyList<BiosSavedProfile?> profiles)
    {
        if(profiles.Any(p=>p!=null&&p.BoardKey!=board))throw new InvalidDataException("Profile board identity differs.");
        Atomic(Path.Combine(Folder(board),"profiles.json"),profiles.Select(p=>p==null?null:p with {FirmwareSchema=new BiosDocument(p.Bytes).SchemaHash}).ToArray());
    }
    public static void Reconcile(BiosDocument fresh,BiosProfile staged)
    {
        if(staged.SchemaHash!=fresh.SchemaHash)throw new InvalidDataException("This export belongs to different firmware. Offline changes were preserved.");
        foreach(var pair in staged.Values)
        {
            var current=fresh.Settings.SingleOrDefault(s=>s.Id==pair.Key);
            if(current==null||!staged.OriginalValues.TryGetValue(pair.Key,out var original)||current.Current!=original)
                throw new InvalidDataException("Firmware values changed since this document was exported. Review a fresh scan before applying.");
        }
        fresh.LoadProfile(staged);
    }
    public static void StageSnapshot(BiosDocument current,BiosSavedProfile profile,string board)
    {
        var saved=new BiosDocument(profile.Bytes);
        if(profile.SchemaVersion!=1||profile.BoardKey!=board||saved.SchemaHash!=current.SchemaHash||profile.FirmwareSchema.Length>0&&profile.FirmwareSchema!=saved.SchemaHash)throw new InvalidDataException("Profile belongs to a different motherboard or firmware schema.");
        var validation=new BiosDocument(current.Original);
        foreach(var setting in saved.Settings){var target=validation.Settings.Single(s=>s.Id==setting.Id);if(target.Editable)validation.Set(target,setting.Current);}
        current.Revert();foreach(var value in validation.Settings.Where(s=>s.Changed))current.Set(current.Settings.Single(s=>s.Id==value.Id),value.Proposed);
    }
    static void Atomic<T>(string path,T value){Directory.CreateDirectory(Path.GetDirectoryName(path)!);var temporary=path+"."+Guid.NewGuid().ToString("N")+".tmp";File.WriteAllText(temporary,JsonSerializer.Serialize(value));File.Move(temporary,path,true);}
}

public sealed class BiosWorkspace
{
    public static BiosWorkspace Instance {get;}=new();
    public BiosStore Store {get;}
    readonly Func<Task<MotherboardInfo>> detect;
    readonly Func<Task<BiosDocument>> scan;
    public BiosWorkspace():this(new BiosStore(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"RionWin11","BIOS")),MotherboardInfo.DetectAsync,()=>BiosOperations.ScanAsync()){}
    public BiosWorkspace(BiosStore store,Func<Task<MotherboardInfo>> detectBoard,Func<Task<BiosDocument>> export){Store=store;detect=detectBoard;scan=export;}
    public DateTime? ScanTimestampUtc {get;private set;}
    public bool IsStale {get;private set;}=true;
    public MotherboardInfo? Board {get;private set;}
    public BiosDocument? Latest {get;private set;}
    public string Source {get;private set;}="No BIOS scan loaded";
    public event Action? Changed;
    Task? initialization;
    public Task InitializeAsync()=>initialization??=InitializeCore();
    async Task InitializeCore()
    {
        try
        {
            Board=await detect();
            var cached=await Task.Run(()=>Store.LoadScan(BiosStore.BoardKey(Board)));
            if(cached!=null){ScanTimestampUtc=cached.TimestampUtc;Latest=new(cached.Bytes);Source=$"Saved scan · {cached.TimestampUtc.ToLocalTime():g} · refreshing";Changed?.Invoke();}
            await RefreshAsync();
        }
        catch(Exception e){IsStale=true;Source=(Latest==null?"BIOS scan unavailable":"Saved scan · "+ScanTimestampUtc?.ToLocalTime().ToString("g")+" · stale")+": "+e.Message;Changed?.Invoke();}
    }
    public async Task RefreshAsync()
    {
        Board??=await detect();
        var fresh=await scan();await AcceptAsync(fresh,"Fresh scan");
    }
    public async Task AcceptAsync(BiosDocument document,string source)
    {
        Board??=await detect();
        await Task.Run(()=>Store.SaveScan(BiosStore.BoardKey(Board),document));Latest=document;IsStale=false;ScanTimestampUtc=DateTime.UtcNow;Source=source+" · "+DateTime.Now.ToString("g");Changed?.Invoke();
    }
}
