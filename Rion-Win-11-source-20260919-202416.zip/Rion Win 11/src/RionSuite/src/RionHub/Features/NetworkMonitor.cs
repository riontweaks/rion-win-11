using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;

namespace RionHub.Features;

public sealed record AdapterInfo(string Id,string Name,string Description,string State,string Type,long LinkMbps)
{
    public override string ToString()=>Name+" — "+Description+" ("+State+")";
}
public sealed record TrafficSample(DateTime Time,double ReceiveMbps,double SendMbps,long ReceivedBytes,long SentBytes,long Errors,long Discards);
public sealed record WifiInfo(string Ssid,uint SignalQuality,uint ReceiveKbps,uint TransmitKbps);

public sealed class TrafficMeter
{
    private long? previousRx, previousTx; private double previousSeconds;
    public (double Receive,double Send) Update(long rx,long tx,double seconds)
    {
        double delta=seconds-previousSeconds;
        var result=previousRx.HasValue && delta>0 && rx>=previousRx && tx>=previousTx
            ? ((rx-previousRx.Value)*8/delta/1_000_000,(tx-previousTx!.Value)*8/delta/1_000_000) : (0d,0d);
        previousRx=rx;previousTx=tx;previousSeconds=seconds;return result;
    }
}
public static class NetworkMonitor
{
    public static AdapterInfo[] Adapters()=>NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.NetworkInterfaceType!=NetworkInterfaceType.Loopback)
        .OrderBy(n=>n.NetworkInterfaceType==NetworkInterfaceType.Wireless80211?0:1)
        .Select(n=>new AdapterInfo(n.Id,n.Name,n.Description,n.OperationalStatus.ToString(),n.NetworkInterfaceType.ToString(),n.Speed/1_000_000)).ToArray();
    public static TrafficSample Sample(string id,TrafficMeter meter,Stopwatch clock)
    {
        var adapter=NetworkInterface.GetAllNetworkInterfaces().SingleOrDefault(n=>n.Id==id)??throw new InvalidOperationException("Selected adapter disconnected or was removed.");
        var stats=adapter.GetIPStatistics();var rate=meter.Update(stats.BytesReceived,stats.BytesSent,clock.Elapsed.TotalSeconds);
        return new(DateTime.Now,rate.Receive,rate.Send,stats.BytesReceived,stats.BytesSent,stats.IncomingPacketsWithErrors+stats.OutgoingPacketsWithErrors,stats.IncomingPacketsDiscarded+stats.OutgoingPacketsDiscarded);
    }
    public static IPAddress? Gateway(string id)=>NetworkInterface.GetAllNetworkInterfaces().Single(n=>n.Id==id).GetIPProperties().GatewayAddresses.Select(g=>g.Address).FirstOrDefault(a=>a.AddressFamily==AddressFamily.InterNetwork);
    public static string ActualInterface(IPAddress remote)
    {
        using var socket=new Socket(remote.AddressFamily,SocketType.Dgram,ProtocolType.Udp);
        socket.Connect(new IPEndPoint(remote,33434)); // Determines the route; does not send payload.
        var local=((IPEndPoint)socket.LocalEndPoint!).Address;
        return NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(n=>n.GetIPProperties().UnicastAddresses.Any(a=>a.Address.Equals(local)))?.Id??"Unknown";
    }
    public static string RateWifi(uint? signal,IReadOnlyList<long?> gatewaySamples)
    {
        if(signal==null||gatewaySamples.Count<10)return "Insufficient data — requires Wi-Fi signal and 10 gateway probes.";
        var successful=gatewaySamples.Where(x=>x.HasValue).Select(x=>x!.Value).Order().ToArray();
        if(successful.Length==0)return "Insufficient data — gateway may block ICMP.";
        double loss=1-successful.Length/(double)gatewaySamples.Count;
        double median=successful[successful.Length/2];
        string rating=signal>=80&&loss==0&&median<10?"Excellent":signal>=60&&loss<=.02&&median<20?"Good":signal>=40&&loss<=.1?"Fair":"Poor";
        return $"{rating} (Rion heuristic): signal {signal}%, gateway median {median} ms, timeout rate {loss:P0}; {gatewaySamples.Count} probes. Internet-path quality is separate.";
    }
    public static WifiInfo? Wifi(string id)
    {
        if(!Guid.TryParse(id,out var guid))return null;
        uint result=WlanOpenHandle(2,IntPtr.Zero,out _,out var client);if(result!=0)return null;
        IntPtr data=IntPtr.Zero;
        try
        {
            result=WlanQueryInterface(client,ref guid,7,IntPtr.Zero,out int size,out data,out _);
            if(result!=0||size<Marshal.SizeOf<Connection>())return null;
            var connection=Marshal.PtrToStructure<Connection>(data);
            if(connection.State!=1)return null;
            var a=connection.Association;
            return new(System.Text.Encoding.UTF8.GetString(a.Ssid.Bytes,0,(int)Math.Min(a.Ssid.Length,32)),a.Signal,a.Rx,a.Tx);
        }
        finally {if(data!=IntPtr.Zero)WlanFreeMemory(data);WlanCloseHandle(client,IntPtr.Zero);}
    }
    [StructLayout(LayoutKind.Sequential)] private struct Ssid {public uint Length;[MarshalAs(UnmanagedType.ByValArray,SizeConst=32)]public byte[] Bytes;}
    [StructLayout(LayoutKind.Sequential)] private struct Association {public Ssid Ssid;public int BssType;[MarshalAs(UnmanagedType.ByValArray,SizeConst=6)]public byte[] Bssid;public int PhyType;public uint PhyIndex,Signal,Rx,Tx;}
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]private struct Connection {public int State,Mode;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=256)]public string Profile;public Association Association;public int SecurityEnabled,OneXEnabled,Auth,Cipher;}
    [DllImport("wlanapi.dll")]private static extern uint WlanOpenHandle(uint version,IntPtr reserved,out uint negotiated,out IntPtr handle);
    [DllImport("wlanapi.dll")]private static extern uint WlanCloseHandle(IntPtr handle,IntPtr reserved);
    [DllImport("wlanapi.dll")]private static extern uint WlanQueryInterface(IntPtr handle,ref Guid guid,int opcode,IntPtr reserved,out int size,out IntPtr data,out int valueType);
    [DllImport("wlanapi.dll")]private static extern void WlanFreeMemory(IntPtr pointer);
}
