using System.Net;

namespace RionHub.Features.Networking;

// Progress<T> posts asynchronously. A completed or replaced run must never repaint the UI.
public sealed class BenchmarkSession
{
    private bool active=true;
    public void Complete()=>active=false;
    public void Update(Action update){if(active)update();}
}

public static class BenchmarkProxy
{
    public static Uri? Resolve(IWebProxy proxy,Uri endpoint)
    {
        // HttpWindowsProxy can return IsBypassed=false and GetProxy=null for a direct route.
        if(proxy.IsBypassed(endpoint))return null;
        var resolved=proxy.GetProxy(endpoint);
        return resolved==null||resolved==endpoint?null:resolved;
    }
}
