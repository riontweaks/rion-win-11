namespace RionHub.Features.Networking;

public sealed record ComparisonMetric(string Metric,string Baseline,string Candidate,string Result);
public sealed record ComparisonResult(string Outcome,string Detail,IReadOnlyList<ComparisonMetric> Metrics);
public static class BenchmarkComparison
{
    public static ComparisonResult Compare(IReadOnlyList<BenchmarkReport> baseline,IReadOnlyList<BenchmarkReport> candidate)
    {
        var all=baseline.Concat(candidate).ToArray();
        ComparisonResult Fail(string detail)=>new("Insufficient evidence",detail,[]);
        if(baseline.Count<3||candidate.Count<3)return Fail("Select at least three independent completed runs for each configuration. A single before/after run cannot establish a reliable change.");
        if(all.Select(r=>r.Id).Distinct().Count()!=all.Length)return Fail("A report cannot appear more than once or on both sides.");
        if(all.Any(r=>!r.Comparable))return Fail("Every run must complete on an unchanged adapter and route.");
        var first=all[0];
        foreach(var report in all)
        {
            var a=first.Before!;var b=report.Before!;
            if(a.RouteIdentity!=b.RouteIdentity||a.Driver!=b.Driver||a.Ssid!=b.Ssid||a.Metered!=b.Metered||a.Proxy!=b.Proxy||first.Options.Endpoint!=report.Options.Endpoint||first.Options.Mode!=report.Options.Mode||first.Options.Streams!=report.Options.Streams||first.Options.PayloadBudgetBytes!=report.Options.PayloadBudgetBytes||first.Options.PhaseSeconds!=report.Options.PhaseSeconds)return Fail("Adapter, route, driver, Wi-Fi network, cost, proxy or test parameters differ. These runs are not comparable.");
            if(b.SignalQuality.HasValue&&a.SignalQuality.HasValue&&Math.Abs((int)b.SignalQuality.Value-(int)a.SignalQuality.Value)>10)return Fail("Wi-Fi signal varies by more than ten percentage points across runs.");
            if(b.Settings.Count!=report.After!.Settings.Count||b.Driver!=report.After.Driver||b.Settings.Any(kv=>!report.After.Settings.TryGetValue(kv.Key,out var after)||after!=kv.Value))return Fail("Settings or driver changed during at least one run.");
        }
        bool SameConfiguration(BenchmarkReport a,BenchmarkReport b)=>a.Before!.Settings.Count==b.Before!.Settings.Count&&a.Before.Settings.All(kv=>b.Before.Settings.TryGetValue(kv.Key,out var value)&&value==kv.Value);
        if(baseline.Any(r=>!SameConfiguration(baseline[0],r))||candidate.Any(r=>!SameConfiguration(candidate[0],r)))return Fail("Settings vary within a configuration group. Compare only repeated runs of the same baseline and candidate.");
        var differences=baseline[0].Before!.Settings.Keys.Union(candidate[0].Before!.Settings.Keys).Count(key=>baseline[0].Before!.Settings.GetValueOrDefault(key)!=candidate[0].Before!.Settings.GetValueOrDefault(key));
        if(differences>1)return Fail("More than one recorded setting differs between baseline and candidate. Isolate one change before comparison.");
        var rows=new List<ComparisonMetric>();int better=0,worse=0;
        void Metric(string name,Func<BenchmarkReport,double?> select,bool higher,string unit)
        {
            var a=baseline.Select(select).ToArray();var b=candidate.Select(select).ToArray();
            if(a.Any(x=>!x.HasValue)||b.Any(x=>!x.HasValue)){rows.Add(new(name,"—","—","Insufficient samples"));return;}
            double[] av=a.Select(x=>x!.Value).Order().ToArray(),bv=b.Select(x=>x!.Value).Order().ToArray();
            double median(double[] v)=>v.Length%2==0?(v[v.Length/2-1]+v[v.Length/2])/2:v[v.Length/2];
            double am=median(av),bm=median(bv);bool separated=bv.Min()>av.Max()||bv.Max()<av.Min();bool meaningful=Math.Abs(bm-am)>Math.Max(unit=="ms"?1:.5,Math.Abs(am)*.05);
            string outcome="No clear difference";
            if(separated&&meaningful){bool improved=higher?bm>am:bm<am;outcome=improved?"Improvement observed":"Regression observed";if(improved)better++;else worse++;}
            rows.Add(new(name,$"{am:F2} {unit} ({av.Min():F2}–{av.Max():F2})",$"{bm:F2} {unit} ({bv.Min():F2}–{bv.Max():F2})",outcome));
        }
        Metric("Download",r=>r.Transfers.FirstOrDefault(t=>t.Direction=="Download")?.Mbps,true,"Mbps");
        Metric("Upload",r=>r.Transfers.FirstOrDefault(t=>t.Direction=="Upload")?.Mbps,true,"Mbps");
        foreach(string phase in new[]{"Unloaded","Download","Upload"})Metric(phase+" remote RTT",r=>r.Latency(phase).Successful>=5?r.Latency(phase).MedianMs:null,false,"ms");
        string outcome=worse>0?"Regression observed":better>0?"Improvement observed":"No clear difference";
        return new(outcome,$"{baseline.Count} baseline / {candidate.Count} candidate runs; median and full run-to-run range. {differences} recorded setting difference(s). A difference requires non-overlapping ranges and more than 5% (at least 1 ms / 0.5 Mbps). This descriptive screen does not prove causation or replace an independent confirmation run. Background traffic and endpoint load remain confounders. No settings are changed or selected automatically.",rows);
    }
}
