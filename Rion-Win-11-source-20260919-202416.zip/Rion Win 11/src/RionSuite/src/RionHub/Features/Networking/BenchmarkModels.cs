using System.IO;
using System.Text.Json;

namespace RionHub.Features.Networking;

public sealed record BenchmarkOptions(string Mode, string AdapterId, string Endpoint, long PayloadBudgetBytes, int PhaseSeconds, int BaselineSamples, int Streams)
{
    public static BenchmarkOptions Quick(string adapter) => new("Quick",adapter,"https://speed.cloudflare.com",64L*1024*1024,10,10,1);
    public static BenchmarkOptions Detailed(string adapter) => new("Detailed",adapter,"https://speed.cloudflare.com",256L*1024*1024,20,30,4);
    public Uri Validate()
    {
        if(Mode is not ("Quick" or "Detailed") || string.IsNullOrWhiteSpace(AdapterId))throw new ArgumentException("Choose a benchmark mode and adapter.");
        if(PayloadBudgetBytes<2*1024*1024 || PayloadBudgetBytes>1024L*1024*1024 || PhaseSeconds is <1 or >60 || BaselineSamples is <2 or >60 || Streams is <1 or >4)throw new ArgumentException("Benchmark limits are outside the supported range.");
        if(!Uri.TryCreate(Endpoint,UriKind.Absolute,out var uri)||uri.UserInfo.Length!=0||uri.Query.Length!=0||uri.Fragment.Length!=0||uri.AbsolutePath!="/" || (uri.Scheme!="https"&&!(uri.Scheme=="http"&&uri.IsLoopback)))throw new ArgumentException("Use an HTTPS measurement server origin. HTTP is supported only for a local loopback test server.");
        return uri;
    }
}
public sealed record NetworkContext(string AdapterId,string Name,string Description,string Type,string Driver,string LocalAddress,string RemoteAddress,string Gateway,string RouteIdentity,string Metered,string Proxy,string? Ssid,uint? SignalQuality,long LinkMbps,long ReceivedBytes,long SentBytes,long Errors,long Discards,Dictionary<string,string> Settings);
public sealed record AuxiliaryTiming(string Name,double? Milliseconds,string Detail);
public sealed record BenchmarkPoint(string Phase,double ElapsedSeconds,double? GatewayMs,double? RemoteMs,double? HttpResponseMs,double ReceiveMbps,double SendMbps,double? CpuPercent,uint? SignalQuality);
public sealed record BenchmarkProgress(string Phase,int CompletedSamples,int TargetSamples,long ReceivedPayload,long SentPayload,long PayloadBudget,double ElapsedSeconds,double ReceiveMbps,double SendMbps,string Detail);
public sealed record LatencySummary(int Attempts,int Successful,double? MedianMs,double? P95Ms,double? JitterMs,double TimeoutRate)
{
    public static LatencySummary From(IEnumerable<double?> source)
    {
        var raw=source.ToArray();var valid=raw.Where(v=>v.HasValue).Select(v=>v!.Value).Order().ToArray();
        var differences=raw.Zip(raw.Skip(1),(a,b)=>a.HasValue&&b.HasValue?(double?)Math.Abs(a.Value-b.Value):null).Where(v=>v.HasValue).Select(v=>v!.Value).ToArray();
        double? percentile(double fraction)=>valid.Length==0?null:valid[(int)Math.Ceiling(fraction*valid.Length)-1];
        return new(raw.Length,valid.Length,percentile(.5),valid.Length>=20?percentile(.95):null,differences.Length>0?differences.Average():null,raw.Length==0?0:1-valid.Length/(double)raw.Length);
    }
}
public sealed record TransferSummary(string Direction,long PayloadBytes,long ConfirmedBytes,double Seconds,double? Mbps,int CompletedRequests,int Streams,string Limitation);
public sealed class BenchmarkReport
{
    public int SchemaVersion {get;init;}=1;
    public string Id {get;init;}=Guid.NewGuid().ToString("N");
    public DateTime StartedUtc {get;init;}=DateTime.UtcNow;
    public DateTime FinishedUtc {get;set;}
    public BenchmarkOptions Options {get;init;}=null!;
    public NetworkContext? Before {get;set;}
    public NetworkContext? After {get;set;}
    public string Status {get;set;}="Running";
    public string Detail {get;set;}="";
    public string Protocol {get;init;}="HTTPS application payload throughput; ICMP round-trip probes; HTTP response headers";
    public List<AuxiliaryTiming> Timings {get;set;}=[];
    public List<BenchmarkPoint> Points {get;init;}=[];
    public List<TransferSummary> Transfers {get;init;}=[];
    public long ReceivedPayload {get;set;}
    public long SentPayload {get;set;}
    public double ElapsedSeconds {get;set;}
    public bool Comparable=>Status=="Completed"&&Before!=null&&After!=null&&Before.RouteIdentity==After.RouteIdentity;
    public LatencySummary Latency(string phase, bool gateway=false)=>LatencySummary.From(Points.Where(p=>p.Phase==phase).Select(p=>gateway?p.GatewayMs:p.RemoteMs));
}
public static class BenchmarkStore
{
    public static string DirectoryPath=>Path.Combine(UtilityPackage.DataRoot,"NetworkBenchmarks");
    public static readonly JsonSerializerOptions JsonOptions=new(){WriteIndented=true};
    public static string Save(BenchmarkReport report,string? directory=null)
    {
        Validate(report);
        directory??=DirectoryPath;Directory.CreateDirectory(directory);
        var path=Path.Combine(directory,report.Id+".json");var temporary=path+".tmp";
        File.WriteAllText(temporary,JsonSerializer.Serialize(report,JsonOptions));File.Move(temporary,path,true);return path;
    }
    public static BenchmarkReport Load(string path)
    {
        if(new FileInfo(path).Length>16*1024*1024)throw new InvalidDataException("Report exceeds 16 MiB.");
        var report=JsonSerializer.Deserialize<BenchmarkReport>(File.ReadAllText(path))??throw new InvalidDataException("Invalid report.");
        Validate(report);return report;
    }
    private static void Validate(BenchmarkReport report)
    {
        if(report.SchemaVersion!=1||!Guid.TryParseExact(report.Id,"N",out _)||report.Points==null||report.Transfers==null||report.Options==null||report.Points.Count>10000||report.Transfers.Count>2)throw new InvalidDataException("Unsupported or invalid report schema.");
        report.Options.Validate();
        if(report.ReceivedPayload<0||report.SentPayload<0||report.ReceivedPayload>report.Options.PayloadBudgetBytes/2||report.SentPayload>report.Options.PayloadBudgetBytes/2)throw new InvalidDataException("Report payload exceeds its declared limits.");
        if(!double.IsFinite(report.ElapsedSeconds)||report.ElapsedSeconds<0)throw new InvalidDataException("Invalid elapsed time.");
    }
}
public sealed class PayloadBudget(long limit)
{
    private long reserved;
    public long Reserved=>Interlocked.Read(ref reserved);
    public long Reserve(long maximum)
    {
        if(maximum<=0)throw new ArgumentOutOfRangeException(nameof(maximum));
        while(true){long current=Interlocked.Read(ref reserved),take=Math.Min(maximum,limit-current);if(take<=0)return 0;if(Interlocked.CompareExchange(ref reserved,current+take,current)==current)return take;}
    }
}
