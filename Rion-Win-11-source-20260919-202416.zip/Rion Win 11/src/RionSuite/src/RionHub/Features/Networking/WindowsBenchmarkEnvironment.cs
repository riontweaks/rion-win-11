using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using RadeonSoftwareSlimmer.Optimize;
using RionHub.Modules.Tools.Network;

namespace RionHub.Features.Networking;

public sealed class WindowsBenchmarkEnvironment : IBenchmarkEnvironment
{
    private readonly TrafficMeter meter=new();
    private readonly Stopwatch clock=Stopwatch.StartNew();
    private readonly CpuMeter cpu=new();
    private IPAddress? resolved;
    private static NetworkInterface Adapter(string id)=>NetworkInterface.GetAllNetworkInterfaces().SingleOrDefault(n=>n.Id.Equals(id,StringComparison.OrdinalIgnoreCase))??throw new IOException("Selected adapter is no longer present.");
    private static IPAddress RouteAddress(IPAddress remote)
    {
        using var socket=new Socket(remote.AddressFamily,SocketType.Dgram,ProtocolType.Udp);
        socket.Connect(new IPEndPoint(remote,33434)); // Route lookup; no datagram is sent.
        return ((IPEndPoint)socket.LocalEndPoint!).Address;
    }
    private static string Identity(NetworkInterface adapter,IPAddress local,IPAddress remote,string gateway)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{adapter.Id}|{adapter.OperationalStatus}|{local}|{remote}|{gateway}")));
    public async Task<NetworkContext> InspectAsync(BenchmarkOptions options,CancellationToken cancellation)
    {
        var endpoint=options.Validate();var adapter=Adapter(options.AdapterId);
        if(adapter.OperationalStatus!=OperationalStatus.Up)throw new IOException("The selected adapter is not connected.");
        if(BenchmarkProxy.Resolve(HttpClient.DefaultProxy,endpoint)!=null)throw new IOException("This endpoint uses a system proxy. Adapter-bound benchmarking is unavailable on that path; no proxy settings were changed. Live traffic remains available.");
        var addresses=resolved==null?await Dns.GetHostAddressesAsync(endpoint.DnsSafeHost,cancellation):[resolved];
        IPAddress? local=null;
        foreach(var address in addresses.OrderBy(a=>a.AddressFamily==AddressFamily.InterNetwork?0:1))
        {
            try {var routed=RouteAddress(address);if(adapter.GetIPProperties().UnicastAddresses.Any(a=>a.Address.Equals(routed))){resolved=address;local=routed;break;}}catch(SocketException){}
        }
        if(local==null||resolved==null)throw new IOException("The measurement endpoint does not route through the selected adapter. Select the active Internet/VPN adapter.");
        var gateway=adapter.GetIPProperties().GatewayAddresses.Select(g=>g.Address).FirstOrDefault(a=>a.AddressFamily==resolved.AddressFamily)?.ToString()??"";
        var stats=adapter.GetIPStatistics();var wifi=NetworkMonitor.Wifi(adapter.Id);
        var settings=new Dictionary<string,string>();string driver="Unavailable",cost="Unknown";
        string id=adapter.Id.Replace("'","''");
        var metadata=await ShellRunner.PowerShellAsync("$ErrorActionPreference='Stop'; $a=Get-NetAdapter -IncludeHidden | Where-Object { [string]$_.InterfaceGuid -eq '"+id+"' } | Select-Object -First 1; $cost='Unknown'; try { $p=[Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]::GetInternetConnectionProfile(); if($p){$c=$p.GetConnectionCost();$cost=[string]$c.NetworkCostType+'; roaming='+$c.Roaming+'; over limit='+$c.OverDataLimit} } catch {}; [pscustomobject]@{Driver=[string]$a.DriverVersion;Cost=$cost} | ConvertTo-Json -Compress",null,10000).WaitAsync(cancellation);
        if(metadata.ExitCode==0){try{using var json=JsonDocument.Parse(metadata.Output.Trim());driver=json.RootElement.GetProperty("Driver").GetString()??driver;cost=json.RootElement.GetProperty("Cost").GetString()??cost;}catch(JsonException){}}
        var inventory=await NetworkSettingService.Run("List",adapter.Id,timeoutMs:10000).WaitAsync(cancellation);
        if(inventory.ExitCode==0){foreach(var row in NetworkSettingService.Parse(inventory.Output))settings[row.Kind+" / "+row.Key]=row.Current;}
        else settings["Inventory status"]="Unavailable";
        settings["Windows build"]=Environment.OSVersion.Version.ToString();settings["DNS servers"]=string.Join(", ",adapter.GetIPProperties().DnsAddresses);
        settings["Path type"]=adapter.NetworkInterfaceType is NetworkInterfaceType.Ppp or NetworkInterfaceType.Tunnel?"Tunnel/VPN adapter":"VPN presence cannot be excluded from interface type alone";
        return new(adapter.Id,adapter.Name,adapter.Description,adapter.NetworkInterfaceType.ToString(),driver,local.ToString(),resolved.ToString(),gateway,Identity(adapter,local,resolved,gateway),cost,"Direct HTTPS; no system proxy configured for endpoint",wifi?.Ssid,wifi?.SignalQuality,adapter.Speed/1_000_000,stats.BytesReceived,stats.BytesSent,stats.IncomingPacketsWithErrors+stats.OutgoingPacketsWithErrors,stats.IncomingPacketsDiscarded+stats.OutgoingPacketsDiscarded,settings);
    }
    public Task AssertRouteAsync(NetworkContext context,CancellationToken cancellation)
    {
        cancellation.ThrowIfCancellationRequested();var adapter=Adapter(context.AdapterId);var remote=IPAddress.Parse(context.RemoteAddress);var local=RouteAddress(remote);
        var gateway=adapter.GetIPProperties().GatewayAddresses.Select(g=>g.Address).FirstOrDefault(a=>a.AddressFamily==remote.AddressFamily)?.ToString()??"";
        if(Identity(adapter,local,remote,gateway)!=context.RouteIdentity)throw new IOException("Adapter or route changed during measurement. Run again after the connection settles.");
        return Task.CompletedTask;
    }
    public async Task<BenchmarkPoint> ProbeAsync(NetworkContext context,string phase,double elapsed,CancellationToken cancellation)
    {
        var probes=await Task.WhenAll(PingAsync(context.Gateway,cancellation),PingAsync(context.RemoteAddress,cancellation));
        var traffic=NetworkMonitor.Sample(context.AdapterId,meter,clock);var signal=NetworkMonitor.Wifi(context.AdapterId)?.SignalQuality;
        return new(phase,elapsed,probes[0],probes[1],null,traffic.ReceiveMbps,traffic.SendMbps,cpu.Sample(),signal);
    }
    private static async Task<double?> PingAsync(string address,CancellationToken cancellation)
    {
        if(!IPAddress.TryParse(address,out var ip))return null;
        try{using var ping=new Ping();var response=await ping.SendPingAsync(ip,TimeSpan.FromMilliseconds(800),new byte[32],null,cancellation);return response.Status==IPStatus.Success?response.RoundtripTime:null;}
        catch(PingException){return null;}
    }
    public async Task<IReadOnlyList<AuxiliaryTiming>> MeasureSetupAsync(NetworkContext context,Uri endpoint,CancellationToken cancellation)
    {
        var result=new List<AuxiliaryTiming>();
        foreach(bool bypass in new[]{false,true})
        {
            var watch=Stopwatch.StartNew();
            try
            {
                int status=await Task.Run(()=>QueryDns(endpoint.DnsSafeHost,IPAddress.Parse(context.RemoteAddress).AddressFamily==AddressFamily.InterNetwork?(ushort)1:(ushort)28,bypass),cancellation).WaitAsync(TimeSpan.FromSeconds(5),cancellation);
                result.Add(new(bypass?"DNS bypass local cache":"DNS normal lookup",status==0?watch.Elapsed.TotalMilliseconds:null,bypass?"Bypasses Windows resolver cache; upstream resolver caches can still answer. Status "+status:"Cache may already be warm from endpoint discovery. Status "+status));
            }
            catch(TimeoutException){result.Add(new("DNS lookup",null,"Resolver exceeded five seconds; no cache flush performed."));}
        }
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(cancellation);deadline.CancelAfter(TimeSpan.FromSeconds(8));
        var remote=IPAddress.Parse(context.RemoteAddress);using var socket=new Socket(remote.AddressFamily,SocketType.Stream,ProtocolType.Tcp);
        socket.Bind(new IPEndPoint(IPAddress.Parse(context.LocalAddress),0));var timing=Stopwatch.StartNew();
        try
        {
            await socket.ConnectAsync(new IPEndPoint(remote,endpoint.Port),deadline.Token);result.Add(new("TCP connection",timing.Elapsed.TotalMilliseconds,"One fresh TCP connection, bound to the selected interface address."));
            if(endpoint.Scheme=="https")
            {
                using var stream=new NetworkStream(socket,false);using var tls=new SslStream(stream,false);timing.Restart();
                await tls.AuthenticateAsClientAsync(new SslClientAuthenticationOptions{TargetHost=endpoint.DnsSafeHost},deadline.Token);
                result.Add(new("TLS handshake",timing.Elapsed.TotalMilliseconds,"Certificate-validated fresh TLS connection; session resumption may occur."));
            }
        }
        catch(Exception ex) when(ex is SocketException or IOException or System.Security.Authentication.AuthenticationException){result.Add(new("Connection setup",null,ex.Message));}
        catch(OperationCanceledException) when(!cancellation.IsCancellationRequested){result.Add(new("Connection setup",null,"Eight-second setup deadline exceeded."));}
        return result;
    }
    private static int QueryDns(string host,ushort type,bool bypass)
    {
        IntPtr records=IntPtr.Zero;
        try{return DnsQuery(host,type,bypass?8u:0u,IntPtr.Zero,out records,IntPtr.Zero);}
        finally{if(records!=IntPtr.Zero)DnsRecordListFree(records,1);}
    }
    [DllImport("dnsapi.dll",EntryPoint="DnsQuery_W",CharSet=CharSet.Unicode)]private static extern int DnsQuery(string name,ushort type,uint options,IntPtr extra,out IntPtr records,IntPtr reserved);
    [DllImport("dnsapi.dll")]private static extern void DnsRecordListFree(IntPtr records,int freeType);
    private sealed class CpuMeter
    {
        private ulong idle,kernel,user;private bool ready;
        public double? Sample()
        {
            if(!GetSystemTimes(out var i,out var k,out var u))return null;
            double? result=null;ulong total=(k-kernel)+(u-user),wait=i-idle;
            if(ready&&total>0&&wait<=total)result=100d*(total-wait)/total;
            (idle,kernel,user,ready)=(i,k,u,true);return result;
        }
        [DllImport("kernel32.dll",SetLastError=true)][return:MarshalAs(UnmanagedType.Bool)]private static extern bool GetSystemTimes(out ulong idle,out ulong kernel,out ulong user);
    }
}
