using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Security.Cryptography;

namespace RionHub.Features.Networking;

public interface IBenchmarkEnvironment
{
    Task<NetworkContext> InspectAsync(BenchmarkOptions options,CancellationToken cancellation);
    Task<IReadOnlyList<AuxiliaryTiming>> MeasureSetupAsync(NetworkContext context,Uri endpoint,CancellationToken cancellation);
    Task<BenchmarkPoint> ProbeAsync(NetworkContext context,string phase,double elapsed,CancellationToken cancellation);
    Task AssertRouteAsync(NetworkContext context,CancellationToken cancellation);
}
public sealed class BenchmarkEngine(IBenchmarkEnvironment environment,Func<NetworkContext,HttpClient>? clientFactory=null)
{
    private static readonly SemaphoreSlim ActiveRun=new(1,1);
    public static HttpClient CreateClient(NetworkContext context)
    {
        var handler=new SocketsHttpHandler
        {
            AllowAutoRedirect=false,AutomaticDecompression=DecompressionMethods.None,UseProxy=false,UseCookies=false,
            ConnectTimeout=TimeSpan.FromSeconds(5),MaxConnectionsPerServer=8,
            ConnectCallback=async(connection,ct)=>
            {
                var local=IPAddress.Parse(context.LocalAddress);var address=IPAddress.Parse(context.RemoteAddress);
                var socket=new Socket(address.AddressFamily,SocketType.Stream,ProtocolType.Tcp){NoDelay=true};
                try{socket.Bind(new IPEndPoint(local,0));await socket.ConnectAsync(new IPEndPoint(address,connection.DnsEndPoint.Port),ct);return new NetworkStream(socket,true);}
                catch{socket.Dispose();throw;}
            }
        };
        var client=new HttpClient(handler){Timeout=Timeout.InfiniteTimeSpan,DefaultRequestVersion=HttpVersion.Version11,DefaultVersionPolicy=HttpVersionPolicy.RequestVersionExact};
        client.DefaultRequestHeaders.UserAgent.ParseAdd("RionWin11/1.0");return client;
    }
    public async Task<BenchmarkReport> RunAsync(BenchmarkOptions options,IProgress<BenchmarkProgress>? progress,CancellationToken cancellation)
    {
        Uri endpoint=options.Validate();
        if(!await ActiveRun.WaitAsync(0,cancellation))throw new InvalidOperationException("A network benchmark is already running.");
        var report=new BenchmarkReport{Options=options};var clock=Stopwatch.StartNew();
        using var deadline=CancellationTokenSource.CreateLinkedTokenSource(cancellation);deadline.CancelAfter(TimeSpan.FromSeconds(options.PhaseSeconds*2+options.BaselineSamples*3+45));
        var ct=deadline.Token;
        try
        {
            progress?.Report(new("Inspecting",0,0,0,0,options.PayloadBudgetBytes,0,0,0,"Reading adapter, route, and connection cost"));
            report.Before=await Stage("Inspecting",token=>environment.InspectAsync(options,token),"Reading adapter and route; inspection has a 25-second limit.");
            using var transfer=(clientFactory??CreateClient)(report.Before);using var latency=(clientFactory??CreateClient)(report.Before);
            report.Timings=(await Stage("Connection setup",token=>environment.MeasureSetupAsync(report.Before,endpoint,token),"Measuring DNS, TCP and TLS connection setup.")).ToList();
            // Warm the latency connection; record timing separately from the repeated baseline.
            var warm=await HttpLatency(latency,endpoint,ct);report.Timings.Add(new("HTTPS warm-up response",warm,"Includes first TLS handshake; excluded from repeated HTTP response samples."));
            for(int i=0;i<options.BaselineSamples;i++)
            {
                await environment.AssertRouteAsync(report.Before,ct);
                var probe=await ProbeWithHttp(environment,report.Before,latency,endpoint,"Unloaded",clock,ct);report.Points.Add(probe);
                progress?.Report(new("Unloaded latency",i+1,options.BaselineSamples,0,0,options.PayloadBudgetBytes,clock.Elapsed.TotalSeconds,probe.ReceiveMbps,probe.SendMbps,"ICMP gateway/remote and warm HTTP response; existing background traffic may remain."));
                if(i+1<options.BaselineSamples)await Task.Delay(250,ct);
            }
            foreach(bool upload in new[]{false,true})
            {
                ct.ThrowIfCancellationRequested();await environment.AssertRouteAsync(report.Before,ct);
                var result=await TransferPhase(upload,options,report,transfer,latency,endpoint,clock,progress,ct);
                report.Transfers.Add(result);
            }
            report.After=await Stage("Finishing",token=>environment.InspectAsync(options,token),"Verifying route and final adapter counters.");
            if(report.Before.RouteIdentity!=report.After.RouteIdentity)throw new IOException("Route/interface changed. Results cannot be compared.");
            report.Status=report.Transfers.All(t=>t.CompletedRequests>0)?"Completed":"Insufficient evidence";
            report.Detail="Payload throughput is measured over each whole transfer phase, including request/response time. Protocol overhead is additional to the payload budget. ICMP timeout rate is not a general UDP packet-loss measurement. Reports are local; no separate result upload is made.";
        }
        catch(OperationCanceledException){report.Status=cancellation.IsCancellationRequested?"Cancelled":"Test failed";report.Detail=cancellation.IsCancellationRequested?"Cancelled; partial measurements retained. No network settings changed.":"Benchmark exceeded its overall deadline; partial measurements retained.";}
        catch(Exception ex){report.Status="Test failed";report.Detail=ex.Message;}
        finally{report.FinishedUtc=DateTime.UtcNow;report.ElapsedSeconds=clock.Elapsed.TotalSeconds;ActiveRun.Release();}
        return report;

        async Task<T> Stage<T>(string name,Func<CancellationToken,Task<T>> action,string detail)
        {
            // Route discovery can call synchronous Windows APIs. Keep it off the dispatcher.
            using var stageStop=CancellationTokenSource.CreateLinkedTokenSource(ct);
            stageStop.CancelAfter(TimeSpan.FromSeconds(25));
            var task=Task.Run(()=>action(stageStop.Token),stageStop.Token).WaitAsync(stageStop.Token);
            while(!task.IsCompleted)
            {
                progress?.Report(new(name,0,0,report.ReceivedPayload,report.SentPayload,options.PayloadBudgetBytes,clock.Elapsed.TotalSeconds,
                    report.Transfers.FirstOrDefault(t=>t.Direction=="Download")?.Mbps??0,report.Transfers.FirstOrDefault(t=>t.Direction=="Upload")?.Mbps??0,detail));
                await Task.WhenAny(task,Task.Delay(250,ct));ct.ThrowIfCancellationRequested();
            }
            try{return await task;}
            catch(OperationCanceledException) when(!ct.IsCancellationRequested){throw new TimeoutException(name+" exceeded 25 seconds. Check the adapter and try again.");}
        }
    }
    private async Task<TransferSummary> TransferPhase(bool upload,BenchmarkOptions options,BenchmarkReport report,HttpClient transfer,HttpClient latency,Uri endpoint,Stopwatch total,IProgress<BenchmarkProgress>? progress,CancellationToken ct)
    {
        string phase=upload?"Upload":"Download";
        var budget=new PayloadBudget(options.PayloadBudgetBytes/2);var clock=Stopwatch.StartNew();
        using var phaseStop=CancellationTokenSource.CreateLinkedTokenSource(ct);phaseStop.CancelAfter(TimeSpan.FromSeconds(options.PhaseSeconds));
        long actual=0,confirmed=0;int completed=0;
        void Count(int count){Interlocked.Add(ref actual,count);}
        async Task Worker()
        {
            int chunk=256*1024;
            try
            {
                while(!phaseStop.IsCancellationRequested)
                {
                    long size=budget.Reserve(chunk);if(size==0)break;
                    using var request=new HttpRequestMessage(upload?HttpMethod.Post:HttpMethod.Get,new Uri(endpoint,upload?"__up":"__down?bytes="+size));
                    request.Headers.CacheControl=new CacheControlHeaderValue{NoCache=true,NoStore=true};
                    if(upload)request.Content=new GeneratedPayload(size,Count);
                    using var response=await transfer.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,phaseStop.Token);
                    response.EnsureSuccessStatusCode();
                    if(!upload)
                    {
                        if(response.Content.Headers.ContentEncoding.Count>0)throw new IOException("Compressed response is not a valid payload-throughput measurement.");
                        if(response.Content.Headers.ContentLength is long length&&length!=size)throw new IOException("Measurement endpoint returned an unexpected download length.");
                        using var body=await response.Content.ReadAsStreamAsync(phaseStop.Token);var buffer=new byte[64*1024];long remaining=size;
                        while(remaining>0){int n=await body.ReadAsync(buffer.AsMemory(0,(int)Math.Min(buffer.Length,remaining)),phaseStop.Token);if(n==0)throw new IOException("Measurement download ended early.");remaining-=n;Count(n);}
                    }
                    else
                    {
                        // A successful HTTP acknowledgement, not writes into the local socket buffer, confirms the upload.
                        using var body=await response.Content.ReadAsStreamAsync(phaseStop.Token);var buffer=new byte[1024];int responseBytes=0,n;
                        while((n=await body.ReadAsync(buffer,phaseStop.Token))>0){responseBytes+=n;if(responseBytes>16384)throw new IOException("Unexpectedly large upload acknowledgement.");}
                    }
                    Interlocked.Add(ref confirmed,size);Interlocked.Increment(ref completed);chunk=Math.Min(chunk*2,8*1024*1024);
                }
            }
            catch(OperationCanceledException) when(phaseStop.IsCancellationRequested) { }
        }
        double transferSeconds=0;
        async Task AllWorkers()
        {
            try { await Task.WhenAll(Enumerable.Range(0,options.Streams).Select(_=>Worker())); }
            finally { transferSeconds=clock.Elapsed.TotalSeconds; }
        }
        var work=AllWorkers();
        async Task SampleLatency()
        {
            try
            {
                while(!work.IsCompleted)
                {
                    await environment.AssertRouteAsync(report.Before!,phaseStop.Token);
                    var sample=await ProbeWithHttp(environment,report.Before!,latency,endpoint,phase,total,phaseStop.Token);
                    if(!work.IsCompleted)report.Points.Add(sample);
                    await Task.Delay(250,phaseStop.Token);
                }
            }
            catch(OperationCanceledException) when(phaseStop.IsCancellationRequested){}
            catch{phaseStop.Cancel();throw;}
        }
        var sampling=SampleLatency();
        void PublishRate()
        {
            long bytes=Interlocked.Read(ref actual);
            double rate=bytes*8/Math.Max(.001,work.IsCompleted?transferSeconds:clock.Elapsed.TotalSeconds)/1_000_000;
            progress?.Report(new(phase,Volatile.Read(ref completed),0,report.ReceivedPayload+(upload?0:bytes),report.SentPayload+(upload?bytes:0),options.PayloadBudgetBytes,total.Elapsed.TotalSeconds,
                upload?report.Transfers.FirstOrDefault(t=>t.Direction=="Download")?.Mbps??0:rate,upload?rate:0,
                $"{options.Streams} stream(s) · phase average · up to {options.PhaseSeconds}s per direction"));
        }
        try
        {
            while(!work.IsCompleted)
            {
                ct.ThrowIfCancellationRequested();PublishRate();
                await Task.WhenAny(work,Task.Delay(250,phaseStop.Token));phaseStop.Token.ThrowIfCancellationRequested();
            }
        }
        catch(OperationCanceledException) when(phaseStop.IsCancellationRequested){ }
        finally
        {
            phaseStop.Cancel();
            try{await Task.WhenAll(work,sampling);PublishRate();}finally{if(upload)report.SentPayload+=Interlocked.Read(ref actual);else report.ReceivedPayload+=Interlocked.Read(ref actual);}
        }
        ct.ThrowIfCancellationRequested();
        double seconds=transferSeconds;
        return new(phase,actual,confirmed,seconds,completed==0?null:confirmed*8/Math.Max(.001,seconds)/1_000_000,completed,options.Streams,
            seconds<3?"Short transfer: payload budget may limit ramp-up; this is not evidence of maximum line capacity.":completed==0?"No complete acknowledged transfer.":"Application-level throughput to this endpoint; includes request latency and endpoint effects.");
    }
    private static async Task<BenchmarkPoint> ProbeWithHttp(IBenchmarkEnvironment env,NetworkContext context,HttpClient http,Uri endpoint,string phase,Stopwatch clock,CancellationToken ct)
    {
        var network=env.ProbeAsync(context,phase,clock.Elapsed.TotalSeconds,ct);var response=HttpLatency(http,endpoint,ct);
        await Task.WhenAll(network,response);return (await network) with{HttpResponseMs=await response};
    }
    private static async Task<double?> HttpLatency(HttpClient http,Uri endpoint,CancellationToken ct)
    {
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct);timeout.CancelAfter(TimeSpan.FromSeconds(2));
        var clock=Stopwatch.StartNew();
        try{using var request=new HttpRequestMessage(HttpMethod.Get,new Uri(endpoint,"__down?bytes=0"));request.Headers.CacheControl=new CacheControlHeaderValue{NoCache=true,NoStore=true};using var response=await http.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,timeout.Token);response.EnsureSuccessStatusCode();return clock.Elapsed.TotalMilliseconds;}
        catch(OperationCanceledException) when(!ct.IsCancellationRequested){return null;}
        catch(HttpRequestException){return null;}
    }
    private sealed class GeneratedPayload(long length,Action<int> count):HttpContent
    {
        protected override bool TryComputeLength(out long result){result=length;return true;}
        protected override Task SerializeToStreamAsync(Stream stream,TransportContext? context)=>SerializeToStreamAsync(stream,context,CancellationToken.None);
        protected override async Task SerializeToStreamAsync(Stream stream,TransportContext? context,CancellationToken cancellationToken)
        {
            var bytes=RandomNumberGenerator.GetBytes(64*1024);long remaining=length;
            while(remaining>0){int n=(int)Math.Min(bytes.Length,remaining);await stream.WriteAsync(bytes.AsMemory(0,n),cancellationToken);count(n);remaining-=n;}
        }
    }
}
