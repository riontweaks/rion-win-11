using System.Text.Json;
using RadeonSoftwareSlimmer.Optimize;

namespace RionHub.Features;

public sealed record MotherboardInfo(string Manufacturer,string Model,string Firmware)
{
    public string BiosVendor {get;init;}="";
    public string CpuVendor {get;init;}="";
    public string CpuName {get;init;}="";
    public string? CpuBrand=>CpuVendor.Trim().ToUpperInvariant() switch
    {
        "AUTHENTICAMD" or "AMD" or "ADVANCED MICRO DEVICES, INC."=>"AMD",
        "GENUINEINTEL" or "INTEL" or "INTEL CORPORATION"=>"Intel",
        _=>null
    };
    public string Display=>string.Join(" · ",new[]{Manufacturer,Model,string.IsNullOrWhiteSpace(Firmware)?"":"BIOS "+Firmware}.Where(s=>!string.IsNullOrWhiteSpace(s)));
    public static async Task<MotherboardInfo> DetectAsync()
    {
        const string script="$ErrorActionPreference='Stop'; $b=Get-CimInstance Win32_BaseBoard | Select-Object -First 1; $f=Get-CimInstance Win32_BIOS | Select-Object -First 1; $c=Get-CimInstance Win32_Processor | Select-Object -First 1; [pscustomobject]@{Manufacturer=[string]$b.Manufacturer;Model=[string]$b.Product;Firmware=[string]$f.SMBIOSBIOSVersion;BiosVendor=[string]$f.Manufacturer;CpuVendor=[string]$c.Manufacturer;CpuName=[string]$c.Name} | ConvertTo-Json -Compress";
        var result=await ShellRunner.PowerShellAsync(script,null,15000);
        if(result.ExitCode!=0)throw new InvalidOperationException("Motherboard detection unavailable.");
        return JsonSerializer.Deserialize<MotherboardInfo>(result.Output.Trim())??throw new InvalidOperationException("Motherboard detection returned no information.");
    }
}
