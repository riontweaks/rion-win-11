using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using RionHub.Features.Networking;

namespace RionHub.Features;

public partial class NetworkMonitorPage : UserControl
{
    private CancellationTokenSource? cancellation;
    private BenchmarkReport? report;
    private List<BenchmarkReport> baseline=[],candidate=[];
    public NetworkMonitorPage()
    {
        InitializeComponent();Loaded+=(_,_)=>{if(Adapters.ItemsSource==null)Refresh();};Unloaded+=(_,_)=>cancellation?.Cancel();UpdateBudget();
    }
    private void Refresh(){var id=(Adapters.SelectedItem as AdapterInfo)?.Id;var rows=NetworkMonitor.Adapters();Adapters.ItemsSource=rows;Adapters.SelectedItem=rows.FirstOrDefault(a=>a.Id==id)??rows.FirstOrDefault(a=>a.State=="Up")??rows.FirstOrDefault();}
    private void Refresh_Click(object sender,RoutedEventArgs e)=>Guard(Refresh);
    private void Mode_Changed(object sender,SelectionChangedEventArgs e){if(BudgetLabel!=null)UpdateBudget();}
    private void UpdateBudget()=>BudgetLabel.Text=Mode.SelectedIndex==1?"Detailed · up to 256 MiB payload · 20 s per direction · 4 streams · 30 baseline probes":"Quick · up to 64 MiB payload · 10 s per direction · 1 stream · 10 baseline probes";
    private async void Run_Click(object sender,RoutedEventArgs e)
    {
        if(cancellation!=null)return;
        var session=new BenchmarkSession();
        try
        {
            var adapter=Adapters.SelectedItem as AdapterInfo??throw new InvalidOperationException("Choose a connected adapter.");
            if(DataConsent.IsChecked!=true)throw new InvalidOperationException("Select the data-use checkbox before starting this test.");
            var options=(Mode.SelectedIndex==1?BenchmarkOptions.Detailed(adapter.Id):BenchmarkOptions.Quick(adapter.Id)) with{Endpoint=Endpoint.Text.Trim()};options.Validate();
            cancellation=new();report=null;SetBusy(true);LatencyGrid.ItemsSource=null;LatencySummaryGrid.ItemsSource=null;ResultDetail.Text="";ConnectionDetail.Text="";TrafficGraph.Children.Clear();GraphScale.Text="Waiting for traffic samples.";
            TransferLabel.Text="Download —    Upload —";ProgressBar.Value=0;ProgressLabel.Text="Inspecting";
            var progress=new Progress<BenchmarkProgress>(p=>
            session.Update(()=>{
                ProgressLabel.Text=p.Phase;ProgressBar.IsIndeterminate=p.Phase is "Inspecting" or "Connection setup" or "Unloaded latency" or "Finishing";
                ProgressBar.Value=(p.ReceivedPayload+p.SentPayload)*100d/p.PayloadBudget;
                if(p.Phase is "Download" or "Upload" or "Finishing")TransferLabel.Text=$"Download {p.ReceiveMbps:F2} Mbps    Upload {(p.Phase=="Download"?"—":$"{p.SendMbps:F2} Mbps")}";
                ProgressDetail.Text=$"{p.ElapsedSeconds:F0}s · {(p.ReceivedPayload+p.SentPayload)/1048576d:F1} / {p.PayloadBudget/1048576d:F0} MiB"+(p.TargetSamples>0?$" · probe {p.CompletedSamples}/{p.TargetSamples}":"")+"\n"+p.Detail;
            }));
            report=await new BenchmarkEngine(new WindowsBenchmarkEnvironment()).RunAsync(options,progress,cancellation.Token);
            session.Complete();
            var path=BenchmarkStore.Save(report);ShowReport(report);ResultDetail.Text+="\nSaved locally: "+path;
        }
        catch(Exception ex){ProgressLabel.Text="Test unavailable";ProgressDetail.Text=ex.Message;}
        finally{session.Complete();cancellation?.Dispose();cancellation=null;SetBusy(false);ProgressBar.IsIndeterminate=false;}
    }
    private void SetBusy(bool busy){Inputs.IsEnabled=!busy;Endpoint.IsEnabled=!busy;RunButton.IsEnabled=!busy;CancelButton.IsEnabled=busy;CancelButton.Visibility=busy?Visibility.Visible:Visibility.Collapsed;ExportButton.IsEnabled=!busy&&report!=null;LiveTab.IsEnabled=!busy;ReportsTab.IsEnabled=!busy;TestOptions.IsEnabled=!busy;}
    private void Cancel_Click(object sender,RoutedEventArgs e)=>cancellation?.Cancel();
    private static string Number(double? value,string suffix=" ms")=>value.HasValue?$"{value:F2}{suffix}":"—";
    private void ShowReport(BenchmarkReport value)
    {
        report=value;ProgressLabel.Text=value.Status;ProgressBar.Value=(value.ReceivedPayload+value.SentPayload)*100d/value.Options.PayloadBudgetBytes;
        TransferLabel.Text=$"Download {Number(value.Transfers.FirstOrDefault(t=>t.Direction=="Download")?.Mbps," Mbps")}    Upload {Number(value.Transfers.FirstOrDefault(t=>t.Direction=="Upload")?.Mbps," Mbps")}";
        ProgressDetail.Text=$"{value.StartedUtc.ToLocalTime():g} · {value.Options.Mode} · {value.ElapsedSeconds:F1}s · received {value.ReceivedPayload/1048576d:F1} / sent {value.SentPayload/1048576d:F1} MiB";
        if(value.Status!="Completed")ProgressDetail.Text=value.Detail+"\n"+ProgressDetail.Text;
        LatencySummaryGrid.ItemsSource=new[]{"Unloaded","Download","Upload"}.Select(phase=>new{Phase=phase,Gateway=Number(value.Latency(phase,true).MedianMs),Remote=Number(value.Latency(phase).MedianMs),HTTP=Number(LatencySummary.From(value.Points.Where(p=>p.Phase==phase).Select(p=>p.HttpResponseMs)).MedianMs)}).ToArray();
        LatencyGrid.ItemsSource=new[]{"Unloaded","Download","Upload"}.SelectMany(phase=>new[]{"Gateway","Remote","HTTP"}.Select(target=>
        {
            var s=target=="HTTP"?LatencySummary.From(value.Points.Where(p=>p.Phase==phase).Select(p=>p.HttpResponseMs)):value.Latency(phase,target=="Gateway");return new{Phase=phase,Target=target,Median=Number(s.MedianMs),P95=Number(s.P95Ms),Jitter=Number(s.JitterMs),Timeouts=$"{s.Attempts-s.Successful}/{s.Attempts}"};
        })).ToArray();
        ResultDetail.Text=value.Detail+"\nP95 requires 20 successful samples. A dash means insufficient or unavailable data. Jitter is mean absolute difference between adjacent successful probes.\n"+string.Join("\n",value.Transfers.Select(t=>$"{t.Direction}: {t.CompletedRequests} acknowledged requests; {t.Seconds:F2}s. {t.Limitation}"));
        DrawGraph();
        var b=value.Before;
        ConnectionDetail.Text=b==null?"Adapter inspection did not complete.":$"{b.Name} · {b.Description}\nDriver {b.Driver} · link {b.LinkMbps} Mbps\nLocal {b.LocalAddress} → {b.RemoteAddress} · gateway {b.Gateway}\nCost: {b.Metered}\n{b.Proxy}\n"+(b.Ssid==null?"Wi-Fi details unavailable":NetworkMonitor.RateWifi(b.SignalQuality,value.Points.Where(p=>p.Phase=="Unloaded").Select(p=>p.GatewayMs.HasValue?(long?)p.GatewayMs.Value:null).ToArray()))+"\n"+string.Join("\n",value.Timings.Select(t=>$"{t.Name}: {Number(t.Milliseconds)} · {t.Detail}"))+"\n"+(value.After==null?"Final adapter counters unavailable.":$"Adapter errors delta: {value.After.Errors-b.Errors}; discards delta: {value.After.Discards-b.Discards} (includes background traffic).");
        var cpu=value.Points.Where(p=>p.CpuPercent.HasValue).Select(p=>p.CpuPercent!.Value).ToArray();
        ConnectionDetail.Text+="\nSystem CPU samples: "+(cpu.Length==0?"Unavailable":$"mean {cpu.Average():F1}%; max {cpu.Max():F1}%; {cpu.Length} samples");
        ExportButton.IsEnabled=cancellation==null;
    }
    private void Graph_SizeChanged(object sender,SizeChangedEventArgs e)=>DrawGraph();
    private void DrawGraph()
    {
        if(TrafficGraph==null)return;TrafficGraph.Children.Clear();var points=report?.Points??[];
        if(points.Count<2){GraphScale.Text="Not enough traffic samples to draw a chart.";return;}
        double max=Math.Max(1,points.Max(p=>Math.Max(p.ReceiveMbps,p.SendMbps)));double span=Math.Max(.001,points.Last().ElapsedSeconds-points.First().ElapsedSeconds);
        foreach(bool receive in new[]{true,false})
        {
            var line=new System.Windows.Shapes.Polyline{Stroke=(System.Windows.Media.Brush)FindResource(receive?"Accent":"TextDim"),StrokeThickness=2};
            foreach(var point in points)line.Points.Add(new Point((point.ElapsedSeconds-points.First().ElapsedSeconds)/span*Math.Max(1,TrafficGraph.ActualWidth),125-(receive?point.ReceiveMbps:point.SendMbps)*120/max));TrafficGraph.Children.Add(line);
        }
        GraphScale.Text=$"0–{max:F1} Mbps · {span:F1}s · {points.Count} samples · blue receive / gray send";
    }
    private void Export_Click(object sender,RoutedEventArgs e)=>Guard(()=>{if(report==null)return;var dialog=new SaveFileDialog{FileName="Rion-network-"+report.StartedUtc.ToString("yyyyMMdd-HHmmss")+".json",Filter="Network report|*.json"};if(dialog.ShowDialog()==true)File.WriteAllText(dialog.FileName,System.Text.Json.JsonSerializer.Serialize(report,BenchmarkStore.JsonOptions));});
    private void More_Click(object sender,RoutedEventArgs e){if(sender is Button {ContextMenu: {} menu} button){menu.PlacementTarget=button;menu.IsOpen=true;}}
    private void Open_Click(object sender,RoutedEventArgs e)=>Guard(()=>{var paths=PickReports(false);if(paths.Length==1){ShowReport(BenchmarkStore.Load(paths[0]));ResultDetail.Text="Imported report. "+ResultDetail.Text;}});
    private static string[] PickReports(bool multiple){var dialog=new OpenFileDialog{Filter="Network report|*.json",Multiselect=multiple,InitialDirectory=Directory.Exists(BenchmarkStore.DirectoryPath)?BenchmarkStore.DirectoryPath:Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)};return dialog.ShowDialog()==true?dialog.FileNames:[];}
    private void Baseline_Click(object sender,RoutedEventArgs e)=>Guard(()=>{var paths=PickReports(true);if(paths.Length>0)baseline=paths.Select(BenchmarkStore.Load).ToList();UpdateSelection();});
    private void Candidate_Click(object sender,RoutedEventArgs e)=>Guard(()=>{var paths=PickReports(true);if(paths.Length>0)candidate=paths.Select(BenchmarkStore.Load).ToList();UpdateSelection();});
    private void UpdateSelection()=>CompareSelection.Text=$"{baseline.Count} baseline runs · {candidate.Count} candidate runs";
    private void Compare_Click(object sender,RoutedEventArgs e)=>Guard(()=>{var result=BenchmarkComparison.Compare(baseline,candidate);CompareGrid.ItemsSource=result.Metrics;ComparisonDetail.Text=result.Outcome+"\n"+result.Detail;});
    private void Live_Selected(object sender,RoutedEventArgs e){if(ReferenceEquals(e.Source,LiveTab)&&LiveTab.Content==null)LiveTab.Content=new PassiveNetworkPage();}
    private void Manage_Click(object sender,RoutedEventArgs e)=>Guard(()=>{var selected=Adapters.SelectedItem as AdapterInfo??throw new InvalidOperationException("Choose an adapter.");var vm=new Modules.Tools.Network.NetworkViewModel{SelectedAdapter=selected.Name};new Window{Title="Network — "+selected.Name,Width=1000,Height=720,Content=new Modules.Tools.Network.NetworkView{DataContext=vm},Owner=Window.GetWindow(this)}.Show();});
    private void Guard(Action action){try{action();}catch(Exception ex){MessageBox.Show(Window.GetWindow(this),ex.Message,"Network Benchmark",MessageBoxButton.OK,MessageBoxImage.Information);}}
}
