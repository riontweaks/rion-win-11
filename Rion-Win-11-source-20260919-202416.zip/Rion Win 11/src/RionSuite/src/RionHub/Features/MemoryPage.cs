using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using RionHub.Modules.Tools.General;

namespace RionHub.Features;

public sealed class MemoryPage : UserControl
{
    private readonly StackPanel cards = new();
    private readonly TextBlock status = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,8,0,0) };
    private readonly Button scan = new() { Content = "Refresh", Margin = new Thickness(0,0,8,0) };
    private readonly Button import = new() { Content = "Import CPU-Z report" };
    private IReadOnlyList<MemoryModule> firmware = Array.Empty<MemoryModule>();
    private IReadOnlyList<MemoryModule> imported = Array.Empty<MemoryModule>();

    public MemoryPage() : this(true) { }
    public MemoryPage(bool scanOnLoad)
    {
        Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri("/Rion Win 11;component/Modules/Tools/ToolStyles.xaml", UriKind.Relative) });
        SetResourceReference(FontFamilyProperty, "AppFont");
        var panel = new DockPanel { Margin = new Thickness(24,14,24,18) };
        var top = new StackPanel(); DockPanel.SetDock(top, Dock.Top); panel.Children.Add(top);
        var heading = new TextBlock { Text = "Memory" }; heading.SetResourceReference(TextBlock.StyleProperty, "ToolHeading"); top.Children.Add(heading);
        var description = new TextBlock { Text = "Module details from Windows firmware data. Import a CPU-Z text report for available SPD profiles and chip information.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,4,0,12) }; description.SetResourceReference(TextBlock.StyleProperty, "ToolCaption"); top.Children.Add(description);
        var actions = new WrapPanel { Margin = new Thickness(0,0,0,12) }; actions.Children.Add(scan); actions.Children.Add(import); top.Children.Add(actions);
        status.SetResourceReference(TextBlock.StyleProperty, "ToolCaption"); DockPanel.SetDock(status, Dock.Bottom); panel.Children.Add(status);
        panel.Children.Add(new ScrollViewer { Content = cards, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled }); Content = panel;
        scan.Click += async (_, _) => await Scan(); import.Click += async (_, _) => await Import();
        if (scanOnLoad) Loaded += async (_, _) => { if (firmware.Count == 0) await Scan(); };
    }

    private async Task Scan()
    {
        scan.IsEnabled = import.IsEnabled = false; status.Text = "Reading memory information…";
        try { firmware = await Task.Run(MemoryDetails.ReadFirmware); Render(); status.Text = firmware.Count == 0 ? "No memory modules reported by firmware." : "Firmware data is not a live frequency measurement. Unknown fields are left unknown."; }
        catch (Exception ex) { status.Text = "Memory scan unavailable: " + ex.Message; }
        finally { scan.IsEnabled = import.IsEnabled = true; }
    }

    private async Task Import()
    {
        var picker = new OpenFileDialog { Filter = "CPU-Z text report|*.txt" }; if (picker.ShowDialog() != true) return;
        scan.IsEnabled = import.IsEnabled = false;
        try { if (new FileInfo(picker.FileName).Length > 8_000_000) throw new IOException("Report must be under 8 MB."); imported = MemoryDetails.ParseCpuZ(await File.ReadAllTextAsync(picker.FileName)); Render(); status.Text = "Report imported locally. No hardware settings changed."; }
        catch (Exception ex) { status.Text = "Report could not be imported: " + ex.Message; }
        finally { scan.IsEnabled = import.IsEnabled = true; }
    }

    public void ShowFixture(IReadOnlyList<MemoryModule> modules, IReadOnlyList<MemoryModule> reports) { firmware = modules; imported = reports; Render(); }
    private void Render()
    {
        cards.Children.Clear(); MemoryDetails.MatchReports(imported, firmware);
        foreach (var group in new[] { ("This PC", firmware), ("Imported report", imported) })
        {
            if (group.Item2.Count == 0) continue;
            var title = new TextBlock { Text = group.Item1, Margin = new Thickness(0,8,0,12) }; title.SetResourceReference(TextBlock.StyleProperty, "ToolHeading"); cards.Children.Add(title);
            var grid = new CardPanel { MinCardWidth = 340, Gutter = 12 }; cards.Children.Add(grid);
            foreach (var module in group.Item2)
            {
                var content = new StackPanel(); var name = new TextBlock { Text = module.Title }; name.SetResourceReference(TextBlock.StyleProperty, "ToolTitle"); content.Children.Add(name);
                if (module.MatchNote.Length > 0) { var note = new TextBlock { Text = module.MatchNote, Margin = new Thickness(0,6,0,0) }; note.SetResourceReference(TextBlock.StyleProperty, "ToolCaption"); content.Children.Add(note); }
                foreach (var field in module.Fields) { var text = new TextBlock { Text = field.Name + ": " + field.Value, ToolTip = field.Source, Margin = new Thickness(0,6,0,0) }; text.SetResourceReference(TextBlock.StyleProperty, "ToolCaption"); content.Children.Add(text); }
                var sources = new TextBlock { Text = string.Join("\n", module.Fields.Select(f => f.Name + ": " + f.Source).Distinct()) }; sources.SetResourceReference(TextBlock.StyleProperty, "ToolCaption"); content.Children.Add(new Expander { Header = "Data sources", Content = sources, Margin = new Thickness(0,8,0,0) });
                var surface = new Border { Child = content, Padding = new Thickness(12) }; surface.SetResourceReference(StyleProperty, "ToolSurface"); grid.Children.Add(surface);
            }
        }
    }
}
