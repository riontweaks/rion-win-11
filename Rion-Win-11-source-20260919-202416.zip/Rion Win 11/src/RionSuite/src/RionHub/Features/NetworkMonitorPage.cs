using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RionHub.Features;

public sealed class PassiveNetworkPage : FeaturePage
{
    private readonly ComboBox adapters=new(){Width=320,Margin=new Thickness(0,0,8,8)};
    private readonly TextBox remote=new(){Text="1.1.1.1",Width=180,Margin=new Thickness(0,0,8,8)};
    private readonly TextBlock readings=new(){FontSize=20,TextWrapping=TextWrapping.Wrap};
    private readonly TextBlock wifi=new(){TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,8)};
    private readonly Canvas chart=new(){Height=200,ClipToBounds=true,Background=new SolidColorBrush(Color.FromRgb(24,29,37))};
    private readonly List<TrafficSample> samples=[];
    private CancellationTokenSource? cancellation;
    public PassiveNetworkPage():base("Live traffic","Receive/send traffic and gateway/Internet latency on the selected adapter.")
    {
        Actions.Children.Add(adapters);
        Action("Refresh adapters",()=>{adapters.ItemsSource=NetworkMonitor.Adapters();});
        Action("Manage selected adapter",()=>
        {
            var selected=adapters.SelectedItem as AdapterInfo??throw new InvalidOperationException("Select an adapter.");
            var vm=new RionHub.Modules.Tools.Network.NetworkViewModel{SelectedAdapter=selected.Name};
            new Window{Title="Network — "+selected.Name,Width=1050,Height=760,Content=new RionHub.Modules.Tools.Network.NetworkView{DataContext=vm},Background=new SolidColorBrush(Color.FromRgb(10,13,18)),Owner=Window.GetWindow(this)}.Show();
        });
        Action("Start monitoring",Start);
        var stop=new Button{Content="Stop",Margin=new Thickness(0,0,8,8)};stop.Click+=(_,_)=>cancellation?.Cancel();Actions.Children.Add(stop);
        Header.Children.Add(new TextBlock{Text="Remote latency endpoint (IP address)"});Header.Children.Add(remote);Header.Children.Add(readings);Header.Children.Add(wifi);
        Layout.Children.Add(chart);
        adapters.SelectionChanged+=(_,_)=>cancellation?.Cancel();Unloaded+=(_,_)=>cancellation?.Cancel();
        Loaded+=(_,_)=>{if(adapters.ItemsSource==null){adapters.ItemsSource=NetworkMonitor.Adapters();adapters.SelectedIndex=0;}};
    }
    private async Task Start()
    {
        var selected=adapters.SelectedItem as AdapterInfo??throw new InvalidOperationException("Select an adapter.");
        if(!IPAddress.TryParse(remote.Text,out var endpoint))throw new ArgumentException("Enter a remote IP address.");
        cancellation?.Cancel();cancellation=new();var ct=cancellation.Token;
        var meter=new TrafficMeter();var clock=Stopwatch.StartNew();samples.Clear();var gatewaySamples=new List<long?>();var remoteSamples=new List<long?>();
        var gateway=NetworkMonitor.Gateway(selected.Id);string route=NetworkMonitor.ActualInterface(endpoint);
        long? baseRx=null,baseTx=null;
        try
        {
            while(!ct.IsCancellationRequested)
            {
                var sample=await Task.Run(()=>NetworkMonitor.Sample(selected.Id,meter,clock),ct);samples.Add(sample);if(samples.Count>120)samples.RemoveAt(0);
                baseRx??=sample.ReceivedBytes;baseTx??=sample.SentBytes;
                if(sample.ReceivedBytes<baseRx)baseRx=sample.ReceivedBytes;if(sample.SentBytes<baseTx)baseTx=sample.SentBytes;
                var probes=await Task.WhenAll(Probe(gateway),Probe(endpoint));ct.ThrowIfCancellationRequested();
                gatewaySamples.Add(probes[0]);remoteSamples.Add(probes[1]);if(gatewaySamples.Count>60){gatewaySamples.RemoveAt(0);remoteSamples.RemoveAt(0);}
                var signal=await Task.Run(()=>NetworkMonitor.Wifi(selected.Id),ct);
                readings.Text=$"Receive {sample.ReceiveMbps:F2} Mbps   Send {sample.SendMbps:F2} Mbps\nSession received {(sample.ReceivedBytes-baseRx)/1048576d:F1} MB / sent {(sample.SentBytes-baseTx)/1048576d:F1} MB\nGateway {Format(probes[0])}   Remote {Format(probes[1])}";
                wifi.Text=(signal==null?"Wi-Fi fields unavailable (not connected, unsupported, or access restricted).":$"{signal.Ssid} · signal {signal.SignalQuality}% · negotiated RX {signal.ReceiveKbps/1000d:F0} / TX {signal.TransmitKbps/1000d:F0} Mbps")+"\n"+NetworkMonitor.RateWifi(signal?.SignalQuality,gatewaySamples);
                string currentRoute=NetworkMonitor.ActualInterface(endpoint);
                Status.Text=$"Blue = receive; green = send. Last {samples.Count} samples. Remote {Statistics(remoteSamples)}. Adapter errors {sample.Errors}, discards {sample.Discards} (OS counters). "+(currentRoute!=selected.Id?"Remote probe route differs from selected adapter; do not attribute it to this Wi-Fi connection.":"Remote route uses the selected adapter.");
                if(currentRoute!=route){gatewaySamples.Clear();remoteSamples.Clear();route=currentRoute;Status.Text+=" Route changed; latency history reset.";}
                Draw();await Task.Delay(1000,ct);
            }
        }
        catch(OperationCanceledException){Status.Text="Monitoring stopped.";}
    }
    private static async Task<long?> Probe(IPAddress? address){if(address==null)return null;try{using var ping=new Ping();var reply=await ping.SendPingAsync(address,800);return reply.Status==IPStatus.Success?reply.RoundtripTime:null;}catch(PingException){return null;}}
    private static string Format(long? value)=>value.HasValue?value+" ms":"timeout / unavailable";
    private static string Statistics(List<long?> values){var valid=values.Where(v=>v.HasValue).Select(v=>v!.Value).ToArray();double jitter=valid.Length>1?valid.Zip(valid.Skip(1),(a,b)=>Math.Abs(a-b)).Average():0;return $"timeouts {values.Count-valid.Length}/{values.Count}, mean absolute successive RTT difference {jitter:F1} ms";}
    private void Draw(){chart.Children.Clear();double max=Math.Max(1,samples.Max(s=>Math.Max(s.ReceiveMbps,s.SendMbps)));double width=Math.Max(1,chart.ActualWidth);foreach(bool rx in new[]{true,false}){var line=new Polyline{Stroke=rx?Brushes.DeepSkyBlue:Brushes.LightGreen,StrokeThickness=2};for(int i=0;i<samples.Count;i++)line.Points.Add(new Point(i*width/119,190-(rx?samples[i].ReceiveMbps:samples[i].SendMbps)*180/max));chart.Children.Add(line);}}
}
