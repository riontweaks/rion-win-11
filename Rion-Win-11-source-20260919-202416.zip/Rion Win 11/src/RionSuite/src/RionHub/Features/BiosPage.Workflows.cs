using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
namespace RionHub.Features;

public partial class BiosPage
{
    readonly BiosWorkspace workspace;
    bool offlineDocument;
    bool workspaceSubscribed;
    async Task InitializeWorkspace()
    {
        if(!workspaceSubscribed){workspaceSubscribed=true;workspace.Changed+=WorkspaceChanged;Unloaded+=(_,_)=>{workspace.Changed-=WorkspaceChanged;workspaceSubscribed=false;};}
        WorkspaceChanged();await workspace.InitializeAsync();WorkspaceChanged();
    }
    void WorkspaceChanged()
    {
        if(offlineDocument||busy||document?.Settings.Any(s=>s.Changed)==true){Report("A newer scan is available. Pending/offline values were preserved.");return;}
        if(workspace.Board!=null)ShowBoard(workspace.Board);
        if(workspace.Latest!=null)SetDocument(new BiosDocument(workspace.Latest.Original){IsLiveScan=workspace.Latest.IsLiveScan},workspace.Source);
        else SourceLabel.Text=workspace.Source;
    }
    bool ConfirmDiscard()=>document?.Settings.Any(s=>s.Changed)!=true||MessageBox.Show("Discard pending BIOS edits?","Pending changes",MessageBoxButton.YesNo)==MessageBoxResult.Yes;
    void DocumentDrop(object sender,DragEventArgs e)
    {
        e.Handled=true;if(busy||!e.Data.GetDataPresent(DataFormats.FileDrop))return;
        Run(()=>{var files=(string[])e.Data.GetData(DataFormats.FileDrop);if(files.Length!=1)throw new InvalidDataException("Drop one NVRAM .txt export.");ImportOfflineFile(files[0]);});
    }
    public void ImportOfflineFile(string path)
    {
        if(busy)return;
        if(!string.Equals(System.IO.Path.GetExtension(path),".txt",StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Choose one NVRAM .txt export.");
        var parsed=new BiosDocument(File.ReadAllBytes(path));if(!ConfirmDiscard())return;
        offlineDocument=true;SetDocument(parsed,"Offline export · "+System.IO.Path.GetFileName(path));
    }
    async Task PromptRestartAsync(BiosImportResult result)
    {
        string message=result.Verified?"BIOS changes were imported and verified. Restart now to let firmware activate them?":"BIOS import completed, but some values were not confirmed. Review the import results. Restart now?";
        if(MessageBox.Show(Window.GetWindow(this),message+"\n\nSave your work first. Choose No to restart later.","Restart after BIOS import",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
        var restart=await RadeonSoftwareSlimmer.Optimize.ShellRunner.PowerShellAsync("& shutdown.exe /r /t 0; exit $LASTEXITCODE",null,15000);
        if(restart.ExitCode!=0)Report("Restart could not be requested. Restart Windows when ready. "+restart.Output);
    }
    void DocumentDrag(object sender,DragEventArgs e){e.Effects=!busy&&e.Data.GetDataPresent(DataFormats.FileDrop)?DragDropEffects.Copy:DragDropEffects.None;e.Handled=true;}
    static TextBlock Note(string text)=>new(){Text=text,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,4,0,8)};
    static Button ActionButton(string name,Action action){var button=new Button{Content=name,Margin=new Thickness(0,0,8,6),HorizontalAlignment=HorizontalAlignment.Left,Padding=new Thickness(10,4,10,4)};button.Click+=(_,_)=>action();return button;}
    void BuildFans()
    {
        if(FansHost==null||document==null)return;
        var panel=new StackPanel();FansHost.Content=panel;
        panel.Children.Add(ActionButton("Live fan control options",()=>System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://github.com/Rem0o/FanControl.Releases"){UseShellExecute=true})));
        panel.Children.Add(Note("Use Fan Control for supported live curves. The settings below edit firmware."));
        panel.Children.Add(Note("Exported headers do not confirm a connected fan. Curves show temperature (°C) and duty (%), not live RPM."));
        var headers=BiosFans.Discover(document);if(headers.Count==0){panel.Children.Add(Note("No recognized Q-Fan headers in this export."));return;}
        var chooser=new ComboBox{ItemsSource=headers,SelectedIndex=0,MinWidth=220,HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,0,0,10)};
        var content=new StackPanel();panel.Children.Add(chooser);panel.Children.Add(content);
        void Choice(Panel into,BiosSetting setting)
        {
            var row=new Grid{Margin=new Thickness(0,0,0,8)};row.ColumnDefinitions.Add(new(){Width=new GridLength(1,GridUnitType.Star)});row.ColumnDefinitions.Add(new(){Width=new GridLength(190)});
            var label=Note(setting.Name);label.ToolTip=setting.Help;row.Children.Add(label);
            var box=new ComboBox{ItemsSource=setting.Choices,DisplayMemberPath="Label",SelectedValuePath="Code",SelectedValue=setting.Proposed,IsEnabled=setting.Editable};Grid.SetColumn(box,1);row.Children.Add(box);
            box.SelectionChanged+=(_,_)=>{if(box.SelectedValue is string value)Stage(setting,value);};into.Children.Add(row);
        }
        void Selected()
        {
            content.Children.Clear();var header=(BiosFanHeader)chooser.SelectedItem;Choice(content,header.Mode);if(header.Profile!=null)Choice(content,header.Profile);
            var advanced=new StackPanel();foreach(var setting in header.Advanced)Choice(advanced,setting);content.Children.Add(new Expander{Header="Temperature source and response",Content=advanced,Margin=new Thickness(0,0,0,10)});
            if(header.Tables.Count==0){content.Children.Add(Note("This header does not expose a complete curve."));return;}
            content.Children.Add(Note(BiosFans.CurveRestriction));
            var tables=new TabControl();foreach(var table in header.Tables)
            {
                var body=new StackPanel();var canvas=new Canvas{Height=220,ClipToBounds=true,Margin=new Thickness(25,8,15,8)};canvas.SetResourceReference(BackgroundProperty,"Bg1");
                canvas.SizeChanged+=(_,_)=>{
                    canvas.Children.Clear();double w=Math.Max(1,canvas.ActualWidth-32),h=180;
                    for(int duty=0;duty<=100;duty+=25){double y=200-duty/100d*h;var line=new Line{X1=30,X2=w+30,Y1=y,Y2=y,Stroke=(Brush)FindResource("Divider")};canvas.Children.Add(line);var text=new TextBlock{Text=duty.ToString(),FontSize=10};Canvas.SetTop(text,y-8);canvas.Children.Add(text);}
                    var points=new Polyline{Stroke=(Brush)FindResource("Accent"),StrokeThickness=2};foreach(var point in table.Points.Where(p=>double.IsFinite(p.TemperatureValue)&&double.IsFinite(p.DutyValue)&&p.TemperatureValue>=0&&p.TemperatureValue<=120&&p.DutyValue>=0&&p.DutyValue<=100)){double x=30+point.TemperatureValue/120*w,y=200-point.DutyValue/100*h;points.Points.Add(new Point(x,y));var dot=new Ellipse{Width=7,Height=7,Fill=(Brush)FindResource("Accent"),ToolTip=$"P{point.Index}: {point.TemperatureValue}°C · {point.DutyValue}%"};Canvas.SetLeft(dot,x-3);Canvas.SetTop(dot,y-3);canvas.Children.Add(dot);}canvas.Children.Add(points);
                };body.Children.Add(canvas);body.Children.Add(Note("Temperature 0–120°C →  |  duty 0–100% ↑  · preview scale, not verified editing limits"));
                foreach(var point in table.Points)body.Children.Add(Note($"Point {point.Index}    {point.Temperature.CurrentLabel} °C    {point.Duty.CurrentLabel}%    · {point.Temperature.Token}/{point.Temperature.Offset} · {point.Duty.Token}/{point.Duty.Offset}"));
                tables.Items.Add(new TabItem{Header=table.Name,Content=body});
            }
            content.Children.Add(tables);
        }
        chooser.SelectionChanged+=(_,_)=>Selected();Selected();
    }
    string ProfileBoard=>detectedBoard==null?throw new InvalidOperationException("Motherboard identity unavailable."):BiosStore.BoardKey(detectedBoard);
    void BuildProfiles()
    {
        if(ProfilesHost==null||document==null||detectedBoard==null)return;
        var key=ProfileBoard;var saved=workspace.Store.Profiles(key).ToList();
        var panel=new StackPanel();ProfilesHost.Content=panel;
        var profileHeading=new WrapPanel{Margin=new Thickness(0,0,0,8)};
        if(detectedBoard.CpuBrand is string cpuBrand){var logo=new Image{Width=58,Height=32,Stretch=Stretch.Uniform,Margin=new Thickness(0,0,12,0),Source=new System.Windows.Media.Imaging.BitmapImage(new Uri($"pack://application:,,,/Rion Win 11;component/Assets/CpuVendors/{cpuBrand.ToLowerInvariant()}.png"))};System.Windows.Automation.AutomationProperties.SetName(logo,cpuBrand+" profile");profileHeading.Children.Add(logo);}
        profileHeading.Children.Add(ActionButton("Review Rion profile",()=>Recommendations_Click(this,new RoutedEventArgs())));profileHeading.Children.Add(Note((detectedBoard.CpuBrand??"Unknown CPU")+" · detected for this PC"));panel.Children.Add(profileHeading);
        panel.Children.Add(Note("Full snapshots include staged values. Loading only stages compatible editable differences; Apply imports them after review."));
        for(int index=0;index<saved.Count;index++)
        {
            int slot=index;var profile=saved[index];var row=new WrapPanel();var name=new TextBox{Text=profile?.Name??$"Profile {index+1}",Width=180,Height=32,MinHeight=0,FontSize=12,Padding=new Thickness(6,2,6,2),Margin=new Thickness(0,0,8,6)};row.Children.Add(name);
            row.Children.Add(ActionButton("Save",()=>Run(()=>{if(offlineDocument||workspace.Latest?.SchemaHash!=document.SchemaHash)throw new InvalidOperationException("Refresh this PC before saving a full board profile. Use Export for an offline file.");if(profile!=null&&MessageBox.Show("Replace this profile with the current staged configuration?","Save profile",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;saved[slot]=new(name.Text.Trim().Length==0?$"Profile {slot+1}":name.Text.Trim(),key,DateTime.UtcNow,document.Export());workspace.Store.SaveProfiles(key,saved);BuildProfiles();})));
            if(profile!=null)
            {
                row.Children.Add(ActionButton("Load",()=>Run(()=>{if(!ConfirmDiscard())return;Remember();BiosStore.StageSnapshot(document,profile,key);Refresh();BuildFans();Report("Profile staged: "+profile.Name);})));
                row.Children.Add(ActionButton("Rename",()=>Run(()=>{if(string.IsNullOrWhiteSpace(name.Text))return;saved[slot]=profile with{Name=name.Text.Trim()};workspace.Store.SaveProfiles(key,saved);BuildProfiles();})));
                row.Children.Add(Note(profile.TimestampUtc.ToLocalTime().ToString("g")));
            }
            panel.Children.Add(row);
        }
        panel.Children.Add(ActionButton("Add profile",()=>Run(()=>{saved.Add(null);workspace.Store.SaveProfiles(key,saved);BuildProfiles();})));
        var choices=saved.Where(p=>p!=null).Cast<BiosSavedProfile>().ToList();var left=new ComboBox{ItemsSource=choices,DisplayMemberPath="Name",Width=180,SelectedIndex=choices.Count>0?0:-1,Margin=new Thickness(0,0,8,6)};var right=new ComboBox{ItemsSource=choices,DisplayMemberPath="Name",Width=180,SelectedIndex=choices.Count>1?1:0,Margin=new Thickness(0,0,8,6)};
        var compare=new WrapPanel();compare.Children.Add(left);compare.Children.Add(right);compare.Children.Add(ActionButton("Compare profiles",()=>Run(()=>{if(left.SelectedItem is BiosSavedProfile a&&right.SelectedItem is BiosSavedProfile b)ShowDiff(new(a.Bytes),new(b.Bytes),a.Name+" → "+b.Name);})));compare.Children.Add(ActionButton("Compare with current",()=>Run(()=>{if(left.SelectedItem is BiosSavedProfile p)ShowDiff(new(p.Bytes),new(document.Export()),p.Name+" → current / staged");})));panel.Children.Add(compare);
    }
    void ShowDiff(BiosDocument left,BiosDocument right,string title){var grid=new DataGrid{ItemsSource=left.Compare(right),IsReadOnly=true,AutoGenerateColumns=true,CanUserAddRows=false};Dialog(title,grid).ShowDialog();}
}
