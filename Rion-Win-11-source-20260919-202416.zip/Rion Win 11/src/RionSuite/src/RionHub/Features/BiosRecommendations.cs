using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace RionHub.Features;

public sealed record BiosDraftEntry(string Name,string Target,string Note,string Category,string Risk,string[]? Aliases,bool ApplyToAll);
public sealed record BiosDraftSource(string Name,string Description,List<BiosDraftEntry> Entries);
public sealed class BiosSuggestion
{
    public bool Selected {get;set;}
    public string Name {get;init;}="";
    public string Current {get;init;}="";
    public string Proposed {get;init;}="";
    public string Risk {get;init;}="";
    public string Status {get;init;}="";
    public string Explanation {get;init;}="";
    public string Identity {get;init;}="";
    public string? Code {get;init;}
    public bool CanStage=>Code!=null&&Status=="Available for individual review";
}
public static class BiosRecommendations
{
    public static BiosDraftSource Source()=>Load("Rion-source-draft.json");
    public static BiosDraftSource SourceFor(MotherboardInfo? board)
    {
        if(board?.CpuBrand=="Intel")return Load("Rion-intel-review.json");
        var legacy=Source();
        BiosDraftEntry Baseline(string name,string target,string note)=>new(name,target,note,"CPU baseline","review",null,false);
        var baseline=new[]{
            Baseline("CPPC Dynamic Preferred Cores","Auto","Uses the current platform preference policy. This is an AM5-style enum, not the old AM4 CPPC enabled/disabled setting."),
            Baseline("Global C-state Control","Auto","Preserves firmware idle-state policy. Disabling idle states is a workload-specific power/latency experiment."),
            Baseline("DF Cstates","Auto","Uses firmware Data Fabric power policy; the exported help says Auto follows Global C-state control."),
            Baseline("Core Performance Boost","Auto","Preserves normal boost behavior. Duplicated fields remain unavailable until individually identified."),
            Baseline("SMT Control","Auto","Preserves firmware threading policy. Duplicated fields remain unavailable.")};
        return legacy with {Name="Rion AMD profile",Description="AMD review: firmware baseline plus individually selected source-draft experiments. No universal overclock is verified.",Entries=legacy.Entries.Concat(baseline).GroupBy(e=>Normal(e.Name)).Select(g=>g.Last()).ToList()};
    }
    private static BiosDraftSource Load(string file)
    {
        using var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("RionHub.Assets.Profiles."+file)??throw new InvalidDataException("Original BIOS draft profile is missing.");
        return JsonSerializer.Deserialize<BiosDraftSource>(stream,new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??throw new InvalidDataException("Invalid BIOS draft.");
    }
    private static string Normal(string text)=>Regex.Replace(text.Trim(),@"\s+"," ").ToUpperInvariant();
    private static string Choice(string text)=>Normal(text) switch{"ENABLE"=>"ENABLED","DISABLE"=>"DISABLED",var other=>other};
    private static bool Excluded(BiosDraftEntry entry)=>entry.Category=="Preserve / inspect"||entry.Category!="CPU baseline"&&Regex.IsMatch(entry.Name,@"(?i)curve optimizer|PBO|precision boost|FCLK|SOC|SMEE|TSME|ECC|scrub|poison|encryption|speculativ|Q-Fan|Fan Profile|Pump Profile|Ai Overclock|A-XMP|SVM|ACS Enable|SMT|CPPC");
    public static IReadOnlyList<BiosSuggestion> Resolve(BiosDocument document,MotherboardInfo? board)
    {
        bool known=board?.CpuBrand is "AMD" or "Intel";var source=SourceFor(board);
        return source.Entries.Select(entry=>
        {
            var names=new[]{entry.Name}.Concat(entry.Aliases??[]).Select(Normal).ToHashSet();
            var found=document.Settings.Where(s=>names.Contains(Normal(s.Name))).ToArray();
            var setting=found.Length==1?found[0]:null;var choices=setting?.Choices.Where(c=>Choice(c.Label)==Choice(entry.Target)).ToArray()??[];
            string status=!known?"CPU vendor unavailable; profile actions blocked":Excluded(entry)?"Excluded from profile actions":found.Length==0?"Not exported":found.Length>1?"Ambiguous — select exact field manually":!setting!.Editable?setting.Restriction:choices.Length!=1?"Target encoding not uniquely exported":setting.Current==choices[0].Code?"Already matches":"Available for individual review";
            return new BiosSuggestion{Name=entry.Name,Current=setting?.CurrentLabel??"—",Proposed=entry.Target,Risk=entry.Risk=="experimental"?"Experimental":"Review",Status=status,Identity=setting?.Id??"",Code=status=="Available for individual review"?choices[0].Code:null,
                Explanation=source.Description+" "+entry.Note+(entry.ApplyToAll?" Source applyToAll is deliberately not executed; every target requires unique identity.":"")};
        }).ToArray();
    }
    public static void Stage(BiosDocument document,MotherboardInfo? board,IEnumerable<BiosSuggestion> selection,bool experimentalConsent)
    {
        var selected=selection.Where(s=>s.Selected).ToArray();if(selected.Length==0)throw new InvalidOperationException("Select individual available entries first.");
        var resolved=Resolve(document,board);
        var clone=new BiosDocument(document.Original); // Validate all before changing the working copy.
        foreach(var entry in selected)
        {
            var current=resolved.SingleOrDefault(s=>s.Name==entry.Name&&s.Identity==entry.Identity&&s.Code==entry.Code);
            if(current==null||!current.CanStage||current.Risk=="Experimental"&&!experimentalConsent)throw new InvalidOperationException("Selection is stale, excluded or requires explicit experimental review: "+entry.Name);
            clone.Set(clone.Settings.Single(s=>s.Id==entry.Identity),entry.Code!);
        }
        foreach(var entry in selected)document.Set(document.Settings.Single(s=>s.Id==entry.Identity),entry.Code!);
    }
}
public static class MotherboardBrand
{
    private static readonly string[] Brands=["ASRock","ASUS","MSI","Gigabyte","EVGA","Biostar","Supermicro","Dell","HP","Lenovo","Acer","Fujitsu","Intel","Tyan","Shuttle","NZXT"];
    public static string Name(string manufacturer)
    {
        if(manufacturer.Contains("ASUSTeK",StringComparison.OrdinalIgnoreCase))return "ASUS";
        if(manufacturer.Contains("Micro-Star",StringComparison.OrdinalIgnoreCase))return "MSI";
        if(manufacturer.Contains("Hewlett",StringComparison.OrdinalIgnoreCase))return "HP";
        return Brands.FirstOrDefault(b=>manufacturer.Contains(b,StringComparison.OrdinalIgnoreCase))??"Board";
    }
}
