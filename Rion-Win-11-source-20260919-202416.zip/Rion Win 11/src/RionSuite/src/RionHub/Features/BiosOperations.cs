using System.IO;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using RadeonSoftwareSlimmer.Optimize;

namespace RionHub.Features;

public sealed record BiosImportSettingResult(string Identity,string Setting,string Requested,string? Actual,bool Verified);
public sealed record BiosImportResult(bool Verified, BiosDocument Actual, string Directory, string Message)
{
    public IReadOnlyList<BiosImportSettingResult> Settings {get;init;}=Array.Empty<BiosImportSettingResult>();
}

public static class BiosOperations
{
    public const string Documentation = "https://github.com/ab3lkaizen/SCEHUB";
    private static readonly SemaphoreSlim Gate = new(1,1);
    private static readonly Dictionary<string,string> Files = new()
    {
        ["Export.bat"]="283D6EA32F1AA30985DC7FF1564E345EF62CA8193D764418B3031BBBA82BB7DA",
        ["Import.bat"]="DC0F3E8F2D484742469D768266CA833FE7330D618770B628BCBAEB6BB40DF6FD",
        ["SCEWIN_64.exe"]="2D78E7BB62FCAB44C54FE853F51E8836ADA45EA374027423BCB6D7A5DB46502B",
        ["amifldrv64.sys"]="E7CBFB16261DE1C7F009431D374D90E9EB049BA78246E38BC4C8B9E06F324B6F",
        ["amigendrv64.sys"]="FFC72F0BDE21BA20AA97BEE99D9E96870E5AA40CCE9884E44C612757F939494F"
    };
    public static string? LastScanDirectory { get; private set; }
    public static bool FirmwareWriteActive {get;private set;}
    public static event Action<bool>? FirmwareWriteStateChanged;
    private static string Ps(string text) => "'"+text.Replace("'","''")+"'";
    private static string Prepare()
    {
        if(!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))
            throw new InvalidOperationException("Administrator rights are required to run the firmware utility.");
        string folder=Path.Combine(UtilityPackage.DataRoot,"BIOS",DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        foreach(var (name,hash) in Files)
        {
            string source=UtilityPackage.Resolve("scewin/"+name);
            using var stream=File.OpenRead(source);
            if(Convert.ToHexString(SHA256.HashData(stream))!=hash) throw new InvalidDataException("SCEWIN package file failed verification: "+name);
            File.Copy(source,Path.Combine(folder,name));
        }
        return folder;
    }
    private static async Task<string> Run(string folder, string script, Action<string>? progress=null,CancellationToken cancellation=default)
    {
        // Only fixed, hash-verified batch files may execute. NUL satisfies their final pause.
        string command="$ErrorActionPreference='Stop'; Set-Location -LiteralPath "+Ps(folder)+"; & $env:ComSpec /d /c "+Ps(script+" <nul")+"; exit $LASTEXITCODE";
        bool writing=script=="Import.bat";
        if(writing){FirmwareWriteActive=true;FirmwareWriteStateChanged?.Invoke(true);}
        ShellRunner.Result result;
        try{result=await ShellRunner.PowerShellAsync(command,progress,writing?0:300000,writing?CancellationToken.None:cancellation);}
        finally{if(writing){FirmwareWriteActive=false;FirmwareWriteStateChanged?.Invoke(false);}}
        string log=File.Exists(Path.Combine(folder,"log-file.txt")) ? await File.ReadAllTextAsync(Path.Combine(folder,"log-file.txt")) : "";
        await File.WriteAllTextAsync(Path.Combine(folder,DateTime.UtcNow.ToString("yyyyMMdd-HHmmssfff")+"-"+script+".output.txt"),result.Output+Environment.NewLine+log);
        progress?.Invoke(log);
        if(result.TimedOut || result.ExitCode!=0 || System.Text.RegularExpressions.Regex.IsMatch(log,@"(?i)ERROR:|unable to|failed|error in writing|BIOS not compatible|does not have setup questions"))
            throw new IOException("Firmware operation failed or is unverified. Inspect "+folder+Environment.NewLine+log);
        return log;
    }
    private static async Task<MotherboardInfo> CheckCompatibility()
    {
        var board=await MotherboardInfo.DetectAsync();
        if(!board.BiosVendor.Contains("American Megatrends",StringComparison.OrdinalIgnoreCase)&&!board.BiosVendor.Equals("AMI",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("AMI firmware could not be verified. Detected firmware vendor: "+board.BiosVendor+". SCEWIN execution is blocked.");
        return board;
    }
    public static async Task<BiosDocument> ScanAsync(Action<string>? progress=null,CancellationToken cancellation=default)
    {
        await Gate.WaitAsync(cancellation);
        try
        {
            progress?.Invoke("Checking AMI firmware compatibility and package identity…");await CheckCompatibility();cancellation.ThrowIfCancellationRequested();
            string folder=await Task.Run(Prepare,cancellation);
            progress?.Invoke("Exporting current NVRAM…");await Run(folder,"Export.bat",progress,cancellation);
            string path=Path.Combine(folder,"nvram.txt");
            if(!File.Exists(path)) throw new IOException("No fresh nvram.txt was exported. Check firmware prerequisites and logs.");
            var document=new BiosDocument(await File.ReadAllBytesAsync(path));
            File.Copy(path,Path.Combine(folder,"original-nvram.txt"));
            document.IsLiveScan=true;LastScanDirectory=folder; return document;
        }
        finally {Gate.Release();}
    }
    public static async Task<BiosImportResult> ImportAsync(BiosDocument document,Action<string>? progress=null,CancellationToken cancellation=default)
    {
        if(!document.IsLiveScan)throw new InvalidOperationException("Firmware import requires a live scan from this session. Saved exports and previews cannot write firmware; scan first, then load reviewed changes.");
        await Gate.WaitAsync(cancellation);
        try
        {
            if(!document.Settings.Any(s=>s.Changed)) throw new InvalidOperationException("No BIOS changes selected.");
            progress?.Invoke("Checking compatibility…");var board=await CheckCompatibility();
            var prerequisites=document.Prerequisites();
            bool asus=board.Manufacturer.Contains("ASUS",StringComparison.OrdinalIgnoreCase)||board.Manufacturer.Contains("ASUSTeK",StringComparison.OrdinalIgnoreCase),asrock=board.Manufacturer.Contains("ASRock",StringComparison.OrdinalIgnoreCase);
            if(prerequisites.Any(p=>p.State=="Needs firmware setup"||(asus||(asrock&&p.Name.Contains("Password")))&&p.State!="Verified in this export"))
                throw new InvalidOperationException("Firmware prerequisites are not verified in this export. Configure them in firmware and scan again.");
            string folder=await Task.Run(Prepare);
            progress?.Invoke("Exporting a fresh baseline and reconciling staged values…");await Run(folder,"Export.bat",progress,cancellation);
            string path=Path.Combine(folder,"nvram.txt");
            var fresh=new BiosDocument(await File.ReadAllBytesAsync(path));
            // Export timestamps vary. Compare the complete parsed identity/value inventory.
            if(fresh.SchemaHash!=document.SchemaHash || !fresh.Settings.Select(s=>(s.Id,s.Current)).SequenceEqual(document.Settings.Select(s=>(s.Id,s.Current))))
                throw new InvalidOperationException("Firmware state changed since inspection. A fresh export is retained; scan and review again.");
            File.Copy(path,Path.Combine(folder,"original-nvram.txt"));
            fresh.LoadProfile(document.Profile("pending"));
            cancellation.ThrowIfCancellationRequested();
            progress?.Invoke("Saving reviewed nvram.txt; immutable baseline retained…");
            string pending=Path.Combine(folder,"pending-nvram.txt");await File.WriteAllBytesAsync(pending,fresh.Export(),cancellation);File.Replace(pending,path,null);
            await File.WriteAllTextAsync(Path.Combine(folder,"journal.txt"),"Import started "+DateTime.UtcNow.ToString("O"));
            cancellation.ThrowIfCancellationRequested();
            progress?.Invoke("Importing firmware values. Active writes cannot be cancelled or forcibly terminated.");document.IsLiveScan=false;await Run(folder,"Import.bat",progress);
            document.IsLiveScan=false;
            File.Copy(path,Path.Combine(folder,"requested-nvram.txt"));
            File.Move(path,Path.Combine(folder,"imported-nvram.txt"));
            progress?.Invoke("Import completed; re-exporting to verify requested values…");await Run(folder,"Export.bat",progress);
            var actual=new BiosDocument(await File.ReadAllBytesAsync(path));
            bool verified=document.Settings.Where(s=>s.Changed).All(s=>actual.Settings.Any(a=>a.Id==s.Id && a.Current==s.Proposed));
            string result=verified ? "Applied and verified in the re-export. Firmware/hardware behavior is not validated; a restart may be required." : "Partially applied or verification pending: some requested values were not read back. A restart may be required; no automatic retry.";
            await File.AppendAllTextAsync(Path.Combine(folder,"journal.txt"),Environment.NewLine+result);
            actual.IsLiveScan=true;LastScanDirectory=folder;return new(verified,actual,folder,result+Environment.NewLine+"Original export and logs: "+folder)
            {Settings=document.Settings.Where(s=>s.Changed).Select(s=>{var found=actual.Settings.SingleOrDefault(a=>a.Id==s.Id);return new BiosImportSettingResult(s.Id,s.Name,s.Proposed,found?.Current,found?.Current==s.Proposed);}).ToArray()};
        }
        finally {Gate.Release();}
    }
}
