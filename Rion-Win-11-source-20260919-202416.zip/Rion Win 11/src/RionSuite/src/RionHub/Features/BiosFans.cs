using System.Text.RegularExpressions;
using System.Globalization;
namespace RionHub.Features;

public sealed record BiosFanPoint(int Index, BiosSetting Temperature, BiosSetting Duty)
{
    public double TemperatureValue=>double.TryParse(Temperature.Proposed,NumberStyles.Float,CultureInfo.InvariantCulture,out var v)?v:double.NaN;
    public double DutyValue=>double.TryParse(Duty.Proposed,NumberStyles.Float,CultureInfo.InvariantCulture,out var v)?v:double.NaN;
}
public sealed record BiosFanTable(string Name,IReadOnlyList<BiosFanPoint> Points,string Reason);
public sealed record BiosFanHeader(string Name,BiosSetting Mode,BiosSetting? Profile,IReadOnlyList<BiosSetting> Advanced,IReadOnlyList<BiosFanTable> Tables)
{
    public override string ToString()=>Name;
}
public static class BiosFans
{
    public const string CurveRestriction="Curve preview only: control-mode table and operating limits are not verified for this firmware.";
    public static IReadOnlyList<BiosFanHeader> Discover(BiosDocument document)
    {
        var result=new List<BiosFanHeader>();
        var settings=document.Settings;
        for(int i=0;i<settings.Count;i++)
        {
            var match=Regex.Match(settings[i].Name,@"^(?<header>.+) Q-Fan Control$",RegexOptions.IgnoreCase);if(!match.Success)continue;
            string name=match.Groups["header"].Value;int end=i+1;
            while(end<settings.Count&&!settings[end].Name.EndsWith("Q-Fan Control",StringComparison.OrdinalIgnoreCase))end++;
            var block=settings.Skip(i+1).Take(end-i-1).ToArray();
            var pointFields=new Dictionary<(int Point,bool Duty),List<BiosSetting>>();
            foreach(var field in block.Where(s=>Regex.IsMatch(s.Name,@"^(CPU Fan|Chassis Fan \d+|AIO Pump|Water Pump\+) ",RegexOptions.IgnoreCase)))
            {
                var suffix=Regex.Replace(field.Name,@"^(CPU Fan|Chassis Fan \d+|AIO Pump|Water Pump\+) ","",RegexOptions.IgnoreCase);var p=Regex.Match(suffix,@"^Point(\d+) (Temperature|Duty Cycle)");int point=0;bool duty=false;
                if(p.Success){point=int.Parse(p.Groups[1].Value);duty=p.Groups[2].Value=="Duty Cycle";}
                else if(suffix.StartsWith("Lower Temperature")||suffix.StartsWith("Min Duty")){point=1;duty=suffix.StartsWith("Min");}
                else if(suffix.StartsWith("Middle Temperature")||suffix.StartsWith("Middle Duty")){point=2;duty=suffix.Contains("Duty");}
                else if(suffix.StartsWith("Upper Temperature")||suffix.StartsWith("Max. Duty")){point=3;duty=suffix.StartsWith("Max.");}
                if(point==0)continue;
                if(!pointFields.TryGetValue((point,duty),out var list))pointFields[(point,duty)]=list=new();list.Add(field);
            }
            var tables=new List<BiosFanTable>();int count=pointFields.Count==0?0:pointFields.Values.Max(l=>l.Count);
            for(int table=0;table<count;table++)
            {
                var points=new List<BiosFanPoint>();
                foreach(int n in pointFields.Keys.Select(k=>k.Point).Distinct().Order())
                    if(pointFields.TryGetValue((n,false),out var temperatures)&&pointFields.TryGetValue((n,true),out var duties)&&table<temperatures.Count&&table<duties.Count)points.Add(new(n,temperatures[table],duties[table]));
                tables.Add(new("Exported table "+(table+1)+(points.Any(p=>!p.Temperature.Name.StartsWith(name+" "))?" · mixed firmware labels":""),points,CurveRestriction));
            }
            // Table occurrence is used only to visualize unverified exports, never to select write targets.
            var advanced=block.Where(s=>s.HasChoices&&(s.Name.StartsWith(name+" ")||s.Name.StartsWith("Temperature Source ")||s.Name=="Allow Fan Stop")&&!s.Name.EndsWith(" Profile")).ToArray();
            result.Add(new(name,settings[i],block.FirstOrDefault(s=>s.Name==name+" Profile"),advanced,tables));
        }
        return result;
    }
}
