using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace RionHub.Features;

public sealed record BiosChoice(string Code, string Label, int StarPosition, bool Selected)
{
    public override string ToString() => $"[{Code}] {Label}";
}
public sealed class BiosSetting : RionHub.ObservableObject
{
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public string Help { get; init; } = "";
    public string Token { get; init; } = "";
    public string Offset { get; init; } = "";
    public string Width { get; init; } = "";
    public string Context { get; init; } = "";
    public string Format { get; init; } = "decimal";
    public decimal? Minimum { get; init; }
    public decimal? Maximum { get; init; }
    public decimal? Step { get; init; }
    public string ValueGuidance => HasChoices ? "Exported firmware choices" : Format=="string" ? "Printable ASCII text; size limited by exported UTF-16 field width" : $"{Format} value; {Width}-byte field"+(Minimum.HasValue?$"; minimum {Minimum}":"")+(Maximum.HasValue?$"; maximum {Maximum}":"")+(Step.HasValue?$"; step {Step}":"")+(Minimum.HasValue&&Maximum.HasValue?"":". Firmware does not export complete semantic limits; field width alone is not a safe operating range.");
    public string Current { get; init; } = "";
    private string proposed="";
    public string Proposed { get=>proposed; set { if(Set(ref proposed,value)){Raise(nameof(Changed));Raise(nameof(ProposedLabel));} } }
    public string Restriction { get; set; } = "";
    public bool Editable => Restriction.Length == 0;
    public List<BiosChoice> Choices { get; init; } = [];
    public bool HasChoices => Choices.Count > 0;
    public int ValuePosition { get; init; }
    public int ValueLength { get; init; }
    public bool Changed => Proposed != Current;
    public string CurrentLabel => Choices.FirstOrDefault(c=>c.Code==Current)?.Label ?? (Current.Length==0?"Not exported":Current);
    public string ProposedLabel => Changed ? Choices.FirstOrDefault(c=>c.Code==Proposed)?.Label ?? Proposed : "—";
}
public sealed record BiosPrerequisite(string Name, string Required, string Observed, string State, string Instructions);
public sealed record BiosProfile(string Name, string SchemaHash, Dictionary<string, string> Values)
{
    public int SchemaVersion { get; init; }=2;
    public string SourceHash { get; init; }="";
    public Dictionary<string,string> OriginalValues { get; init; }=[];
    public string Description { get; init; }="Staged settings only. Review each change against this board and firmware before import.";
}
public sealed record BiosDifference(string Setting,string Identity,string Before,string After,string State);

public sealed class BiosDocument
{
    public byte[] Original { get; }
    public string Hash => Convert.ToHexString(SHA256.HashData(Original));
    public string SchemaHash { get; }
    public List<BiosSetting> Settings { get; } = [];
    public bool IsLiveScan {get;internal set;}
    private readonly Encoding encoding;
    private readonly byte[] preamble;
    private readonly string text;
    private static readonly Regex Heads = new(@"(?mi)^[ \t]*(?<comment>(?://|#|;)[ \t]*)?Setup[ \t]+Question[ \t]*=[ \t]*(?<name>[^\r\n]+)");
    private static string Identifier(string raw){var value=raw.StartsWith("0x",StringComparison.OrdinalIgnoreCase)?raw[2..]:raw;value=value.TrimStart('0').ToUpperInvariant();return value.Length==0?"0":value;}
    private static string Field(string block, string field) => Regex.Match(block, @"(?mi)^[ \t]*" + Regex.Escape(field) + @"[ \t]*=[ \t]*(?<v>[^\r\n]*?)(?:[ \t]*//[^\r\n]*)?\r?$", RegexOptions.None).Groups["v"].Value.Trim();
    public BiosDocument(byte[] bytes)
    {
        if (bytes.Length == 0 || bytes.Length > 20 * 1024 * 1024) throw new InvalidDataException("Choose a nonempty SCEWIN text export under 20 MB.");
        Original = (byte[])bytes.Clone();
        if (bytes.AsSpan().StartsWith(new byte[] {255,254})) { encoding = new UnicodeEncoding(false, false, true); preamble = [255,254]; }
        else if (bytes.AsSpan().StartsWith(new byte[] {254,255})) { encoding = new UnicodeEncoding(true, false, true); preamble = [254,255]; }
        else if (bytes.AsSpan().StartsWith(new byte[] {239,187,191})) { encoding = new UTF8Encoding(false, true); preamble = [239,187,191]; }
        else
        {
            preamble=[];int length=Math.Min(bytes.Length-bytes.Length%2,512);int even=0,odd=0;
            for(int i=0;i<length;i+=2){if(bytes[i]==0)even++;if(bytes[i+1]==0)odd++;}
            if(length>=20&&odd>length*.25&&even<length*.05)encoding=new UnicodeEncoding(false,false,true);
            else if(length>=20&&even>length*.25&&odd<length*.05)encoding=new UnicodeEncoding(true,false,true);
            else
            {
                try{encoding=new UTF8Encoding(false,true);encoding.GetString(bytes);}
                catch(DecoderFallbackException){Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);encoding=Encoding.GetEncoding(1252,EncoderFallback.ExceptionFallback,DecoderFallback.ExceptionFallback);}
            }
        }
        text = encoding.GetString(bytes, preamble.Length, bytes.Length - preamble.Length);
        if (text.Contains('\0')) throw new InvalidDataException("Unrecognized text encoding; a BIOS binary is not an NVRAM text export.");
        var heads = Heads.Matches(text);
        if (heads.Count == 0 || heads.Count > 15000) throw new InvalidDataException("No supported Setup Question blocks, or too many blocks. Check Publish HII Resources in firmware.");
        for (int i = 0; i < heads.Count; i++)
        {
            var head = heads[i]; int end = i + 1 < heads.Count ? heads[i + 1].Index : text.Length;
            var block = text[head.Index..end];
            string name = head.Groups["name"].Value.Split("//")[0].Trim();
            var choices = new List<BiosChoice>();
            foreach (Match option in Regex.Matches(block, @"(?mi)^(?<prefix>[ \t]*(?:Options[ \t]*=[ \t]*)?)(?<star>\*?)[ \t]*\[(?<code>[0-9a-f]+)\](?<label>[^\r\n]*)"))
                choices.Add(new(option.Groups["code"].Value.ToUpperInvariant(), option.Groups["label"].Value.Split("//")[0].Trim(), head.Index + option.Groups["star"].Index, option.Groups["star"].Length == 1));
            var numeric = Regex.Matches(block, "(?mi)^[ \\t]*Value[ \\t]*=[ \\t]*(?:<(?<decimal>-?[0-9]+)>|(?:0x)?(?<hex>[0-9a-f]+)|\"(?<string>[^\"\\r\\n]*)\")[ \\t]*(?://[^\\r\\n]*)?\\r?$");
            string format=numeric.Count==1 ? new[]{"decimal","hex","string"}.Single(k=>numeric[0].Groups[k].Success) : "decimal";
            var valueGroup=numeric.Count==1?numeric[0].Groups[format]:null;
            string token = Field(block, "Token"), offset = Field(block, "Offset"), width = Field(block, "Width");
            string context=string.Join(" / ",new[]{"VarStore","VarStoreId","FormId","FormSet","Section"}.Where(k=>Field(block,k).Length>0).Select(k=>k+"="+Field(block,k)));
            string id = $"{Identifier(token)}|{Identifier(offset)}|{Identifier(width)}|{name}"+(context.Length>0?"|"+context:"");
            string current = choices.FirstOrDefault(c => c.Selected)?.Code ?? valueGroup?.Value ?? "";
            decimal? Bound(string key)=>decimal.TryParse(Field(block,key),NumberStyles.Integer,CultureInfo.InvariantCulture,out var bound)?bound:null;
            var minimum=Bound("Minimum")??Bound("Min");var maximum=Bound("Maximum")??Bound("Max");var step=Bound("Step");
            string restriction = head.Groups["comment"].Success ? "Commented/read-only firmware entry" : "";
            if (!Regex.IsMatch(token,@"\A(?:0x)?[0-9a-fA-F]+\z") || !Regex.IsMatch(offset,@"\A(?:0x)?[0-9a-fA-F]+\z") || !int.TryParse(width, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out int size) || size < 1 || size > (format=="string"?4096:8)) restriction = "Missing or unsupported firmware identity/width";
            if (choices.Count == 0 && numeric.Count != 1) restriction = "Unsupported value encoding";
            if (choices.Count > 0 && (choices.Count(c => c.Selected) != 1 || choices.Select(c => Identifier(c.Code)).Distinct().Count() != choices.Count || numeric.Count > 0)) restriction = "Ambiguous value/options";
            if(new[]{"Token","Offset","Width","Value","Options"}.Any(key=>Regex.Matches(block,@"(?mi)^[ \t]*"+key+@"[ \t]*=").Count>1))restriction="Duplicate identity/value fields";
            if(minimum>maximum||step<=0)restriction="Invalid exported numeric constraints";
            if (Regex.IsMatch(name, @"(?i)password|secure boot|tpm|rollback|flash|bios lock|publish hii")) restriction = "Protected prerequisite/security setting; inspect and change through firmware setup";
            if (Regex.IsMatch(name,@"(?i)^(?:CPU Fan|Chassis Fan \d+|AIO Pump|Water Pump\+) (?:Point\d+ (?:Temperature|Duty Cycle)|(?:Upper|Middle|Lower) Temperature|(?:Max\.|Middle|Min) Duty)")) restriction=BiosFans.CurveRestriction;
            Settings.Add(new() { Id=id, Name=name, Help=Field(block,"Help String"), Token=token, Offset=offset, Width=width,
                Current=current, Proposed=current, Restriction=restriction, Choices=choices,Context=context,Format=format,Minimum=minimum,Maximum=maximum,Step=step,
                ValuePosition=valueGroup!=null ? head.Index + valueGroup.Index : 0, ValueLength=valueGroup?.Length??0 });
        }
        foreach (var group in Settings.GroupBy(s => s.Id).Where(g => g.Count() > 1)) foreach (var s in group) s.Restriction = "Duplicate firmware identity; edit blocked";
        SchemaHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Field(text,"HIICrc32")+"\n"+string.Join('\n', Settings.Select(s => s.Id + ":"+s.Format+":"+s.Minimum+":"+s.Maximum+":"+s.Step+":"+s.Restriction+":" + string.Join(',', s.Choices.Select(c => c.Code+"="+c.Label)))))));
    }
    public void Set(BiosSetting setting, string value)
    {
        if (!Settings.Contains(setting) || !setting.Editable) throw new InvalidOperationException(setting.Restriction);
        if (setting.Choices.Count > 0)
        { if (!setting.Choices.Any(c => c.Code == value)) throw new ArgumentException("Choose an exported option code."); }
        else if(setting.Format=="string")
        {
            int length=int.Parse(setting.Width,NumberStyles.HexNumber)/2-1;
            if(value.Length>length||value.Length<setting.Minimum||value.Length>setting.Maximum||value.Any(c=>c<' '||c>'~'||c=='"'))throw new ArgumentException($"Use up to {Math.Max(0,length)} printable ASCII characters without quotation marks, within any exported length bounds.");
        }
        else
        {
            int width = int.Parse(setting.Width, NumberStyles.HexNumber);
            decimal number;
            if(setting.Format=="hex")
            {
                if(!ulong.TryParse(value.StartsWith("0x",StringComparison.OrdinalIgnoreCase)?value[2..]:value,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out var hex))throw new ArgumentException("Enter a hexadecimal whole number.");
                number=hex;value=hex.ToString("X",CultureInfo.InvariantCulture);
            }
            else if(!decimal.TryParse(value,NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out number))throw new ArgumentException("Enter a decimal whole number.");
            bool signed=setting.Current.StartsWith('-')||setting.Minimum<0;
            decimal max=signed?(decimal)Math.Pow(2,width*8-1)-1:width==8?ulong.MaxValue:(decimal)(1UL<<(width*8))-1;
            decimal min=signed?-(decimal)Math.Pow(2,width*8-1):0;
            if(number<min||number>max||number<setting.Minimum||number>setting.Maximum||(setting.Step is decimal stride&&(number-(setting.Minimum??0))%stride!=0))throw new ArgumentException("Value is outside the exported width, range or step.");
            if(setting.Format=="decimal")value=number.ToString(CultureInfo.InvariantCulture);
        }
        setting.Proposed = value;
    }
    public byte[] Export()
    {
        var edits = new List<(int Position, int Length, string Value)>();
        foreach (var s in Settings.Where(s => s.Changed))
        {
            Set(s, s.Proposed);
            if (s.Choices.Count == 0) edits.Add((s.ValuePosition, s.ValueLength, s.Proposed));
            else foreach (var c in s.Choices)
            { if (c.Selected) edits.Add((c.StarPosition, 1, "")); if (c.Code == s.Proposed) edits.Add((c.StarPosition, 0, "*")); }
        }
        if (edits.Count == 0) return (byte[])Original.Clone();
        var builder = new StringBuilder(text);
        foreach (var edit in edits.OrderByDescending(e => e.Position)) builder.Remove(edit.Position, edit.Length).Insert(edit.Position, edit.Value);
        return preamble.Concat(encoding.GetBytes(builder.ToString())).ToArray();
    }
    public void Revert() { foreach (var s in Settings) s.Proposed = s.Current; }
    public BiosProfile Profile(string name) => new(name, SchemaHash, Settings.Where(s => s.Changed).ToDictionary(s => s.Id, s => s.Proposed)){SourceHash=Hash,OriginalValues=Settings.Where(s=>s.Changed).ToDictionary(s=>s.Id,s=>s.Current)};
    public void LoadProfile(BiosProfile profile)
    {
        if (profile.SchemaVersion!=2||profile.Values==null||profile.Values.Count>15000||profile.SchemaHash != SchemaHash) throw new InvalidDataException("Profile belongs to a different or unsupported export schema/firmware. No changes applied.");
        var proposed = new BiosDocument(Original);
        foreach (var entry in profile.Values) proposed.Set(proposed.Settings.Single(s => s.Id == entry.Key), entry.Value);
        foreach (var s in proposed.Settings.Where(s => s.Changed)) Set(Settings.Single(x => x.Id == s.Id), s.Proposed);
    }
    public IReadOnlyList<BiosDifference> Compare(BiosDocument other)
    {
        var result=new List<BiosDifference>();
        var leftGroups=Settings.GroupBy(s=>s.Id).ToDictionary(g=>g.Key,g=>g.ToArray());
        var rightGroups=other.Settings.GroupBy(s=>s.Id).ToDictionary(g=>g.Key,g=>g.ToArray());
        foreach(var group in Settings.Concat(other.Settings).GroupBy(s=>s.Id))
        {
            var left=leftGroups.GetValueOrDefault(group.Key)??[];var right=rightGroups.GetValueOrDefault(group.Key)??[];
            string state=left.Length>1||right.Length>1?"Ambiguous identity":left.Length==0?"Added":right.Length==0?"Removed":TypedValue(left[0])!=TypedValue(right[0])?"Changed":"Same";
            if(state!="Same")result.Add(new(group.First().Name,group.Key,left.Length==1?left[0].CurrentLabel:"—",right.Length==1?right[0].CurrentLabel:"—",state));
        }
        return result;
    }
    private static string TypedValue(BiosSetting setting)
    {
        if(setting.HasChoices)return "option:"+Identifier(setting.Current);
        if(setting.Format=="hex"&&ulong.TryParse(setting.Current,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out var hex))return "number:"+hex.ToString(CultureInfo.InvariantCulture);
        if(setting.Format=="decimal"&&decimal.TryParse(setting.Current,NumberStyles.Integer,CultureInfo.InvariantCulture,out var number))return "number:"+number.ToString(CultureInfo.InvariantCulture);
        return setting.Format+":"+setting.Current;
    }
    public IReadOnlyList<BiosPrerequisite> Prerequisites() =>
    [
        Check("Publish HII Resources", "Enabled / On", ["Enabled","Enable","On"], "ASUS: Setup → Tool → Publish HII Resources. Save and reboot, then scan again."),
        Check("Password Protection of Runtime Variables", "Disabled / Off", ["Disabled","Disable","Off"], "Applicable ASUS/ASRock: Setup → Advanced → UEFI Variables Protection. Save and reboot, then scan again.")
    ];
    private BiosPrerequisite Check(string name, string required, string[] allowed, string instructions)
    {
        var found = Settings.Where(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToArray();
        string observed = found.Length == 1 ? found[0].Choices.FirstOrDefault(c => c.Code == found[0].Current)?.Label ?? "Unrecognized" : "Not verifiable from this export";
        return new(name, required, observed, allowed.Contains(observed, StringComparer.OrdinalIgnoreCase) ? "Verified in this export" : found.Length == 1 ? "Needs firmware setup" : "Unknown", instructions);
    }
}
