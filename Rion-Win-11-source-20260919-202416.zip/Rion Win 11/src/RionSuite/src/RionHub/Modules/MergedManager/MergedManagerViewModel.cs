using Aldx.Views;
using RadeonSoftwareSlimmer.ViewModels.Wizard;
using RadeonSoftwareSlimmer.Views;
using AdrenalineVm = Aldx.ViewModels.ShellViewModel;   // distinct from RionHub.ShellViewModel (the shell)

namespace RionHub.Modules.MergedManager;

/// <summary>
/// AMD GPU Manager = the former "Rions AMD GPU Driver Tool" and "ALDX" behind one nav group.
/// Composes both original view-models unchanged — <see cref="WizardViewModel"/> for the driver
/// flow and <see cref="Aldx.ViewModels.ShellViewModel"/> for Better Adrenaline — and owns one
/// cached content view for each. The shell's nav tree drives which is shown.
/// </summary>
public sealed class MergedManagerViewModel : ObservableObject
{
    private WizardViewModel? _wizard;
    private AdrenalineVm? _adrenaline;
    private DriverToolContentView? _driverContent;
    private AdrenalineSectionView? _adrenalineContent;

    public event Action? MonitorWindowRequested;

    public WizardViewModel Wizard
    {
        get
        {
            if (_wizard == null)
            {
                _wizard = new WizardViewModel();
                _wizard.MonitorWindowRequested += () => MonitorWindowRequested?.Invoke();
            }
            return _wizard;
        }
    }
    public AdrenalineVm Adrenaline => _adrenaline ??= new AdrenalineVm();

    /// <summary>Driver-tool content pane (step header + body + Back/Next + message strip).</summary>
    public DriverToolContentView DriverContent => _driverContent ??= new DriverToolContentView { DataContext = Wizard };

    /// <summary>Better Adrenaline section body (System / Display / Performance / Overclocking).</summary>
    public AdrenalineSectionView AdrenalineContent => _adrenalineContent ??= new AdrenalineSectionView { DataContext = Adrenaline };

    public void SelectStep(WizardStepViewModel step) => Wizard.JumpCommand.Execute(step);

    public void SelectPostInstall() => Wizard.ShowPostInstallToolCommand.Execute(null);

    public void SelectSection(Aldx.ViewModels.TabVm tab) => Adrenaline.SelectedTab = tab;
}
