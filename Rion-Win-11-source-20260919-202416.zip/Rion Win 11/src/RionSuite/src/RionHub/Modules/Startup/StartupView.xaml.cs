using System.Windows.Controls;
namespace RionHub.Modules.Startup;
public partial class StartupView : UserControl
{
    public StartupView() : this(false) { }
    public StartupView(bool autoruns)
    {
        InitializeComponent();
        if(autoruns)
        {
            PageTitle.Text="Autoruns";
            AutorunsLauncher.Visibility=System.Windows.Visibility.Visible;
            AutorunsLauncher.DataContext=new RionHub.Modules.Tools.Windows.UtilityToolRowViewModel(
                RadeonSoftwareSlimmer.Optimize.UtilityToolCatalog.All.Single(entry=>entry.Name=="Autoruns"));
        }
        // Keep the list and selected-service action usable in short laptop/VM windows.
        // At normal sizes the page fits; shorter windows scroll the complete workspace.
        SizeChanged += (_, _) => StartupLayout.Height = Math.Max(620, ActualHeight - 28);
        DataContext = new StartupViewModel();
    }
}

