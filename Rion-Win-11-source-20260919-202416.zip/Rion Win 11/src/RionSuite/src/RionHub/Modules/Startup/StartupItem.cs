using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace RionHub.Modules.Startup;

public sealed record StartupItem
{
    public string Kind { get; init; } = "";
    public string Location { get; init; } = "";
    public string Name { get; init; } = "";
    public string Command { get; init; } = "";
    public string Identity { get; init; } = "";
    public string? State { get; init; }
    public string Publisher { get; init; } = "Not checked";
    public bool PublisherVerified { get; init; }
    public string Description { get; init; } = "No description supplied by this entry.";
    public int ServiceType { get; init; }
    public bool IsServiceTemplate => Kind == "Services" && (ServiceType & 0x30) != 0 && (ServiceType & 0x40) != 0 && (ServiceType & 0x80) == 0;
    public string Activity { get; init; } = "Not measured";
    public string Schedule { get; init; } = "";
    public string Recommendation => !StateKnown ? "Review needed" : !Enabled ? "Leave disabled" : !Editable && Verdict == "Keep enabled" ? "Leave unchanged" : Verdict;
    public string ResourceImpact => Kind == "Services" ? "Unchecking disables future starts and requests a stop. Activity shows the last scan; stop failures are reported. Checking restores saved startup settings without starting the service. Resource savings are not measured." : Activity is "Ready" or "Stopped" or "Disabled"
        ? "Not running at scan time. Disabling does not free memory from this entry now; it prevents future starts. Related applications may still be running."
        : Activity == "Running"
        ? "Running at scan time. Disabling affects future starts and does not stop this instance. CPU and memory savings have not been measured."
        : "Enabled does not mean running. Resource savings have not been measured; disabling changes future starts, not existing processes.";
    public string Verdict { get; init; } = "Keep enabled";
    public string Reason { get; init; } = "No reviewed rule for this entry. Inspect it before making changes outside this tool.";
    public bool Editable { get; init; }
    // Manual control is independent of the curated automatic recommendations.
    public bool ManuallyEditable => StateKnown && (!Enabled || VendorStartupRules.ProtectedRole(this) == null) && (Kind is "Logon apps" or "Startup folders" or "Scheduled tasks" || Kind == "Services" && State is "2" or "3" or "4" && (!Enabled || RadeonSoftwareSlimmer.Optimize.ServiceProtection.Reason(Name) == null));
    public bool Recommended { get; init; }
    public bool StartsAtLogon { get; init; }
    private bool stateKnown = true;
    public bool StateKnown { get => stateKnown && (Kind is not ("Logon apps" or "Startup folders") || ValidApproval(State)); init => stateKnown = value; }
    private static bool ValidApproval(string? state)
    {
        if (state == null) return true;
        try { byte[] bytes = Convert.FromBase64String(state); return bytes.Length >= 12 && bytes[0] is 2 or 3 or 6 or 7; }
        catch (FormatException) { return false; }
    }
    public bool Enabled => StateKnown && (Kind == "Packaged apps" ? State is "2" or "4" : Kind == "Services" ? State != "4" : Kind == "Scheduled tasks" ? State == "True" : State == null || (Convert.FromBase64String(State)[0] & 1) == 0);
    public string Id => Kind + "|" + Location + "|" + Name;
    public string Status => !StateKnown ? "Unknown" : Kind == "Services" ? State switch { "2" => "Automatic", "3" => "Manual", "4" => "Disabled", _ => "System" } : Enabled ? "Enabled" : "Disabled";
    public string Category => IsUpdater ? "Updaters" : Kind;
    public bool IsUpdater => Name.Contains("update", StringComparison.OrdinalIgnoreCase) || Command.Contains("update", StringComparison.OrdinalIgnoreCase) || Name == "AdobeARMservice";
}

public static class StartupRules
{
    public static string Hash(string text) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
    public static string Executable(string command)
    {
        string text = Environment.ExpandEnvironmentVariables(command).Trim();
        if (text.StartsWith('"')) { int end = text.IndexOf('"', 1); return end > 1 ? text[1..end] : ""; }
        // Unquoted paths with spaces are ambiguous: do not guess which executable runs.
        string first = text.Split(' ', 2)[0];
        return Path.IsPathFullyQualified(first) && first.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? first : "";
    }
    public static StartupItem Classify(StartupItem item, string executable, string publisher, bool trusted)
    {
        item = item with { Editable = false, Recommended = false, Verdict = "Keep enabled" };
        if (!trusted) return item with { Publisher = publisher, Reason = "Publisher could not be verified, or this entry is not a plain executable. No automatic change." };
        string file = Path.GetFileName(executable).ToLowerInvariant();
        bool valve = publisher is "Valve Corp." or "Valve Corporation";
        bool epic = publisher is "Epic Games, Inc." or "Epic Games Inc.";
        bool spotify = publisher == "Spotify AB";
        if (item.IsUpdater) return item with { Publisher = publisher, Reason = "Update component: retained to keep automatic fixes available." };
        if (item.Kind == "Scheduled tasks" && item.StartsAtLogon && ((file == "steam.exe" && valve) || (file == "spotify.exe" && spotify) || (file == "epicgameslauncher.exe" && epic)))
            return item with { Publisher = publisher, Editable = true, Verdict = "Your choice", Reason = "Recognized app scheduled to launch at sign-in or boot. Disable only if you prefer to launch it manually; background downloads and notifications may be delayed." };
        if (item.Kind == "Logon apps" && ((file == "steam.exe" && valve) || (file == "epicgameslauncher.exe" && epic) || (file == "spotify.exe" && spotify)))
            return item with { Publisher = publisher, Editable = true, Recommended = true, Verdict = "Recommended to disable", Reason = "Optional app launch at sign-in. You can still open the app yourself; background downloads or notifications wait until you do." };
        if (item.Kind == "Logon apps" && file == "onedrive.exe" && publisher == "Microsoft Corporation")
            return item with { Publisher = publisher, Editable = true, Verdict = "Your choice", Reason = "Disabling sign-in launch delays file sync and backup until OneDrive is opened. Keep it enabled if you rely on automatic sync." };
        if (item.Kind == "Services" && item.Name == "FvSvc" && file == "nvfvsdksvc_x64.exe" && publisher == "NVIDIA Corporation")
            return item with { Publisher = publisher, Editable = true, Verdict = "Your choice", Reason = "FrameView performance monitoring will be unavailable. Keep enabled if you use its metrics. This does not disable the display driver." };
        if (((item.Kind == "Services" && item.Name == "AdobeARMservice") || (item.Kind == "Scheduled tasks" && item.Name == "Adobe Acrobat Update Task")) && file is "armsvc.exe" or "adobearm.exe" && publisher is "Adobe Inc." or "Adobe Systems Incorporated")
            return item with { Publisher = publisher, Verdict = "Keep enabled", Reason = "Installs Acrobat/Reader updates, including security fixes. Updaters are not included in recommended disabling." };
        return item with { Publisher = publisher, Reason = item.IsUpdater ? "Update component: keep enabled to retain automatic fixes. A name containing 'update' is not a recommendation to disable it." : "No reviewed disable rule. Windows, hardware, security and unknown components are left unchanged." };
    }
}
