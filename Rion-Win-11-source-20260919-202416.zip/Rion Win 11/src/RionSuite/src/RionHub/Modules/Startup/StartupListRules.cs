namespace RionHub.Modules.Startup;

public static class StartupListRules
{
    public static bool InState(StartupItem item, string state) => state switch
    {
        "All states" => true,
        "Enabled" => item.StateKnown && item.Enabled,
        "Disabled" => item.StateKnown && !item.Enabled,
        "Suggested to disable" => item.StateKnown && item.Enabled && item.Recommended && item.ManuallyEditable,
        _ => false
    };
    public static bool InCategory(StartupItem item, string category)
    {
        if (category == "All entries (advanced)") return true;
        if (category == "Manual service options") return ServiceManualRules.Guidance(item) != null;
        // Inventory must not depend on eligibility for automatic optimization.
        if (category == "Apps") return item.Kind is "Logon apps" or "Startup folders" or "Packaged apps";
        if (!item.Editable || !item.StateKnown || VendorStartupRules.ProtectedRole(item) != null) return false;
        if (item.Kind == "Services" && RadeonSoftwareSlimmer.Optimize.ServiceProtection.Reason(item.Name) != null) return false;
        bool updater = VendorStartupRules.Match(item) != null || item.IsUpdater;
        return category switch
        {
            "Scheduled tasks" => item.Kind == "Scheduled tasks",
            "Background extras" => item.Kind == "Services" && !updater,
            "Updaters" => updater,
            _ => false
        };
    }
}
