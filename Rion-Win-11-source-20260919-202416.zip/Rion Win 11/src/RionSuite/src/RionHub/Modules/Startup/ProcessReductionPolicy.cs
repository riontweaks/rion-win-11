using RadeonSoftwareSlimmer.Optimize;

namespace RionHub.Modules.Startup;

public sealed record ProcessReductionChoices(bool Xbox = true, bool Printing = true, bool Phone = true, bool Location = true, bool RemoteDesktop = true,
    bool OneDrive = true, bool Midi = true, bool EdgeBackground = true, bool Widgets = true, bool SearchHighlights = true,
    bool Scanning = true, bool MailSync = true, bool Bluetooth = true, bool ConnectedDevices = true, bool Telemetry = true, bool DeviceManagement = true, bool CrashReporting = true, bool Troubleshooting = true, bool Compatibility = true, bool LinkTracking = true, bool OfflineMaps = true, bool RetailDemo = true, bool RemoteRegistry = true, bool EventCollection = true, bool Insider = true, bool DeveloperDiagnostics = true, bool LogitechLighting = true, bool AsusUpdateChecks = true, bool VendorUpdates = true);

public static class ProcessReductionPolicy
{
    private static readonly Dictionary<string, (string Label, string Effect)> ServiceDescriptions = new(StringComparer.OrdinalIgnoreCase)
    {
        ["DiagTrack"] = ("Windows usage reporting", "Stops optional Windows usage and diagnostic reporting."),
        ["dmwappushservice"] = ("Device management message routing", "Stops push-message routing used by some device-management setups."),
        ["diagnosticshub.standardcollector.service"] = ("Developer diagnostic recording", "Developer tools cannot collect these diagnostic recordings until restored."),
        ["RetailDemo"] = ("Shop display demo mode", "Turns off the demonstration mode used on retail display PCs."),
        ["RemoteRegistry"] = ("Remote registry administration", "Other computers cannot remotely manage this PC's registry through this service."),
        ["WerSvc"] = ("Windows crash reporting", "Windows cannot submit these app crash reports automatically."),
        ["wercplsupport"] = ("Problem-report viewing support", "Some problem-report viewing features become unavailable."),
        ["MapsBroker"] = ("Offline map downloads", "Automatic downloads and updates for offline maps stop."),
        ["TrkWks"] = ("Moved-file link tracking", "Some links to files moved between computers may stop following the file."),
        ["Fax"] = ("Fax support", "Sending and receiving faxes through Windows stops."),
        ["AJRouter"] = ("AllJoyn smart-device messaging", "Apps using AllJoyn device messaging may stop discovering or talking to those devices."),
        ["WMPNetworkSvc"] = ("Media Player sharing", "Windows Media Player cannot share its library to other devices."),
        ["WalletService"] = ("Windows Wallet support", "Windows Wallet features become unavailable."),
        ["SEMgrSvc"] = ("NFC payments", "Tap-to-pay and secure NFC features become unavailable."),
        ["PushToInstall"] = ("Remote Store app installs", "Installing apps onto this PC remotely from the Store stops. Local Store installs stay available."),
        ["GraphicsPerfSvc"] = ("Graphics performance monitoring", "Tools using this graphics performance service lose its measurements."),
        ["PerfHost"] = ("Legacy performance monitoring", "Some older performance-monitoring tools lose their counters."),
        ["Wecsvc"] = ("Collect logs from other PCs", "This PC no longer collects forwarded Windows event logs from other computers."),
        ["PcaSvc"] = ("Older-app compatibility assistance", "Windows stops offering some automatic compatibility help for older programs.")
    };
    public static string? ServiceLabel(string name) => ServiceDescriptions.TryGetValue(name, out var info) ? info.Label : null;
    private static readonly (string[] Services, Func<ProcessReductionChoices, bool> Keep, string Feature)[] Features =
    {
        (new[] { "XblGameSave", "XblAuthManager", "XboxNetApiSvc" }, c => c.Xbox, "Xbox cloud saves and sign-in"),
        (new[] { "Spooler", "PrintNotify", "PrintWorkflowUserSvc", "Fax" }, c => c.Printing, "printing, including Print to PDF and virtual printers"),
        (new[] { "PhoneSvc", "MessagingService" }, c => c.Phone, "phone and messaging features"),
        (new[] { "lfsvc" }, c => c.Location, "location and automatic location detection"),
        (new[] { "MidiSrv" }, c => c.Midi, "MIDI instruments, controllers and music applications"),
        (new[] { "TermService", "SessionEnv", "UmRdpService" }, c => c.RemoteDesktop, "Remote Desktop hosting and device redirection"),
        (new[] { "stisvc" }, c => c.Scanning, "scanning and image acquisition"),
        (new[] { "OneSyncSvc", "PimIndexMaintenanceSvc" }, c => c.MailSync, "mail, calendar and contact sync"),
        (new[] { "bthserv", "BluetoothUserService", "BthAvctpSvc", "BTAGService" }, c => c.Bluetooth, "Bluetooth input devices, audio and controllers"),
        (new[] { "CDPSvc", "CDPUserSvc" }, c => c.ConnectedDevices, "Nearby Sharing and connected-device experiences"),
        (new[] { "DiagTrack" }, c => c.Telemetry, "Windows diagnostic reporting"),
        (new[] { "dmwappushservice" }, c => c.DeviceManagement, "device-management push routing"),
        (new[] { "WerSvc", "wercplsupport" }, c => c.CrashReporting, "crash reporting and problem reports"),
        (new[] { "DPS", "diagsvc", "WdiServiceHost", "WdiSystemHost" }, c => c.Troubleshooting, "Windows diagnostic troubleshooting"),
        (new[] { "PcaSvc" }, c => c.Compatibility, "older-app compatibility assistance"),
        (new[] { "TrkWks" }, c => c.LinkTracking, "moved-file link tracking"),
        (new[] { "MapsBroker" }, c => c.OfflineMaps, "offline maps"),
        (new[] { "RetailDemo" }, c => c.RetailDemo, "retail demonstration mode"),
        (new[] { "RemoteRegistry" }, c => c.RemoteRegistry, "remote registry administration"),
        (new[] { "Wecsvc" }, c => c.EventCollection, "forwarded event-log collection"),
        (new[] { "wisvc" }, c => c.Insider, "Windows Insider support"),
        (new[] { "diagnosticshub.standardcollector.service" }, c => c.DeveloperDiagnostics, "developer diagnostic recording")
    };

    // Legacy optional extras. Feature groups above require an explicit opt-out.
    private static readonly HashSet<string> Extras = new(StringComparer.OrdinalIgnoreCase)
    {
        "AJRouter", "WMPNetworkSvc", "WalletService", "SEMgrSvc",
        "PushToInstall", "GraphicsPerfSvc", "PerfHost"
    };

    public static bool ServiceMatches(string actual, string template) =>
        actual.Equals(template, StringComparison.OrdinalIgnoreCase)
        || (actual.StartsWith(template + "_", StringComparison.OrdinalIgnoreCase)
            && actual.Length > template.Length + 1
            && actual[(template.Length + 1)..].All(Uri.IsHexDigit));

    // Only these reviewed capabilities may bypass the generic manual-disable guard,
    // and only inside Process Reduction after their own opt-out. Core protection stays intact.
    public static bool IsOptionalProtectedService(string name) =>
        new[] { "bthserv", "BluetoothUserService", "BthAvctpSvc", "BTAGService", "CDPSvc", "CDPUserSvc" }
            .Any(n => ServiceMatches(name, n));

    public static bool CanOptOutProtectedService(StartupItem item, ProcessReductionChoices? choices) =>
        item.Kind == "Services" && IsOptionalProtectedService(item.Name)
        && item.StateKnown && item.State is "2" or "3" or "4"
        && IsVerifiedWindowsService(item)
        && Features.Any(f => f.Services.Any(n => ServiceMatches(item.Name, n)) && !f.Keep(choices ?? new()));

    private static bool IsVerifiedWindowsService(StartupItem item) => item.PublisherVerified
        && item.Publisher is "Microsoft Corporation" or "Microsoft Windows" or "Microsoft Windows Publisher";

    public static bool ServiceOptOutRequested(StartupItem item, ProcessReductionChoices choices) =>
        item.Kind == "Services" && (Features.Any(f => !f.Keep(choices) && f.Services.Any(n => ServiceMatches(item.Name, n)))
            || (!choices.AsusUpdateChecks && item.Name.Equals("AsusUpdateCheck", StringComparison.OrdinalIgnoreCase))
            || (!choices.LogitechLighting && item.Name.Equals("logi_lamparray_service", StringComparison.OrdinalIgnoreCase)));

    private static string? VendorFeature(StartupItem item)
    {
        if (item.Kind != "Services" || !item.PublisherVerified) return null;
        string file = System.IO.Path.GetFileName(StartupRules.Executable(item.Command));
        if (item.Name.Equals("AsusUpdateCheck", StringComparison.OrdinalIgnoreCase)
            && file.Equals("AsusUpdateCheck.exe", StringComparison.OrdinalIgnoreCase)
            && item.Publisher == "ASUSTeK COMPUTER INC.") return "ASUS update checks";
        if (item.Name.Equals("logi_lamparray_service", StringComparison.OrdinalIgnoreCase)
            && file.Equals("logi_lamparray_service.AMD64.exe", StringComparison.OrdinalIgnoreCase)
            && item.Publisher is "Microsoft Windows Hardware Compatibility Publisher" or "Logitech Inc" or "Logitech Inc." or "Logitech Europe S.A.")
            return "Logitech LampArray lighting";
        return null;
    }

    // Kept out of the lists above on purpose, so they stay in "Review":
    //   SystemSettingsBroker - not a service; the Settings app depends on it.
    //   EpicWebHelper        - not a service; dies with the Epic launcher.
    //   clr_optimization_*   - precompiles assemblies then idles; disabling only slows startup.
    //   defragsvc            - also issues TRIM on SSDs.
    //   DoSvc                - disabling breaks Store/Update downloads.

    public static string? KeepReason(StartupItem item, ProcessReductionChoices? choices = null)
    {
        choices ??= new();
        if (!item.StateKnown) return "Review: unreadable or unknown state";
        if (item.Kind == "Services" && (item.State is not ("2" or "3" or "4") || (item.ServiceType != 0 && (item.ServiceType & 0x30) == 0))) return "Protected: driver or system startup type";
        if (VendorStartupRules.ProtectedRole(item) is string protectedRole) return "Protected: " + protectedRole;
        if (IsOneDriveLogon(item)) return choices.OneDrive ? "Keep available: OneDrive automatic file sync and folder backup" : null;
        var vendor = VendorStartupRules.Match(item);
        if (vendor != null)
            return vendor.Xbox && choices.Xbox ? "Keep available: Xbox background updates"
                : choices.VendorUpdates ? "Keep available: automatic vendor updates, including security fixes" : null;
        if (VendorFeature(item) is string vendorFeature)
            return (vendorFeature == "ASUS update checks" ? choices.AsusUpdateChecks : choices.LogitechLighting)
                ? "Keep available: " + vendorFeature : null;
        if (item.Kind == "Services")
        {
            string? protectedReason = ServiceProtection.Reason(item.Name);
            if (protectedReason != null && !CanOptOutProtectedService(item, choices)) return "Protected: " + protectedReason;
            foreach (var feature in Features)
                if (feature.Services.Any(name => ServiceMatches(item.Name, name)))
                    return feature.Keep(choices) ? "Keep available: " + feature.Feature
                        : !IsVerifiedWindowsService(item) ? "Review: Windows service publisher could not be verified"
                        : null;
            if (!Extras.Contains(item.Name)) return "Review: feature-dependent, hardware, third-party or unreviewed service";
            if (item.State is not ("2" or "3" or "4")) return "Protected: driver or system startup type";
            return null;
        }
        if (item.Kind is not ("Logon apps" or "Startup folders") && !(item.Kind == "Scheduled tasks" && item.StartsAtLogon))
            return "Protected: setup entry or task outside app startup";
        string text = (item.Name + " " + item.Command + " " + item.Publisher).ToLowerInvariant();
        // Retain hardware, security, accessibility and recovery helpers even when signed.
        string[] critical = { "security", "defender", "antivirus", "malware", "bitdefender", "kaspersky", "eset", "avast", "avg", "norton", "mcafee", "sophos", "crowdstrike", "sentinel", "vpn", "wireguard", "openvpn", "tailscale", "zerotier", "audio", "realtek", "nahimic", "dolby", "dts", "bluetooth", "intel", "amd", "nvidia", "synaptics", "elan", "logitech", "razer", "corsair", "steelseries", "screenreader", "nvda", "jaws", "backup", "acronis", "veeam", "macrium" };
        if (critical.Any(text.Contains)) return "Protected: security, network, hardware, accessibility or backup helper";
        if (item.Publisher.StartsWith("Microsoft", StringComparison.OrdinalIgnoreCase)
            || item.Kind == "Scheduled tasks" && item.Location.StartsWith(@"\Microsoft\", StringComparison.OrdinalIgnoreCase))
            return "Protected/review: Microsoft component, sync or Windows integration";
        if (!item.PublisherVerified) return "Review: publisher or executable could not be verified";
        // A valid signature establishes the publisher, not that an unknown program is optional.
        string[] appPublishers = { "Valve Corp.", "Valve Corporation", "Epic Games, Inc.", "Epic Games Inc.", "Spotify AB", "Discord Inc.", "Discord, Inc.", "Slack Technologies, LLC", "Slack Technologies Inc.", "Zoom Video Communications, Inc.", "Google LLC", "Mozilla Corporation", "Brave Software, Inc.", "Opera Norway AS", "GOG sp. z o.o.", "Electronic Arts Inc.", "Ubisoft Entertainment", "Riot Games, Inc.", "Blizzard Entertainment, Inc." };
        if (!appPublishers.Contains(item.Publisher, StringComparer.OrdinalIgnoreCase))
            return "Review: signed application with an unreviewed role; use Startup controls after checking its purpose";
        return null;
    }

    public static string DisableEffect(StartupItem item)
    {
        if (VendorFeature(item) is string vendorFeature) return "Unavailable after restart: " + vendorFeature + ". Restore its original startup setting in Startup history.";
        if (IsOneDriveLogon(item)) return "OneDrive sync and folder backup wait until you open OneDrive. Files are not removed; restart to end the existing instance.";
        if (VendorStartupRules.Match(item) is VendorStartupEntry vendor) return vendor.Effect;
        if (item.Kind == "Services" && ServiceDescriptions.TryGetValue(item.Name, out var info)) return info.Effect;
        foreach (var feature in Features)
            if (feature.Services.Any(name => ServiceMatches(item.Name, name)))
                return "Unavailable after restart: " + feature.Feature;
        return item.Kind == "Services" ? "Background feature disabled after restart: " + item.Description
            : "Launch manually when needed; background sync, updates and notifications may wait until launch";
    }

    private static bool IsOneDriveLogon(StartupItem item) => item.Kind == "Logon apps" && item.PublisherVerified
        && item.Publisher.Equals("Microsoft Corporation", StringComparison.OrdinalIgnoreCase)
        && System.IO.Path.GetFileName(StartupRules.Executable(item.Command)).Equals("OneDrive.exe", StringComparison.OrdinalIgnoreCase);
}
