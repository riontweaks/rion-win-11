namespace RionHub.Modules.Startup;

public static class StartupAppBatch
{
    public static bool CanDisable(StartupItem item) => item.StateKnown && item.Enabled && item.ManuallyEditable
        && item.Kind is "Logon apps" or "Startup folders";
}
