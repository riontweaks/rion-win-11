using System.IO;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.Win32;
using Microsoft.Win32.TaskScheduler;
using RadeonSoftwareSlimmer.Services;
using RTask = Microsoft.Win32.TaskScheduler.Task;

namespace RionHub.Modules.Startup;

public sealed class StartupEngine
{
    private const string Run = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string PackagedStartup = @"Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData";
    private const string Approved = @"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\";
    private readonly Dictionary<string, (string Publisher, bool Trusted)> signatures = new(StringComparer.OrdinalIgnoreCase);
    public static string HistoryDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "StartupHistory");
    public List<string> Warnings { get; } = new();
    private readonly string historyDirectory = HistoryDirectory;
    private readonly Func<StartupItem, StartupItem>? testRead;
    private readonly System.Action<StartupItem>? testWrite;
    private readonly Func<StartupItem, StartupItem>? testInspect;
    private readonly System.Action<string> stopService = StopService;
    private readonly System.Action<string> checkDependents = EnsureNoDependents;
    public int LastDisabledCount { get; private set; }
    public List<string> LastDisableErrors { get; } = new();
    public StartupEngine() { }
    internal StartupEngine(string historyDirectory, Func<StartupItem, StartupItem> read,
        System.Action<StartupItem> write, Func<StartupItem, StartupItem> inspect,
        System.Action<string>? stop = null, System.Action<string>? dependents = null)
    {
        this.historyDirectory = historyDirectory;
        testRead = read; testWrite = write; testInspect = inspect;
        stopService = stop ?? (_ => { });
        checkDependents = dependents ?? (_ => { });
    }

    public List<StartupItem> Scan()
    {
        signatures.Clear(); Warnings.Clear();
        var items = new List<StartupItem>();
        foreach (bool machine in new[] { false, true })
        foreach (bool view32 in new[] { false, true })
        foreach (bool once in new[] { false, true })
        {
            if (!machine && view32) continue; // Current-user Run is shared between registry views.
            string path = Run + (once ? "Once" : "");
            string location = $"{(machine ? "HKLM" : "HKCU")}|{(view32 ? "32" : "64")}|{path}|{Approved}{(view32 ? "Run32" : "Run")}";
            TryScan(() => {
                using var root = Root(location);
                using var key = root.OpenSubKey(path);
                if (key == null) return;
                foreach (string name in key.GetValueNames())
                    TryScan(() => items.Add(Inspect(Read(new StartupItem { Kind = once ? "RunOnce" : "Logon apps", Location = location, Name = name }))), name);
            }, location);
        }
        foreach (bool common in new[] { false, true })
        {
            string folder = Environment.GetFolderPath(common ? Environment.SpecialFolder.CommonStartup : Environment.SpecialFolder.Startup);
            string location = $"{(common ? "HKLM" : "HKCU")}|64|{folder}|{Approved}StartupFolder";
            TryScan(() => {
                if (!Directory.Exists(folder)) return;
                foreach (var file in Directory.GetFiles(folder).Where(f => !Path.GetFileName(f).Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)))
                    TryScan(() => items.Add(Inspect(Read(new StartupItem { Kind = "Startup folders", Location = location, Name = Path.GetFileName(file) }))), file);
            }, folder);
        }
        // Windows owns packaged-app startup permissions. Enumerate known registrations
        // read-only; do not write the private AppModel registry contract.
        TryScan(() => {
            using var packages = Registry.CurrentUser.OpenSubKey(PackagedStartup);
            if (packages == null) return;
            foreach (string family in packages.GetSubKeyNames())
                TryScan(() => {
                    using var package = packages.OpenSubKey(family);
                    if (package == null) return;
                    foreach (string taskId in package.GetSubKeyNames())
                        TryScan(() => {
                            using var task = package.OpenSubKey(taskId);
                            if (task?.GetValue("State") is not int) return;
                            items.Add(Read(new StartupItem { Kind = "Packaged apps", Name = family.Split('_')[0],
                                Location = PackagedStartup + "\\" + family + "\\" + taskId,
                                Command = taskId, Description = "Packaged app startup task: " + taskId,
                                Reason = "Managed by Windows. Use Windows startup settings to change this app's startup permission.", Verdict = "Manage in Windows" }));
                        }, taskId);
                }, family);
        }, "Packaged startup apps");
        TryScan(() => {
            using var services = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services");
            if (services == null) return;
            foreach (string name in services.GetSubKeyNames())
                TryScan(() => {
                    using var service = services.OpenSubKey(name);
                    int type = Convert.ToInt32(service?.GetValue("Type", 0));
                    if ((type & 0x30) == 0) return; // Drivers are not editable startup services.
                    items.Add(Inspect(Read(new StartupItem { Kind = "Services", Name = name, Location = name })));
                }, name);
        }, "Services");
        TryScan(() => {
            using var scheduler = new TaskService();
            foreach (RTask task in scheduler.AllTasks)
                using (task) TryScan(() => items.Add(Inspect(ReadTask(task))), task.Path);
        }, "Scheduled tasks");
        return items.OrderByDescending(i => i.Recommended && i.Enabled).ThenBy(i => i.Category).ThenBy(i => i.Name).ToList();
    }

    private void TryScan(System.Action action, string name)
    {
        try { action(); } catch (Exception ex) { Warnings.Add(name + ": " + ex.Message); }
    }
    private static RegistryKey Root(string location)
    {
        var parts = location.Split('|');
        return RegistryKey.OpenBaseKey(parts[0] == "HKLM" ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, parts[1] == "32" ? RegistryView.Registry32 : RegistryView.Registry64);
    }
    private StartupItem Inspect(StartupItem item)
    {
        if (testInspect != null) return testInspect(item);
        item = item with { Editable = false, Recommended = false, Verdict = "Keep enabled", PublisherVerified = false, Publisher = "Not checked" };
        if (!item.StateKnown) return item with { Reason = "Unrecognized Windows approval state. Displayed for inspection only; left unchanged." };
        if (item.Kind == "Services" && !ProcessReductionPolicy.IsOptionalProtectedService(item.Name)
            && RadeonSoftwareSlimmer.Optimize.ServiceProtection.Reason(item.Name) is string protection)
            return item with { Verdict = "Protected", Reason = protection + ": excluded from disabling." };
        if (VendorStartupRules.ProtectedRole(item) is string vendorProtection)
            return item with { Verdict = "Protected", Reason = vendorProtection };
        string executable = StartupRules.Executable(item.Command);
        if (item.Kind is "RunOnce" or "Startup folders") return item with { Reason = item.Kind == "RunOnce" ? "One-time setup entry: left unchanged so installation can finish." : "Startup-folder entry: inspect its shortcut and purpose manually. No reviewed automatic rule." };
        if (!File.Exists(executable)) return item with { Reason = "Target is missing or the command cannot be resolved unambiguously. No automatic change." };
        // Signature checks qualify automatic recommendations, not manual controls.
        if (!signatures.TryGetValue(executable, out var signature))
        {
            try
            {
                var check = new InstallerValidator().Inspect(executable);
                signature = (check.Publisher ?? "Not verified", check.SignatureStatus is RadeonSoftwareSlimmer.Models.SignatureStatus.Valid or RadeonSoftwareSlimmer.Models.SignatureStatus.ValidButNotAmd);
            }
            catch (Exception ex)
            {
                Warnings.Add(item.Name + ": Publisher verification failed: " + ex.Message);
                return item with { Reason = "Publisher verification failed. Entry is shown without an automatic recommendation." };
            }
            signatures[executable] = signature;
        }
        var classified = StartupRules.Classify(item with { PublisherVerified = signature.Trusted }, executable, signature.Publisher, signature.Trusted);
        if (VendorStartupRules.Match(classified) is VendorStartupEntry vendor)
            return classified with { Editable = true, Recommended = false, Verdict = "Optional updater", Reason = vendor.Effect };
        if (ProcessReductionPolicy.KeepReason(classified) == null)
        {
            // A service only reaches here if it is on the curated Extras list and survived every
            // protection check — the same bar process reduction uses to disable it automatically.
            // Recommending it here just makes "Disable suggested" agree with what Auto-Optimize
            // would already do, instead of limiting itself to logon apps.
            bool suggest = classified.Kind is "Logon apps" or "Services";
            return classified with
            {
                Editable = true,
                Recommended = suggest,
                Verdict = suggest ? "Can disable" : "Your choice",
                Reason = ProcessReductionPolicy.DisableEffect(classified)
            };
        }
        return classified;
    }
    public StartupItem Read(StartupItem target)
    {
        if (testRead != null) return testRead(target);
        if (target.Kind == "Packaged apps")
        {
            using var key = Registry.CurrentUser.OpenSubKey(target.Location);
            var state = key?.GetValue("State") as int?;
            return target with { State = state?.ToString(), StateKnown = state is >= 0 and <= 4,
                Identity = StartupRules.Hash(target.Location) };
        }
        if (target.Kind == "Scheduled tasks")
        {
            using var scheduler = new TaskService();
            using var task = scheduler.GetTask(target.Location) ?? throw new IOException("Task no longer exists.");
            return ReadTask(task);
        }
        if (target.Kind == "Services")
        {
            using var service = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + target.Name) ?? throw new IOException("Service no longer exists.");
            string command = Convert.ToString(service.GetValue("ImagePath")) ?? "";
            string identity = command + "|" + service.GetValue("Type") + "|" + service.GetValue("ObjectName") + "|" + service.GetValue("DelayedAutoStart") + "|" + string.Join(",", service.GetValue("DependOnService") as string[] ?? Array.Empty<string>());
            string activity = "Unknown";
            try { using var controller = new ServiceController(target.Name); activity = controller.Status.ToString(); } catch { }
            return target with { Command = command, Identity = StartupRules.Hash(identity), State = Convert.ToString(service.GetValue("Start")), Activity = activity,
                ServiceType = Convert.ToInt32(service.GetValue("Type", 0)),
                Description = ResolveDescription(Convert.ToString(service.GetValue("Description"))),
                Schedule = "Service: " + ResolveDescription(Convert.ToString(service.GetValue("DisplayName"))) };
        }
        var parts = target.Location.Split('|');
        using var root = Root(target.Location);
        string content;
        string sourceIdentity;
        if (target.Kind == "Startup folders")
        {
            content = Path.Combine(parts[2], target.Name);
            sourceIdentity = InstallerValidator.Sha256(content);
        }
        else
        {
            using var source = root.OpenSubKey(parts[2]) ?? throw new IOException("Startup key no longer exists.");
            content = source.GetValue(target.Name, null, RegistryValueOptions.DoNotExpandEnvironmentNames) as string ?? throw new IOException("Startup entry no longer exists or is not a string.");
            sourceIdentity = content + "|" + source.GetValueKind(target.Name);
        }
        using var approvalRoot = RegistryKey.OpenBaseKey(parts[0] == "HKLM" ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, RegistryView.Registry64);
        using var approved = approvalRoot.OpenSubKey(parts[3]);
        object? value = approved?.GetValue(target.Name);
        bool known = value == null || (value is byte[] bytes && bytes.Length >= 12 && bytes[0] is 2 or 3 or 6 or 7);
        return target with { Command = content, Identity = StartupRules.Hash(sourceIdentity), StateKnown = known, State = value is byte[] blob ? Convert.ToBase64String(blob) : null };
    }
    private static StartupItem ReadTask(RTask task)
    {
        var xml = XDocument.Parse(task.Xml);
        XNamespace ns = xml.Root!.Name.Namespace;
        var enabled = xml.Root.Element(ns + "Settings")?.Element(ns + "Enabled");
        enabled?.Remove();
        var actions = task.Definition.Actions.OfType<ExecAction>().ToList();
        string command = actions.Count == 1 && task.Definition.Actions.Count == 1 ? "\"" + actions[0].Path + "\" " + actions[0].Arguments : "Multiple or non-executable actions";
        bool logonOnly = task.Definition.Triggers.Count > 0 && task.Definition.Triggers.All(t => t is LogonTrigger or BootTrigger);
        return new StartupItem { Kind = "Scheduled tasks", StartsAtLogon = logonOnly, Location = task.Path, Name = task.Name, Command = command, State = task.Enabled.ToString(), Identity = StartupRules.Hash(xml.ToString(SaveOptions.DisableFormatting)),
            Description = ResolveDescription(task.Definition.RegistrationInfo.Description), Activity = task.State.ToString(),
            Schedule = "Triggers: " + (task.Definition.Triggers.Count == 0 ? "None (may be started on demand)" : string.Join("; ", task.Definition.Triggers.Select(t => t.ToString())))
                + "\nLast run: " + FormatRunTime(task.LastRunTime) + " · Next scheduled run: " + FormatRunTime(task.NextRunTime),
            Reason = "No reviewed disable rule for this task. Use its full path and description to identify it; its name alone does not establish whether it is optional." };
    }

    private static string FormatRunTime(DateTime value) => value.Year < 2000 || value == DateTime.MaxValue ? "Not reported" : value.ToString("g");
    private static string ResolveDescription(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "No description supplied by this entry.";
        if (!value.StartsWith('@')) return value;
        var buffer = new System.Text.StringBuilder(4096);
        return SHLoadIndirectString(Environment.ExpandEnvironmentVariables(value), buffer, (uint)buffer.Capacity, IntPtr.Zero) == 0
            ? buffer.ToString() : "Windows resource description could not be loaded.";
    }
    [DllImport("shlwapi.dll", CharSet = CharSet.Unicode)]
    private static extern int SHLoadIndirectString(string source, System.Text.StringBuilder output, uint outputSize, IntPtr reserved);

    /// <summary>Disabled startup state. Game runtimes remain protected; no automatic Manual conversion.</summary>
    public static string DisabledState(StartupItem item, bool processReduction = false)
    {
        if (item.Kind == "Services")
            return "4";
        if (item.Kind == "Scheduled tasks") return "False";
        byte[] state = new byte[12]; state[0] = 3;
        BitConverter.GetBytes(DateTime.UtcNow.ToFileTimeUtc()).CopyTo(state, 4);
        return Convert.ToBase64String(state);
    }
    public static bool Same(StartupItem a, StartupItem b) => a.Id == b.Id && a.Identity == b.Identity && a.State == b.State;

    public string Disable(IEnumerable<StartupItem> selected, bool manual = false, bool processReduction = false, ProcessReductionChoices? choices = null)
    {
        LastDisabledCount = 0;
        LastDisableErrors.Clear();
        Directory.CreateDirectory(historyDirectory);
        int changed = 0;
        var errors = new List<string>();
        foreach (var original in selected)
        {
            try
            {
                signatures.Clear();
                var current = Inspect(Read(original));
                if (!Same(original, current)) throw new IOException("Entry changed since scanning. Rescan first.");
                bool optionalOptOut = processReduction && ProcessReductionPolicy.CanOptOutProtectedService(current, choices);
                if (current.Kind == "Services" && !optionalOptOut && RadeonSoftwareSlimmer.Optimize.ServiceProtection.Reason(current.Name) is string reason)
                    throw new IOException("Protected: " + reason);
                if (VendorStartupRules.ProtectedRole(current) is string vendorReason) throw new IOException("Protected: " + vendorReason);
                if (processReduction && ProcessReductionPolicy.KeepReason(current, choices) is string keep)
                    throw new IOException(keep);
                if (!(optionalOptOut || (manual ? current.ManuallyEditable : current.Editable)) || !current.Enabled) throw new IOException("Entry is not eligible for disabling.");
                if (current.Kind == "Services") checkDependents(current.Name);
                string target = DisabledState(current, processReduction);
                // A Manual service still reads as Enabled, so without this a repeat process-reduction
                // run would rewrite the same value and log a history entry every time.
                if (target == current.State) continue;
                var record = new StartupChange { Before = current, After = current with { State = target } };
                string path = Path.Combine(historyDirectory, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff") + "-" + Guid.NewGuid().ToString("N") + ".json");
                // Write and flush before making any system change, including the intended state.
                using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { JsonSerializer.Serialize(stream, record); stream.Flush(true); }
                Write(record.After);
                if (!Same(Read(record.After), record.After)) throw new IOException("Windows did not retain the requested state.");
                changed++;
                if (current.Kind == "Services" && !processReduction)
                {
                    try { stopService(current.Name); }
                    catch (Exception ex) { errors.Add(current.Name + ": Startup is disabled, but stopping failed: " + ex.Message + ". Check activity or restart Windows."); }
                }
            }
            catch (Exception ex) { errors.Add(original.Name + ": " + ex.Message); }
        }
        LastDisabledCount = changed;
        LastDisableErrors.AddRange(errors);
        return $"Disabled {changed} entries. " + (processReduction ? "Restart Windows to apply service changes; apps are not terminated." : "Services are also stopped when Windows permits; other entries affect future starts only.") + (errors.Count > 0 ? "\n" + string.Join("\n", errors) : "");
    }
    public string SetEnabled(StartupItem item, bool enabled)
    {
        if (!enabled) return Disable(new[] { item }, manual: true);
        var current = Read(item);
        if (!Same(current, item)) throw new IOException("Entry changed since scanning. Rescan first.");
        if (current.StateKnown && current.Enabled) return "Already enabled.";
        var backup = History().FirstOrDefault(h => Same(h.After, current));
        if (backup != null) return Undo(backup);
        // Desktop approval states have a defined enabled value; service startup types
        // cannot be inferred from Disabled and still require their original backup.
        current = Inspect(current);
        if (!current.ManuallyEditable || current.Enabled || current.Kind is not ("Logon apps" or "Startup folders"))
            throw new IOException("No matching original settings are available. Restore this entry through Windows or its application.");
        byte[] state = new byte[12]; state[0] = 2;
        var record = new StartupChange { Before = current, After = current with { State = Convert.ToBase64String(state) } };
        Directory.CreateDirectory(historyDirectory);
        string path = Path.Combine(historyDirectory, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff") + "-" + Guid.NewGuid().ToString("N") + ".json");
        using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        { JsonSerializer.Serialize(stream, record); stream.Flush(true); }
        Write(record.After);
        if (!Same(Read(record.After), record.After)) throw new IOException("Windows did not retain the requested state.");
        return "Enabled " + current.Name + ". Takes effect at next sign-in; the app was not launched.";
    }

    public string SetManual(StartupItem original)
    {
        signatures.Clear();
        var current = Inspect(Read(original));
        if (!Same(original, current)) throw new IOException("Entry changed since scanning. Rescan first.");
        if (ServiceManualRules.Guidance(current) == null) throw new IOException("This service has no reviewed Manual option, or is protected.");
        if (current.State == "3") return "Already Manual. A Manual service can still be running.";
        checkDependents(current.Name);
        var record = new StartupChange { Before = current, After = current with { State = "3" } };
        Directory.CreateDirectory(historyDirectory);
        string path = Path.Combine(historyDirectory, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fffffff") + "-" + Guid.NewGuid().ToString("N") + ".json");
        using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        { JsonSerializer.Serialize(stream, record); stream.Flush(true); }
        Write(record.After);
        if (!Same(Read(record.After), record.After)) throw new IOException("Windows did not retain Manual. The recovery record was kept; rescan before retrying.");
        return "Set " + current.Name + " to Manual. Its current process was left running; Windows or an app can start it on demand. Restore through Change history.";
    }
    public string? ProcessReductionKeepReason(StartupItem item, ProcessReductionChoices choices)
    {
        string? reason = ProcessReductionPolicy.KeepReason(item, choices);
        if (reason != null || item.Kind != "Services") return reason;
        try { checkDependents(item.Name); return null; }
        catch (Exception ex) { return "Protected/review: " + ex.Message; }
    }
    private static void StopService(string name)
    {
        using var service = new ServiceController(name);
        if (service.Status == ServiceControllerStatus.Stopped) return;
        if (service.Status != ServiceControllerStatus.StopPending)
        {
            if (!service.CanStop) throw new IOException("The service does not accept stop requests");
            service.Stop(false);
        }
        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15));
        service.Refresh();
        if (service.Status != ServiceControllerStatus.Stopped) throw new IOException("Windows has not confirmed that the service stopped");
    }
    public List<StartupChange> History()
    {
        var result = new List<StartupChange>();
        if (!Directory.Exists(historyDirectory)) return result;
        foreach (string path in Directory.GetFiles(historyDirectory, "*.json").OrderByDescending(p => p))
        {
            try
            {
                var change = JsonSerializer.Deserialize<StartupChange>(File.ReadAllText(path));
                if (change != null)
                {
                    change.FilePath = path;
                    try { var current = Read(change.After); change.Outcome = Same(current, change.Before) ? "Original state" : Same(current, change.After) ? current.Status : "Changed since backup"; }
                    catch { change.Outcome = "Entry unavailable"; }
                    result.Add(change);
                }
            }
            catch (Exception ex) { Warnings.Add("Unreadable history: " + ex.Message); }
        }
        return result;
    }
    public string Undo(StartupChange change)
    {
        if (change.Before.Id != change.After.Id || change.Before.Identity != change.After.Identity
            || !change.Before.StateKnown || !change.After.StateKnown
            || (!change.Before.Enabled && change.Before.Kind is not ("Logon apps" or "Startup folders"))
            || (change.Before.Kind == "Services"
                ? !((change.Before.State == "2" && change.After.State is "3" or "4")
                    || (change.Before.State == "3" && change.After.State == "4"))
                : change.Before.Enabled == change.After.Enabled))
            throw new IOException("Invalid change history: entry identity or state does not match.");
        var current = Read(change.After);
        if (Same(current, change.Before)) return "Already at the original state.";
        if (!Same(current, change.After)) throw new IOException("Entry changed after this backup. Undo was skipped to preserve the newer state.");
        // Revalidate rule and identity; history must never be able to target unrelated Windows components.
        signatures.Clear();
        var verifiedCurrent = Inspect(current);
        bool searchManualRecovery = change.Before.State == "2" && change.After.State == "3" && ServiceManualRules.IsWindowsSearch(verifiedCurrent);
        if (!verifiedCurrent.ManuallyEditable && !searchManualRecovery) throw new IOException("This entry cannot be restored through this tool.");
        Write(change.Before);
        if (!Same(Read(change.Before), change.Before)) throw new IOException("Windows did not retain the restored state.");
        return "Restored " + change.Before.Name + ". Takes effect at next sign-in or restart.";
    }
    public bool IsAtOriginalState(StartupChange change) => Same(Read(change.After), change.Before);
    public bool IsAtRecordedState(StartupChange change) => Same(Read(change.After), change.After);
    private void Write(StartupItem item)
    {
        if (testWrite != null) { testWrite(item); return; }
        if (item.Kind == "Services")
        {
            if (item.IsServiceTemplate)
            {
                // SCM instances are transient; Windows creates future instances from this template.
                // The same flushed StartupChange journal/readback/undo protects this Start-only write.
                using var templateKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + item.Name, true)
                    ?? throw new IOException("Service template no longer exists.");
                if (Convert.ToInt32(templateKey.GetValue("Type", 0)) != item.ServiceType
                    || item.State is not ("2" or "3" or "4")) throw new IOException("Service template changed; rescan first.");
                templateKey.SetValue("Start", int.Parse(item.State), RegistryValueKind.DWord);
            }
            else SetServiceStart(item.Name, uint.Parse(item.State!));
            return;
        }
        if (item.Kind == "Scheduled tasks")
        {
            using var scheduler = new TaskService();
            using var task = scheduler.GetTask(item.Location) ?? throw new IOException("Task no longer exists.");
            task.Enabled = bool.Parse(item.State!); return;
        }
        if (item.Kind is not ("Logon apps" or "Startup folders")) throw new IOException("This startup category is read-only.");
        var parts = item.Location.Split('|');
        if (parts.Length != 4) throw new IOException("Invalid startup location.");
        bool valid = item.Kind == "Logon apps"
            ? parts[2] == Run && (parts[3] == Approved + "Run" || parts[3] == Approved + "Run32")
            : parts[2] == Environment.GetFolderPath(parts[0] == "HKLM" ? Environment.SpecialFolder.CommonStartup : Environment.SpecialFolder.Startup) && parts[3] == Approved + "StartupFolder";
        if (!valid) throw new IOException("Invalid startup location.");
        using var root = RegistryKey.OpenBaseKey(parts[0] == "HKLM" ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, RegistryView.Registry64);
        using var key = root.CreateSubKey(parts[3]);
        if (item.State == null) key.DeleteValue(item.Name, false);
        else key.SetValue(item.Name, Convert.FromBase64String(item.State), RegistryValueKind.Binary);
    }
    private static void EnsureNoDependents(string name)
    {
        using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + name);
        int type = Convert.ToInt32(key?.GetValue("Type", 0));
        if (new StartupItem { Kind = "Services", ServiceType = type }.IsServiceTemplate)
        {
            // Check both registered dependencies on the template and the current instances.
            using var root = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services")
                ?? throw new IOException("Service dependencies could not be inspected.");
            foreach (string registered in root.GetSubKeyNames())
            {
                using var entry = root.OpenSubKey(registered)
                    ?? throw new IOException("A service disappeared while checking dependencies; rescan.");
                if ((entry.GetValue("DependOnService") as string[] ?? Array.Empty<string>())
                    .Any(d => ProcessReductionPolicy.ServiceMatches(d, name)))
                    throw new IOException("Other services depend on this template or an instance; left unchanged.");
            }
            var instances = ServiceController.GetServices();
            try
            {
                foreach (var instance in instances.Where(s => ProcessReductionPolicy.ServiceMatches(s.ServiceName, name)))
                {
                    var children = instance.DependentServices;
                    try { if (children.Length > 0) throw new IOException("Other services depend on an instance; left unchanged."); }
                    finally { foreach (var child in children) child.Dispose(); }
                }
            }
            finally { foreach (var instance in instances) instance.Dispose(); }
            return;
        }
        using var service = new ServiceController(name);
        var dependents = service.DependentServices;
        try { if (dependents.Length > 0) throw new IOException("Other services depend on this service; left unchanged."); }
        finally { foreach (var dependent in dependents) dependent.Dispose(); }
    }
    private static void SetServiceStart(string name, uint start)
    {
        if (start is not (2 or 3 or 4)) throw new IOException("Invalid service startup type.");
        IntPtr manager = OpenSCManager(null, null, 1);
        if (manager == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
        try
        {
            IntPtr service = OpenService(manager, name, 2);
            if (service == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            try { if (!ChangeServiceConfig(service, uint.MaxValue, start, uint.MaxValue, null, null, IntPtr.Zero, null, null, null, null)) throw new Win32Exception(Marshal.GetLastWin32Error()); }
            finally { CloseServiceHandle(service); }
        }
        finally { CloseServiceHandle(manager); }
    }
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr OpenSCManager(string? machine, string? database, uint access);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr OpenService(IntPtr manager, string name, uint access);
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool ChangeServiceConfig(IntPtr service, uint type, uint start, uint error, string? binary, string? group, IntPtr tag, string? dependencies, string? account, string? password, string? display);
    [DllImport("advapi32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool CloseServiceHandle(IntPtr handle);
}
public sealed class StartupChange
{
    public DateTimeOffset Created { get; set; } = DateTimeOffset.Now;
    public StartupItem Before { get; set; } = new();
    public StartupItem After { get; set; } = new();
    [System.Text.Json.Serialization.JsonIgnore] public string FilePath { get; set; } = "";
    [System.Text.Json.Serialization.JsonIgnore] public string Outcome { get; set; } = "Saved before change";
    public string Description => $"{Created:g} · {Before.Name} · {Before.Kind} · {Outcome}";
}
