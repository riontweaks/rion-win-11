using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using RionHub.Modules.Optimize;
using RionHub.Shell;

namespace RionHub.Modules.Startup;

public partial class BackgroundAppsView : UserControl
{
    private CancellationTokenSource? scan;
    private sealed record AppRule(string Name, string[] Names, string[] Processes, string Guidance);
    private sealed record AppRow(string Name, string State, string Guidance);
    private static readonly AppRule[] Catalog =
    {
        new("Discord", new[] { "Discord" }, new[] { "Discord" }, "Turn off automatic launch and minimize-to-tray behavior if you only use Discord during calls. Quit it from the tray when finished; messages and calls will not arrive while it is closed."),
        new("Spotify", new[] { "Spotify", "SpotifyAB.SpotifyMusic" }, new[] { "Spotify" }, "Disable sign-in launch if you open Spotify yourself. Fully quit it when finished; playback and remote playback control will stop."),
        new("Epic Games Launcher", new[] { "Epic Games Launcher" }, new[] { "EpicGamesLauncher", "EpicWebHelper" }, "Disable launcher startup and quit the launcher when no download or game needs it. Keep Epic Online Services and anti-cheat available for games."),
        new("Steam", new[] { "Steam" }, new[] { "steam", "steamwebhelper" }, "Disable sign-in launch if background game downloads are unnecessary. Exit after games and downloads finish. Keep Steam Client Service available for installs and repairs."),
        new("Chrome", new[] { "Google Chrome" }, new[] { "chrome" }, "Review the option to continue running background apps when Chrome is closed. Turning it off can stop extension notifications. Retain the Google updater for browser security fixes."),
        new("Microsoft Edge", new[] { "Microsoft Edge" }, new[] { "msedge" }, "Review Startup boost and background extensions/apps in Edge's system settings. Keep Edge Update and WebView2; other applications depend on WebView2."),
        new("Teams", new[] { "Microsoft Teams", "MSTeams", "MicrosoftTeams" }, new[] { "ms-teams", "Teams" }, "Turn off sign-in launch and keep-running-on-close if you only use Teams for scheduled meetings. Quit it when finished; calls and notifications may be missed."),
        new("Slack", new[] { "Slack" }, new[] { "slack" }, "Disable sign-in launch and quit from the tray when you do not need work messages. Background notifications stop while Slack is closed."),
        new("Zoom", new[] { "Zoom", "Zoom Workplace" }, new[] { "Zoom" }, "Disable sign-in launch if you only open Zoom for meetings. Quit it after the meeting; incoming calls and notifications may be unavailable."),
        new("Adobe Creative Cloud", new[] { "Adobe Creative Cloud" }, new[] { "Creative Cloud", "CCXProcess" }, "Review sign-in launch, file sync and background preferences in Creative Cloud. Keep licensing components; disabling update services requires maintaining security updates yourself."),
        new("OneDrive", new[] { "Microsoft OneDrive", "Microsoft.OneDriveSync" }, new[] { "OneDrive" }, "Disable startup to stop automatic sync until launch, or review removal in Debloating. Download needed cloud-only files first; removal stops sync and folder backup and does not delete the data folder."),
        new("Phone Link", new[] { "Microsoft.YourPhone", "Phone Link" }, new[] { "PhoneExperienceHost", "YourPhone" }, "Turn off sign-in launch and background permissions where offered. Debloating can attempt removal where Windows permits it; phone calls, messages and cross-device features will be unavailable."),
        new("Dropbox", new[] { "Dropbox" }, new[] { "Dropbox" }, "Disable sign-in launch or pause sync when it is unnecessary. Keep a local copy of files you need offline. Changes will not sync while Dropbox is closed."),
        new("Google Drive", new[] { "Google Drive" }, new[] { "GoogleDriveFS" }, "Review sign-in launch or pause syncing. Streamed files may become unavailable while Drive is closed; make needed files available offline first.")
    };
    public BackgroundAppsView()
    {
        InitializeComponent();
        Unloaded += (_, _) => scan?.Cancel();
    }
    private async void Scan_Click(object sender, RoutedEventArgs e) => await ScanAsync();
    private async Task ScanAsync()
    {
        if (scan != null) return;
        using var cancellation = new CancellationTokenSource();
        scan = cancellation; ScanButton.IsEnabled = false;
        try
        {
            var inventory = await Task.Run(() => AppInventoryScanner.Scan(cancellation.Token,
                new Progress<string>(message => Dispatcher.InvokeAsync(() => { if (!cancellation.IsCancellationRequested) Status.Text = message; }))));
            cancellation.Token.ThrowIfCancellationRequested();
            var processes = await Task.Run(() =>
            {
                var names = new List<string>();
                foreach (var process in Process.GetProcesses())
                    using (process)
                        try { names.Add(process.ProcessName); } catch (InvalidOperationException) { } catch (System.ComponentModel.Win32Exception) { }
                return names;
            });
            cancellation.Token.ThrowIfCancellationRequested();
            var rows = Catalog.Select(rule =>
            {
                bool installed = inventory.Apps.Any(app => rule.Names.Contains(app.Name, StringComparer.OrdinalIgnoreCase));
                int running = processes.Count(name => rule.Processes.Contains(name, StringComparer.OrdinalIgnoreCase));
                return (Show: installed || running > 0, Row: new AppRow(rule.Name,
                    $"{(installed ? "Found in app inventory" : "Running process name observed; installation not verified")} · {running} matching process(es)", rule.Guidance));
            }).Where(row => row.Show).Select(row => row.Row).ToArray();
            Rows.ItemsSource = rows;
            Status.Text = $"{rows.Length} common apps found · {processes.Count} readable processes · {DateTime.Now:t}. "
                + (inventory.Warnings.Count == 0 ? "Scan complete; matching process names are observations, not verified executable identities."
                    : $"Inventory incomplete ({inventory.Warnings.Count} warning(s)); missing entries do not prove an app is absent.\n" + string.Join("\n", inventory.Warnings.Take(3)));
        }
        catch (OperationCanceledException) { Status.Text = "Scan cancelled. Scan again to refresh the results."; }
        catch (Exception ex) { Status.Text = "Scan unavailable: " + ex.Message; }
        finally { scan = null; ScanButton.IsEnabled = true; }
    }
    private void Open(string uri)
    {
        try { Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); }
        catch (Exception ex) { Status.Text = "Could not open Windows settings: " + ex.Message; }
    }
    private void Startup_Click(object sender, RoutedEventArgs e) => Open("ms-settings:startupapps");
    private void Apps_Click(object sender, RoutedEventArgs e) => Open("ms-settings:appsfeatures");
}
