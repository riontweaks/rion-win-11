using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;

namespace RionHub.Modules.Startup;

public sealed class StartupRow : ObservableObject
{
    private readonly Func<StartupRow, bool, Task> toggle;
    public StartupRow(StartupItem item, bool canToggle, Func<StartupRow, bool, Task> toggle)
    { Item = item; CanToggle = canToggle; this.toggle = toggle; }
    public StartupItem Item { get; }
    public bool CanToggle { get; }
    public string FriendlyName => VendorStartupRules.Match(Item)?.Label
        ?? ProcessReductionPolicy.ServiceLabel(Item.Name)
        ?? (Item.Kind == "Services" && Item.Schedule.StartsWith("Service: ") ? Item.Schedule[9..] : Item.Name);
    public string Guidance => !Item.StateKnown ? "Unknown state · leave unchanged" : Item.Kind == "Packaged apps" ? "Manage in Windows settings" : !Item.Enabled ? "Disabled"
        : VendorStartupRules.Match(Item) != null ? "Optional · manual updates needed"
        : Item.Recommended ? "Can disable · open manually" : Item.Editable ? "Optional · check what changes" : "Keep enabled";
    public bool? Enabled
    {
        get => Item.StateKnown ? Item.Enabled : null;
        set { if (value.HasValue && value != Enabled && CanToggle) _ = toggle(this, value.Value); }
    }
    public void RefreshState() => Raise(nameof(Enabled));
    public string? ManualGuidance => ServiceManualRules.Guidance(Item);
    public string ToggleHint => !CanToggle ? "Read-only: unsupported entry type, unknown state, or no saved settings to restore."
        : Item.Enabled ? "Uncheck to disable. Services are also stopped." : "Check to enable startup or restore saved settings.";
}
public sealed class StartupViewModel : ObservableObject
{
    private readonly StartupEngine engine = new();
    public ObservableCollection<StartupRow> Rows { get; } = new();
    public ObservableCollection<StartupChange> History { get; } = new();
    public ICollectionView View { get; }
    private readonly ObservableCollection<StartupRow> pageRows = new();
    private const int PageSize = 15;
    private int pageIndex;
    private int matchingCount;
    public string[] Categories { get; } = { "Apps", "Background extras", "Manual service options", "Updaters", "Scheduled tasks", "All entries (advanced)" };
    public string[] States { get; } = { "All states", "Enabled", "Disabled", "Suggested to disable" };
    private string state = "All states";
    public string State { get => state; set { if (Set(ref state, value)) { pageIndex = 0; RefreshPage(); } } }
    public RelayCommand PreviousPageCommand { get; }
    public RelayCommand NextPageCommand { get; }
    public string PageSummary => $"Page {pageIndex + 1} of {Math.Max(1, (matchingCount + PageSize - 1) / PageSize)}";
    public bool HasMultiplePages => matchingCount > PageSize;
    public bool HasNoEntries => matchingCount == 0 && !Busy;
    public RelayCommand ScanCommand { get; }
    public RelayCommand DisableCommand { get; }
    public RelayCommand DisableAllAppsCommand { get; }
    public RelayCommand UndoCommand { get; }
    public RelayCommand ManualCommand { get; }
    public StartupViewModel()
    {
        View = CollectionViewSource.GetDefaultView(pageRows);
        PreviousPageCommand = new RelayCommand(() => { pageIndex--; RefreshPage(); }, () => !Busy && pageIndex > 0);
        NextPageCommand = new RelayCommand(() => { pageIndex++; RefreshPage(); }, () => !Busy && (pageIndex + 1) * PageSize < matchingCount);
        ScanCommand = new RelayCommand(async () => await ScanAsync(), () => !Busy);
        DisableCommand = new RelayCommand(async () => await ChangeAsync(false), () => !Busy && ShowDisableSuggested && pageRows.Any(r => r.Item.Recommended && r.Item.Editable && r.Item.Enabled));
        DisableAllAppsCommand = new RelayCommand(async () => await DisableAllAppsAsync(), () => !Busy && Rows.Any(r => StartupAppBatch.CanDisable(r.Item)));
        UndoCommand = new RelayCommand(async () => await ChangeAsync(true), () => !Busy && SelectedHistory != null);
        ManualCommand = new RelayCommand(async () => await SetManualAsync(), () => !Busy && SelectedRow is { Item.State: "2", ManualGuidance: not null });
        _ = ScanAsync();
    }
    private bool busy;
    public bool Busy { get => busy; private set { Set(ref busy, value); Raise(nameof(Idle)); UpdateCommands(); } }
    public bool Idle => !Busy;
    private string search = "";
    public string Search { get => search; set { if (Set(ref search, value)) { pageIndex = 0; RefreshPage(); } } }
    private string category = "Apps";
    public string Category { get => category; set { if (Set(ref category, value)) { pageIndex = 0; Raise(nameof(ShowDisableSuggested)); RefreshPage(); } } }
    public bool ShowDisableSuggested => Category != "Manual service options";
    private string status = "Scanning startup entries…";
    public string Status { get => status; private set => Set(ref status, value); }
    public RelayCommand WindowsSettingsCommand { get; } = new RelayCommand(() => System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("ms-settings:startupapps") { UseShellExecute = true }));
    public string Summary => $"{matchingCount} matching · {pageRows.Count} on this page · {Rows.Count(r => StartupListRules.InCategory(r.Item, Category) && r.Item.StateKnown && r.Item.Enabled)} enabled in {Category}";
    private void RefreshPage()
    {
        var selectedId = SelectedRow?.Item.Id;
        var matches = Rows.Where(row => StartupListRules.InCategory(row.Item, Category)
            && StartupListRules.InState(row.Item, State)
            && (string.IsNullOrWhiteSpace(Search) || (row.FriendlyName + " " + row.Item.Name + " " + row.Item.Command + " " + row.Item.Publisher + " " + row.Item.Description).Contains(Search, StringComparison.OrdinalIgnoreCase)))
            .OrderByDescending(r => r.Item.Enabled).ThenBy(r => r.FriendlyName, StringComparer.OrdinalIgnoreCase).ThenBy(r => r.Item.Id).ToList();
        matchingCount = matches.Count;
        pageIndex = Math.Clamp(pageIndex, 0, Math.Max(0, (matchingCount - 1) / PageSize));
        pageRows.Clear();
        foreach (var row in matches.Skip(pageIndex * PageSize).Take(PageSize)) pageRows.Add(row);
        SelectedRow = pageRows.FirstOrDefault(r => r.Item.Id == selectedId) ?? pageRows.FirstOrDefault();
        Raise(nameof(Summary)); Raise(nameof(PageSummary)); Raise(nameof(HasMultiplePages)); Raise(nameof(HasNoEntries));
        UpdateCommands();
    }
    private StartupRow? selectedRow;
    public StartupRow? SelectedRow { get => selectedRow; set { Set(ref selectedRow, value); ManualCommand?.RaiseCanExecuteChanged(); } }
    private StartupChange? selectedHistory;
    public StartupChange? SelectedHistory { get => selectedHistory; set { Set(ref selectedHistory, value); UndoCommand.RaiseCanExecuteChanged(); } }
    private void UpdateCommands()
    {
        ScanCommand?.RaiseCanExecuteChanged(); DisableCommand?.RaiseCanExecuteChanged(); UndoCommand?.RaiseCanExecuteChanged();
        ManualCommand?.RaiseCanExecuteChanged();
        DisableAllAppsCommand?.RaiseCanExecuteChanged();
        PreviousPageCommand?.RaiseCanExecuteChanged(); NextPageCommand?.RaiseCanExecuteChanged();
        Raise(nameof(HasNoEntries));
        Raise(nameof(Summary));
    }
    private async Task LoadAsync()
    {
        var items = await Task.Run(engine.Scan);
        var previousId = SelectedRow?.Item.Id;
        History.Clear();
        foreach (var change in await Task.Run(engine.History)) History.Add(change);
        Rows.Clear();
        foreach (var item in items)
        {
            var row = new StartupRow(item, item.ManuallyEditable && (item.Enabled || item.Kind is "Logon apps" or "Startup folders" || History.Any(h => StartupEngine.Same(h.After, item))), ToggleAsync);
            Rows.Add(row);
        }
        SelectedRow = Rows.FirstOrDefault(r => r.Item.Id == previousId);
        RefreshPage();
    }
    private async Task ScanAsync()
    {
        if (Busy) return;
        Busy = true; Status = "Scanning startup entries. No settings are being changed…";
        try { await LoadAsync(); Status = engine.Warnings.Count == 0 ? "Apps shows enabled and disabled desktop apps, startup shortcuts and known packaged startup registrations. Checked means enabled. Packaged apps are read-only here; use Windows settings to manage them." : $"Scan complete with {engine.Warnings.Count} inaccessible entries/locations.\n" + string.Join("\n", engine.Warnings.Take(8)); }
        catch (Exception ex) { Status = "Scan failed: " + ex.Message; }
        finally { Busy = false; }
    }
    private async Task ToggleAsync(StartupRow row, bool enabled)
    {
        if (Busy) { row.RefreshState(); return; }
        if (!enabled && (row.Item.Kind is "Services" or "Scheduled tasks")
            && System.Windows.MessageBox.Show(row.FriendlyName + "\n\n" + row.Item.Reason
                + "\n\nDisabling can stop background features or updates. Services are also stopped immediately. Continue?",
                "Review startup change", System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Warning, System.Windows.MessageBoxResult.No) != System.Windows.MessageBoxResult.Yes)
        { row.RefreshState(); return; }
        Busy = true;
        SelectedRow = row;
        Status = enabled ? "Enabling startup or restoring saved settings…" : "Disabling entry and stopping it if it is a service…";
        try
        {
            string result;
            try { result = await Task.Run(() => engine.SetEnabled(row.Item, enabled)); }
            catch (Exception ex) { result = "Change was not completed: " + ex.Message; }
            await LoadAsync();
            Status = result;
        }
        catch (Exception ex) { Status = "Could not refresh the state. Rescan before continuing: " + ex.Message; }
        finally { row.RefreshState(); Busy = false; }
    }
    private async Task ChangeAsync(bool undo)
    {
        if (Busy) return;
        var chosen = pageRows.Where(r => r.Item.Recommended && r.Item.Editable && r.Item.Enabled).Select(r => r.Item).ToArray();
        var history = SelectedHistory;
        if (undo ? history == null : chosen.Length == 0) return;
        if (!undo && System.Windows.MessageBox.Show("Disable these entries on the current page?\n\n"
            + string.Join("\n", chosen.Select(i => i.Name)) + "\n\nBackground notifications, syncing or updates may wait until you open the apps. Undo is available in Change history.",
            "Review startup changes", System.Windows.MessageBoxButton.YesNo,
            System.Windows.MessageBoxImage.Warning, System.Windows.MessageBoxResult.No) != System.Windows.MessageBoxResult.Yes) return;
        Busy = true; Status = undo ? "Restoring original startup state…" : "Saving original states and disabling selected entries…";
        try
        {
            string result = await Task.Run(() => undo ? engine.Undo(history!) : engine.Disable(chosen));
            await LoadAsync(); Status = result;
        }
        catch (Exception ex) { Status = "Change was not completed: " + ex.Message; }
        finally { Busy = false; }
    }

    private async Task DisableAllAppsAsync()
    {
        if (Busy) return;
        var chosen = Rows.Where(r => StartupAppBatch.CanDisable(r.Item)).Select(r => r.Item).ToArray();
        int skipped = Rows.Count(r => StartupListRules.InCategory(r.Item, "Apps") && (!r.Item.StateKnown || r.Item.Enabled) && !StartupAppBatch.CanDisable(r.Item));
        if (chosen.Length == 0) return;
        if (System.Windows.MessageBox.Show($"Disable {chosen.Length} startup apps across all pages and filters?\n\n"
            + string.Join("\n", chosen.Take(20).Select(i => i.Name)) + (chosen.Length > 20 ? $"\n…and {chosen.Length - 20} more" : "")
            + $"\n\n{skipped} protected, packaged or unknown entries will be skipped. Notifications and syncing may wait until you open the apps. Services and scheduled tasks are not included. Saved states are available in Change history.",
            "Review all startup apps", System.Windows.MessageBoxButton.YesNo, System.Windows.MessageBoxImage.Warning,
            System.Windows.MessageBoxResult.No) != System.Windows.MessageBoxResult.Yes) return;
        Busy = true;
        try { Status = "Saving startup states…"; var result = await Task.Run(() => engine.Disable(chosen, manual: true)); await LoadAsync(); Status = result + $" {skipped} entries skipped; use Windows settings for packaged apps."; }
        catch (Exception ex) { Status = "Startup batch was not completed: " + ex.Message + ". Inspect Change history before retrying."; }
        finally { Busy = false; }
    }

    private async Task SetManualAsync()
    {
        var row = SelectedRow;
        if (Busy || row?.ManualGuidance == null || row.Item.State != "2") return;
        Busy = true;
        try
        {
            Status = await Task.Run(() => engine.SetManual(row.Item));
            await LoadAsync();
        }
        catch (Exception ex) { Status = "Manual change was not completed: " + ex.Message; }
        finally { Busy = false; }
    }
}


