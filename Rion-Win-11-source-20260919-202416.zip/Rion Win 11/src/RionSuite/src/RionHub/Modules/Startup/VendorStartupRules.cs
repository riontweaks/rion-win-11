using System.IO;

namespace RionHub.Modules.Startup;

public sealed record VendorStartupEntry(string Label, string Effect, bool Xbox = false);

public static class VendorStartupRules
{
    public static VendorStartupEntry? Match(StartupItem item)
    {
        if (!item.PublisherVerified) return null;
        string file = Path.GetFileName(StartupRules.Executable(item.Command)).ToLowerInvariant();
        bool adobe = item.Publisher is "Adobe Inc." or "Adobe Systems Incorporated";
        if (adobe && ((item.Kind == "Services" && item.Name == "AdobeARMservice" && file == "armsvc.exe")
            || (item.Kind == "Scheduled tasks" && item.Name == "Adobe Acrobat Update Task" && file == "adobearm.exe")))
            return new("Adobe Acrobat updater", "Acrobat/Reader automatic updates, including security fixes, stop. Use Help → Check for updates regularly.");
        if (adobe && item.Kind == "Services" && item.Name == "AdobeUpdateService" && file == "adobeupdateservice.exe")
            return new("Adobe software updater", "Adobe background updates stop. Open Adobe apps to check for updates manually.");
        if (item.Kind == "Services" && item.Publisher is "Google LLC" or "Google Inc."
            && (item.Name is "gupdate" or "gupdatem" || item.Name.StartsWith("GoogleUpdater", StringComparison.OrdinalIgnoreCase))
            && file is "googleupdate.exe" or "updater.exe")
            return new("Google software updater", "Automatic Google app/browser updates may stop. Check for browser security updates manually.");
        // OEM updater names vary. Require matching signer, service name, executable and
        // descriptive role; never treat an audio/game runtime as an updater based on its vendor.
        if (item.Kind != "Services" || !item.Name.Contains("update", StringComparison.OrdinalIgnoreCase)
            || !file.Contains("update", StringComparison.OrdinalIgnoreCase)
            || !item.Description.Contains("updat", StringComparison.OrdinalIgnoreCase)) return null;
        if (item.Publisher.StartsWith("Realtek", StringComparison.OrdinalIgnoreCase)
            && (item.Name.StartsWith("Realtek", StringComparison.OrdinalIgnoreCase) || item.Name.StartsWith("Rtk", StringComparison.OrdinalIgnoreCase)))
            return new("Realtek updater", "Automatic Realtek software update checks stop. Audio services stay protected; update drivers through your PC manufacturer when needed.");
        if (item.Publisher is "Epic Games, Inc." or "Epic Games Inc." && item.Name.StartsWith("Epic", StringComparison.OrdinalIgnoreCase))
            return new("Epic Games updater", "Background Epic update checks stop. Open the launcher to update. Epic Online Services and anti-cheat remain protected.");
        if (item.Publisher.StartsWith("Microsoft", StringComparison.OrdinalIgnoreCase) && item.Name.StartsWith("Xbox", StringComparison.OrdinalIgnoreCase))
            return new("Xbox updater", "Xbox background update checks stop. Update through the Xbox app or Store. Gaming Services and Windows Update remain protected.", true);
        return null;
    }

    public static string? ProtectedRole(StartupItem item)
    {
        string name = item.Name.ToLowerInvariant();
        string file = Path.GetFileName(StartupRules.Executable(item.Command)).ToLowerInvariant();
        string role = (item.Name + " " + item.Description + " " + file).ToLowerInvariant();
        if (role.Contains("thermal") || role.Contains("dynamic tuning") || role.Contains("dynamic platform")
            || role.Contains("fan control") || role.Contains("platform framework") || role.Contains("amdpmf"))
            return "OEM power, fan or thermal management: retain the laptop manufacturer's protections.";
        if (name is "rtkaudiouniversalservice" or "rtkauduservice" or "realtekaudioservice" || file is "rtkauduservice64.exe" or "rtkaudioservice64.exe")
            return "Realtek audio support: keep enabled for audio features and devices.";
        if (name is "epiconlineservices" or "gamingservices" or "gamingservicesnet" or "vgc" or "vgk"
            || name.Contains("vanguard") || file == "vgtray.exe" || name.StartsWith("easyanticheat") || name is "beservice"
            || role.Contains("anticheat") || role.Contains("anti-cheat") || role.Contains("battleye") || role.Contains("faceit"))
            return "Game installation, online features or anti-cheat support: not an updater to remove.";
        if (name is "agsservice" or "agmservice") return "Adobe licensing/integrity support: not an updater.";
        return null;
    }
}

public static class ServiceManualRules
{
    // Eligibility is an option to review, never a bulk recommendation. Manual permits an
    // explicit/trigger start but does not guarantee that the owning app will request it.
    public static string? Guidance(StartupItem item)
    {
        // Search remains protected from disabling. This exact, signed service has a
        // separately reviewed Automatic -> Manual option with history recovery.
        if (IsWindowsSearch(item))
            return "Windows Search indexing. Manual removes automatic startup, but does not restrict indexing to active searches. A running indexer stays running. File and Outlook searches can be slower or incomplete when it is stopped. Restore through Change history.";
        if (item.Kind != "Services" || !item.StateKnown || item.State is not ("2" or "3")
            || VendorStartupRules.ProtectedRole(item) != null
            || RadeonSoftwareSlimmer.Optimize.ServiceProtection.Reason(item.Name) != null) return null;
        if (VendorStartupRules.Match(item) is { } updater)
            return updater.Effect + " Manual allows on-demand start, but automatic updates are not guaranteed. Keep Automatic unless you will maintain these apps yourself.";
        if (item.PublisherVerified)
        {
            string file = Path.GetFileName(StartupRules.Executable(item.Command));
            if (item.Name.Equals("FvSvc", StringComparison.OrdinalIgnoreCase) && item.Publisher == "NVIDIA Corporation"
                && file.Equals("nvfvsdksvc_x64.exe", StringComparison.OrdinalIgnoreCase))
                return "Optional FrameView metrics service. Manual may make FrameView measurements unavailable until its service is started; the display driver remains enabled.";
            if (item.Name.Equals("Steam Client Service", StringComparison.OrdinalIgnoreCase)
                && item.Publisher is "Valve Corp." or "Valve Corporation" && file.Equals("SteamService.exe", StringComparison.OrdinalIgnoreCase))
                return "Steam's privileged install/repair helper. Manual permits Steam to request it when needed; installs may require elevation. Leave it available rather than Disabled.";
            if (item.Name.Equals("MozillaMaintenance", StringComparison.OrdinalIgnoreCase) && item.Publisher == "Mozilla Corporation"
                && file.Equals("maintenanceservice.exe", StringComparison.OrdinalIgnoreCase))
                return "Firefox's update elevation helper. Manual permits an update to request it. Keep it installed and keep browser updates enabled.";
        }
        if (!item.PublisherVerified || item.Publisher is not ("Microsoft Corporation" or "Microsoft Windows")) return null;
        var windows = RadeonSoftwareSlimmer.Optimize.ServiceTrimCatalog.All.FirstOrDefault(s => s.Name.Equals(item.Name, StringComparison.OrdinalIgnoreCase) && s.TargetStart == 3);
        return windows == null ? null : windows.Note + ". Manual permits apps or Windows triggers to start the service; the related feature may need an explicit start. Review whether you use it.";
    }

    public static bool IsWindowsSearch(StartupItem item) => item.Kind == "Services" && item.StateKnown && item.State is "2" or "3"
        && item.Name.Equals("WSearch", StringComparison.OrdinalIgnoreCase) && item.PublisherVerified
        && item.Publisher is "Microsoft Corporation" or "Microsoft Windows"
        && StartupRules.Executable(item.Command).Equals(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "SearchIndexer.exe"), StringComparison.OrdinalIgnoreCase);
}
