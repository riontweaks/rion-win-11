namespace RionHub.Modules.History;

public sealed record RecoveryCheckpoint(string Key, IReadOnlyList<HistoryRecord> Changes)
{
    public string Title => Changes[0].Label;
    public string When => Changes[0].LocalTime;
    public int RestorableCount => Changes.Count(c => c.CanRestore);
    public string Summary => $"{Changes.Count} recorded changes · {RestorableCount} available to restore";
    public string Details => string.Join("\n\n", Changes.Select(c => $"{c.Target}\n{c.PreviousValue} → {c.RequestedValue}\n{c.Status}"));
    // Registry IDs are explicitly backup-file:index, not a time-based guess at a batch.
    public static IReadOnlyList<RecoveryCheckpoint> From(IEnumerable<HistoryRecord> records) => records
        .Where(r => r.Source == "Registry" && r.Id.LastIndexOf(':') > 0 && int.TryParse(r.Id[(r.Id.LastIndexOf(':') + 1)..], out _))
        .GroupBy(r => r.Id[..r.Id.LastIndexOf(':')])
        .Select(g => new RecoveryCheckpoint(g.Key, g.OrderByDescending(r => int.Parse(r.Id[(r.Id.LastIndexOf(':') + 1)..])).ToArray()))
        .Where(g => g.Changes.Count > 1)
        .OrderByDescending(g => g.Changes[0].TimestampUtc).ToArray();
}
