namespace RionHub.Modules.History;

public sealed record HistoryRecord(
    string Source, string Id, DateTime TimestampUtc, string Description, string Target,
    string PreviousValue, string RequestedValue, string Status, string Error, bool CanRestore)
{
    public string LocalTime => TimestampUtc == default ? "Date unavailable" : TimestampUtc.ToLocalTime().ToString("g");
    public string Label => string.IsNullOrWhiteSpace(Description) ? Target : Description;
}

public sealed record HistoryRestoreResult(bool Success, string Message);

public interface IHistorySource
{
    string Name { get; }
    IReadOnlyList<HistoryRecord> ListEntries();
    HistoryRestoreResult Restore(string id);
}

public sealed class RegistryHistorySource : IHistorySource
{
    public string Name => "Registry";
    public IReadOnlyList<HistoryRecord> ListEntries() =>
        RadeonSoftwareSlimmer.Services.RegistryChangeHistory.ListEntries().Select(e =>
            new HistoryRecord(Name, e.Id, e.TimestampUtc, e.Description, e.Target,
                e.PreviousValue, e.RequestedValue, e.Status, e.Error, e.CanRestore)).ToList();
    public HistoryRestoreResult Restore(string id)
    {
        var result = RadeonSoftwareSlimmer.Services.RegistryChangeHistory.Restore(id);
        return new(result.Success, result.Message);
    }
}

public sealed class PowerHistorySource : IHistorySource
{
    public string Name => "Power";
    public IReadOnlyList<HistoryRecord> ListEntries() =>
        PowerSettingsExplorer.Services.PowerChangeHistory.ListEntries().Select(e =>
            new HistoryRecord(Name, e.Id, e.TimestampUtc, e.Description, e.Target,
                e.PreviousValue, e.RequestedValue, e.Status, e.Error, e.CanRestore)).ToList();
    public HistoryRestoreResult Restore(string id)
    {
        var result = PowerSettingsExplorer.Services.PowerChangeHistory.Restore(id);
        return new(result.Success, result.Message);
    }
}
