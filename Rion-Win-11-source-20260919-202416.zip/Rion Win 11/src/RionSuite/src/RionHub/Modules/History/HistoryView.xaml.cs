using System.Windows;
using System.Windows.Controls;

namespace RionHub.Modules.History;

public partial class HistoryView : UserControl
{
    public HistoryView()
    {
        InitializeComponent();
        SizeChanged += (_, _) =>
        {
            bool compact = ActualWidth < 800;
            Reflow(OperationsLayout, OperationDetails, compact);
            Reflow(ChangesLayout, ChangeDetails, compact);
        };
        Loaded += async (_, _) => { if (DataContext is HistoryViewModel vm) await vm.RefreshAsync(); };
    }
    private static void Reflow(Grid grid, FrameworkElement details, bool compact)
    {
        grid.ColumnDefinitions[1].Width = new GridLength(compact ? 0 : 16);
        grid.ColumnDefinitions[2].Width = compact ? new GridLength(0) : new GridLength(1, GridUnitType.Star);
        grid.RowDefinitions[1].Height = compact ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
        Grid.SetColumn(details, compact ? 0 : 2);
        Grid.SetRow(details, compact ? 1 : 0);
        details.Margin = compact ? new Thickness(0, 10, 0, 0) : new Thickness(0);
    }
}
