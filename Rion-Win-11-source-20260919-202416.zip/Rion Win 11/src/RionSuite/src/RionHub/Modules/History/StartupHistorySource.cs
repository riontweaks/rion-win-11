using System.IO;
using RionHub.Modules.Startup;

namespace RionHub.Modules.History;

public sealed class StartupHistorySource : IHistorySource
{
    private readonly StartupEngine engine;
    private readonly object gate = new();
    public string Name => "Startup";
    public StartupHistorySource() : this(new StartupEngine()) { }
    internal StartupHistorySource(StartupEngine engine) => this.engine = engine;

    public IReadOnlyList<HistoryRecord> ListEntries()
    {
        lock (gate)
        {
            engine.Warnings.Clear();
            var records = new List<HistoryRecord>();
            foreach (var change in engine.History())
            {
                string id = Path.GetFileName(change.FilePath);
                try
                {
                    bool canRestore = !engine.IsAtOriginalState(change) && engine.IsAtRecordedState(change);
                    records.Add(new(Name, id, change.Created.UtcDateTime, change.Before.Name,
                        change.Before.Kind + " / " + change.Before.Location,
                        change.Before.Status, change.After.Status, change.Outcome,
                        change.Outcome is "Changed since backup" or "Entry unavailable" ? change.Outcome : "", canRestore));
                }
                catch (Exception ex)
                {
                    records.Add(new(Name, id, change.Created.UtcDateTime, "Unavailable startup history", id,
                        "", "", "Unavailable", ex.Message, false));
                }
            }
            for (int i = 0; i < engine.Warnings.Count; i++)
                records.Add(new(Name, "warning:" + i, default, "Unreadable startup history", "Startup history",
                    "", "", "Unreadable", engine.Warnings[i], false));
            return records.OrderByDescending(r => r.TimestampUtc).ToList();
        }
    }

    public HistoryRestoreResult Restore(string id)
    {
        lock (gate)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(id) || id != Path.GetFileName(id) || !id.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                    return new(false, "Invalid startup history identifier.");
                // Reload the persisted object; UI fields never authorize a startup write.
                engine.Warnings.Clear();
                var change = engine.History().SingleOrDefault(c => Path.GetFileName(c.FilePath) == id);
                if (change == null) return new(false, "The saved startup change is missing or unreadable. Refresh history.");
                string message = engine.Undo(change);
                return engine.IsAtOriginalState(change)
                    ? new(true, message)
                    : new(false, "Startup restoration could not be verified. Refresh history; the record was retained.");
            }
            catch (Exception ex) { return new(false, "Startup restoration failed: " + ex.Message); }
        }
    }
}
