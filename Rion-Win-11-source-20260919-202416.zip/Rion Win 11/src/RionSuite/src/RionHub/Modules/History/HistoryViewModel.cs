using System.Collections.ObjectModel;

namespace RionHub.Modules.History;

public sealed class HistoryViewModel : ObservableObject
{
    private readonly IReadOnlyList<IHistorySource> _sources;
    private readonly Action<string>? _navigate;
    private List<HistoryRecord> _all = new();
    private bool _busy;
    private string _search = "";
    private string _filter = "All";
    private string _message = "";
    private string _loadWarning = "";
    private HistoryRecord? _selected;

    public HistoryViewModel(IEnumerable<IHistorySource>? sources = null, Action<string>? navigate = null)
    {
        _sources = (sources ?? new IHistorySource[] { new RegistryHistorySource(), new PowerHistorySource(), new StartupHistorySource() }).ToList();
        _navigate = navigate;
        Filters = new[] { "All" }.Concat(_sources.Select(s => s.Name).Distinct()).ToArray();
        RefreshCommand = new RelayCommand(async () => await RefreshAsync(), () => !IsBusy);
        RestoreCommand = new RelayCommand(async () => await RestoreAsync(), () => !IsBusy && Selected?.CanRestore == true);
        NetworkCommand = new RelayCommand(() => _navigate?.Invoke("Network"), () => _navigate != null && !IsBusy);
        RestoreCheckpointCommand = new RelayCommand(async () => await RestoreCheckpointAsync(), () => !IsBusy && SelectedCheckpoint?.RestorableCount > 0);
        SystemRestoreCommand = new RelayCommand(async () => await OpenRecoveryTool("rstrui.exe"));
        ProtectionCommand = new RelayCommand(async () => await OpenRecoveryTool("SystemPropertiesProtection.exe"));
    }

    public ObservableCollection<HistoryRecord> Entries { get; } = new();
    public ObservableCollection<RecoveryCheckpoint> Checkpoints { get; } = new();
    public RelayCommand RestoreCheckpointCommand { get; }
    public RelayCommand SystemRestoreCommand { get; }
    public RelayCommand ProtectionCommand { get; }
    private RecoveryCheckpoint? _checkpoint;
    public RecoveryCheckpoint? SelectedCheckpoint { get => _checkpoint; set { if (Set(ref _checkpoint, value)) RestoreCheckpointCommand.RaiseCanExecuteChanged(); } }
    public string CheckpointHint => Checkpoints.Count == 0 ? "No matching multi-change Rion backups. Individual changes remain available in the detailed log." : "Rion backups cover only the changes recorded in that operation; they are not Windows system restore points.";

    private async Task OpenRecoveryTool(string name)
    {
        try
        {
            Message = "Use the Windows window to review restore points. Opening it does not restore or create a point.";
            var result = await RadeonSoftwareSlimmer.Optimize.ShellRunner.RunAsync(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), name), "", null, timeoutMs: 0);
            if (result.ExitCode != 0) Message = "Windows recovery could not be opened: " + result.Output;
        }
        catch (Exception ex) { Message = ex.Message; }
    }

    public async Task RestoreCheckpointAsync()
    {
        var checkpoint = SelectedCheckpoint;
        if (IsBusy || checkpoint == null || checkpoint.RestorableCount == 0) return;
        IsBusy = true;
        int restored = 0;
        try
        {
            foreach (var row in checkpoint.Changes.Where(r => r.CanRestore))
            {
                var source = _sources.Single(s => s.Name == row.Source);
                var result = await Task.Run(() => source.Restore(row.Id));
                if (!result.Success) { Message = $"Restored {restored} changes, then stopped: {result.Message} Remaining changes were not attempted."; return; }
                restored++;
            }
            Message = $"Restored {restored} changes. {checkpoint.Changes.Count - restored} unavailable or already restored records were skipped.";
        }
        catch (Exception ex) { Message = $"Restored {restored} changes, then stopped: {ex.Message}"; }
        finally { try { await LoadAsync(); } finally { IsBusy = false; } }
    }
    public string[] Filters { get; }
    public RelayCommand RefreshCommand { get; }
    public RelayCommand RestoreCommand { get; }
    public RelayCommand NetworkCommand { get; }
    public bool IsBusy
    {
        get => _busy;
        private set
        {
            if (!Set(ref _busy, value)) return;
            RefreshCommand.RaiseCanExecuteChanged(); RestoreCommand.RaiseCanExecuteChanged(); NetworkCommand.RaiseCanExecuteChanged();
            RestoreCheckpointCommand.RaiseCanExecuteChanged();
        }
    }
    public string Search { get => _search; set { if (Set(ref _search, value)) FilterEntries(); } }
    public string Filter { get => _filter; set { if (Set(ref _filter, value)) FilterEntries(); } }
    public string Message { get => _message; private set => Set(ref _message, value); }
    public string LoadWarning { get => _loadWarning; private set => Set(ref _loadWarning, value); }
    public bool IsEmpty => Entries.Count == 0;
    public bool HasSelection => Selected != null;
    public string CountText => $"{Checkpoints.Count} saved operations · {Entries.Count} individual records in the detailed log";
    public string EmptyText => _all.Count == 0
        ? "No saved changes yet. Changes recorded by supported registry, power and startup tools will appear here."
        : "No changes match this search.";
    public string RestoreHint => Selected == null ? "Select a change to inspect its recovery details."
        : Selected.CanRestore ? "Restore checks the current setting first. A change made elsewhere will not be overwritten. Some settings require a restart."
        : "This record cannot be restored here. Check its status and details; older backups may lack verified outcomes.";
    public HistoryRecord? Selected
    {
        get => _selected;
        set { if (Set(ref _selected, value)) { Raise(nameof(HasSelection)); Raise(nameof(RestoreHint)); RestoreCommand.RaiseCanExecuteChanged(); } }
    }

    public async Task RefreshAsync()
    {
        if (IsBusy) return;
        IsBusy = true;
        try { await LoadAsync(); }
        finally { IsBusy = false; }
    }

    private async Task LoadAsync()
    {
        var rows = new List<HistoryRecord>();
        var errors = new List<string>();
        foreach (var source in _sources)
        {
            try { rows.AddRange(await Task.Run(source.ListEntries)); }
            catch (Exception ex) { errors.Add($"{source.Name} history could not be read: {ex.Message}"); }
        }
        _all = rows.OrderByDescending(r => r.TimestampUtc).ThenBy(r => r.Source).ToList();
        LoadWarning = string.Join("\n", errors);
        FilterEntries();
    }

    private void FilterEntries()
    {
        var old = Selected;
        Entries.Clear();
        foreach (var row in _all.Where(r => (Filter == "All" || Filter == r.Source) &&
            (string.IsNullOrWhiteSpace(Search) ||
             $"{r.Label} {r.Target} {r.Source} {r.Status}".Contains(Search.Trim(), StringComparison.OrdinalIgnoreCase))))
            Entries.Add(row);
        Selected = Entries.FirstOrDefault(r => r.Source == old?.Source && r.Id == old.Id) ?? Entries.FirstOrDefault();
        var key = SelectedCheckpoint?.Key;
        Checkpoints.Clear();
        var matchedKeys = RecoveryCheckpoint.From(_all).Where(c => c.Changes.Any(r => Entries.Contains(r))).ToArray();
        foreach (var checkpoint in matchedKeys) Checkpoints.Add(checkpoint);
        SelectedCheckpoint = Checkpoints.FirstOrDefault(c => c.Key == key) ?? Checkpoints.FirstOrDefault();
        Raise(nameof(CheckpointHint));
        Raise(nameof(IsEmpty)); Raise(nameof(EmptyText)); Raise(nameof(CountText)); Raise(nameof(RestoreHint));
    }

    public async Task RestoreAsync()
    {
        var record = Selected;
        if (IsBusy || record?.CanRestore != true) return;
        var source = _sources.SingleOrDefault(s => s.Name == record.Source);
        if (source == null) { Message = "This recovery source is unavailable."; return; }
        IsBusy = true;
        Message = "Restoring the previous setting…";
        try
        {
            var result = await Task.Run(() => source.Restore(record.Id));
            Message = (result.Success ? "Restored. " : "Not restored. ") + result.Message;
            await LoadAsync();
        }
        catch (Exception ex) { Message = "Restoration could not be completed: " + ex.Message; }
        finally { IsBusy = false; }
    }
}
