using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;
using RionHub.Modules.Startup;
using System.ComponentModel;
using System.Windows.Data;

namespace RionHub.Modules.Optimize;

public enum OptimizePhase { Picker, Running, Report }

public sealed class SectionPick : ObservableObject
{
    public SectionPick(OptimizeSectionInfo info)
    {
        Info = info;
        _selected = info.RecommendedDefault;
    }

    public OptimizeSectionInfo Info { get; }
    public string Title => Info.Title;
    public string Description => Info.Description;
    public string Meta => Info.EstDuration + (Info.MayNeedReboot ? " · may need a restart" : "");
    private bool recommended;
    public bool Recommended { get => recommended || Info.RecommendedDefault; set => Set(ref recommended, value); }

    private bool _selected;
    public bool IsSelected { get => _selected; set { if (Set(ref _selected, value)) Raise(nameof(ShowProcessOptions)); } }
    public bool ShowProcessOptions => Info.Section == OptimizeSection.ProcessReduction && IsSelected;
}

public sealed class AutoOptimizeViewModel : ObservableObject
{
    private bool scanBusy;
    private bool gaming = true;
    private PcScanResult? scan;
    private CancellationTokenSource? scanCts;
    private string scanStatus = "Scan this PC to build recommendations from its current settings. No optimizations run during a scan.";
    public string ScanStatus { get => scanStatus; private set => Set(ref scanStatus, value); }
    public bool ScanBusy { get => scanBusy; private set { Set(ref scanBusy, value); RefreshScanCommands(); } }
    public bool Gaming { get => gaming; set { if (Set(ref gaming, value)) Raise(nameof(Esports)); } }
    public bool Esports { get => !gaming; set { if (value) Gaming = false; } }
    public bool CanScan => IsPicker && !scanBusy && !previewBusy;
    public ObservableCollection<ScanFinding> ScanFindings { get; } = new();
    public ICollectionView FindingView { get; }
    private bool showAllFindings;
    public bool ShowAllFindings { get => showAllFindings; set { if (Set(ref showAllFindings, value)) FindingView.Refresh(); } }
    public ObservableCollection<ScannedApp> ScannedApps { get; } = new();
    public ICollectionView AppInventoryView { get; }
    private string appSearch = "";
    private bool onlyBloatCandidates;
    public string AppSearch { get => appSearch; set { if (Set(ref appSearch, value)) AppInventoryView.Refresh(); } }
    public bool OnlyBloatCandidates { get => onlyBloatCandidates; set { if (Set(ref onlyBloatCandidates, value)) AppInventoryView.Refresh(); } }
    public string AppInventorySummary => $"{ScannedApps.Count} inventory entries · {ScannedApps.Where(a => a.DebloatCandidate).Select(a => a.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count()} distinct optional debloat matches";
    public RelayCommand ScanCommand { get; }
    public RelayCommand CancelScanCommand { get; }
    public RelayCommand UseRecommendationsCommand { get; }
    public RelayCommand InstallGpuCommand { get; }
    public RelayCommand ReviewScanCommand { get; }
    public RelayCommand SelectAllSectionsCommand { get; }
    public RelayCommand ClearSectionsCommand { get; }
    public event Action? ScanResultsRequested;
    private void RefreshScanCommands()
    {
        Raise(nameof(CanScan)); Raise(nameof(CanEditProcessChoices));
        ScanCommand?.RaiseCanExecuteChanged(); CancelScanCommand?.RaiseCanExecuteChanged();
        UseRecommendationsCommand?.RaiseCanExecuteChanged(); InstallGpuCommand?.RaiseCanExecuteChanged();
        ReviewScanCommand?.RaiseCanExecuteChanged();
        SelectAllSectionsCommand?.RaiseCanExecuteChanged(); ClearSectionsCommand?.RaiseCanExecuteChanged();
        RunCommand?.RaiseCanExecuteChanged(); PreviewProcessCommand?.RaiseCanExecuteChanged();
    }
    private async Task ScanAsync()
    {
        if (!CanScan) return;
        scan = null; ScanFindings.Clear(); ScannedApps.Clear(); Raise(nameof(AppInventorySummary)); ScanBusy = true;
        scanCts = new CancellationTokenSource();
        RefreshScanCommands();
        var choices = CurrentProcessChoices();
        var progress = new Progress<string>(s => ScanStatus = s);
        try
        {
            scan = await Task.Run(() => new PcScanService().Scan(choices, progress, scanCts.Token));
            foreach (var finding in scan.Findings) ScanFindings.Add(finding);
            foreach (var app in scan.Apps.OrderByDescending(a => a.DebloatCandidate).ThenBy(a => a.Name)) ScannedApps.Add(app);
            Raise(nameof(AppInventorySummary));
            ScanStatus = $"{scan.SuggestedSections.Count} sections ready to run. {scan.Apps.Count} app entries checked. "
                + (scan.Findings.Any(f => f.State == "Unavailable") ? "Some checks could not finish; see findings." : "Review the selections, then apply when ready.");
        }
        catch (OperationCanceledException) { ScanStatus = "Scan cancelled. No settings changed."; }
        catch (Exception ex) { ScanStatus = "Scan could not finish: " + ex.Message; }
        finally { scanCts.Dispose(); scanCts = null; ScanBusy = false; }
        if (scan != null)
        {
            UseRecommendationsCommand.Execute(null);
            ScanResultsRequested?.Invoke();
        }
    }
    private async Task InstallGpuAsync()
    {
        if (!CanScan || scan == null) return;
        bool profile = Gaming;
        var candidates = scan.Gpus.Where(g => PcScanService.CanUpdateGpu(g, DateTime.Today)).ToList();
        ScanBusy = true;
        try
        {
            foreach (var gpu in candidates)
                ScanStatus = await AutomaticGpuInstaller.RunAsync(gpu, profile, new Progress<string>(s => ScanStatus = s), CancellationToken.None);
        }
        catch (Exception ex) { ScanStatus = "Driver installation needs attention: " + ex.Message; }
        finally { scan = null; ScanBusy = false; }
    }
    private CancellationTokenSource? _cts;
    private readonly ProcessReductionRunner processReduction = new();
    private bool previewBusy;
    public ObservableCollection<ProcessReductionRow> ProcessPreview { get; } = new();
    public RelayCommand PreviewProcessCommand { get; }
    private string processStatus = "These features stay available when checked. Run selected scans and applies fresh changes each time; preview is optional.";
    public string ProcessStatus { get => processStatus; private set => Set(ref processStatus, value); }
    private bool keepOneDrive = true, keepMidi = true, keepEdgeBackground = true, keepWidgets = true, keepSearchHighlights = true;
    public bool KeepOneDrive { get => keepOneDrive; set { if (Set(ref keepOneDrive, value)) InvalidatePreview(); } }
    public bool KeepMidi { get => keepMidi; set { if (Set(ref keepMidi, value)) InvalidatePreview(); } }
    public bool KeepEdgeBackground { get => keepEdgeBackground; set { if (Set(ref keepEdgeBackground, value)) InvalidatePreview(); } }
    public bool KeepWidgets { get => keepWidgets; set { if (Set(ref keepWidgets, value)) InvalidatePreview(); } }
    public bool KeepSearchHighlights { get => keepSearchHighlights; set { if (Set(ref keepSearchHighlights, value)) InvalidatePreview(); } }
    private bool keepXbox = true, keepPrinting = true, keepPhone = true, keepLocation = true, keepRemoteDesktop = true;
    public bool KeepXbox { get => keepXbox; set { if (Set(ref keepXbox, value)) InvalidatePreview(); } }
    public bool KeepPrinting { get => keepPrinting; set { if (Set(ref keepPrinting, value)) InvalidatePreview(); } }
    public bool KeepPhone { get => keepPhone; set { if (Set(ref keepPhone, value)) InvalidatePreview(); } }
    public bool KeepLocation { get => keepLocation; set { if (Set(ref keepLocation, value)) InvalidatePreview(); } }
    public bool KeepRemoteDesktop { get => keepRemoteDesktop; set { if (Set(ref keepRemoteDesktop, value)) InvalidatePreview(); } }
    public ProcessReductionChoices CurrentProcessChoices() => new(KeepXbox, KeepPrinting, KeepPhone, KeepLocation, KeepRemoteDesktop, KeepOneDrive, KeepMidi, KeepEdgeBackground, KeepWidgets, KeepSearchHighlights,
        Scanning: KeepScanning, MailSync: KeepMailSync, Bluetooth: KeepBluetooth, ConnectedDevices: KeepConnectedDevices, Telemetry: KeepTelemetry, DeviceManagement: KeepDeviceManagement, CrashReporting: KeepCrashReporting, Troubleshooting: KeepTroubleshooting, Compatibility: KeepCompatibility, LinkTracking: KeepLinkTracking, OfflineMaps: KeepOfflineMaps, RetailDemo: KeepRetailDemo, RemoteRegistry: KeepRemoteRegistry, EventCollection: KeepEventCollection, Insider: KeepInsider, DeveloperDiagnostics: KeepDeveloperDiagnostics, LogitechLighting: KeepLogitechLighting, AsusUpdateChecks: KeepAsusUpdateChecks, VendorUpdates: KeepVendorUpdates);
    private bool keepScanning = true;
    public bool KeepScanning { get => keepScanning; set { if (Set(ref keepScanning, value)) InvalidatePreview(); } }
    private bool keepMailSync = true;
    public bool KeepMailSync { get => keepMailSync; set { if (Set(ref keepMailSync, value)) InvalidatePreview(); } }
    private bool keepBluetooth = true;
    public bool KeepBluetooth { get => keepBluetooth; set { if (Set(ref keepBluetooth, value)) InvalidatePreview(); } }
    private bool keepConnectedDevices = true;
    public bool KeepConnectedDevices { get => keepConnectedDevices; set { if (Set(ref keepConnectedDevices, value)) InvalidatePreview(); } }
    private bool keepTelemetry = true;
    public bool KeepTelemetry { get => keepTelemetry; set { if (Set(ref keepTelemetry, value)) InvalidatePreview(); } }
    private bool keepDeviceManagement = true;
    public bool KeepDeviceManagement { get => keepDeviceManagement; set { if (Set(ref keepDeviceManagement, value)) InvalidatePreview(); } }
    private bool keepCrashReporting = true;
    public bool KeepCrashReporting { get => keepCrashReporting; set { if (Set(ref keepCrashReporting, value)) InvalidatePreview(); } }
    private bool keepTroubleshooting = true;
    public bool KeepTroubleshooting { get => keepTroubleshooting; set { if (Set(ref keepTroubleshooting, value)) InvalidatePreview(); } }
    private bool keepCompatibility = true;
    public bool KeepCompatibility { get => keepCompatibility; set { if (Set(ref keepCompatibility, value)) InvalidatePreview(); } }
    private bool keepLinkTracking = true;
    public bool KeepLinkTracking { get => keepLinkTracking; set { if (Set(ref keepLinkTracking, value)) InvalidatePreview(); } }
    private bool keepOfflineMaps = true;
    public bool KeepOfflineMaps { get => keepOfflineMaps; set { if (Set(ref keepOfflineMaps, value)) InvalidatePreview(); } }
    private bool keepRetailDemo = true;
    public bool KeepRetailDemo { get => keepRetailDemo; set { if (Set(ref keepRetailDemo, value)) InvalidatePreview(); } }
    private bool keepRemoteRegistry = true;
    public bool KeepRemoteRegistry { get => keepRemoteRegistry; set { if (Set(ref keepRemoteRegistry, value)) InvalidatePreview(); } }
    private bool keepEventCollection = true;
    public bool KeepEventCollection { get => keepEventCollection; set { if (Set(ref keepEventCollection, value)) InvalidatePreview(); } }
    private bool keepInsider = true;
    public bool KeepInsider { get => keepInsider; set { if (Set(ref keepInsider, value)) InvalidatePreview(); } }
    private bool keepDeveloperDiagnostics = true;
    public bool KeepDeveloperDiagnostics { get => keepDeveloperDiagnostics; set { if (Set(ref keepDeveloperDiagnostics, value)) InvalidatePreview(); } }
    private bool keepLogitechLighting = true;
    public bool KeepLogitechLighting { get => keepLogitechLighting; set { if (Set(ref keepLogitechLighting, value)) InvalidatePreview(); } }
    private bool keepAsusUpdateChecks = true;
    public bool KeepAsusUpdateChecks { get => keepAsusUpdateChecks; set { if (Set(ref keepAsusUpdateChecks, value)) InvalidatePreview(); } }
    private bool keepVendorUpdates = true;
    public bool KeepVendorUpdates { get => keepVendorUpdates; set { if (Set(ref keepVendorUpdates, value)) InvalidatePreview(); } }
    public bool CanEditProcessChoices => !previewBusy && !scanBusy && IsPicker;
    private bool ProcessSelected => Sections.Any(s => s.Info.Section == OptimizeSection.ProcessReduction && s.IsSelected);
    private void InvalidatePreview()
    {
        processReduction.Invalidate();
        ProcessPreview.Clear();
        ProcessStatus = "Choices saved for the next run. Run selected will scan again; preview is optional.";
        RunCommand.RaiseCanExecuteChanged();
    }
    private async Task PreviewProcessAsync()
    {
        if (!CanScan) return;
        previewBusy = true;
        RefreshScanCommands();
        Raise(nameof(CanEditProcessChoices));
        PreviewProcessCommand.RaiseCanExecuteChanged();
        RunCommand.RaiseCanExecuteChanged();
        ProcessStatus = "Scanning apps, services and dependencies. No settings are being changed…";
        try
        {
            var choices = CurrentProcessChoices();
            var rows = await Task.Run(() => processReduction.Preview(choices));
            ProcessPreview.Clear();
            foreach (var row in rows.Where(r => r.Action is "Disable" or "Review")) ProcessPreview.Add(row);
            ProcessStatus = $"{rows.Count(r => r.Action == "Disable")} entries to disable. Service-host threshold: 0x{SystemInfo.ServiceHostSplitThresholdKb():X} KB. "
                + "Grouping reduces isolation; fewer processes does not guarantee better performance. "
                + string.Join("; ", processReduction.Warnings);
        }
        catch (Exception ex) { ProcessStatus = "Preview failed: " + ex.Message; }
        finally
        {
            previewBusy = false;
            RefreshScanCommands();
            Raise(nameof(CanEditProcessChoices));
            PreviewProcessCommand.RaiseCanExecuteChanged();
            RunCommand.RaiseCanExecuteChanged();
        }
    }

    public AutoOptimizeViewModel()
    {
        FindingView = CollectionViewSource.GetDefaultView(ScanFindings);
        FindingView.SortDescriptions.Add(new SortDescription(nameof(ScanFinding.Priority), ListSortDirection.Ascending));
        FindingView.Filter = item => item is ScanFinding finding && (ShowAllFindings || finding.Priority < 3);
        AppInventoryView = CollectionViewSource.GetDefaultView(ScannedApps);
        AppInventoryView.Filter = item => item is ScannedApp app && (!OnlyBloatCandidates || app.DebloatCandidate)
            && (string.IsNullOrWhiteSpace(AppSearch) || (app.Name + " " + app.Publisher + " " + app.Kind + " " + app.Scope + " " + app.Identity).Contains(AppSearch, StringComparison.OrdinalIgnoreCase));
        ScanCommand = new RelayCommand(async () => await ScanAsync(), () => CanScan);
        ReviewScanCommand = new RelayCommand(() => ScanResultsRequested?.Invoke(), () => CanScan && scan != null);
        SelectAllSectionsCommand = new RelayCommand(() => { foreach (var section in Sections) section.IsSelected = true; }, () => CanScan);
        ClearSectionsCommand = new RelayCommand(() => { foreach (var section in Sections) section.IsSelected = false; }, () => CanScan);
        CancelScanCommand = new RelayCommand(() => scanCts?.Cancel(), () => scanBusy && scanCts != null);
        UseRecommendationsCommand = new RelayCommand(() =>
        {
            if (scan == null) return;
            foreach (var section in Sections)
            {
                section.Recommended = scan.SuggestedSections.Contains(section.Info.Section);
                section.IsSelected = section.Recommended;
            }
        }, () => CanScan && scan != null);
        InstallGpuCommand = new RelayCommand(async () => await InstallGpuAsync(), () => CanScan && scan != null && scan.Gpus.Any(g => PcScanService.CanUpdateGpu(g, DateTime.Today)));
        Sections = new ObservableCollection<SectionPick>(
            OptimizeSectionInfo.All.Where(i => i.Section != OptimizeSection.BackgroundServices && i.Section != OptimizeSection.GpuDriver)
                .OrderBy(i => i.Section == OptimizeSection.ProcessReduction ? 0 : i.Section == OptimizeSection.RegistryTweaks ? 1 : 2)
                .Select(i => new SectionPick(i)));

        RunCommand = new RelayCommand(Run, () => CanScan && Sections.Any(s => s.IsSelected));
        PreviewProcessCommand = new RelayCommand(async () => await PreviewProcessAsync(), () => CanEditProcessChoices);
        CancelCommand = new RelayCommand(() => _cts?.Cancel(), () => _phase == OptimizePhase.Running);
        BackToPickerCommand = new RelayCommand(() => Phase = OptimizePhase.Picker, () => _phase == OptimizePhase.Report);
        RevertLastRunCommand = new RelayCommand(RevertLastRun, () => _phase == OptimizePhase.Report);
        foreach (var section in Sections)
            section.PropertyChanged += (_, e) => {
                if (e.PropertyName != nameof(SectionPick.IsSelected)) return;
                Raise(nameof(SelectionSummary));
                RunCommand.RaiseCanExecuteChanged();
            };
    }

    public ObservableCollection<SectionPick> Sections { get; }
    public string SelectionSummary => $"{Sections.Count(s => s.IsSelected)} of {Sections.Count} sections selected";
    public OptimizeMonitor Monitor { get; } = new OptimizeMonitor();

    private OptimizePhase _phase = OptimizePhase.Picker;
    public OptimizePhase Phase
    {
        get => _phase;
        private set
        {
            if (!Set(ref _phase, value)) return;
            Raise(nameof(IsPicker));
            Raise(nameof(IsRunning));
            Raise(nameof(IsReport));
            Raise(nameof(CanEditProcessChoices));
            RefreshScanCommands();
            PreviewProcessCommand.RaiseCanExecuteChanged();
            RunCommand.RaiseCanExecuteChanged();
            CancelCommand.RaiseCanExecuteChanged();
            BackToPickerCommand.RaiseCanExecuteChanged();
            RevertLastRunCommand.RaiseCanExecuteChanged();
        }
    }

    public bool IsPicker => _phase == OptimizePhase.Picker;
    public bool IsRunning => _phase == OptimizePhase.Running;
    public bool IsReport => _phase == OptimizePhase.Report;

    public void SelectProcessReduction()
    {
        if (IsRunning || scanBusy || previewBusy) return;
        Phase = OptimizePhase.Picker;
        foreach (var section in Sections) section.IsSelected = section.Info.Section == OptimizeSection.ProcessReduction;
    }

    private OptimizeReport? _report;
    public OptimizeReport? Report { get => _report; private set => Set(ref _report, value); }

    private string _revertStatus = "";
    public string RevertStatus { get => _revertStatus; private set => Set(ref _revertStatus, value); }

    public RelayCommand RunCommand { get; }
    public RelayCommand CancelCommand { get; }
    public RelayCommand BackToPickerCommand { get; }
    public RelayCommand RevertLastRunCommand { get; }

    private async void Run()
    {
        var selected = Sections.Where(s => s.IsSelected).Select(s => s.Info.Section).ToList();
        if (selected.Count == 0 || !CanScan) return;
        var choices = CurrentProcessChoices();

        _cts = new CancellationTokenSource();
        Monitor.Reset(Sections.Where(s => s.IsSelected).Select(s => s.Info));
        Phase = OptimizePhase.Running;
        RevertStatus = "";
        Report = null;

        try
        {
            var keepApps = new List<string>();
            if (KeepOneDrive) keepApps.Add("Microsoft OneDrive");
            if (KeepPhone) keepApps.Add("Microsoft.YourPhone");
            if (KeepXbox) keepApps.AddRange(DebloatCatalog.Remove.Where(n => n.StartsWith("Microsoft.Xbox", StringComparison.OrdinalIgnoreCase)
                || n.StartsWith("Microsoft.GamingApp", StringComparison.OrdinalIgnoreCase)));
            Report = await new AutoOptimizeService {
                KeepDebloatApps = keepApps,
                ProcessReduction = (sr, monitor, ct) => processReduction.RunAsync(sr, monitor, ct, choices)
            }.RunAsync(selected, Monitor, _cts.Token);
        }
        catch (Exception ex)
        {
            Monitor.Log("Run failed: " + ex.Message);
            RevertStatus = "Run failed: " + ex.Message;
        }
        finally
        {
            if (ProcessSelected) InvalidatePreview();
            Phase = OptimizePhase.Report;
            _cts.Dispose();
            _cts = null;
        }
    }

    private void RevertLastRun()
    {
        try
        {
            if (BackupStore.LatestRequiresLegacyRestoreReview && System.Windows.MessageBox.Show(
                "This older backup does not record the applied values, so Rion cannot check whether another app changed these settings afterward. Restoring it may overwrite newer changes.\n\nRestore the saved registry values from this older backup?",
                "Review older backup", System.Windows.MessageBoxButton.YesNo,
                System.Windows.MessageBoxImage.Warning, System.Windows.MessageBoxResult.No) != System.Windows.MessageBoxResult.Yes)
            {
                RevertStatus = "Older backup restoration canceled. No settings were changed.";
                return;
            }
            int n = BackupStore.RevertLatestRegistry(new WindowsRegistry());
            RevertStatus = n > 0
                ? $"Reverted {n} registry / service change(s) from the most recent backup. Process-reduction app/service changes have separate undo in Startup history; Edge/Widgets/Search policies have undo in Tweaks > General. Removed apps require reinstall. Restart Windows."
                : "No registry changes were restored. Check System > History & recovery for unavailable records or conflicts. Startup changes also have undo on the Startup page; Edge/Widgets/Search policies have undo in Tweaks > General. Removed apps require reinstall.";
        }
        catch (Exception ex)
        {
            RevertStatus = "Revert failed: " + ex.Message;
        }
    }
}
