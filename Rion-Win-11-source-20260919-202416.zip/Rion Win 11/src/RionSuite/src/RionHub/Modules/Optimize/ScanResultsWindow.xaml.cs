using System.Windows;
using System.Windows.Input;
using GlassKit;

namespace RionHub.Modules.Optimize;

public partial class ScanResultsWindow : GlassWindow
{
    public ScanResultsWindow()
    {
        InitializeComponent();
        PreviewKeyDown += (_, e) => { if (e.Key == Key.Escape) { Close(); e.Handled = true; } };
    }
    private void Max_Click(object sender, RoutedEventArgs e) => ToggleMaximise(MaxGlyph, RootShell);
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
