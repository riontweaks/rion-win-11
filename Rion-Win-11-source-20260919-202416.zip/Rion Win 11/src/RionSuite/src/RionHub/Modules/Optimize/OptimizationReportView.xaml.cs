using System.Windows.Controls;

namespace RionHub.Modules.Optimize;

public partial class OptimizationReportView : UserControl
{
    public OptimizationReportView() => InitializeComponent();
}
