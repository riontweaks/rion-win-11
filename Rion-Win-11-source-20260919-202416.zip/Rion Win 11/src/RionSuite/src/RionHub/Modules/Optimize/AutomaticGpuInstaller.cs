using System.IO;
using System.IO.Abstractions;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using NvidiaDriverTool.Services;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;
using RadeonSoftwareSlimmer.ViewModels;

namespace RionHub.Modules.Optimize;

public static class AutomaticGpuInstaller
{
    public static Version? CompatibleInfVersion(string text, string vendor, string device)
    {
        if (!Regex.IsMatch(vendor, "^[0-9A-Fa-f]{4}$") || !Regex.IsMatch(device, "^[0-9A-Fa-f]{4}$")) return null;
        var activeLines = string.Join("\n", text.Split('\n').Select(l => l.Split(';')[0]));
        if (!Regex.IsMatch(activeLines, @"PCI\\VEN_" + vendor + "&DEV_" + device + @"(?=&|\s|\""|$)", RegexOptions.IgnoreCase)) return null;
        var match = Regex.Match(activeLines, @"^\s*DriverVer\s*=\s*[^,\r\n]+,\s*([0-9]+(?:\.[0-9]+){1,3})\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
        return match.Success && Version.TryParse(match.Groups[1].Value, out var version) ? version : null;
    }
    public static HashSet<string> NvidiaExclusions(IReadOnlyList<NvidiaComponentManifest.NvidiaComponent> components, bool gaming)
    {
        // Unknown packages remain included. Resolve dependencies before accepting the plan.
        var capture = new HashSet<string>(new[] { "Display.NvApp", "GFExperience", "ShadowPlay" }, StringComparer.OrdinalIgnoreCase);
        if (gaming && !components.Any(c => capture.Contains(c.Name)))
            throw new InvalidOperationException("This package has no recognized NVIDIA recording app. Use NVIDIA Manager to install the recording app separately.");
        var excluded = components.Where(c => !gaming && capture.Contains(c.Name)
            && NvidiaComponentManifest.ToClassification(c) != Classification.Required).Select(c => c.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        bool changed;
        do
        {
            changed = false;
            foreach (var c in components.Where(c => !excluded.Contains(c.Name)))
                if (c.Requires.Any(excluded.Contains))
                {
                    if (NvidiaComponentManifest.ToClassification(c) == Classification.Required)
                        throw new InvalidOperationException("Required package depends on recording. This package cannot use the eSports preset.");
                    changed |= excluded.Add(c.Name);
                }
        } while (changed);
        _ = NvidiaInstallPlan.Arguments(components, excluded);
        return excluded;
    }

    public static async Task<string> RunAsync(HardwareInfo scanned, bool gaming, IProgress<string> progress, CancellationToken ct)
    {
        var hardware = await Task.Run(() => new HardwareInspector().Inspect(scanned.VendorId), ct);
        if (hardware.PnpDeviceId != scanned.PnpDeviceId || hardware.DriverVersion != scanned.DriverVersion)
            throw new InvalidOperationException("Graphics hardware or driver changed since the scan. Scan again.");
        if (hardware.IsLaptop || hardware.IsHybridGraphics || hardware.IsOemDriverLikely)
            throw new InvalidOperationException("This PC needs OEM / hybrid graphics review in the GPU manager before a generic driver installation.");
        if (!PcScanService.IsOldDriver(hardware.DriverDate, DateTime.Today))
            throw new InvalidOperationException("No driver older than six months was confirmed. Scan again.");
        bool nvidia = hardware.VendorId == "10DE";
        if (!nvidia && hardware.VendorId != "1002") throw new InvalidOperationException("Unsupported GPU vendor.");
        string root = Path.Combine(RegistrySnapshot.Directory, "driver-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        progress.Report("Resolving the official driver for " + hardware.GpuName);
        var amdDownload = new DriverDownloadService();
        var nvDownload = new NvidiaDriverDownloadService();
        string url = nvidia
            ? (await nvDownload.ResolveLatestDriverAsync(hardware.GpuName, ct)).DownloadUrl
            : (await amdDownload.ResolveGpuSeriesPackageAsync(hardware.GpuName, ct)).InstallerUrl;
        ct.ThrowIfCancellationRequested();
        var downloadProgress = new Progress<double>(p => progress.Report($"Downloading official driver · {p:F0}%"));
        string file = nvidia ? await nvDownload.DownloadAsync(url, root, downloadProgress, ct)
            : await amdDownload.DownloadAsync(url, root, downloadProgress, ct: ct);
        var validator = new InstallerValidator();
        var info = await Task.Run(() => validator.Inspect(file, url), ct);
        if (nvidia ? !NvidiaInstallPlan.IsTrusted(info) : !info.LooksTrusted)
            throw new InvalidOperationException("The downloaded driver's vendor signature could not be verified.");
        progress.Report("Preparing recommended packages");
        string extracted = Path.Combine(root, "package");
        Directory.CreateDirectory(extracted);
        string arguments;
        List<string> kept, excluded;
        if (nvidia)
        {
            using var sevenZip = SevenZip.Acquire();
            var extract = await ShellRunner.RunAsync(sevenZip.ExecutablePath, $"x \"{file}\" -o\"{extracted}\" -y", null);
            if (extract.ExitCode != 0) throw new IOException("Driver extraction failed.");
            var components = NvidiaComponentManifest.Parse(extracted);
            var exclusions = NvidiaExclusions(components, gaming);
            arguments = NvidiaInstallPlan.Arguments(components, exclusions);
            kept = components.Where(c => !exclusions.Contains(c.Name)).Select(c => c.Name).ToList();
            excluded = exclusions.ToList();
        }
        else
        {
            var pre = new PreInstallViewModel(new FileSystem());
            pre.InstallerFiles.InstallerFile = file;
            pre.InstallerFiles.ExtractedInstallerDirectory = extracted;
            await Task.Run(() => { pre.InstallerFiles.ExtractInstallerFiles(); pre.ReadFromExtractedInstaller(); }, ct);
            var rules = new RecommendationEngine();
            kept = new(); excluded = new();
            foreach (var package in pre.PackageList.InstallerPackages)
            {
                var rule = rules.Match(package.ProductName) ?? rules.Match(package.Description);
                package.Keep = gaming || rule?.Id != "relive-recording";
                (package.Keep ? kept : excluded).Add(package.ProductName);
            }
            // Gaming keeps the full package and its recording dependencies. Unknown packages stay intact.
            if (!gaming && excluded.Count == 0)
                throw new InvalidOperationException("No separable recording package was recognized. Use AMD Manager for this package.");
            await Task.Run(pre.ModifyInstaller, ct);
            if (!pre.InstallerFiles.ValidateExtractedLocation()) throw new IOException("Prepared AMD installer is incomplete.");
            // Reuse the existing AMD manager's normal vendor setup; no undocumented silent flags.
            arguments = "";
        }
        string setup = Path.Combine(extracted, "setup.exe");
        // Compare the INF version to WMI's driver version, not the marketing package version.
        var versions = await Task.Run(() => Directory.EnumerateFiles(extracted, "*.inf", SearchOption.AllDirectories)
            .Select(path => CompatibleInfVersion(File.ReadAllText(path), hardware.VendorId, hardware.DeviceId))
            .Where(v => v != null).Cast<Version>().ToList(), ct);
        if (!Version.TryParse(hardware.DriverVersion, out var installed) || !versions.Any(v => v > installed))
            throw new InvalidOperationException("No newer driver INF matching this GPU was confirmed in the package. Nothing was installed.");
        var setupInfo = await Task.Run(() => validator.Inspect(setup, url), ct);
        if (nvidia ? !NvidiaInstallPlan.IsTrusted(setupInfo) : !setupInfo.LooksTrusted)
            throw new InvalidOperationException("The extracted setup vendor signature could not be verified.");
        string planPath = Path.Combine(root, "install-plan.json");
        File.WriteAllText(planPath, JsonSerializer.Serialize(new { Hardware = hardware, Profile = gaming ? "Gaming" : "eSports", Source = url, Keeping = kept, Excluding = excluded, Arguments = arguments }, new JsonSerializerOptions { WriteIndented = true }));
        ct.ThrowIfCancellationRequested();
        var consent = MessageBox.Show(Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w.IsActive) ?? Application.Current.MainWindow,
            $"Install the downloaded, signed driver for {hardware.GpuName}?\n\nProfile: {(gaming ? "Gaming — recording packages retained" : "eSports — recording packages excluded")}\nKeep: {string.Join(", ", kept)}\nExclude: {string.Join(", ", excluded)}\n\nThe display may flicker and a restart may be needed. Exclusions do not remove previously installed recording apps. " +
            (nvidia ? "" : "AMD's setup window will open; complete its vendor prompts. ") + $"\nPlan: {planPath}",
            "Agree to GPU installation", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
        if (consent != MessageBoxResult.Yes) return "Driver prepared; installation declined. Plan: " + planPath;
        progress.Report("Creating restore point before driver installation");
        bool restore = await Task.Run(() => RestorePoint.TryCreate("Rion automatic GPU installation"));
        File.WriteAllText(Path.Combine(root, "restore-status.txt"), restore ? "Restore point created" : "Restore point unavailable");
        progress.Report("Installing driver — allow setup to finish");
        // The consent dialog and restore-point operation can take minutes. Recheck
        // the exact executable while its file and path remain locked until exit.
        using var setupLease = InstallerExecutionLease.Acquire(setup, nvidia ? "NVIDIA" : "AMD");
        // Once setup begins it is allowed to finish; killing a driver installer is not cancellation.
        var install = await ShellRunner.RunAsync(setupLease.ExecutablePath, arguments, line => progress.Report(line), timeoutMs: 0);
        File.WriteAllText(Path.Combine(root, "installer-output.txt"), install.Output ?? "");
        if (install.ExitCode != 0 && !(nvidia && install.ExitCode == 1) && install.ExitCode != 3010)
            throw new InvalidOperationException($"Installer exited with {install.ExitCode}. See {root}");
        var after = await Task.Run(() => new HardwareInspector().Inspect(hardware.VendorId));
        File.WriteAllText(Path.Combine(root, "hardware-after.json"), JsonSerializer.Serialize(after));
        if (!DriverValidation.IsReady(after, hardware.VendorId) || after.DriverVersion == hardware.DriverVersion)
            return "Setup ended, but a driver version change is not yet verified. Restart if requested, then scan again. Logs: " + root;
        return $"Driver changed to {after.DriverVersion}; device reports healthy. Restart if requested. Logs: {root}";
    }
}
