namespace RionHub.Modules.Optimize;

public sealed record ScanFinding(string Title, string Detail, string State, string TechnicalDetail = "")
{
    public bool HasTechnicalDetail => !string.IsNullOrWhiteSpace(TechnicalDetail);
    public int Priority => State is "Suggested" or "Update suggested" ? 0 : State is "Unavailable" or "Unknown" ? 1 : State is "Review" or "Review feature" or "Optional process reduction" ? 2 : 3;
}
public sealed record BackgroundProcessSample(string Name, long WorkingSetBytes, long PrivateBytes);

/// <summary>Inventory is evidence of activity, not evidence that an app is unwanted.</summary>
public static class BackgroundProcessReview
{
    public static IEnumerable<ScanFinding> Analyze(IEnumerable<BackgroundProcessSample> samples)
    {
        foreach (var group in samples.GroupBy(p => p.Name, StringComparer.OrdinalIgnoreCase))
        {
            string? guidance = group.Key.ToLowerInvariant() switch
            {
                "widgets" or "widgetservice" => "Optional Widgets content. Use the Disable Windows Widgets control on supported editions, or review Windows Web Experience Pack in Debloat > Store apps. Hiding the taskbar icon alone does not disable the board. Removal needs reinstall to restore.",
                "msedge" => "Edge can be open or preloaded. Process reduction can disable Edge preloading/background apps when you uncheck that keep option. Existing browser windows are not closed. Restore the two Edge controls in Tweaks > General.",
                "msedgewebview2" => "Shared WebView2 runtime, used by Windows Search, Widgets and other apps. These totals do not identify a single owner. Review the host features; do not uninstall the runtime or kill all WebView2 processes.",
                "onedrive" => "Optional only if you do not need automatic file sync/folder backup. Uncheck OneDrive in Process reduction to disable its verified sign-in entry, or use Startup. Files are retained; sync waits until you open OneDrive. Uninstall is a separate choice in Debloat > Desktop apps.",
                "crossdeviceresume" => "Windows cross-device resume. Review Settings > Apps > Resume and turn off unused app handoffs. This is not a standalone service. Do not disable Bluetooth/device-pairing services to remove it.",
                "searchhost" => "Windows Search interface. Disable Search highlights in Tweaks > General on supported editions, or Settings > Privacy & security > Search permissions on Home. File/app search stays available; this does not guarantee WebView2 exits.",
                "midisrv" => "Windows MIDI service for instruments, controllers and music apps. Process reduction keeps it by default. Uncheck MIDI only if unused; restore in Startup history. This is not evidence of third-party bloatware.",
                _ => null
            };
            if (guidance == null) continue;
            double workingSet = group.Sum(p => (double)p.WorkingSetBytes) / 1048576;
            double privateBytes = group.Sum(p => (double)p.PrivateBytes) / 1048576;
            yield return new(group.Key + " · background review",
                $"{group.Count()} processes · {workingSet:F1} MB working set (includes shared pages) · {privateBytes:F1} MB private commit (not necessarily resident RAM). {guidance} Savings have not been measured.", "Review feature");
        }
    }
}
