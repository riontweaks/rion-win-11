using Microsoft.Win32;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;
using RionHub.Modules.Startup;
using System.Threading;

namespace RionHub.Modules.Optimize;

public sealed record ProcessReductionRow(StartupItem Item, string Action, string Reason)
{
    public string Label => $"{Action} · {VendorStartupRules.Match(Item)?.Label ?? ProcessReductionPolicy.ServiceLabel(Item.Name) ?? Item.Name}\n{Reason}";
}

public sealed class ProcessReductionRunner
{
    private readonly StartupEngine engine = new();
    private List<ProcessReductionRow>? plan;
    private ProcessReductionChoices choices = new();
    public IReadOnlyList<ProcessReductionRow> Preview(ProcessReductionChoices selected)
    {
        choices = selected;
        plan = engine.Scan().Select(item =>
        {
            string? reason = engine.ProcessReductionKeepReason(item, selected);
            return new ProcessReductionRow(item,
                !item.StateKnown ? "Review" : !item.Enabled ? "Already disabled" : reason == null ? "Disable"
                    : ProcessReductionPolicy.ServiceOptOutRequested(item, selected) ? "Review" : "Keep / review",
                (reason ?? ProcessReductionPolicy.DisableEffect(item)) + (item.IsServiceTemplate ? ". Scope: service template for all future user sign-ins; restart/sign out to refresh instances." : ""));
        }).OrderBy(row => row.Action == "Disable" ? 0 : 1).ThenBy(row => row.Item.Name).ToList();
        foreach (var tweak in SelectedPolicies(selected))
        {
            bool? applied = tweak.InspectCommandState();
            plan.Add(new(new StartupItem { Kind = "Background policies", Name = tweak.Title, Identity = tweak.Id },
                applied == true ? "Already disabled" : applied == false ? "Disable" : "Review",
                applied == null ? "Unsupported Windows edition/build or unreadable policy. " + tweak.TradeOff
                    : tweak.Summary + " " + tweak.TradeOff + " Undo in Tweaks > General using this control."));
        }
        return plan;
    }
    public static IEnumerable<SystemTweak> SelectedPolicies(ProcessReductionChoices selected) =>
        ResearchedTweakCatalog.General.Where(t =>
            (!selected.EdgeBackground && t.Id is "edge-startup-boost-off" or "edge-background-mode-off")
            || (!selected.Widgets && t.Id == "widgets-off")
            || (!selected.SearchHighlights && t.Id == "search-highlights-off"));
    public IReadOnlyList<string> Warnings => engine.Warnings;
    public void Invalidate() => plan = null;

    /// <param name="onProgress">Optional (current, total, message) callback. Auto-Optimize leaves it
    /// null and drives its own section progress; the Tweaks card uses it to fill a progress toast.</param>
    public async Task RunAsync(SectionReport report, OptimizeMonitor monitor, CancellationToken ct,
        ProcessReductionChoices selected, Action<int, int, string>? onProgress = null)
    {
        monitor.Log("Scanning current startup apps and services with your keep choices…");
        onProgress?.Invoke(0, 0, "Scanning startup apps and services…");
        await Task.Run(() => Preview(selected), ct).ConfigureAwait(false);
        foreach (string warning in Warnings) monitor.Log("Scan warning: " + warning);
        await ApplyAsync(report, monitor, ct, onProgress).ConfigureAwait(false);
    }

    public Task ApplyAsync(SectionReport report, OptimizeMonitor monitor, CancellationToken ct,
        Action<int, int, string>? onProgress = null) => Task.Run(() =>
    {
        if (plan == null) throw new InvalidOperationException("Preview process reduction with your current choices first.");
        ct.ThrowIfCancellationRequested();
        var registry = new WindowsRegistry();
        var service = new TweakService(registry);
        var threshold = TweakCatalog.All.Single(t => t.Id == "svchost-split-threshold");
        var state = service.Inspect(threshold, out _);
        if (state == TweakState.Unreadable) report.Failed.Add("Service-host threshold could not be read; left unchanged.");
        else if (state == TweakState.AtTarget) report.AlreadyOptimal.Add("RAM-tier service-host grouping");
        else
        {
            // The shared write path journals the original and requested values before mutation.
            var backup = new BackupSession { Description = "Process reduction — service-host grouping" };
            var written = service.Apply(new[] { threshold }, backup, out _);
            if (!backup.IsEmpty) monitor.Log("Grouping history saved: " + backup.Save());
            if (written.Contains(threshold.Id)) report.Applied.Add($"Service-host threshold: 0x{threshold.EffectiveTarget:X} KB");
            else report.Failed.Add("Service-host grouping was not applied.");
        }
        int total = plan.Count(r => r.Action == "Disable");
        int done = 0;
        foreach (var row in plan)
        {
            ct.ThrowIfCancellationRequested();
            if (row.Item.Kind == "Background policies")
            {
                if (row.Action == "Already disabled") report.AlreadyOptimal.Add(row.Item.Name);
                else if (row.Action == "Review") report.Failed.Add(row.Item.Name + " — skipped: " + row.Reason);
                else
                {
                    onProgress?.Invoke(++done, total, row.Item.Name);
                    try
                    {
                        var policy = SelectedPolicies(choices).Single(t => t.Id == row.Item.Identity);
                        if (policy.CustomApply()) report.Applied.Add(row.Item.Name + " — undo in Tweaks > General");
                        else report.AlreadyOptimal.Add(row.Item.Name);
                    }
                    catch (Exception ex) { report.Failed.Add(row.Item.Name + ": " + ex.Message); }
                }
                continue;
            }
            if (row.Action == "Already disabled" && ProcessReductionPolicy.KeepReason(row.Item, choices) == null)
                report.AlreadyOptimal.Add(row.Item.Name + " (already disabled)");
            if (row.Action == "Review" && ProcessReductionPolicy.ServiceOptOutRequested(row.Item, choices))
                report.Failed.Add(row.Item.Name + " — left unchanged: " + row.Reason);
            if (row.Action != "Disable") continue;
            monitor.Log("Disabling " + row.Item.Name);
            onProgress?.Invoke(++done, total, $"Disabling {row.Item.Name}");
            engine.Disable(new[] { row.Item }, manual: true, processReduction: true, choices: choices);
            if (engine.LastDisabledCount > 0) report.Applied.Add(row.Item.Name + " — " + row.Reason);
            report.Failed.AddRange(engine.LastDisableErrors);
        }
        monitor.Log("Protected networking, cryptography, audio, Search, backup/restore, security and core services were retained. Optional features followed your keep choices.");
        monitor.Log("Restore app/service entries individually in Startup → history. The registry backup restores grouping.");
        report.Summary = $"{report.Applied.Count} changes; restart to apply. App/service undo: Startup history. Background policy undo: Tweaks > General.";
    }, ct);
}
