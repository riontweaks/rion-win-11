using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net.NetworkInformation;
using System.Text.Json;
using System.Management;
using Microsoft.Win32;
using RadeonSoftwareSlimmer.Models;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;
using RionHub.Modules.Startup;

namespace RionHub.Modules.Optimize;

public sealed class PcScanResult
{
    public DateTime TimestampUtc { get; init; } = DateTime.UtcNow;
    public List<ScanFinding> Findings { get; } = new();
    public List<HardwareInfo> Gpus { get; } = new();
    public List<ScannedApp> Apps { get; } = new();
    public HashSet<OptimizeSection> SuggestedSections { get; } = new();
    public string SnapshotPath { get; set; } = "";
}

public sealed class PcScanService
{
    public static bool RecommendProcessReduction(int processCount) => processCount > 100;
    public static void SelectRoutineSections(PcScanResult result)
    {
        result.SuggestedSections.UnionWith(new[] { OptimizeSection.DiskCleanup, OptimizeSection.RegistryTweaks,
            OptimizeSection.Runtimes, OptimizeSection.SystemFileCheck });
    }
    public static DateTime? DriverDate(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        if (value.Length >= 8 && DateTime.TryParseExact(value[..8], "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var wmi)) return wmi;
        return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out var date) ? date : null;
    }
    public static bool IsOldDriver(string? value, DateTime today) => DriverDate(value) is DateTime date && date < today.Date.AddMonths(-6);
    public static bool CanUpdateGpu(HardwareInfo gpu, DateTime today) => gpu.VendorId is "1002" or "10DE" && IsOldDriver(gpu.DriverDate, today);

    // Inventory only: writing the local report is the sole scan side effect.
    public PcScanResult Scan(ProcessReductionChoices choices, IProgress<string> progress, CancellationToken ct)
    {
        var result = new PcScanResult();
        SelectRoutineSections(result);
        result.Findings.Add(new("Routine maintenance", "Cleanup, recommended tweaks, runtime checks and Windows file checks are selected. Each section checks current state when it runs.", "Suggested"));
        void Probe(string name, Action action)
        {
            ct.ThrowIfCancellationRequested();
            progress.Report(name);
            try { action(); }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { result.Findings.Add(new(name, ex.Message, "Unavailable")); }
        }
        Probe("Detecting graphics hardware", () =>
        {
            foreach (string vendor in new[] { "1002", "10DE", "8086" })
            {
                ct.ThrowIfCancellationRequested();
                var gpu = new HardwareInspector().Inspect(vendor);
                if (!string.Equals(gpu.VendorId, vendor, StringComparison.OrdinalIgnoreCase)) continue;
                result.Gpus.Add(gpu);
                if (vendor == "8086")
                {
                    result.Findings.Add(new(gpu.GpuName, "Intel graphics detected. Detection only; automatic installation and GPU controls are not available.", "Detected"));
                    continue;
                }
                var date = DriverDate(gpu.DriverDate);
                bool old = IsOldDriver(gpu.DriverDate, DateTime.Today);
                result.Findings.Add(new(gpu.GpuName, $"Driver {gpu.DriverVersion ?? "unknown"} · published {date?.ToString("yyyy-MM-dd") ?? "unknown"}. " +
                    (old ? "Older than six months; check the official package. " : "") +
                    "Published date is not installation date. " + (gpu.IsLaptop || gpu.IsHybridGraphics ? "Laptop / hybrid graphics: OEM review required." : ""),
                    old ? "Update suggested" : date == null ? "Unknown" : "Recent"));
            }
            if (result.Gpus.Count == 0) result.Findings.Add(new("GPU", "No AMD, NVIDIA or Intel adapter was identified. No automatic driver installation is offered.", "Review"));
        });
        Probe("Reading tweak registry values", () =>
        {
            var registry = new WindowsRegistry();
            var service = new TweakService(registry);
            var recommended = GeneralTweakCatalog.Recommended.Select(t => t.Id).ToHashSet();
            foreach (var tweak in GeneralTweakCatalog.All.Where(t => !t.IsCommandBased && !t.IsCustom))
            {
                ct.ThrowIfCancellationRequested();
                var state = service.Inspect(tweak, out var current);
                bool suggest = state == TweakState.NeedsApply && recommended.Contains(tweak.Id);
                if (suggest) result.SuggestedSections.Add(OptimizeSection.RegistryTweaks);
                result.Findings.Add(new(tweak.Title,
                    state == TweakState.AtTarget ? "This setting is already applied." : tweak.Summary,
                    state == TweakState.AtTarget ? "Already applied" : state == TweakState.Unreadable ? "Unknown" : suggest ? "Suggested" : "Manual choice",
                    $"{tweak.Hive}\\{tweak.KeyPath}\n{tweak.ValueName}: {current?.ToString() ?? "not set / unreadable"} → {tweak.EffectiveTarget}"));
            }
            foreach (var diff in RegistrySnapshot.DiffFromDefault(registry))
                result.Findings.Add(new("Existing setting: " + diff.Note, $"{diff.KeyPath} · {diff.ValueName} = {diff.Current}; reference default {diff.WindowsDefault}. A difference does not identify the tool or prove a problem.", "Review"));
        });
        Probe("Inventorying installed apps and optional bloatware", () =>
        {
            var inventory = AppInventoryScanner.Scan(ct, progress);
            result.Apps.AddRange(inventory.Apps);
            foreach (var warning in inventory.Warnings) result.Findings.Add(new("App inventory coverage", warning, "Unavailable"));
            result.Findings.Add(new("App inventory", $"{inventory.Apps.Count} inventory entries, including desktop apps, Store packages, provisioned packages and shortcuts. Entries from different scopes can refer to the same app. Search the app list in this window.", "Scanned"));
            var candidates = inventory.Apps.Where(a => a.DebloatCandidate).Select(a => a.Name).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n).ToList();
            if (candidates.Count > 0) result.SuggestedSections.Add(OptimizeSection.Debloat);
            result.Findings.Add(new("Optional bloatware", candidates.Count == 0 ? "No exact matches to the existing debloat catalog were found in the available inventory. Other apps remain available for manual review." :
                $"{candidates.Count} optional apps: {string.Join(", ", candidates)}. Debloat is selected; uncheck it to keep these apps. Removal may delete app data and requires reinstalling to undo.", candidates.Count > 0 ? "Suggested" : "Checked"));
            result.Findings.Add(new("App scan coverage", "Desktop registration: machine, current user and other loaded user hives, both registry views. Store packages: all users where permitted, otherwise current user. Provisioned packages are for new profiles. Start-menu shortcuts are discovery hints, not verified installations. Unloaded user hives and portable apps outside these sources are not fully covered. No personal-file crawl or installer repair is run.", "Coverage"));
        });
        Probe("Inspecting startup and service dependencies", () =>
        {
            var runner = new ProcessReductionRunner();
            var rows = runner.Preview(choices);
            foreach (var row in rows.Where(r => r.Action is "Disable" or "Review"))
                result.Findings.Add(new(row.Item.Name, row.Reason, row.Action == "Disable" ? "Optional process reduction" : "Unknown"));
            foreach (var warning in runner.Warnings) result.Findings.Add(new("Startup scan", warning, "Unavailable"));
            result.Findings.Add(new("Background entries", $"{rows.Count(r => r.Action == "Disable")} entries can be disabled with your keep-feature choices. Process reduction rescans before applying.", "Checked"));
        });
        Probe("Checking system capacity", () =>
        {
            var processes = Process.GetProcesses();
            int count = processes.Length;
            if (RecommendProcessReduction(count)) result.SuggestedSections.Add(OptimizeSection.ProcessReduction);
            result.Findings.Add(new("Process reduction", RecommendProcessReduction(count)
                ? $"{count} processes are running. Process reduction is selected because the count is above 100. Check the features you want to keep; fewer processes alone does not guarantee higher FPS."
                : $"{count} processes are running. Process reduction is available if you want to review background apps.",
                RecommendProcessReduction(count) ? "Suggested" : "Checked"));
            var samples = new List<BackgroundProcessSample>();
            foreach (var process in processes)
            {
                using (process)
                {
                    try { samples.Add(new(process.ProcessName, process.WorkingSet64, process.PrivateMemorySize64)); }
                    catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception or NotSupportedException) { }
                }
            }
            result.Findings.AddRange(BackgroundProcessReview.Analyze(samples));
            result.Findings.Add(new("Process inventory coverage", $"Read memory for {samples.Count}/{count} processes. Exited or protected processes may be unavailable. Close the report collector and other apps before comparing idle snapshots.", "Measured"));
            result.Findings.Add(new("System", $"{Environment.OSVersion.VersionString} · {SystemInfo.TotalPhysicalMemoryGb()} GB RAM · {count} processes. Process count alone is not a performance diagnosis.", "Measured"));
            var drive = new DriveInfo(Path.GetPathRoot(Environment.SystemDirectory)!);
            double free = (double)drive.AvailableFreeSpace / drive.TotalSize;
            result.Findings.Add(new("System drive", $"{drive.AvailableFreeSpace / 1073741824d:F1} GB free ({free:P0}). Cleanup deletes caches; review before running.", free < .15 ? "Low space" : "Measured"));
            if (free < .15) result.SuggestedSections.Add(OptimizeSection.DiskCleanup);
        });
        Probe("Inspecting network adapters", () =>
        {
            foreach (var adapter in NetworkInterface.GetAllNetworkInterfaces().Where(n => n.OperationalStatus == OperationalStatus.Up))
                result.Findings.Add(new(adapter.Description, $"{adapter.NetworkInterfaceType} · link {adapter.Speed / 1000000} Mbps. Link speed does not measure internet latency or throughput.", "Measured"));
            result.Findings.Add(new("Kernel, network and debloat", "Use measured latency, sustained resource usage and an app removal preview before choosing changes. This scan does not infer corruption or unused apps from registry differences.", "Manual choice"));
        });
        Probe("Checking memory and page-file configuration", () =>
        {
            using var query = new ManagementObjectSearcher("SELECT AvailableMBytes, CommittedBytes, CommitLimit FROM Win32_PerfFormattedData_PerfOS_Memory");
            query.Options.Timeout = TimeSpan.FromSeconds(5);
            using var memory = query.Get();
            foreach (ManagementObject item in memory)
            using (item)
                result.Findings.Add(new("Memory headroom", $"{item["AvailableMBytes"]} MB available · {Convert.ToDouble(item["CommittedBytes"]) / 1073741824:F1} GB committed / {Convert.ToDouble(item["CommitLimit"]) / 1073741824:F1} GB limit. This is one sample, not a workload benchmark. Size page files around peak commit and crash-dump needs; do not disable them just to free disk space.", "Measured"));
            using var systemQuery = new ManagementObjectSearcher("SELECT AutomaticManagedPagefile FROM Win32_ComputerSystem");
            systemQuery.Options.Timeout = TimeSpan.FromSeconds(5);
            using var systems = systemQuery.Get();
            foreach (ManagementObject item in systems)
            using (item)
                result.Findings.Add(new("Page-file management", $"Automatically managed: {item["AutomaticManagedPagefile"] ?? "unknown"}. A custom configuration is not automatically a problem. No memory settings were changed.", "Review"));
        });
        Probe("Detecting NVMe storage", () =>
        {
            using var query = new ManagementObjectSearcher(@"root\Microsoft\Windows\Storage", "SELECT FriendlyName, BusType, HealthStatus FROM MSFT_PhysicalDisk");
            query.Options.Timeout = TimeSpan.FromSeconds(5);
            using var disks = query.Get();
            int nvme = 0;
            foreach (ManagementObject disk in disks)
            using (disk)
                if (Convert.ToInt32(disk["BusType"]) == 17)
                {
                    nvme++;
                    result.Findings.Add(new("NVMe · " + disk["FriendlyName"], $"Storage health status: {disk["HealthStatus"]} (0 = healthy, 1 = warning, 2 = unhealthy). Windows balances idle transition latency and power use. No blanket power-state, cache or queue-depth override is recommended.", "Detected"));
                }
            if (nvme == 0) result.Findings.Add(new("NVMe", "No NVMe device is exposed by the storage provider. Virtual machines may expose a virtual disk instead of the host's physical drive.", "Not detected"));
        });
        Probe("Inspecting USB and input preferences", () =>
        {
            using var usb = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\USB");
            var disable = usb?.GetValue("DisableSelectiveSuspend");
            result.Findings.Add(new("USB power management", $"Global DisableSelectiveSuspend override: {disable ?? "not set"}. Power-plan and device policies also apply. Keep selective suspend unless diagnosing a specific device resume failure; disabling it is not a proven universal latency improvement.", "Manual choice"));
            using var mouse = Registry.CurrentUser.OpenSubKey(@"Control Panel\Mouse");
            using var keyboard = Registry.CurrentUser.OpenSubKey(@"Control Panel\Keyboard");
            result.Findings.Add(new("Mouse preferences", $"MouseSpeed: {mouse?.GetValue("MouseSpeed") ?? "unknown"}. Pointer acceleration is a preference for desktop and legacy input. Raw-input mouse events bypass the Control Panel pointer-speed setting; changing this is not a universal gaming optimization.", "Manual choice"));
            result.Findings.Add(new("Keyboard preferences", $"Repeat speed: {keyboard?.GetValue("KeyboardSpeed") ?? "unknown"} · repeat delay: {keyboard?.GetValue("KeyboardDelay") ?? "unknown"}. These control held-key text repetition, not hardware polling or initial key latency. Accessibility settings are retained.", "Manual choice"));
        });
        ct.ThrowIfCancellationRequested();
        progress.Report("Saving PC snapshot");
        Directory.CreateDirectory(RegistrySnapshot.Directory);
        result.SnapshotPath = Path.Combine(RegistrySnapshot.Directory, "pc-scan-" + Guid.NewGuid().ToString("N") + ".json");
        File.WriteAllText(result.SnapshotPath, JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
        return result;
    }
}
