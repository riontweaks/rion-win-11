using System.Windows.Controls;
using System.Windows;
using System.ComponentModel;

namespace RionHub.Modules.Optimize;

/// <summary>
/// Auto-Optimize module — section picker → live progress → report. The engine
/// (<see cref="RadeonSoftwareSlimmer.Optimize.AutoOptimizeService"/>) lives in the AMD
/// assembly so it can reuse the restore-point / backup / audit / hardware plumbing.
/// </summary>
public partial class AutoOptimizeView : UserControl
{
    private Window? results;
    public AutoOptimizeView()
    {
        InitializeComponent();
        if (DataContext is AutoOptimizeViewModel vm) vm.ScanResultsRequested += () => ShowResults(vm);
    }
    private void ShowResults(AutoOptimizeViewModel vm)
    {
        if (results != null) { results.Activate(); return; }
        var owner = Window.GetWindow(this);
        if (owner == null || !owner.IsVisible) return;
        var dialog = new ScanResultsWindow
        {
            Title = "Auto Optimize · scan results", Owner = owner, ShowInTaskbar = false,
            Icon = owner.Icon, DataContext = vm
        };
        results = dialog;
        RionHub.Shell.WindowFit.Apply(dialog, 860, 740);
        dialog.SourceInitialized += (_, _) => RionHub.Shell.WindowFit.Apply(dialog, 860, 740);
        PropertyChangedEventHandler handler = (_, e) => { if (e.PropertyName == nameof(vm.Phase) && !vm.IsPicker) dialog.Close(); };
        vm.PropertyChanged += handler;
        dialog.Closing += (_, e) => { if (vm.ScanBusy) e.Cancel = true; };
        dialog.Closed += (_, _) => { vm.PropertyChanged -= handler; results = null; };
        dialog.ShowDialog();
    }
}
