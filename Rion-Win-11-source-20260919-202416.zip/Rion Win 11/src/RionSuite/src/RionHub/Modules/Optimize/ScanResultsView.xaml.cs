using System.Windows;
using System.Windows.Controls;

namespace RionHub.Modules.Optimize;

public partial class ScanResultsView : UserControl
{
    public ScanResultsView() => InitializeComponent();
    private void Close_Click(object sender, RoutedEventArgs e) => Window.GetWindow(this)?.Close();
}
