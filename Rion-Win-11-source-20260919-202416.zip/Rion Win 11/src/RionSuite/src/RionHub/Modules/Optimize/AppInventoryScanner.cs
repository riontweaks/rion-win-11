using Microsoft.Win32;
using System.IO;
using System.Security.Principal;
using System.Text.Json;
using RadeonSoftwareSlimmer.Optimize;

namespace RionHub.Modules.Optimize;

public sealed record ScannedApp(string Name, string Version, string Publisher, string Kind, string Scope,
    string Identity, string Location, bool Protected, bool DebloatCandidate)
{
    public string Status => Protected ? "Keep / component" : DebloatCandidate ? "Optional debloat candidate" : "Review only";
    public string Detail => $"{Kind} · {Scope} · {Version}\nPublisher: {Publisher}\n{Status} · {Identity}";
}

public sealed class AppInventoryResult
{
    public List<ScannedApp> Apps { get; } = new();
    public List<string> Warnings { get; } = new();
    public string WindowsDescription { get; set; } = "Windows build unavailable";
}

public static class AppInventoryScanner
{
    public static bool IsProtectedPackage(string name, bool framework, bool resource, bool nonRemovable, bool removeWidgets = false) =>
        framework || resource || nonRemovable || (!(removeWidgets && name.Equals(DebloatPackageRemoval.WidgetsPackage, StringComparison.OrdinalIgnoreCase))
            && DebloatCatalog.KeepAlways.Any(k => name.Contains(k, StringComparison.OrdinalIgnoreCase)));
    public static bool IsDebloatCandidate(string name, bool protectedComponent) =>
        !protectedComponent && DebloatCatalog.Remove.Contains(name, StringComparer.OrdinalIgnoreCase);

    public static AppInventoryResult Scan(CancellationToken ct, IProgress<string> progress, bool removeWidgets = false)
    {
        var result = new AppInventoryResult();
        try
        {
            using var version = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            result.WindowsDescription = $"Windows {version?.GetValue("DisplayVersion")} · {version?.GetValue("EditionID")} · build {version?.GetValue("CurrentBuildNumber")}.{version?.GetValue("UBR")}";
        }
        catch (Exception ex) { result.Warnings.Add("Windows build detection: " + ex.Message); }
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Add(ScannedApp app)
        {
            if (seen.Add(app.Kind + "|" + app.Scope + "|" + app.Identity)) result.Apps.Add(app);
        }
        void ReadUninstall(RegistryKey root, string path, string scope, RegistryView view)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                using var uninstall = root.OpenSubKey(path);
                if (uninstall == null) return;
                foreach (var child in uninstall.GetSubKeyNames())
                {
                    ct.ThrowIfCancellationRequested();
                    try
                    {
                        using var app = uninstall.OpenSubKey(child);
                        if (app == null) continue;
                        string Text(string key) => app.GetValue(key)?.ToString() ?? "";
                        var name = Text("DisplayName");
                        if (string.IsNullOrWhiteSpace(name)) continue;
                        bool component = Text("SystemComponent") == "1" || !string.IsNullOrEmpty(Text("ParentKeyName"));
                        Add(new(name, Text("DisplayVersion"), Text("Publisher"), "Desktop app", scope + " / " + view,
                            child, Text("InstallLocation"), component, DesktopDebloatCatalog.IsCandidate(name, Text("Publisher"), component)
                                && (scope == "All users" || scope == "Current user")));
                    }
                    catch (Exception ex) when (ex is not OperationCanceledException)
                    { result.Warnings.Add($"Desktop entry {scope} / {child}: {ex.Message}"); }
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            { result.Warnings.Add($"Desktop inventory {scope} / {view}: {ex.Message}"); }
        }
        progress.Report("Scanning desktop apps for this PC and loaded user profiles");
        const string uninstallPath = @"Software\Microsoft\Windows\CurrentVersion\Uninstall";
        string? currentSid = null;
        using (var identity = WindowsIdentity.GetCurrent()) currentSid = identity.User?.Value;
        foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
        {
            using var machine = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view);
            ReadUninstall(machine, uninstallPath, "All users", view);
            using var user = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view);
            ReadUninstall(user, uninstallPath, "Current user", view);
            using var users = RegistryKey.OpenBaseKey(RegistryHive.Users, view);
            foreach (var sid in users.GetSubKeyNames().Where(s => s.StartsWith("S-1-5-21-", StringComparison.OrdinalIgnoreCase)
                         && !s.EndsWith("_Classes", StringComparison.OrdinalIgnoreCase) && s != currentSid))
                ReadUninstall(users, sid + "\\" + uninstallPath, "Loaded profile " + sid, view);
        }
        ct.ThrowIfCancellationRequested();
        progress.Report("Scanning Store packages, shared frameworks and provisioned apps");
        var packageResult = ShellRunner.PowerShellAsync(PackageScript, null, timeoutMs: 90000, ct: ct).GetAwaiter().GetResult();
        ct.ThrowIfCancellationRequested();
        foreach (var line in (packageResult.Output ?? "").Split('\n').Where(l => l.TrimStart().StartsWith('{')))
        {
            try
            {
                using var document = JsonDocument.Parse(line.Trim());
                var row = document.RootElement;
                string Text(string key) => row.TryGetProperty(key, out var v) ? v.ToString() : "";
                bool Flag(string key) => row.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.True;
                if (Text("Kind") == "Warning") { result.Warnings.Add(Text("Message")); continue; }
                string name = Text("Name");
                bool protect = IsProtectedPackage(name, Flag("Framework"), Flag("Resource"), Flag("NonRemovable"), removeWidgets);
                Add(new(name, Text("Version"), Text("Publisher"), Text("Kind"), Text("Scope"), Text("Identity"), Text("Location"), protect,
                    IsDebloatCandidate(name, protect) || (!protect && removeWidgets && name.Equals(DebloatPackageRemoval.WidgetsPackage, StringComparison.OrdinalIgnoreCase))));
            }
            catch (JsonException ex) { result.Warnings.Add("A package inventory row could not be read: " + ex.Message); }
        }
        if (packageResult.ExitCode != 0 || packageResult.TimedOut || !(packageResult.Output ?? "").Split('\n').Any(l => l.Trim() == "INVENTORY-DONE"))
            result.Warnings.Add("Package inventory did not complete. Available rows are shown; missing packages are not proof they are absent.");

        progress.Report("Checking Start-menu entries for additional apps");
        foreach (var folder in new[] { Environment.SpecialFolder.Programs, Environment.SpecialFolder.CommonPrograms })
        {
            string path = Environment.GetFolderPath(folder);
            if (!Directory.Exists(path)) continue;
            try
            {
                var options = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = false, AttributesToSkip = FileAttributes.ReparsePoint };
                foreach (var file in Directory.EnumerateFiles(path, "*", options))
                {
                    ct.ThrowIfCancellationRequested();
                    if (Path.GetExtension(file).ToLowerInvariant() is not (".lnk" or ".appref-ms")) continue;
                    Add(new(Path.GetFileNameWithoutExtension(file), "", "Unknown", "Start-menu shortcut", folder.ToString(), file, file, false, false));
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException) { result.Warnings.Add("Start-menu inventory: " + ex.Message); }
        }
        return result;
    }

    // No Win32_Product queries: those can trigger MSI repair. Never execute uninstall strings or shortcuts.
    private const string PackageScript = """
        $ErrorActionPreference = 'Stop'
        $ProgressPreference = 'SilentlyContinue'
        [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
        function Warn($message) { @{ Kind='Warning'; Message=$message } | ConvertTo-Json -Compress }
        $scope = 'All users'
        try { $packages = @(Get-AppxPackage -AllUsers -PackageTypeFilter All -ErrorAction Stop) }
        catch {
            Warn ('All-user Store inventory unavailable; trying current user. ' + $_.Exception.Message)
            $scope = 'Current user'
            try { $packages = @(Get-AppxPackage -PackageTypeFilter All -ErrorAction Stop) }
            catch { Warn ('Store inventory unavailable: ' + $_.Exception.Message); $packages = @() }
        }
        foreach ($p in $packages) {
            @{ Name=[string]$p.Name; Version=[string]$p.Version; Publisher=[string]$p.Publisher;
               Kind='Store package'; Scope=$scope; Identity=[string]$p.PackageFullName;
               Location=[string]$p.InstallLocation; Framework=[bool]$p.IsFramework;
               Resource=[bool]$p.IsResourcePackage; NonRemovable=[bool]$p.NonRemovable } | ConvertTo-Json -Compress
        }
        try {
            Get-AppxProvisionedPackage -Online -ErrorAction Stop | ForEach-Object {
                @{ Name=[string]$_.DisplayName; Version=[string]$_.Version; Publisher='Not reported';
                   Kind='Provisioned package'; Scope='New user profiles'; Identity=[string]$_.PackageName;
                   Location=''; Framework=$false; Resource=$false; NonRemovable=$false } | ConvertTo-Json -Compress
            }
        } catch { Warn ('Provisioned inventory unavailable: ' + $_.Exception.Message) }
        Write-Output 'INVENTORY-DONE'
        """;
}
