using System.Windows;
using System.Windows.Controls;

namespace RionHub.Modules.Tools.Debloat;

public partial class DebloatView : UserControl
{
    public DebloatView()
    {
        InitializeComponent();
        SizeChanged += (_, _) =>
        {
            PublisherColumn.Visibility = ActualWidth >= 800 ? Visibility.Visible : Visibility.Collapsed;
            DateColumn.Visibility = ActualWidth >= 660 ? Visibility.Visible : Visibility.Collapsed;
            FitAppColumn();
        };
        DesktopGrid.SizeChanged += (_, _) => FitAppColumn();
    }

    private void FitAppColumn()
    {
        // Explicitly refill space after optional columns collapse. WPF can retain a star
        // column's minimum width while switching tabs or resizing a previously hidden grid.
        double reserved = 38 + 76 + 12;
        if (PublisherColumn.Visibility == Visibility.Visible) reserved += PublisherColumn.Width.Value;
        if (DateColumn.Visibility == Visibility.Visible) reserved += DateColumn.Width.Value;
        AppColumn.Width = new DataGridLength(System.Math.Max(170, DesktopGrid.ActualWidth - reserved));
    }

    private void DesktopToggle_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is DebloatViewModel vm) vm.IsStoreView = false;
    }

    private void StoreToggle_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is DebloatViewModel vm) vm.IsStoreView = true;
    }
    private void ClearSearch_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is DebloatViewModel vm) vm.Search = "";
        SearchBox.Focus();
    }
}
