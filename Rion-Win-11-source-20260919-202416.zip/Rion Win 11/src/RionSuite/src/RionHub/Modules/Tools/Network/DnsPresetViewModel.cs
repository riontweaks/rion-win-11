namespace RionHub.Modules.Tools.Network;

public sealed class DnsPresetViewModel : ObservableObject
{
	public string Label { get; }

	public RelayCommand ApplyCommand { get; }

	public DnsPresetViewModel(string label, NetworkViewModel owner)
	{
		Label = label;
		ApplyCommand = new RelayCommand(async delegate
		{
			await owner.ApplyDnsPresetAsync(label);
		});
	}
}
