namespace RionHub.Modules.Tools.Network;

public sealed class NetworkChoice
{
	public string Value { get; }

	public string Label { get; }

	public bool IsRecommended { get; }

	public NetworkChoice(string value, string recommended, string? display = null)
	{
		Value = value;
		IsRecommended = value == recommended && recommended.Length > 0;
		Label = (display ?? ((value == "__ABSENT__") ? "Windows default (no override)" : value)) + (IsRecommended ? " · Recommended" : "");
	}
}
