using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace RionHub.Modules.Tools.Network;

public sealed class NetworkSettingGroup
{
	public string Title { get; }

	public ObservableCollection<NetworkSettingRow> Rows { get; }

	public NetworkSettingGroup(string title, IEnumerable<NetworkSettingRow> rows)
	{
		Title = title;
		Rows = new ObservableCollection<NetworkSettingRow>(rows);
	}
}
