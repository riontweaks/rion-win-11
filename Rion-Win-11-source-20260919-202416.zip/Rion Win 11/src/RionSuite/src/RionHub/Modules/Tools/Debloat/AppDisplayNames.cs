using System;
using System.Collections.Generic;

namespace RionHub.Modules.Tools.Debloat;

/// <summary>Presentation names only. Removal and protection always use the original package identity.</summary>
public static class AppDisplayNames
{
    private static readonly Dictionary<string, string> Names = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Microsoft.ECApp"] = "Microsoft EC app", ["Windows.CBSPreview"] = "CBS Preview", ["Windows.PrintDialog"] = "Print Dialog",
        ["Microsoft.BingSearch"] = "Microsoft Bing Search", ["Microsoft.MicrosoftStickyNotes"] = "Sticky Notes",
        ["Microsoft.RawImageExtension"] = "RAW Image Extension", ["Microsoft.SecHealthUI"] = "Windows Security",
        ["Microsoft.Windows.SecHealthUI"] = "Windows Security", ["Microsoft.Xbox.TCUI"] = "Xbox TCUI",
        ["Microsoft.XboxSpeechToTextOverlay"] = "Xbox Speech to Text Overlay", ["Microsoft.XboxGameCallableUI"] = "Xbox Game Callable UI",
        ["Microsoft.AccountsControl"] = "Accounts Control", ["Microsoft.Windows.ParentalControls"] = "Parental Controls",
        ["Microsoft.Windows.PrintQueueActionCenter"] = "Print Queue", ["Microsoft.Windows.PrintDialog"] = "Print Dialog",
        ["Microsoft.GamingApp"] = "Xbox", ["Microsoft.GamingApp.Beta"] = "Xbox Beta",
        ["Microsoft.XboxGamingOverlay"] = "Xbox Game Bar", ["Microsoft.XboxApp"] = "Xbox Console Companion",
        ["Microsoft.XboxIdentityProvider"] = "Xbox Identity Provider",
        ["Microsoft.Windows.Photos"] = "Microsoft Photos", ["Microsoft.WindowsNotepad"] = "Notepad",
        ["Microsoft.WindowsCalculator"] = "Calculator", ["Microsoft.WindowsCamera"] = "Camera",
        ["Microsoft.ScreenSketch"] = "Snipping Tool", ["Microsoft.WindowsTerminal"] = "Windows Terminal",
        ["Microsoft.WindowsSoundRecorder"] = "Sound Recorder", ["Microsoft.WindowsAlarms"] = "Clock",
        ["Microsoft.WindowsStore"] = "Microsoft Store", ["Microsoft.StorePurchaseApp"] = "Store Purchase App",
        ["Microsoft.DesktopAppInstaller"] = "App Installer", ["Microsoft.YourPhone"] = "Phone Link",
        ["Microsoft.Copilot"] = "Microsoft Copilot", ["Microsoft.MicrosoftOfficeHub"] = "Microsoft 365",
        ["MicrosoftTeams"] = "Microsoft Teams (classic)", ["MSTeams"] = "Microsoft Teams",
        ["Microsoft.SkypeApp"] = "Skype", ["Microsoft.Paint"] = "Paint", ["Microsoft.MSPaint"] = "Paint 3D",
        ["Microsoft.BingNews"] = "Microsoft News", ["Microsoft.BingWeather"] = "MSN Weather",
        ["Microsoft.GetHelp"] = "Get Help", ["Microsoft.Getstarted"] = "Tips",
        ["Microsoft.WindowsFeedbackHub"] = "Feedback Hub", ["Microsoft.WindowsMaps"] = "Windows Maps",
        ["Microsoft.People"] = "People", ["Microsoft.MicrosoftSolitaireCollection"] = "Microsoft Solitaire",
        ["Microsoft.Windows.DevHome"] = "Dev Home", ["Microsoft.Todos"] = "Microsoft To Do",
        ["Microsoft.PowerAutomateDesktop"] = "Power Automate", ["Microsoft.MixedReality.Portal"] = "Mixed Reality Portal",
        ["Microsoft.Microsoft3DViewer"] = "3D Viewer", ["Microsoft.549981C3F5F10"] = "Cortana",
        ["MicrosoftCorporationII.QuickAssist"] = "Quick Assist", ["Microsoft.Family"] = "Microsoft Family",
        ["Microsoft.OutlookForWindows"] = "Outlook for Windows", ["Clipchamp.Clipchamp"] = "Microsoft Clipchamp",
        ["Microsoft.ZuneMusic"] = "Media Player", ["Microsoft.ZuneVideo"] = "Movies & TV",
        ["microsoft.windowscommunicationsapps"] = "Mail and Calendar", ["Microsoft.MicrosoftJournal"] = "Microsoft Journal",
        ["MicrosoftWindows.Client.WebExperience"] = "Windows Widgets (Web Experience Pack)"
    };
    public static string Get(string identity) => Names.TryGetValue(identity, out var name) ? name : identity;
}
