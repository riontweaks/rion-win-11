using System;
using System.Threading;
using System.Threading.Tasks;
using RadeonSoftwareSlimmer.Optimize;
using RionHub.Modules.Optimize;
using RionHub.Modules.Startup;
using RionHub.Shell;

namespace RionHub.Modules.Tools.General;

public sealed class ProcessReductionRowViewModel : ObservableObject
{
	private bool _isBusy;

	private string _status = "";

	public string Title => "Process reduction";
    public bool UseAdvancedSection { get; set; }
    public string DisplaySection => UseAdvancedSection ? TweakPresentationOrder.AdvancedSection : Section;

	public string Section => "Performance & power";

	public string TradeOff => "Some vendor apps may need manual starts. Restart after applying; undo in Startup history.";

	public string Summary => "Reduces background services and startup entries while keeping printing, remote access, sync and Xbox saves.";

	public string Detail => "Run it again any time — each run rescans. Undo lives in Startup → history. For printing, scanning, Bluetooth, sync, reporting, diagnostics and vendor-helper choices, use Auto-Optimize > Process reduction. Features and vendor updates are kept by default. Separate Edge, Widgets and Search controls are also below.";

	public RelayCommand RunCommand { get; }

	public bool IsBusy
	{
		get
		{
			return _isBusy;
		}
		private set
		{
			if (Set(ref _isBusy, value, "IsBusy"))
			{
				RunCommand.RaiseCanExecuteChanged();
			}
		}
	}

	public string Status
	{
		get
		{
			return _status;
		}
		private set
		{
			Set(ref _status, value, "Status");
		}
	}

	public bool LastSucceeded { get; private set; }

	public int LastChangedCount { get; private set; }

	public ProcessReductionRowViewModel()
	{
		RunCommand = new RelayCommand(async delegate
		{
			await RunAsync();
		}, () => !_isBusy);
	}

	public bool MatchesCategory(string categoryFilter)
	{
		if (!(categoryFilter == "All Tweaks"))
		{
			return categoryFilter == "Performance";
		}
		return true;
	}

	public bool MatchesSearch(string search)
	{
		if (!string.IsNullOrWhiteSpace(search) && !Title.Contains(search, StringComparison.OrdinalIgnoreCase))
		{
			return Summary.Contains(search, StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	public async Task RunAsync()
	{
		if (IsBusy)
		{
			return;
		}
		LastSucceeded = false;
		LastChangedCount = 0;
		IsBusy = true;
		IProgressToastHandle toast = ToastCenter.ShowProgress("Process reduction — scanning…");
		SectionReport report = new SectionReport
		{
			Section = OptimizeSection.ProcessReduction,
			Title = "Process reduction"
		};
		try
		{
			OptimizeMonitor monitor = new OptimizeMonitor();
			await new ProcessReductionRunner().RunAsync(report, monitor, CancellationToken.None, new ProcessReductionChoices(), delegate(int current, int total, string message)
			{
				toast.Report(current, total, message);
			});
			int num = (LastChangedCount = report.Applied.Count);
			string text = ((num == 0) ? "No changes made for these choices. Review optional background apps in Auto-Optimize; this does not mean all memory use is reducible." : $"{num} disabled. Restart to apply service changes.");
			if (report.Failed.Count > 0)
			{
				text += $" {report.Failed.Count} could not be changed.";
			}
			LastSucceeded = report.Failed.Count == 0;
			Status = text;
			toast.Complete("Process reduction: " + text);
		}
		catch (Exception ex)
		{
			Status = "Failed: " + ex.Message;
			toast.Fail("Process reduction failed: " + ex.Message);
		}
		finally
		{
			IsBusy = false;
		}
	}
}
