using System.Windows.Controls;
namespace RionHub.Modules.Tools.Network;
public partial class NetworkProfileSettingsView : UserControl
{
    public NetworkProfileSettingsView() => InitializeComponent();
}
