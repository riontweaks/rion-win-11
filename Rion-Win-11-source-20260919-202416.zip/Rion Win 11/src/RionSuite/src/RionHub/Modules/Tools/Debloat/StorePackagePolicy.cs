using System.Text.Json;

namespace RionHub.Modules.Tools.Debloat;

public sealed record StorePackageInfo
{
    public string Name { get; init; } = "";
    public string PackageFullName { get; init; } = "";
    public string Publisher { get; init; } = "";
    public string InstallLocation { get; init; } = "";
    public string DisplayName { get; init; } = "";
    public string ProvisionedName { get; init; } = "";
    public bool CurrentUser { get; init; }
    public bool NonRemovable { get; init; }
    public bool IsFramework { get; init; }
    public bool IsResourcePackage { get; init; }
    public bool SystemComponent { get; init; }
    public string[] Dependents { get; init; } = Array.Empty<string>();
}

public static class StorePackagePolicy
{
    private static readonly HashSet<string> Protected = new(StringComparer.OrdinalIgnoreCase) {
        "Microsoft.WindowsStore", "Microsoft.StorePurchaseApp", "Microsoft.DesktopAppInstaller",
        "Microsoft.SecHealthUI", "Microsoft.Windows.SecHealthUI", "Microsoft.AAD.BrokerPlugin",
        "Microsoft.AccountsControl", "Microsoft.Windows.ShellExperienceHost", "Microsoft.Windows.StartMenuExperienceHost",
        "MicrosoftWindows.Client.CBS", "MicrosoftWindows.Client.Core", "Microsoft.Windows.CloudExperienceHost",
        "Microsoft.Windows.OOBENetworkCaptivePortal", "Microsoft.Windows.OOBENetworkConnectionFlow"
    };
    public static string BlockReason(StorePackageInfo package)
    {
        if (package.PackageFullName.Length == 0 && AppDisplayNames.Get(package.Name) == package.Name) return "Provisioned-only package metadata is incomplete; removal is unavailable.";
        if (Protected.Contains(package.Name)) return "Protected Windows, account, security, or Store infrastructure.";
        if (package.NonRemovable) return "Windows marks this package as non-removable.";
        if (package.IsFramework || package.IsResourcePackage) return "Shared framework or resource package; remove the owning app instead.";
        if (package.Dependents.Length > 0) return "Required by installed packages: " + string.Join(", ", package.Dependents);
        return "";
    }
    public static string Impact(string name) => name switch {
        "Microsoft.Paint" => "Removes Paint. Saved image files remain.",
        "Microsoft.MicrosoftStickyNotes" => "Local sticky notes may be lost. Sync or export notes first.",
        "Microsoft.RawImageExtension" => "RAW image previews and decoding may stop working in apps that use this extension.",
        "Microsoft.YourPhone" => "Phone Link pairing, messages and phone integration become unavailable.",
        "MicrosoftCorporationII.QuickAssist" => "Quick Assist remote support becomes unavailable.",
        "Microsoft.Windows.ParentalControls" or "Microsoft.Family" => "Family safety and parental-control features may be affected.",
        "Microsoft.Windows.PrintQueueActionCenter" or "Microsoft.Windows.PrintDialog" => "Windows print dialogs or print-queue controls may be affected.",
        _ when name.Contains("Xbox", StringComparison.OrdinalIgnoreCase) || name == "Microsoft.GamingServices" || name == "Microsoft.GamingApp" => "Xbox sign-in, overlays, Game Pass or games may require this component. Reinstall it if those features are needed.",
        _ => "Removes this app for the selected scope. Reinstalling does not recover deleted local app data."
    };
    public static IReadOnlyList<StorePackageInfo> Parse(string output)
    {
        const string marker = "RION_APPX_JSON:";
        var line = output.Split('\n').LastOrDefault(l => l.StartsWith(marker, StringComparison.Ordinal));
        if (line == null) throw new InvalidOperationException("The package scan did not return a complete inventory.");
        return JsonSerializer.Deserialize<List<StorePackageInfo>>(line[marker.Length..], new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();
    }

    public const string InventoryScript = """
        $ErrorActionPreference = 'Stop'
        $current = @(Get-AppxPackage -PackageTypeFilter Main,Bundle,Framework,Resource -ErrorAction Stop)
        $all = @(Get-AppxPackage -AllUsers -PackageTypeFilter Main,Bundle,Framework,Resource -ErrorAction Stop)
        $provisioned = @(Get-AppxProvisionedPackage -Online -ErrorAction Stop)
        $rows = @($all | ForEach-Object {
          $p = $_
          $display = ''
          try { $display = [string](Get-AppxPackageManifest -Package $p.PackageFullName -ErrorAction Stop).Package.Properties.DisplayName } catch {}
          if ($display -like 'ms-resource:*') { $display = '' }
          $prov = @($provisioned | Where-Object DisplayName -eq $p.Name)
          [pscustomobject]@{ Name=$p.Name; PackageFullName=$p.PackageFullName; Publisher=$p.Publisher; InstallLocation=$p.InstallLocation;
            DisplayName=$display; ProvisionedName= $(if ($prov.Count) { $prov[0].PackageName } else { '' });
            CurrentUser= [bool]@($current | Where-Object PackageFullName -eq $p.PackageFullName).Count;
            NonRemovable=[bool]$p.NonRemovable; IsFramework=[bool]$p.IsFramework; IsResourcePackage=[bool]$p.IsResourcePackage;
            SystemComponent= [bool]($p.InstallLocation -like "$env:windir\SystemApps\*" -or $p.NonRemovable);
            Dependents=@($all | Where-Object { @($_.Dependencies | Where-Object Name -eq $p.Name).Count -gt 0 } | Select-Object -ExpandProperty Name -Unique) }
        })
        foreach ($p in $provisioned) {
          if (-not @($rows | Where-Object Name -eq $p.DisplayName).Count) {
            $rows += [pscustomobject]@{Name=$p.DisplayName;PackageFullName='';Publisher='';InstallLocation='';DisplayName='';ProvisionedName=$p.PackageName;CurrentUser=$false;NonRemovable=$false;IsFramework=$false;IsResourcePackage=$false;SystemComponent=$true;Dependents=@()}
          }
        }
        Write-Output ('RION_APPX_JSON:' + (ConvertTo-Json -InputObject @($rows) -Depth 5 -Compress))
        """;

    public static string RemovalScript(StorePackageInfo package, bool allUsers, bool provisioned)
    {
        string reason = BlockReason(package);
        if (reason.Length > 0) throw new InvalidOperationException(reason);
        string Literal(string value) => "'" + value.Replace("'", "''") + "'";
        string name = Literal(package.Name), full = Literal(package.PackageFullName), prov = Literal(package.ProvisionedName);
        // Reinspect immediately before a mutation; inventory is only a preview.
        return $$"""
            $ErrorActionPreference = 'Stop'
            try {
              $all = @(Get-AppxPackage -AllUsers -PackageTypeFilter Main,Bundle,Framework,Resource -ErrorAction Stop)
              $exact = @($all | Where-Object PackageFullName -eq {{full}})
              if (@($exact | Where-Object { $_.NonRemovable -or $_.IsFramework -or $_.IsResourcePackage }).Count) { throw 'Package is protected by Windows.' }
              if (@($all | Where-Object { @($_.Dependencies | Where-Object Name -eq {{name}}).Count }).Count) { throw 'An installed package depends on this component.' }
              {{(allUsers ? "" : "$current = @(Get-AppxPackage -PackageTypeFilter Main,Bundle -ErrorAction Stop)")}}
              if ({{full}} -ne '') {
                $targets = @({{(allUsers ? "$exact" : "$current | Where-Object PackageFullName -eq " + full)}})
                foreach ($target in $targets) { Remove-AppxPackage -Package $target.PackageFullName {{(allUsers ? "-AllUsers" : "")}} -ErrorAction Stop }
                if (@(Get-AppxPackage {{(allUsers ? "-AllUsers" : "")}} -PackageTypeFilter Main,Bundle,Framework,Resource -ErrorAction Stop | Where-Object PackageFullName -eq {{full}}).Count) { throw 'Installed package remains after removal.' }
              }
              {{(provisioned && package.ProvisionedName.Length > 0 ? "$provisioned = @(Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object PackageName -eq " + prov + "); foreach ($p in $provisioned) { Remove-AppxProvisionedPackage -Online -PackageName $p.PackageName -ErrorAction Stop | Out-Null }; if (@(Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object PackageName -eq " + prov + ").Count) { throw 'Provisioned package remains after removal.' }" : "")}}
              Write-Output 'RION_REMOVAL_VERIFIED'
            } catch { Write-Output ('Removal failed: ' + $_.Exception.Message); exit 1 }
            """;
    }
}
