using System.Windows.Controls;

namespace RionHub.Modules.Tools.Fixes;

public partial class FixesView : UserControl
{
    public FixesView()
    {
        InitializeComponent();
    }
}
