// Recovered from the original September 15 executable using ILSpy; original source unavailable.
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace RionHub.Modules.Tools.Network;

public sealed class NetworkSettingRow : ObservableObject
{
	private string _value;

	public NetworkSettingData Data { get; }

	public string Title
	{
		get
		{
			if (Data.Kind == "RSS" && Data.Key == "Enabled")
			{
				return "Adapter receive side scaling";
			}
			string result;
			switch (Data.Key)
			{
			case "*NumRssQueues":
			case "NumberOfReceiveQueues":
				result = "RSS receive queue count";
				break;
			case "ArpOffload":
				result = "ARP sleep offload";
				break;
			case "NSOffload":
				result = "Neighbor-solicitation sleep offload";
				break;
			case "RsnRekeyOffload":
				result = "Wireless key renewal during sleep";
				break;
			case "WakeOnMagicPacket":
				result = "Wake on magic packet";
				break;
			case "WakeOnPattern":
				result = "Wake on packet pattern";
				break;
			case "ITR":
			case "*InterruptModerationRate":
				result = "Interrupt moderation rate";
				break;
			case "GigabitLite":
			case "GigaLite":
				result = "Gigabit Lite power saving";
				break;
			case "UltraLowPowerMode":
			case "ULPMode":
				result = "Ultra-low-power mode";
				break;
			case "AFD / FastSendDatagramThreshold":
				result = "Fast datagram send threshold";
				break;
			case "ReceiveSideScaling":
				result = "Windows receive side scaling";
				break;
			case "TaskOffload":
				result = "Windows task offload";
				break;
			case "*IPChecksumOffloadIPv4":
				result = "IPv4 checksum offload";
				break;
			case "*TCPChecksumOffloadIPv4":
				result = "TCP checksum offload (IPv4)";
				break;
			case "*TCPChecksumOffloadIPv6":
				result = "TCP checksum offload (IPv6)";
				break;
			case "*UDPChecksumOffloadIPv4":
				result = "UDP checksum offload (IPv4)";
				break;
			case "*UDPChecksumOffloadIPv6":
				result = "UDP checksum offload (IPv6)";
				break;
			case "*LsoV2IPv4":
				result = "Large-send offload (IPv4)";
				break;
			case "*LsoV2IPv6":
				result = "Large-send offload (IPv6)";
				break;
			case "*SpeedDuplex":
				result = "Link speed and duplex";
				break;
			case "*InterruptModeration":
				result = "Interrupt moderation";
				break;
			case "EEE":
			case "*EEE":
				result = "Energy-efficient Ethernet";
				break;
			case "SelectiveSuspend":
				result = "Adapter selective suspend";
				break;
			case "DeviceSleepOnDisconnect":
				result = "Sleep on disconnect";
				break;
			case "D0PacketCoalescing":
				result = "Packet coalescing power saving";
				break;
			case "AllowComputerToTurnOffDevice":
				result = "Allow device power off";
				break;
			case "AdvancedEEE":
				result = "Advanced energy-efficient Ethernet";
				break;
			case "GreenEthernet":
			case "EnableGreenEthernet":
				result = "Green Ethernet";
				break;
			case "PowerSavingMode":
			case "AutoPowerSaveModeEnabled":
			case "*NicAutoPowerSaver":
				result = "Adapter power saving";
				break;
			case "EnableCoalesce":
				result = "DMA coalescing";
				break;
			case "*FlowControl":
				result = "Flow control";
				break;
			case "*JumboPacket":
				result = "Jumbo packet size";
				break;
			case "*ReceiveBuffers":
				result = "Receive buffers";
				break;
			case "*TransmitBuffers":
				result = "Transmit buffers";
				break;
			default:
				result = Data.Key.TrimStart('*');
				break;
			}
			return result;
		}
	}

	public string NavigationGroup
	{
		get
		{
			if (!(Data.Kind == "Power") && !Title.Contains("sleep", StringComparison.OrdinalIgnoreCase) && !Title.Contains("power", StringComparison.OrdinalIgnoreCase) && !Title.Contains("wake", StringComparison.OrdinalIgnoreCase) && !Title.Contains("Ethernet", StringComparison.OrdinalIgnoreCase))
			{
				if (!Title.Contains("offload", StringComparison.OrdinalIgnoreCase) && !Title.Contains("scaling", StringComparison.OrdinalIgnoreCase) && !Title.Contains("RSS", StringComparison.OrdinalIgnoreCase))
				{
					if (!(Data.Kind == "Registry"))
					{
						return "Link and packet handling";
					}
					return "Windows network options";
				}
				return "Offloads and CPU distribution";
			}
			return "Power and wake";
		}
	}

	public string Current => "Current: " + (string.IsNullOrWhiteSpace(Data.Current) ? "Unavailable" : DisplayValue(Data.Current));

	public string Note => Data.Note;

	public string Recommendation
	{
		get
		{
			if (Data.Recommended.Length <= 0)
			{
				return "Kept by the profile; adjust only if needed";
			}
			return "Recommended: " + DisplayValue(Data.Recommended);
		}
	}

	public bool HasRecommendation => Data.Recommended.Length > 0;

	public bool IsAtRecommendation
	{
		get
		{
			if (HasRecommendation)
			{
				return string.Equals(Data.Current, Data.Recommended, StringComparison.OrdinalIgnoreCase);
			}
			return false;
		}
	}

	public string ProfileState
	{
		get
		{
			if (IsEditable)
			{
				if (HasRecommendation)
				{
					if (!IsAtRecommendation)
					{
						return "Change available";
					}
					return "Applied";
				}
				return "Optional";
			}
			return "Read only · driver exposes no supported choices";
		}
	}

	public bool IsEditable => Data.Choices.Length != 0;

	public bool IsNumeric => Data.Choices.Contains("__NUMBER__");

	public ObservableCollection<NetworkChoice> Choices { get; }

	public string Value
	{
		get
		{
			return _value;
		}
		set
		{
			Set(ref _value, value, "Value");
			ApplyCommand.RaiseCanExecuteChanged();
		}
	}

	public string EditorValue
	{
		get
		{
			if (!(Value == "__ABSENT__"))
			{
				return Value;
			}
			return "";
		}
		set
		{
			Value = ((Data.Kind == "Registry" && string.IsNullOrWhiteSpace(value)) ? "__ABSENT__" : value);
		}
	}

	public RelayCommand ApplyCommand { get; }

	public RelayCommand RestoreCommand { get; }

	private string DisplayValue(string value)
	{
		if (value == "__ABSENT__")
		{
			return "Windows default (no override)";
		}
		string result;
		if (Data.Kind == "RSS" && Data.Key == "Enabled")
		{
			result = (value.Equals("True", StringComparison.OrdinalIgnoreCase) ? "Enabled" : "Disabled");
		}
		else
		{
			string text;
			if (Data.Key.Contains("ChecksumOffload", StringComparison.Ordinal) || Data.Key == "*FlowControl")
			{
				text = value switch
				{
					"0" => "Disabled", 
					"1" => "Transmit", 
					"2" => "Receive", 
					"3" => "Receive and transmit", 
					_ => value, 
				};
			}
			else
			{
				bool flag = Data.Key.StartsWith("*LsoV2", StringComparison.Ordinal);
				if (!flag)
				{
					bool flag2;
					switch (Data.Key)
					{
					case "*InterruptModeration":
					case "*EEE":
					case "EEE":
						flag2 = true;
						break;
					default:
						flag2 = false;
						break;
					}
					flag = flag2;
				}
				string text3;
				if (flag)
				{
					string text2 = ((value == "0") ? "Disabled" : ((!(value == "1")) ? value : "Enabled"));
					text3 = text2;
				}
				else
				{
					text3 = ((Data.Key == "*SpeedDuplex" && value == "0") ? "Automatic negotiation" : value);
				}
				text = text3;
			}
			result = text;
		}
		return result;
	}

	public NetworkSettingRow(NetworkSettingData data, NetworkViewModel owner)
	{
		NetworkSettingRow networkSettingRow = this;
		Data = data;
		_value = data.Current;
		Choices = new ObservableCollection<NetworkChoice>(from v in data.Choices
			where v != "__NUMBER__"
			select new NetworkChoice(v, data.Recommended, networkSettingRow.DisplayValue(v)));
		ApplyCommand = new RelayCommand(async delegate
		{
			await owner.ChangeSettingAsync(networkSettingRow, restore: false);
		}, () => !owner.IsBusy && networkSettingRow.IsEditable && networkSettingRow.Value != networkSettingRow.Data.Current);
		RestoreCommand = new RelayCommand(async delegate
		{
			await owner.ChangeSettingAsync(networkSettingRow, restore: true);
		}, () => !owner.IsBusy && NetworkSettingService.HasBackup(data));
	}

	public void UpdateCommands()
	{
		ApplyCommand.RaiseCanExecuteChanged();
		RestoreCommand.RaiseCanExecuteChanged();
	}
}
