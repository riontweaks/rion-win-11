using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace RionHub.Modules.Tools.Debloat;

/// <summary>A bounded, scrollable review even when a new Windows image has many optional apps.</summary>
public sealed class DebloatReviewDialog : Window
{
    private readonly List<CheckBox> choices = new();
    public List<string> SelectedNames => choices.Where(c => c.IsChecked == true).Select(c => (string)c.Tag).ToList();

    public DebloatReviewDialog(IEnumerable<string> names, bool incompleteInventory)
    {
        Title = "Review Auto Debloat";
        SetResourceReference(FontFamilyProperty, "AppFont");
        UseLayoutRounding = true;
        Width = 680; Height = 600;
        MaxHeight = SystemParameters.WorkArea.Height - 40;
        MaxWidth = SystemParameters.WorkArea.Width - 40;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        if (Application.Current?.MainWindow?.IsVisible == true) Owner = Application.Current.MainWindow;
        SetResourceReference(BackgroundProperty, "Bg1");
        SetResourceReference(ForegroundProperty, "Text");
        Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new System.Uri("/Rion Win 11;component/Modules/Tools/ToolStyles.xaml", System.UriKind.Relative) });
        var layout = new DockPanel { Margin = new Thickness(22) };
        Content = layout;
        var actions = new WrapPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0,14,0,0) };
        DockPanel.SetDock(actions, Dock.Bottom); layout.Children.Add(actions);
        var cancel = new Button { Content = "Cancel", IsCancel = true, Padding = new Thickness(18,8,18,8), Margin = new Thickness(0,0,8,0) };
        var apply = new Button { Content = "Apply selected", Padding = new Thickness(18,8,18,8), IsEnabled = false };
        cancel.SetResourceReference(StyleProperty, "ToolButton");
        apply.SetResourceReference(StyleProperty, "ToolPrimaryButton");
        apply.Click += (_, _) => { if (SelectedNames.Count > 0) DialogResult = true; };
        actions.Children.Add(cancel); actions.Children.Add(apply);
        var header = new StackPanel { Margin = new Thickness(0,0,0,14) };
        var title = new TextBlock { Text = "Review your changes" }; title.SetResourceReference(StyleProperty, "ToolHeading"); header.Children.Add(title);
        var description = new TextBlock { Text = "Uncheck anything you want to keep. App removal can erase local app data and requires reinstalling to undo. Selected services switch to Manual with recovery history.", TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,8,0,0) };
        description.SetResourceReference(StyleProperty, "ToolCaption"); header.Children.Add(description);
        var nameList = names.ToList();
        if (nameList.Contains("Microsoft OneDrive")) {
            var sync = new TextBlock { Text="OneDrive removal stops sync and folder backup. Download needed cloud-only files first; your data folder is retained.", TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,10,0,0) };
            sync.SetResourceReference(StyleProperty, "ToolCaption"); sync.SetResourceReference(ForegroundProperty, "CautionCol"); header.Children.Add(sync);
        }
        if (incompleteInventory) {
            var warning = new TextBlock { Text="Some sources could not be scanned. Only the listed selections will be targeted. See the activity log for details.", TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,10,0,0) };
            warning.SetResourceReference(StyleProperty, "ToolCaption"); warning.SetResourceReference(ForegroundProperty, "CautionCol"); header.Children.Add(warning);
        }
        DockPanel.SetDock(header, Dock.Top); layout.Children.Add(header);
        var count = new TextBlock { Margin = new Thickness(0,0,0,10) }; count.SetResourceReference(StyleProperty, "ToolCaption");
        DockPanel.SetDock(count, Dock.Top); layout.Children.Add(count);
        var rows = new StackPanel();
        void UpdateSelection() { int selected = SelectedNames.Count; count.Text = $"{selected} of {choices.Count} changes selected"; apply.IsEnabled = selected > 0; }
        foreach (var name in nameList) {
            var choice = new CheckBox { Content = new TextBlock { Text=AppDisplayNames.Get(name), TextWrapping=TextWrapping.Wrap }, Tag=name, ToolTip=name, IsChecked = true, Margin = new Thickness(6,4,6,4) };
            choice.SetResourceReference(StyleProperty, "ToolCheck");
            System.Windows.Automation.AutomationProperties.SetName(choice, AppDisplayNames.Get(name));
            choice.Checked += (_, _) => UpdateSelection();
            choice.Unchecked += (_, _) => UpdateSelection();
            choices.Add(choice); rows.Children.Add(choice);
        }
        UpdateSelection();
        layout.Children.Add(new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = rows });
    }
}
