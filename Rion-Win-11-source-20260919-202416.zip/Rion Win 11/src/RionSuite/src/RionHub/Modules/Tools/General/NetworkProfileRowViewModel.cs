using RadeonSoftwareSlimmer.Optimize;

namespace RionHub.Modules.Tools.General;

public sealed class NetworkProfileRowViewModel
{
    public Modules.Tools.Network.NetworkViewModel Network { get; } = new();
    public bool IsFeatured => true;
    public bool UseAdvancedSection { get; set; }
    public string DisplaySection => UseAdvancedSection ? TweakPresentationOrder.AdvancedSection : Section;
    public string Section => TweakBundleCatalog.PerformanceSection;
}
