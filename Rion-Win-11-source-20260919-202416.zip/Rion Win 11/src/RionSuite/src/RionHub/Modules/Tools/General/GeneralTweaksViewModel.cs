using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using GlassKit;
using RadeonSoftwareSlimmer.Optimize;
using RionHub.Shell;

namespace RionHub.Modules.Tools.General;

public sealed partial class GeneralTweaksViewModel : ObservableObject
{
	private static readonly string[] Categories = new string[] { "All Tweaks", "Quality of life", "Performance", "System", "Graphics", "Security", "Network", "MMCSS" };

	private readonly List<TweakBundleRowViewModel> _all;

	private bool _isBulkBusy;

	private int _selectedFilterIndex;

	private string _searchText = "";

	public NetworkProfileRowViewModel NetworkProfile { get; } = new NetworkProfileRowViewModel();

	public ProcessReductionRowViewModel ProcessReduction { get; } = new ProcessReductionRowViewModel();

	private bool CanStartBatch
	{
		get
		{
			if (!_isBulkBusy && !_all.Any((TweakBundleRowViewModel r) => r.IsBusy) && !ProcessReduction.IsBusy)
			{
				return !NetworkProfile.Network.IsBusy;
			}
			return false;
		}
	}

	public ObservableCollection<string> Filters { get; }

	public ObservableCollection<object> Rows { get; }

	public int SelectedFilterIndex
	{
		get
		{
			return _selectedFilterIndex;
		}
		set
		{
			if (Set(ref _selectedFilterIndex, value, "SelectedFilterIndex"))
			{
				Recompute();
			}
		}
	}

	public string SearchText
	{
		get
		{
			return _searchText;
		}
		set
		{
			if (Set(ref _searchText, value, "SearchText"))
			{
				Recompute();
			}
		}
	}

	public bool CanEditTweaks => !_isBulkBusy;

	public ObservableCollection<TweakOperationResult> Results { get; } = new ObservableCollection<TweakOperationResult>();

	public bool HasResults => Results.Count > 0;

	public string ResultSummary => TweakOperationResult.Summarize(Results);

	public string AppliedSummary
	{
		get
		{
			int value = _all.Sum((TweakBundleRowViewModel r) => r.AppliedCount);
			int value2 = _all.Sum((TweakBundleRowViewModel r) => r.TotalCount);
			return $"{value} of {value2} settings applied across {_all.Count} cards";
		}
	}

	public RelayCommand RefreshCommand { get; }

	public RelayCommand ApplyAllCommand { get; }

	public RelayCommand ApplyAllTweaksCommand { get; }

	public RelayCommand RevertAllCommand { get; }

	public GeneralTweaksViewModel()
	{
		_all = (from b in TweakBundleCatalog.All
			orderby Math.Max(0, TweakBundleCatalog.Sections.ToList().IndexOf(b.Section))
			select new TweakBundleRowViewModel(b)).ToList();
		Filters = new ObservableCollection<string>(Categories);
		Rows = new ObservableCollection<object>();
		RefreshCommand = new RelayCommand(RefreshAll);
		ApplyAllCommand = new RelayCommand(async delegate
		{
			await ApplyAllVisibleAsync();
		}, () => CanStartBatch && Rows.OfType<TweakBundleRowViewModel>().Any((TweakBundleRowViewModel r) => r.Recommended && !r.IsFullyOn));
		ApplyAllTweaksCommand = new RelayCommand(async delegate
		{
			await ApplyEntireCatalogAsync();
		}, () => CanStartBatch);
		RevertAllCommand = new RelayCommand(async delegate
		{
			await RevertAllVisibleAsync();
		}, () => CanStartBatch);
		foreach (TweakBundleRowViewModel item in _all)
		{
			item.PropertyChanged += delegate(object? _, PropertyChangedEventArgs args)
			{
				bool flag;
				switch (args.PropertyName)
				{
				case "IsBusy":
				case "IsOn":
				case "AppliedCount":
					flag = true;
					break;
				default:
					flag = false;
					break;
				}
				if (flag)
				{
					ApplyAllCommand.RaiseCanExecuteChanged();
					ApplyAllTweaksCommand.RaiseCanExecuteChanged();
					RevertAllCommand.RaiseCanExecuteChanged();
					Raise("AppliedSummary");
				}
			};
		}
		Recompute();
	}

	private void Recompute()
	{
		string category = Categories[Math.Clamp(_selectedFilterIndex, 0, Categories.Length - 1)];
        bool allTweaks = category == "All Tweaks";
        Rows.Clear();
        foreach (var row in _all) row.UseAdvancedSection = allTweaks && TweakPresentationOrder.IsAdvanced(row.Bundle);
        NetworkProfile.UseAdvancedSection = allTweaks;
        ProcessReduction.UseAdvancedSection = allTweaks;
        var ordered = TweakPresentationOrder.Sort(_all.Select(r => r.Bundle), allTweaks)
            .Select(b => _all.First(r => ReferenceEquals(r.Bundle, b)));
        foreach (TweakBundleRowViewModel item in ordered.Where(r => r.MatchesCategory(category) && r.MatchesSearch(SearchText)))
		{
			Rows.Add(item);
		}
		if ((category == "All Tweaks" || category == "Network") && (string.IsNullOrWhiteSpace(SearchText) || "Recommended adapter profile Wi-Fi Ethernet RSS Network EEE energy power savings offload".Contains(SearchText, StringComparison.OrdinalIgnoreCase)))
		{
			Rows.Add(NetworkProfile);
		}
		if (ProcessReduction.MatchesCategory(category) && ProcessReduction.MatchesSearch(SearchText))
		{
			Rows.Add(ProcessReduction);
		}
		Raise("AppliedSummary");
		ApplyAllCommand.RaiseCanExecuteChanged();
		ApplyAllTweaksCommand.RaiseCanExecuteChanged();
		RevertAllCommand.RaiseCanExecuteChanged();
	}

	private void RefreshAll()
	{
		foreach (TweakBundleRowViewModel item in _all)
		{
			item.Refresh();
		}
		Raise("AppliedSummary");
	}

	private async Task ApplyAllVisibleAsync()
	{
		await BulkAsync(applying: true, (from r in Rows.OfType<TweakBundleRowViewModel>()
			where r.Recommended
			select r).ToList(), "Applying recommended tweaks");
	}

	private async Task RevertAllVisibleAsync()
	{
		await BulkAsync(applying: false, (from r in Rows.OfType<TweakBundleRowViewModel>()
			where r.AppliedCount > 0 && !r.IsAdjustable
			select r).ToList(), "Restoring tweaks");
	}


	private async Task BulkAsync(bool applying, List<TweakBundleRowViewModel> targets, string verb, bool includeActions = false)
	{
		if (!CanStartBatch || targets.Count == 0 || (applying && !TweakConsent.Request(verb)))
		{
			return;
		}
		using (TweakConsent.ApprovedBatch())
		{
			_isBulkBusy = true;
			foreach (TweakBundleRowViewModel item in _all)
			{
				item.IsLocked = true;
			}
			Results.Clear();
			Raise("CanEditTweaks");
			Raise("HasResults");
			ApplyAllCommand.RaiseCanExecuteChanged();
			ApplyAllTweaksCommand.RaiseCanExecuteChanged();
			RevertAllCommand.RaiseCanExecuteChanged();
			List<TweakBatchItem> list = targets.SelectMany((TweakBundleRowViewModel r) => r.BatchItems(applying)).ToList();
			if (includeActions)
			{
				list.Add(new TweakBatchItem("process-reduction", "Process reduction", async delegate
				{
					await ProcessReduction.RunAsync();
					return TweakOperationResult.ForAction("process-reduction", "Process reduction", ProcessReduction.LastSucceeded, ProcessReduction.Status, ProcessReduction.LastChangedCount > 0);
				}));
				list.Add(new TweakBatchItem("adapter-profile", "Recommended adapter profile", async delegate
				{
					await NetworkProfile.Network.ApplyRecommendedAsync();
					return TweakOperationResult.ForAction("adapter-profile", "Recommended adapter profile", NetworkProfile.Network.LastProfileSucceeded, (NetworkProfile.Network.SelectedAdapter == null) ? "No adapter selected; connect and retry the profile." : NetworkProfile.Network.Status, NetworkProfile.Network.LastProfileChangedCount > 0);
				}));
			}
			IProgressToastHandle toast = ToastCenter.ShowProgress($"{verb}… 0/{list.Count}");
			try
			{
				await TweakBatch.RunAsync(list, delegate(int done, int total, TweakOperationResult result)
				{
					Results.Add(result);
					toast.Report(done, total, $"{verb}… {done}/{total}: {result.Title}");
					Raise("HasResults");
					Raise("ResultSummary");
				});
				if (Results.Any((TweakOperationResult r) => !r.Success))
				{
					toast.Fail(ResultSummary);
				}
				else
				{
					toast.Complete(ResultSummary);
				}
			}
			catch (Exception ex)
			{
				toast.Fail("Operation interrupted: " + ex.Message + ". " + ResultSummary);
			}
			finally
			{
				_isBulkBusy = false;
				foreach (TweakBundleRowViewModel item2 in _all)
				{
					item2.IsLocked = false;
					item2.Refresh();
				}
				Raise("CanEditTweaks");
				ApplyAllCommand.RaiseCanExecuteChanged();
				ApplyAllTweaksCommand.RaiseCanExecuteChanged();
				RevertAllCommand.RaiseCanExecuteChanged();
				Raise("AppliedSummary");
			}
		}
	}
}
