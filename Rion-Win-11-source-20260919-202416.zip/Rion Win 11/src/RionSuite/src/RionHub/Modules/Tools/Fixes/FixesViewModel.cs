using System.Collections.ObjectModel;
using System.Windows;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;
using RionHub.Shell;

namespace RionHub.Modules.Tools.Fixes;

public sealed class FixRowViewModel : ObservableObject
{
    private readonly FixDefinition _def;
    private readonly ObservableCollection<string> _sharedLog;

    public FixRowViewModel(FixDefinition def, ObservableCollection<string> sharedLog)
    {
        _def = def;
        _sharedLog = sharedLog;
        RunCommand = new RelayCommand(async () => await RunAsync(), () => !IsBusy);
    }

    public string Title => _def.Title;
    public string Description => _def.Description;
    public string Glyph => _def.Glyph;
    public bool IsNvidiaIcon => _def.Glyph == "nvidia";

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        private set { if (Set(ref _isBusy, value)) RunCommand.RaiseCanExecuteChanged(); }
    }

    private string _resultMessage = "";
    public string ResultMessage { get => _resultMessage; private set => Set(ref _resultMessage, value); }

    private bool _resultIsError;
    public bool ResultIsError { get => _resultIsError; private set => Set(ref _resultIsError, value); }

    public RelayCommand RunCommand { get; }

    private async System.Threading.Tasks.Task RunAsync()
    {
        IsBusy = true;
        ResultMessage = "";
        IProgressToastHandle toast = ToastCenter.ShowProgress($"{Title}…");
        try
        {
            FixResult result = await _def.Run(new WindowsRegistry(),
                line => Application.Current.Dispatcher.Invoke(() => _sharedLog.Add($"[{Title}] {line}")),
                (cur, tot) => toast.Report(cur, tot, $"{Title}… {cur}/{tot}"),
                default);
            ResultMessage = result.Message;
            ResultIsError = !result.Success;
            if (result.Success) toast.Complete(result.Message);
            else toast.Fail(result.Message);
        }
        catch (System.Exception ex)
        {
            ResultMessage = "Fix failed: " + ex.Message;
            ResultIsError = true;
            toast.Fail(ResultMessage);
        }
        finally
        {
            IsBusy = false;
        }
    }
}

public sealed class FixesViewModel : ObservableObject
{
    public ObservableCollection<FixRowViewModel> Fixes { get; } = new();
    public ObservableCollection<string> LogLines { get; } = new();

    public FixesViewModel()
    {
        foreach (FixDefinition def in FixCatalog.All)
            Fixes.Add(new FixRowViewModel(def, LogLines));
    }
}
