using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using RadeonSoftwareSlimmer.Models.PostInstall;
using RadeonSoftwareSlimmer.Optimize;
using RadeonSoftwareSlimmer.Services;
using RionHub.Shell;

namespace RionHub.Modules.Tools.Debloat;

public sealed class StoreAppRowViewModel : ObservableObject
{
    public string Name { get; init; } = "";
    public StorePackageInfo Package { get; init; } = new();
    public string DisplayName => AppDisplayNames.Get(Name) != Name ? AppDisplayNames.Get(Name) : string.IsNullOrWhiteSpace(Package.DisplayName) ? Name : Package.DisplayName;
    private bool scopeEligible = true;
    public bool ScopeEligible { get => scopeEligible; set { if (Set(ref scopeEligible, value)) { if (!CanRemove) IsSelected = false; Raise(nameof(CanRemove)); Raise(nameof(ReviewNote)); } } }
    public bool CanRemove => ScopeEligible && StorePackagePolicy.BlockReason(Package).Length == 0;
    public bool IsAdvanced => Package.SystemComponent || Package.IsFramework || Package.IsResourcePackage || StorePackagePolicy.BlockReason(Package).Length > 0 || !Package.CurrentUser;
    public string ReviewNote => StorePackagePolicy.BlockReason(Package) is { Length: > 0 } reason ? reason : !ScopeEligible ? "Not installed for this user. Choose an advanced removal scope if needed." : StorePackagePolicy.Impact(Name);
    public string ScopeLabel => (Package.CurrentUser ? "Current user" : "Other users / provisioned") + (Package.ProvisionedName.Length > 0 ? " · Provisioned for new users" : "");
    public string PackageFullName { get; init; } = "";
    public string Publisher { get; init; } = "";
    public string IconPath { get; init; } = "";
    public string IconGlyph => StoreAppIconResolver.FallbackGlyph(Name);
    public string PublisherGroup => Publisher.Contains("O=Microsoft Corporation", StringComparison.OrdinalIgnoreCase) ? "Microsoft" : "Other publishers";
    public long SizeBytes { get; init; }
    public string SizeLabel => SizeBytes > 0 ? $"{SizeBytes / 1024.0 / 1024.0:0.#} MB" : "—";

    private bool _isSelected;
    public bool IsSelected { get => _isSelected; set => Set(ref _isSelected, value); }
}

public sealed class DebloatViewModel : ObservableObject
{
    private CancellationTokenSource? _cts;

    public ObservableCollection<InstalledModel> DesktopApps { get; } = new();
    public ObservableCollection<StoreAppRowViewModel> StoreApps { get; } = new();
    public ICollectionView DesktopView { get; }
    public ICollectionView StoreView { get; }
    private string search = "";
    public string Search { get => search; set { if (Set(ref search, value)) { DesktopView.Refresh(); StoreView.Refresh(); RefreshPresentation(); } } }

    private bool showAdvanced, removeAllUsers, removeProvisioned;
    public bool ShowAdvanced { get => showAdvanced; set { if (Set(ref showAdvanced, value)) { if (!value) { RemoveAllUsers = false; RemoveProvisioned = false; foreach (var row in StoreApps.Where(r => r.IsAdvanced)) row.IsSelected = false; } StoreView.Refresh(); RefreshPresentation(); } } }
    public bool RemoveAllUsers { get => removeAllUsers; set { if (Set(ref removeAllUsers, value)) RefreshScopes(); } }
    public bool RemoveProvisioned { get => removeProvisioned; set { if (Set(ref removeProvisioned, value)) RefreshScopes(); } }
    private void RefreshScopes() { foreach (var row in StoreApps) row.ScopeEligible = row.Package.CurrentUser || RemoveAllUsers && row.Package.PackageFullName.Length > 0 || RemoveProvisioned && row.Package.ProvisionedName.Length > 0; RefreshPresentation(); }

    private bool _isStoreView;
    public bool IsStoreView
    {
        get => _isStoreView;
        set { if (Set(ref _isStoreView, value)) RefreshPresentation(); }
    }

    public int SelectedCount => IsStoreView
        ? StoreApps.Count(a => a.IsSelected && a.CanRemove)
        : DesktopApps.Count(a => a.Uninstall);

    private bool _isBusy;
    public bool IsBusy { get => _isBusy; private set { if (Set(ref _isBusy, value)) Raise(nameof(CanUninstallSelected)); } }
    public bool CanUninstallSelected => !IsBusy && SelectedCount > 0;
    public bool HasVisibleApps => !(IsStoreView ? StoreView : DesktopView).IsEmpty;
    public string InventorySummary => $"{(IsStoreView ? StoreView : DesktopView).Cast<object>().Count()} of {(IsStoreView ? StoreApps.Count : DesktopApps.Count)} apps";
    public string SelectionSummary => SelectedCount == 0 ? "Select apps to uninstall." : $"{SelectedCount} selected, including any hidden by search";
    private void RefreshPresentation()
    {
        Raise(nameof(SelectedCount)); Raise(nameof(SelectionSummary)); Raise(nameof(CanUninstallSelected));
        Raise(nameof(HasVisibleApps)); Raise(nameof(InventorySummary));
    }

    private string _status = "";
    public string Status { get => _status; private set => Set(ref _status, value); }

    public ObservableCollection<string> LogLines { get; } = new();

    public RelayCommand ScanCommand { get; }
    public RelayCommand UninstallSelectedCommand { get; }
    public RelayCommand AutoDebloatCommand { get; }
    private bool removeOneDrive, removeWidgets;
    public bool RemoveOneDrive { get => removeOneDrive; set => Set(ref removeOneDrive, value); }
    public bool RemoveWidgets { get => removeWidgets; set => Set(ref removeWidgets, value); }
    private bool trimServices = true;
    public bool TrimServices { get => trimServices; set => Set(ref trimServices, value); }

    public DebloatViewModel() : this(true) { }
    public DebloatViewModel(bool scanOnStart)
    {
        DesktopView = CollectionViewSource.GetDefaultView(DesktopApps);
        StoreView = CollectionViewSource.GetDefaultView(StoreApps);
        DesktopView.Filter = item => item is InstalledModel app && (string.IsNullOrWhiteSpace(Search)
            || (app.DisplayName + " " + app.Publisher).Contains(Search, StringComparison.OrdinalIgnoreCase));
        StoreView.Filter = item => item is StoreAppRowViewModel app && (ShowAdvanced || !app.IsAdvanced) && (string.IsNullOrWhiteSpace(Search)
            || (app.Name + " " + app.DisplayName + " " + app.PublisherGroup + " " + app.Publisher).Contains(Search, StringComparison.OrdinalIgnoreCase));
        StoreView.GroupDescriptions.Add(new PropertyGroupDescription(nameof(StoreAppRowViewModel.PublisherGroup)));
        DesktopApps.CollectionChanged += (_, _) => RefreshPresentation();
        StoreApps.CollectionChanged += (_, _) => RefreshPresentation();
        ScanCommand = new RelayCommand(async () => await ScanAsync());
        UninstallSelectedCommand = new RelayCommand(async () => await UninstallSelectedAsync());
        AutoDebloatCommand = new RelayCommand(async () => await AutoDebloatAsync());
        if (scanOnStart) _ = ScanAsync();
    }

    private async Task ScanAsync()
    {
        if (IsBusy) return;
        IsBusy = true;
        Status = "Scanning installed apps…";
        try
        {
            await ScanDesktopAppsAsync();
            await ScanStoreAppsAsync();
            Status = $"{DesktopApps.Count} desktop apps, {StoreApps.Count} Store apps.";
        }
        catch (Exception ex) { Status = "Scan incomplete: " + ex.Message; }
        finally
        {
            IsBusy = false;
            Raise(nameof(SelectedCount));
        }
    }

    private async Task ScanDesktopAppsAsync()
    {
        await Task.Run(() =>
            {
                var model = new InstalledListModel(new WindowsRegistry(), amdOnly: false);
                model.LoadOrRefresh();
                var items = model.InstalledItems.OrderBy(i => i.DisplayName).ToList();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    DesktopApps.Clear();
                    foreach (InstalledModel item in items)
                    {
                        item.PropertyChanged += OnRowPropertyChanged;
                        DesktopApps.Add(item);
                    }
                });
            });

    }

    private async Task ScanStoreAppsAsync()
    {
        var result = await ShellRunner.PowerShellAsync(StorePackagePolicy.InventoryScript, null, timeoutMs: 120000);
        if (result.ExitCode != 0 || result.TimedOut) throw new InvalidOperationException("Store inventory unavailable: " + result.Output);
        var packages = StorePackagePolicy.Parse(result.Output);
        var selected = StoreApps.Where(r => r.IsSelected).Select(r => r.PackageFullName).ToHashSet(StringComparer.OrdinalIgnoreCase);
        StoreApps.Clear();
        foreach (var package in packages.OrderBy(p => p.Name))
        {
            var row = new StoreAppRowViewModel { Name = package.Name, PackageFullName = package.PackageFullName, Publisher = package.Publisher, Package = package,
                IconPath = StoreAppIconResolver.Resolve(package.InstallLocation) };
            row.PropertyChanged += OnRowPropertyChanged; StoreApps.Add(row);
            row.ScopeEligible = package.CurrentUser || RemoveAllUsers && package.PackageFullName.Length > 0 || RemoveProvisioned && package.ProvisionedName.Length > 0;
            row.IsSelected = row.CanRemove && selected.Contains(row.PackageFullName);
        }
        StoreView.Refresh(); RefreshPresentation();
    }

    private void OnRowPropertyChanged(object? sender, PropertyChangedEventArgs e) => RefreshPresentation();

    private async Task UninstallSelectedAsync()
    {
        if (IsBusy || SelectedCount == 0) return;
        string reviewNotes = IsStoreView ? string.Join("\n", StoreApps.Where(a => a.IsSelected && a.CanRemove && a.ReviewNote.Length > 0).Select(a => a.ReviewNote)) : "";
        if (MessageBox.Show($"Uninstall {SelectedCount} selected app(s)? Apps may lose local data and need to be reinstalled. Selection includes apps hidden by search. Scope: {(RemoveAllUsers ? "all users" : "current user")}{(RemoveProvisioned ? ", including provisioned copies for future users" : "")}.\n{reviewNotes}",
            "Review app removal", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No) != MessageBoxResult.Yes) return;
        try
        {
        if (IsStoreView)
        {
            var selected = StoreApps.Where(a => a.IsSelected && a.CanRemove).ToList();
            if (selected.Count == 0) return;
            IsBusy = true;
            var toast = ToastCenter.ShowProgress($"Removing apps… 0/{selected.Count}");
            int removed = 0, done = 0;
            foreach (var app in selected)
            {
                try
                {
                    var result = await ShellRunner.PowerShellAsync(StorePackagePolicy.RemovalScript(app.Package, RemoveAllUsers, RemoveProvisioned), null, timeoutMs: 120000);
                    bool verified = result.ExitCode == 0 && !result.TimedOut && result.Output.Split('\n').Any(l => l.Trim() == "RION_REMOVAL_VERIFIED");
                    if (verified) { removed++; app.IsSelected = false; }
                    LogLines.Add(app.DisplayName + ": " + (verified ? "Removal verified." : "Failed or unconfirmed. " + result.Output));
                }
                catch (Exception ex) { LogLines.Add(app.DisplayName + ": " + ex.Message); }
                toast.Report(++done, selected.Count, $"Removing apps… {done}/{selected.Count}");
            }
            string summary = $"Removed {removed}/{selected.Count} apps; {selected.Count - removed} failed or unconfirmed.";
            if (removed == selected.Count) toast.Complete(summary); else toast.Fail(summary);
            await ScanStoreAppsAsync(); Status = summary;

        }
        else
        {
            var selected = DesktopApps.Where(a => a.Uninstall).ToList();
            if (selected.Count == 0) return;

            IsBusy = true;
            Status = $"Uninstalling {selected.Count} app(s)…";
            IProgressToastHandle toast = ToastCenter.ShowProgress($"Uninstalling apps… 0/{selected.Count}");
            await Task.Run(() =>
            {
                for (int i = 0; i < selected.Count; i++)
                {
                    InstalledModel app = selected[i];
                    Application.Current.Dispatcher.Invoke(() => LogLines.Add("Uninstalling " + app.DisplayName));
                    toast.Report(i, selected.Count, $"Uninstalling apps… {i}/{selected.Count}: {app.DisplayName}");
                    app.RunUninstaller();
                }
            });
            toast.Complete($"Requested uninstall for {selected.Count} app(s). Rescan to verify completion.");
            IsBusy = false;
            Status = "Done. Re-scan to refresh the list.";
        }

        Raise(nameof(SelectedCount));
        }
        catch (Exception ex) { Status = "Removal incomplete: " + ex.Message; }
        finally { IsBusy = false; Raise(nameof(SelectedCount)); }
    }

    private async Task AutoDebloatAsync()
    {
        if (IsBusy) return;
        IsBusy = true;
        Status = "Checking desktop and Store apps…";
        LogLines.Clear();
        _cts = new CancellationTokenSource();
        IProgressToastHandle toast = ToastCenter.ShowProgress("Running Auto Debloat…");
        try
        {
        bool removeSync = RemoveOneDrive, removeWidgetPackage = RemoveWidgets, manualServices = TrimServices;
        var inventory = await Task.Run(() => Modules.Optimize.AppInventoryScanner.Scan(_cts.Token, new Progress<string>(), removeWidgetPackage));
        LogLines.Add(inventory.WindowsDescription);
        var names = inventory.Apps.Where(a => a.DebloatCandidate && (removeSync || !a.Name.Equals("Microsoft OneDrive", StringComparison.OrdinalIgnoreCase)))
            .Select(a => a.Name).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n).ToList();
        var serviceNames = new System.Collections.Generic.List<string>();
        if (manualServices)
        {
            try { serviceNames = await Task.Run(() => ServiceTrimCatalog.Detect(new WindowsRegistry())
                .Where(s => ServiceTrimCatalog.GetCurrentStart(new WindowsRegistry(), s.Name) == 2).Select(s => s.Name).ToList()); }
            catch (Exception ex) { inventory.Warnings.Add("Service scan unavailable: " + ex.Message); }
        }
        foreach (var warning in inventory.Warnings) LogLines.Add(warning);
        foreach (var retained in inventory.Apps.Where(a => a.Protected && DebloatCatalog.Remove.Contains(a.Name, StringComparer.OrdinalIgnoreCase)).Select(a => a.Name).Distinct())
            LogLines.Add("Retained by Windows: " + retained);
        if (names.Count == 0 && serviceNames.Count == 0) { Status = inventory.Warnings.Count > 0 ? "Scan incomplete; no matches found in available sources." : "No matching apps or automatic optional services found."; toast.Complete(Status); return; }
        const string servicePrefix = "Service → Manual: ";
        var review = new DebloatReviewDialog(names.Concat(serviceNames.Select(n => servicePrefix + n)), inventory.Warnings.Count > 0);
        if (review.ShowDialog() != true)
        { Status = "Auto Debloat cancelled. No apps removed."; toast.Complete(Status); return; }
        names = review.SelectedNames;
        serviceNames = serviceNames.Where(n => names.Contains(servicePrefix + n)).ToList();
        names = names.Where(n => !n.StartsWith(servicePrefix, StringComparison.Ordinal)).ToList();
        Status = "Removing matching desktop and Store apps…";
        var (removed, notPresent, failed) = await DebloatCatalog.RunAsync(
            line => Application.Current.Dispatcher.Invoke(() => LogLines.Add(line)),
            (cur, tot) => toast.Report(cur, tot, $"Running Auto Debloat… {cur}/{tot}"),
            _cts.Token, removeSync ? Array.Empty<string>() : new[] { "Microsoft OneDrive" }, removeWidgetPackage, names);

        int servicesChanged = 0;
        if (serviceNames.Count > 0)
        {
            var serviceResult = await Task.Run(() =>
            {
                var backup = new BackupSession { Description = "Auto Debloat — optional services to Manual" };
                var result = ServiceTrimCatalog.Apply(new WindowsRegistry(), backup, serviceNames);
                backup.Save();
                return result;
            });
            servicesChanged = serviceResult.applied.Count;
            failed.AddRange(serviceResult.failed);
            foreach (var line in serviceResult.applied) LogLines.Add(line);
            foreach (var line in serviceResult.failed) LogLines.Add("Service change failed: " + line);
        }
        Status = $"Removed {removed.Count} app/package entries; {servicesChanged} services set to Manual. {failed.Count} failures or retained entries. Rescan after restarting to verify pending changes.";
        toast.Complete(Status);
        await ScanDesktopAppsAsync();
        await ScanStoreAppsAsync();
        }
        catch (Exception ex) { Status = "Auto Debloat incomplete: " + ex.Message; toast.Fail(Status); }
        finally { IsBusy = false; Raise(nameof(SelectedCount)); _cts.Dispose(); _cts = null; }
    }
}

