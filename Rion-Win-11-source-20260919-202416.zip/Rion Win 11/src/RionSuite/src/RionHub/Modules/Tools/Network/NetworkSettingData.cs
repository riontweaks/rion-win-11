using System;

namespace RionHub.Modules.Tools.Network;

public sealed class NetworkSettingData
{
	public string Adapter { get; set; } = "";

	public string Kind { get; set; } = "";

	public string Key { get; set; } = "";

	public string Group { get; set; } = "";

	public string Current { get; set; } = "";

	public string[] Choices { get; set; } = Array.Empty<string>();

	public string Note { get; set; } = "";

	public string Recommended { get; set; } = "";
}
