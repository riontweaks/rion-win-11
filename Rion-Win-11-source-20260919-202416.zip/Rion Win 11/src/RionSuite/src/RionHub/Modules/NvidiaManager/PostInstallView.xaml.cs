using System.Windows;
using System.Windows.Controls;
using NvidiaDriverTool.ViewModels;

namespace RionHub.Modules.NvidiaManager;

public partial class PostInstallView : UserControl
{
    private readonly NvidiaWizardViewModel wizard;
    public PostInstallView(NvidiaWizardViewModel wizard)
    {
        this.wizard = wizard;
        InitializeComponent();
        EnsureTab();
    }
    private void ModifyPackages_Click(object sender, RoutedEventArgs e) => wizard.ModifyPackage();
    private void Tabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    { if (ReferenceEquals(e.Source, Tabs)) EnsureTab(); }
    private void EnsureTab()
    {
        if (Tabs?.SelectedItem is not TabItem tab || tab.Content != null) return;
        switch (tab.Tag as string)
        {
            case "monitor": tab.Content = new Nvidia.Views.DashboardView(); break;
            case "tweaks":
            case "display":
                var vm = new Nvidia.ViewModels.ShellViewModel();
                vm.SelectedTab = vm.Tabs.First(t => t.Title == ((string)tab.Tag == "display" ? "Display" : "Performance"));
                tab.Content = new Nvidia.Views.NvidiaSectionView { DataContext = vm };
                break;
            case "packages":
                var packages = new Tools.Debloat.DebloatViewModel { Search = "NVIDIA" };
                tab.Content = new Tools.Debloat.DebloatView { DataContext = packages };
                break;
            case "startup":
                var startup = new Startup.StartupView();
                if (startup.DataContext is Startup.StartupViewModel model)
                { model.Search = "NVIDIA"; model.Category = "All entries (advanced)"; }
                tab.Content = startup;
                break;
        }
    }
}
