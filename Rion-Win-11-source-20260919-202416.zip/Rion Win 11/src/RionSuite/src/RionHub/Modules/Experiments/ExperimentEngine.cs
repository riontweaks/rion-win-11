using System.IO;
using System.Globalization;
using System.Text.Json;

namespace RionHub.Modules.Experiments;

public sealed record ExperimentDefinition(string Id, string Title, uint Target, string Description)
{
    public static readonly Guid Subgroup = new("54533251-82be-4824-96c1-47b60b740d00");
    public static readonly Guid Setting = new("893dee8e-2bef-41e0-89c6-b55d0929964c");
    public static readonly ExperimentDefinition[] All = {
        new("cpu-floor-100", "Processor minimum: 100% on AC", 100, "Test whether requesting a higher processor performance floor helps your workload. May increase idle power and heat. Actual clocks depend on hardware and firmware; improvement is unproven."),
        new("cpu-floor-5", "Processor minimum: 5% on AC", 5, "Test a lower processor performance floor against your current setting. May reduce idle power; workload response depends on hardware. This is a comparison target, not a universal recommendation.")
    };
    public override string ToString() => Title;
}

public sealed class ExperimentSession
{
    public int Version { get; set; } = 1;
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public DateTimeOffset Created { get; set; } = DateTimeOffset.Now;
    public string DefinitionId { get; set; } = "";
    public Guid Plan { get; set; }
    public uint Original { get; set; }
    public uint Target { get; set; }
    public string Environment { get; set; } = "";
    public string Workload { get; set; } = "";
    public string Metric { get; set; } = "Frame time (ms)";
    public List<double> Baseline { get; set; } = new();
    public List<double> Trial { get; set; } = new();
    public List<double> RestoredRuns { get; set; } = new();
    public string State { get; set; } = "Captured";
    public string LastResult { get; set; } = "Original value captured. No change applied.";
    public bool IsOpen => State is not ("Restored" or "Cancelled");
    public string Label => $"{Created:MMM d HH:mm} · {Target}% · {State}";
    public override string ToString() => Label;
    public string Details => $"{State} · AC minimum processor state: {Original}% → {Target}%\nPower plan: {Plan}\n{Environment}\nWorkload: {Workload}\nMetric: {Metric} · Runs: baseline {Baseline.Count}, trial {Trial.Count}, restored {RestoredRuns.Count}\n{LastResult}";
    public string Comparison => Baseline.Count < 3 || Trial.Count < 3 ? "Record at least three runs per phase. Use the same workload and measurement tool."
        : $"{Metric}: baseline {Baseline.Average():0.###} → trial {Trial.Average():0.###} ({(Trial.Average() / Baseline.Average() - 1) * 100:+0.0;-0.0;0}% change; lower is better).\n"
        + $"Range: {Baseline.Min():0.###}–{Baseline.Max():0.###} / {Trial.Min():0.###}–{Trial.Max():0.###}. "
        + (RestoredRuns.Count >= 3 ? $"Restored mean: {RestoredRuns.Average():0.###}. " : "Repeat baseline after restoring. ")
        + "Descriptive comparison only; this does not prove a benefit or measure input latency by itself.";
}

public interface IExperimentPower
{
    Guid ActivePlan();
    bool OnAc();
    uint Read(Guid plan);
    void Write(Guid plan, uint value);
    string DescribeEnvironment();
}

public sealed class ExperimentEngine
{
    private readonly string folder;
    private readonly IExperimentPower power;
    public ExperimentEngine(string folder, IExperimentPower power) { this.folder = folder; this.power = power; }
    private FileStream Lock()
    {
        Directory.CreateDirectory(folder);
        return new FileStream(Path.Combine(folder, ".lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    }
    private List<ExperimentSession> ReadAll() => Directory.GetFiles(folder, "*.json").Select(path => {
        var s = JsonSerializer.Deserialize<ExperimentSession>(File.ReadAllText(path)) ?? throw new InvalidDataException("Unreadable experiment journal: " + path);
        Validate(s); return s;
    }).OrderByDescending(s => s.Created).ToList();
    private static void Validate(ExperimentSession s)
    {
        if (s.Version != 1 || !Guid.TryParseExact(s.Id, "N", out _) || s.Plan == Guid.Empty || s.Original > 100
            || !ExperimentDefinition.All.Any(d => d.Id == s.DefinitionId && d.Target == s.Target)
            || s.State is not ("Captured" or "Applying" or "Applied" or "Restoring" or "Restored" or "Cancelled"))
            throw new InvalidDataException("Experiment journal is unsupported or damaged. No settings were changed.");
    }
    private void Save(ExperimentSession s)
    {
        Validate(s);
        string path = Path.Combine(folder, s.Id + ".json"), temp = path + ".tmp";
        using (var file = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None))
        { JsonSerializer.Serialize(file, s, new JsonSerializerOptions { WriteIndented = true }); file.Flush(true); }
        File.Move(temp, path, true);
    }
    public List<ExperimentSession> History() { using var gate = Lock(); return ReadAll(); }
    public ExperimentSession Capture(string definitionId, string workload, string metric)
    {
        using var gate = Lock();
        if (ReadAll().Any(s => s.IsOpen)) throw new InvalidOperationException("Restore or cancel the existing experiment first.");
        if (string.IsNullOrWhiteSpace(workload)) throw new InvalidOperationException("Describe the workload and measurement tool first.");
        var d = ExperimentDefinition.All.Single(x => x.Id == definitionId);
        if (!power.OnAc()) throw new InvalidOperationException("Connect AC power before capturing an experiment.");
        var plan = power.ActivePlan(); var original = power.Read(plan);
        if (original == d.Target) throw new InvalidOperationException("This plan already uses that value. Choose a different experiment.");
        var s = new ExperimentSession { DefinitionId = d.Id, Plan = plan, Original = original, Target = d.Target,
            Workload = workload.Trim(), Metric = metric, Environment = power.DescribeEnvironment() };
        Save(s); return s;
    }
    private ExperimentSession Get(string id) => ReadAll().Single(s => s.Id == id);
    public void Apply(string id)
    {
        using var gate = Lock(); var s = Get(id);
        if (s.State != "Captured" || s.Baseline.Count < 3) throw new InvalidOperationException("Capture and save three baseline runs before applying.");
        if (!power.OnAc() || power.ActivePlan() != s.Plan) throw new InvalidOperationException("Reconnect AC and select the captured power plan before applying.");
        if (power.Read(s.Plan) != s.Original) throw new InvalidOperationException("The setting changed outside this experiment. Cancel and capture a new baseline.");
        s.State = "Applying"; s.LastResult = "Change pending; original value saved for recovery."; Save(s);
        power.Write(s.Plan, s.Target);
        if (power.Read(s.Plan) != s.Target) throw new IOException("Target read-back failed. Use Restore original to recover.");
        s.State = "Applied"; s.LastResult = "Target written and read back successfully."; Save(s);
    }
    public void Restore(string id)
    {
        using var gate = Lock(); var s = Get(id);
        if (!s.IsOpen) throw new InvalidOperationException("This experiment is already closed.");
        if (s.State == "Captured") { s.State = "Cancelled"; s.LastResult = "Cancelled without writing any setting."; Save(s); return; }
        var current = power.Read(s.Plan);
        if (current != s.Target && current != s.Original) throw new InvalidOperationException("Restore stopped: another tool changed this setting. No value was overwritten.");
        s.State = "Restoring"; s.LastResult = "Original value restoration pending."; Save(s);
        power.Write(s.Plan, s.Original);
        if (power.Read(s.Plan) != s.Original) throw new IOException("Original value could not be verified. Recovery journal retained.");
        s.State = "Restored"; s.LastResult = "Original value restored and verified. Other power plans and battery values were not changed."; Save(s);
    }
    public void Record(string id, string values)
    {
        var samples = ParseSamples(values);
        using var gate = Lock(); var s = Get(id);
        if (s.State is not ("Captured" or "Applied" or "Restored")) throw new InvalidOperationException("Resolve the pending change before recording results.");
        uint expected = s.State == "Applied" ? s.Target : s.Original;
        if (!power.OnAc() || power.ActivePlan() != s.Plan || power.Read(s.Plan) != expected)
            throw new InvalidOperationException("The current power plan or setting no longer matches this phase. Results were not recorded.");
        if (s.State == "Captured") s.Baseline = samples;
        else if (s.State == "Applied") s.Trial = samples;
        else s.RestoredRuns = samples;
        s.LastResult = $"Saved {samples.Count} manually measured runs for this phase."; Save(s);
    }
    public static List<double> ParseSamples(string text)
    {
        var result = text.Split(new[] { '\r', '\n', ';', ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => double.TryParse(x, NumberStyles.Float, CultureInfo.InvariantCulture, out var n) && double.IsFinite(n) && n > 0 && n < 1e9
                ? n : throw new ArgumentException("Enter positive numbers using a decimal point, one run per line.")).ToList();
        if (result.Count < 3 || result.Count > 1000) throw new ArgumentException("Enter 3–1000 measured runs.");
        return result;
    }
    public string Export(string id)
    {
        using var gate = Lock(); var s = Get(id);
        var file = Path.Combine(folder, s.Id + "-report.md");
        File.WriteAllText(file, $"# Rion experiment — private research\n\n{s.Label}\n\n{s.Workload}\n\n{s.Details}\n\n{s.Comparison}\n\nBaseline: {string.Join(", ", s.Baseline)}\n\nTrial: {string.Join(", ", s.Trial)}\n\nRestored: {string.Join(", ", s.RestoredRuns)}\n\nNo statistical confidence or general recommendation is implied.\n");
        return file;
    }
}



