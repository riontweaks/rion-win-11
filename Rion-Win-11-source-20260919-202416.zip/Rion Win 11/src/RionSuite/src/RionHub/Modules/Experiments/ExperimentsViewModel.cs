using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
namespace RionHub.Modules.Experiments;

public sealed class ExperimentsViewModel : ObservableObject
{
    private readonly ExperimentEngine engine;
    public ExperimentsViewModel() : this(new ExperimentEngine(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RionWin11", "Experiments"), new WindowsExperimentPower())) { }
    public ExperimentsViewModel(ExperimentEngine engine)
    {
        this.engine = engine;
        CaptureCommand = new RelayCommand(() => Run(() => { var s = engine.Capture(Definition.Id, Workload, Metric); Reload(s.Id); }), () => !Busy && !History.Any(s => s.IsOpen));
        ApplyCommand = new RelayCommand(() => Run(() => engine.Apply(Selected!.Id)), () => !Busy && Selected?.State == "Captured" && Selected.Baseline.Count >= 3);
        RestoreCommand = new RelayCommand(() => Run(() => engine.Restore(Selected!.Id)), () => !Busy && Selected?.IsOpen == true);
        RecordCommand = new RelayCommand(() => Run(() => engine.Record(Selected!.Id, Samples)), () => !Busy && (Selected?.State is "Captured" or "Applied" or "Restored"));
        RefreshCommand = new RelayCommand(() => Run(() => Reload()), () => !Busy);
        ExportCommand = new RelayCommand(() => Run(() => { Status = "Report saved: " + engine.Export(Selected!.Id); }), () => !Busy && Selected != null);
        ResearchCommand = new RelayCommand(() => Process.Start(new ProcessStartInfo("https://learn.microsoft.com/windows-hardware/test/wpt/cpu-analysis") { UseShellExecute = true }));
        try { Reload(); } catch (Exception ex) { Status = "Could not load journals: " + ex.Message; }
    }
    public ExperimentDefinition[] Definitions => ExperimentDefinition.All;
    private ExperimentDefinition definition = ExperimentDefinition.All[0];
    public ExperimentDefinition Definition { get => definition; set => Set(ref definition, value); }
    public string[] Metrics { get; } = { "Frame time (ms)", "Audio latency (ms)", "Task duration (ms)" };
    public string Metric { get; set; } = "Frame time (ms)";
    public string Workload { get; set; } = "";
    private string samples = "";
    public string Samples { get => samples; set => Set(ref samples, value); }
    public ObservableCollection<ExperimentSession> History { get; } = new();
    private ExperimentSession? selected;
    public ExperimentSession? Selected { get => selected; set { if (Set(ref selected, value)) { Samples = ""; Update(); } } }
    private bool busy;
    public bool Busy { get => busy; set { Set(ref busy, value); Update(); } }
    private string status = "Ready. Capture a baseline to begin; nothing changes when this page opens.";
    public string Status { get => status; set => Set(ref status, value); }
    public string Phase => Selected?.State switch { "Captured" => "Baseline — record three or more runs, then apply", "Applied" => "Experiment — repeat the same workload, then restore", "Restored" => "Restored — repeat baseline to check reproducibility", "Applying" or "Restoring" => "Interrupted change — use Restore original to recover", _ => "Choose or capture an experiment" };
    public RelayCommand CaptureCommand { get; }
    public RelayCommand ApplyCommand { get; }
    public RelayCommand RestoreCommand { get; }
    public RelayCommand RecordCommand { get; }
    public RelayCommand RefreshCommand { get; }
    public RelayCommand ExportCommand { get; }
    public RelayCommand ResearchCommand { get; }
    private void Update()
    {
        Raise(nameof(Phase));
        foreach (var command in new[] { CaptureCommand, ApplyCommand, RestoreCommand, RecordCommand, RefreshCommand, ExportCommand }) command?.RaiseCanExecuteChanged();
    }
    private void Reload(string? id = null)
    {
        var previous = id ?? Selected?.Id;
        var rows = engine.History(); History.Clear(); foreach (var row in rows) History.Add(row);
        Selected = History.FirstOrDefault(s => s.Id == previous) ?? History.FirstOrDefault(s => s.IsOpen) ?? History.FirstOrDefault(); Update();
    }
    private void Run(Action action)
    {
        if (Busy) return;
        Busy = true;
        try { Status = ""; action(); Reload(); if (Status.Length == 0) Status = Selected?.LastResult ?? "Refreshed."; }
        catch (Exception ex) { Status = ex.Message; try { Reload(); } catch { } }
        finally { Busy = false; }
    }
}
