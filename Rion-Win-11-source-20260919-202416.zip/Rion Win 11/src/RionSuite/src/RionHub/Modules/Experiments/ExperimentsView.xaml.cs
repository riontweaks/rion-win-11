using System.Windows.Controls;
namespace RionHub.Modules.Experiments;
public partial class ExperimentsView : UserControl
{
    public ExperimentsView() { InitializeComponent(); }
}
