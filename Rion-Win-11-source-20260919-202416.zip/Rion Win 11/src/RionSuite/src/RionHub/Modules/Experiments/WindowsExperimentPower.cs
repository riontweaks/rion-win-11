using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32;
namespace RionHub.Modules.Experiments;

public sealed class WindowsExperimentPower : IExperimentPower
{
    [DllImport("powrprof.dll")] private static extern uint PowerGetActiveScheme(IntPtr key, out IntPtr scheme);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
    [DllImport("powrprof.dll")] private static extern uint PowerReadACValueIndex(IntPtr key, ref Guid scheme, ref Guid subgroup, ref Guid setting, out uint value);
    [DllImport("powrprof.dll")] private static extern uint PowerWriteACValueIndex(IntPtr key, ref Guid scheme, ref Guid subgroup, ref Guid setting, uint value);
    [DllImport("powrprof.dll")] private static extern uint PowerSetActiveScheme(IntPtr key, ref Guid scheme);
    [StructLayout(LayoutKind.Sequential)] private struct PowerStatus { public byte Ac, Battery, Percent, Reserved; public uint Life, FullLife; }
    [DllImport("kernel32.dll")] private static extern bool GetSystemPowerStatus(out PowerStatus status);
    private static void Check(uint code) { if (code != 0) throw new Win32Exception((int)code); }
    public Guid ActivePlan()
    {
        Check(PowerGetActiveScheme(IntPtr.Zero, out var pointer));
        try { return Marshal.PtrToStructure<Guid>(pointer); } finally { LocalFree(pointer); }
    }
    public bool OnAc() => GetSystemPowerStatus(out var status) && status.Ac == 1;
    public uint Read(Guid plan)
    {
        var subgroup = ExperimentDefinition.Subgroup; var setting = ExperimentDefinition.Setting;
        Check(PowerReadACValueIndex(IntPtr.Zero, ref plan, ref subgroup, ref setting, out var value));
        return value;
    }
    public void Write(Guid plan, uint value)
    {
        if (value > 100) throw new ArgumentOutOfRangeException(nameof(value));
        var subgroup = ExperimentDefinition.Subgroup; var setting = ExperimentDefinition.Setting;
        Check(PowerWriteACValueIndex(IntPtr.Zero, ref plan, ref subgroup, ref setting, value));
        if (ActivePlan() == plan) Check(PowerSetActiveScheme(IntPtr.Zero, ref plan));
    }
    public string DescribeEnvironment()
    {
        using var os = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        using var cpu = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
        return $"Windows build {os?.GetValue("CurrentBuildNumber")}.{os?.GetValue("UBR")} · {cpu?.GetValue("ProcessorNameString")} · {Environment.ProcessorCount} logical CPUs";
    }
}
