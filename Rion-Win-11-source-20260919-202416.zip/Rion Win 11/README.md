# Rion Win 11

A Windows 11 desktop utility for GPU controls, driver preparation, power settings, startup apps, network settings and reversible system tweaks. Built with C#/.NET 8 and WPF for Windows x64.

Download from the [Files release](https://github.com/riontweaks/rion-win-11/releases/tag/Files):

- **[Portable EXE](https://github.com/riontweaks/rion-win-11/releases/download/Files/Rion-Win11-Portable.exe)** — run without installing.
- **[Installer EXE](https://github.com/riontweaks/rion-win-11/releases/download/Files/Rion-Win11-Setup.exe)** — offline setup with shortcuts and an uninstaller.

Both contain .NET; no separate runtime download is required. Licenses are available inside **About → Licenses and notices**. Release notes contain checksums and the corresponding source link.

## Build

Install the .NET 8 SDK on Windows (Visual Studio 2022 with .NET desktop development is optional).

```powershell
./tools/Build.ps1
./tools/Test.ps1
./tools/Publish.ps1
./tools/Build-Installer.ps1 -CompilerPath 'C:\Tools\nsis-3.12\makensis.exe'
./tools/Export-Source.ps1
```

Open `Rion Win 11.sln` in Visual Studio. Publishing creates `dist/win-x64/Rion Win 11.exe`, checksums, a source/artifact manifest and license notices. License files accompany the distribution but are not runtime dependencies. Native GPU APIs use the installed vendor drivers. The executable requests administrator rights for system operations.

The separate installer build uses NSIS 3.12 and produces
`dist/installer/Rion-Win11-Setup.exe`. It embeds the self-contained core and all
license notices, registers an uninstaller, and preserves local profiles and
recovery data on removal. Optional utility downloads are separate. Clean-system
install, upgrade and uninstall still require validation. Feature coverage and
remaining work are recorded in [IMPLEMENTATION.md](docs/IMPLEMENTATION.md).

`tools/Test.ps1` runs the selected regression suites with fake system state and child-process fixtures; it requires no administrator rights. See [testing](docs/TESTING.md) for coverage and limits. Publishing preserves the previous output under `dist/previous` and leaves raw build output under `dist/.staging` for inspection. The portable EXE embeds its license notices; the installer also installs loose copies. Manifests and checksums stay available as local verification records.

## Layout

```text
Rion Win 11.sln         Main solution
src/
  RionSuite/           Shell, network/startup/Windows pages and integration tests
  RionAmdThinner/      Shared engines and AMD driver preparation
  ALDX/                AMD control panel and dashboard
  Nvidia/              NVIDIA control panel
  NvidiaDriverTool/    NVIDIA driver preparation
  Power Settings Explorer/  Power plan editor and tests
tools/                 Build, publish and source export scripts
docs/                  Architecture, contribution and release notes
licenses/              Preserved upstream notices
dist/                  Generated standalone releases (not committed)
artifacts/             Generated logs and local build reports (not committed)
```

Tests stay beside their owning projects to preserve relative paths and ownership. Internal module names are retained for upstream attribution and compatibility. Old demos, remote-support prototypes, SDK reference downloads, screenshots, logs and backups are outside the publishable source tree.

## Licensing and release status

The combined application uses GPL-3.0 because it incorporates the GPL-3.0 Radeon Software Slimmer engine. Existing third-party licenses and copyright notices remain in force; see [third-party notices](THIRD_PARTY_NOTICES.md).

**Local source-release preparation:** the owner states that Rion Power Settings was independently authored. Independent provenance verification and the final release checks remain open. See [release readiness](docs/RELEASE.md).

The Files release offers only the two application downloads above. Web-bootstrapper tooling is retained for compatibility but is not used for this delivery. Use `tools/Export-Source.ps1` to create a source package containing the application, tests, build tools, and public documentation. Local workspace history and generated reports are excluded.

## Contributing

Read [CONTRIBUTING.md](CONTRIBUTING.md). Build success is not evidence that hardware writes, gaming performance or antivirus behavior have been validated.


## GPU and BIOS workflows

GPU edits are staged and reviewed before applying, with a cancellable delay and timed Keep/Revert confirmation. BIOS Settings, Fans and Profiles share saved scans; imports require a fresh compatible scan and verified readback, followed by a restart prompt. Ambiguous firmware fan curves and unverified NVIDIA settings remain unavailable. See [workflow details](docs/UI-BIOS-WORKFLOWS.md).
