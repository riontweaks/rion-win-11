# GPU controls: routing and limits

Updated 2026-09-19. A native route means the app calls a documented driver interface and checks its result. It does not mean every GPU, display, driver or game supports the control. NVIDIA hardware writes have not been validated on a physical NVIDIA system.

## AMD display controls

All 15 display catalogue entries have native ADLX routes: FreeSync, VSR, GPU scaling, scaling mode, integer scaling, colour depth, pixel format, Vari-Bright enable/preset, colour temperature, HDCP, hue, saturation, brightness and contrast. Runtime capability checks still decide availability.

Custom colour uses `IADLXDisplayCustomColor` with individual support, range, getter and setter calls. Sliders snap to the driver's step; native writes reject nonfinite, fractional, out-of-range and off-step values and check readback. Colour temperature commonly uses 100 K increments, which the previous slider ignored.

The display selector uses ADLX display identities and names. Re-detect re-enumerates displays; losing the selected display does not silently redirect writes to another one. AMD display routing is separate from the discrete GPU selected for 3D/tuning.

## NVIDIA catalogue coverage

The catalogue has 54 display/graphics entries: 48 writable native routes, one read-only HDCP capability route and five explicitly unavailable entries. Tuning identifiers are separate from this catalogue and remain unavailable through the current public integration.

| Group | Native routing |
| --- | --- |
| Display | G-SYNC global mode through DRS; selected-display GPU/scaling/integer scaling through Get/SetDisplayConfig; colour depth, format and output dynamic range through ColorControl; GPU HDCP capability is read-only |
| Existing graphics | Pre-rendered frame queue, V-Sync, FPS cap, AA mode/level, FXAA, anisotropy mode/level, texture quality, threaded optimization, OpenGL triple buffering, shader cache enable, power management |
| Additional graphics | Ambient occlusion, transparency multisampling/supersampling, AA gamma correction, MFAA, anisotropic sample/filter optimization, trilinear optimization, negative LOD bias, automatic LOD bias, preferred refresh rate, VR pre-rendered frames, Vulkan/OpenGL presentation, OpenGL GDI compatibility/deep colour, PhysX/FXAA indicators and adaptive V-Sync tear control |
| DLSS overrides | DLAA, frame-generation mode/override/preset, ray-reconstruction override/quality/preset and super-resolution override/quality/preset; effective behaviour requires a compatible GPU, driver and application |
| Explicitly unavailable | DSR and smoothness, NVIDIA Image Scaling and sharpness, and in-game Reflex + Boost. No verified native routes are implemented for these entries. |
| GeForce tuning | Automatic OC, voltage/clock offsets, fan curves, power and temperature targets still require a supported vendor tool; this integration has no verified public setters for them. |

The queue control is labelled pre-rendered frame queue because `PRERENDERLIMIT_ID` is not NVIDIA's separate Ultra Low Latency mechanism. V-Sync now decodes the application-controlled default; anisotropy decodes the linear-filtering default. A 2x AA choice is explicitly labelled diagonal. All six documented power-management values are represented.

Scaling reads the complete topology, preserves sources/targets, resolution, position, rotation, refresh and timing, edits only the selected display's scaling field, validates the topology, then submits it. Unknown current scaling modes are blocked because exact restoration cannot be guaranteed. NVIDIA display selection currently enumerates the first physical GPU; multi-GPU adapter selection remains a limitation.

## Inspect, apply and restore

Detection and display enumeration are read-only. Before a setting's first edit, its current value is saved to the local restore snapshot. Snapshots are bound to the selected display and retain native scaling values, colour-selection policy, and DRS DWORD/predefined status. Revert all restores only settings touched through that snapshot. NVIDIA predefined DRS states use RestoreProfileDefaultSetting instead of creating a user override with the same value. Failures are shown; restore does not silently report success.

Display edits retain the 15-second keep-or-revert confirmation. Changing displays cancels pending slider edits and is blocked while a write is active. Unavailable rows show a reason; a failed or unimplemented route must not be described as proof of a hardware limitation.

## Validation

- `tools/Build.ps1 -Configuration Release`: successful, with existing repository warnings.
- `src/RionSuite/tests/GpuWiring`: 455 checks passed using fake native interfaces, including custom-colour range/step rejection, readback mismatch, NVIDIA second-monitor targeting, topology preservation, validation rejection, colour-policy restoration and DRS predefined-state restoration.
- `src/RionSuite/tests/GpuProfiles` and `GpuWorkflow`: passed, using mock providers and UI rendering.
- Read-only RX 7700 XT query: all five AMD custom-colour controls supported; temperature read 6500 K with 4000–10000 K range and 100 K step. No live GPU setting was written.

## References

- [AMD Custom Color](https://gpuopen.com/manuals/adlx/adlx-sdk-references/adlx-interfaces/display/iadlxdisplaycustomcolor/)
- [AMD display interfaces](https://github.com/GPUOpen-LibrariesAndSDKs/ADLX/blob/main/SDK/Include/IDisplays.h)
- [NVIDIA settings constants](https://github.com/NVIDIA/nvapi/blob/main/NvApiDriverSettings.h)
- [NVIDIA display API](https://docs.nvidia.com/nvapi/group__dispcontrol.html)
- [NVIDIA ABI and interface IDs](https://github.com/NVIDIA/nvapi)

This is not complete AMD Software or NVIDIA App parity. Vendor-only features, application-specific features and hardware restrictions remain distinct from implemented routes.
