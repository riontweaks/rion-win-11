# Regression checks

On Windows x64 with the .NET 8 SDK, run from any directory:

```powershell
./tools/Test.ps1
```

The script runs suites sequentially, stops on the first failure, and defaults to Release. Use `-Configuration Debug` when debugging. NUnit result files are saved under `artifacts/test-results`; the UI fixtures write images and generated scripts under `artifacts`.

| Suite | What it checks |
| --- | --- |
| ReleasePackaging | Inert publish fixture, notices/checksums, source drift rejection, previous output preservation and private-file exclusions |
| Startup | Fake startup/service state, protection rules, dependency failures, durable history and exact restoration |
| PowerHistory | Injected power-setting reads/writes, restoration, conflicting external changes, invalid imports and backup failures |
| Selected RadeonSoftwareSlimmer tests | Custom tweak/Nagle/registry history restoration with injected registry, storage and command failures |
| ShellRunner | Fixture child-process output, failures, cancellation, timeout and process cleanup |
| DiskCleanup | Fixture directories only: path/link protection, locked or unreadable files, cancellation, cache filters and deletion totals |
| OptimizationRegression | Catalog decisions, partial batch failures, protected apps and selected WPF bindings/layout |
| RecoveryFeatures | RAM threshold table, CoreCycler configuration backups/conflict detection, BIOS export/edit/profile integrity, network rate arithmetic and driver identity matching; see [recovery notes](RECOVERY.md) for optional archive and render checks |
| NetworkBenchmark | Real loopback HTTP upload/download, concurrent payload caps, cancellation, truncated-response rejection, report round trips, route/configuration mismatch and conservative repeated-run comparisons; no Internet speed test or adapter mutation |
| GpuProfiles | Both vendors' complete preset transitions, inherited NVIDIA defaults, cancellation, timeout, partial failures, exact rollback, readback rejection and AMD Chill endpoint dependencies with fake providers |
| UiWorkflows | AMD/Intel fan layouts, duplicate-table blocking, exact export bytes, scan/profile persistence, incompatible snapshots, offline import handling, stale scans, portable license resources and 96 BIOS/GPU renders at 560/900/1280/1600 DIPs × 100/150/200% raster scale |
| Installer publisher tests | Exact AMD certificate-name policy shared by inspection/preparation/execution, rejected signatures, spoofed names and locked executable paths; installers are never launched |
| GpuInteraction | Mock-driver continuous slider writes, coalescing, late readback, final values, cancellation and failure; fan native increments, point ordering, endpoint preservation, keyboard/numeric edits, and AMD/NVIDIA fan/dropdown renders at four widths and three scales |
| DebloatExpansion | Exact package identities, kept Windows utilities, service selection and review UI |
| Responsiveness | Fake GPU discovery, lazy module initialization, cached/hidden/retry dashboard lifecycle, NVIDIA navigation gates, and dispatcher telemetry ordering/coalescing/cancellation; no native GPU providers are initialized |
| Typography / TypographyLayout | Shared font references across source XAML; compact Drivers auto-scan, retry, check/apply visibility and ambiguous-candidate exclusion using injected fake inventory; checkbox wrapping, search alignment and narrow History layouts rendered at 560/900/1280/1600 DIP and 100/150/200% image scale |
| StoreDebloat / PackageRemoval PowerShell fixtures | Generated production scripts with fake AppX commands; provisioning, failed inventories, partial failures, retained apps and readback |

These suites do not run live registry, service, AppX, driver, GPU, network or power-setting mutations. They do not certify every screen, physical hardware behavior, gaming performance or antivirus results. Tests that inspect live hardware or depend on extra fixtures are intentionally outside this default list.

The selected RadeonSoftwareSlimmer engine tests use `RionWorkflowTests=true` to exclude the old `ShellSmokeTests.cs`, which still references a removed standalone window. The explicit filter in `tools/Test.ps1` includes installer publisher/execution checks and the selected recovery, command-state and control tests. This is focused engine coverage; it is not a claim that the entire legacy test project compiles or passes without that switch. Disk cleanup fixtures create and restore permissions only inside their generated fixture directories.

`WebInstaller.Tests.ps1` exercises the embedded downloader with in-memory HTTP
responses: expected bytes, hash rejection, truncated/oversize bodies even when
headers claim the expected length, HTTP failure, HTTPS-only URLs, cleanup and
existing-file preservation. It runs without executing downloaded payloads.

GitHub Actions runs this command before packaging. `Publish.ps1` builds and packages; it does not repeat the regression suites. A successful publish alone is not a passing test report.

The UI matrix uses WPF offscreen layout and rasterization at 96/144/192 DPI. It does not claim physical monitor switching or complete OS accessibility certification. Private full NVRAM exports may be supplied as arguments to UiWorkflows for local byte-preservation and profile checks; only sanitized fan excerpts are committed.
