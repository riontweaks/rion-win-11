# Unified prompt implementation coverage

Controlling request: `Rion-Win11-Unified-Astra-Prompt.md` supplied by Ryan,
with later chat corrections taking precedence. This record tracks the entire
request; a passing build or completed UI task is not whole-request completion.

Later corrections: BIOS belongs under Tweaks and uses native Rion styling;
Utilities is a top-level page, removed from Windows; prepare the pinned Rion2
package at startup without launching tools; CoreCycler uses one auto-saving
selector. AMD BIOS suggestions must distinguish AMD PBO from Ai Tweaker, permit
scalar 1× and +200 MHz override, and leave Curve Optimizer/PBO limits unchanged.
SvcHostSplitThresholdInKB uses Ryan's hexadecimal RAM table. Individual-choice
MMCSS/Win32 settings remain excluded from Apply all.

| Prompt | Current implementation and remaining work | Evidence / owner |
| --- | --- | --- |
| 1 Recovery/baseline | Buildable recovered/reconstructed source; original EXE preserved. Behavioral parity is not certified. | RECOVERY.md; Build.ps1 |
| 2 Navigation | BIOS, Drivers, Utilities and Network Benchmark added. Network settings now live under Tweaks; Autoruns directly opens the existing startup manager with the verified Microsoft utility launcher. Dedicated Services/Privacy and CPU OC placement remain open. | ShellViewModel |
| 3 Shared execution/recovery | Existing ShellRunner, TweakService, StartupEngine, registry history, network settings backup reused. New settings must retain exact original state and stale-state checks. Coverage remains incomplete. | Existing regression suites |
| 4 UI/responsiveness | Shared font/layout changes and lazy GPU loading implemented by concurrent tasks. Measured physical-machine cold/warm/idle data not yet complete. | Rework pages; Improve responsiveness |
| 5 Services | Existing startup-service backend is present. Full registry/SCM dual-state inventory, delayed/trigger state, preview and runtime controls not yet completed. | StartupEngine; pending |
| 6 Privacy/security | Existing individual tweaks; dedicated applicable-policy inventory and complete shared profile workflow pending. Supported Defender inspection required; no bypass methods. | pending audit |
| 7 Autoruns/bloat | Autoruns navigation and verified Microsoft utility launcher integrated with existing StartupEngine. Full Autorunsc inventory/signature/category coverage remains open; current integrated inventory is the existing startup engine. | Startup regression; Rework pages |
| 8 Scheduler | Existing Win32 choices and new guidance owned by Rework task; synchronized advanced hex/decimal editor and verified bit interpretation still require audit. | General tweaks |
| 9 GPU/fans/profiles | AMD display/NVIDIA DRS additions retained. GPU dropdowns, continuous coalesced sliders and precise fan editing (numbers, keys, drag, native increments, detected endpoints) implemented. NVIDIA fan tuning remains unavailable in its production page; a full NVIDIA per-application DRS editor remains open. | GpuWiring455; GpuInteraction fixtures/renders |
| 10 Platform controls | Existing catalogs; full target/provenance/deduplication audit and unclear acronyms still open. | pending |
| 11 Network settings | Existing dynamic PowerShell/CIM settings engine and reversible history. MSI applicability and unsupported registry inventory need audit. | NetworkSettings.ps1 fixtures |
| 12 Network benchmark | Quick/Detailed real HTTPS upload/download, unloaded/loaded gateway/remote latency, DNS normal/cache-bypass timing, TCP/TLS/application response, CPU/errors/discards/context, payload budgets/cancellation and local JSON reports are implemented. Repeat-run comparison rejects mismatched routes/settings and reports descriptive ranges; fully automatic approved candidate trials, rollback orchestration and independent winner confirmation remain open. | NetworkBenchmark32 loopback assertions; integrated build |
| 13 BIOS | Byte-preserving decimal/hex/signed/string edits, explicit range/step constraints, schema-bound profiles, two-file comparison/diff export, original96-entry draft review, AMI/prerequisite checks and live operation popup are implemented. Saved/demo exports cannot invoke firmware writes; active import has no forced timeout. CPU/board detection and16 original vendor text badges added. Approved AMD/Intel automatic presets and verified PBO section/units mapping are still absent. | RecoveryFeatures fixture/render; no live firmware writes tested |
| 14 OC Tuner | Guided supported runtime PBO/CO experiment workflow not implemented. Hardware compatibility must be established before enabled writes. | pending |
| 15 Utilities | Twenty original/imported/installable entries, categorized with icons and CoreCycler selector. Version/removal workflows and selected-installation support still need audit. | Archive65 / render58 assertions |
| 16 Delivery | Reproducible self-contained core publish, source ZIP and NSIS3.12 single-EXE installer build entry points. Clean-system install/upgrade/uninstall testing remains open, as does whole-request completion. | tools/Build, Test, Publish, Build-Installer, Export-Source |

## Network design and evidence

Use native asynchronous .NET measurements and Windows read-only diagnostics;
ordinary benchmark execution never changes network settings. Display payload
budgets separately from additional protocol overhead. Saved reports keep raw
samples, route/interface context, phase durations and reasons for missing data.

The September 19 benchmark repair distinguishes Windows' direct-route response
(`IsBypassed=false`, `GetProxy=null`) from an actual proxy. Actual proxied routes
remain explicitly unavailable for adapter-bound tests; they are not bypassed.
Inspection/setup has a 25-second deadline and runs off the UI dispatcher.
Transfer progress refreshes independently of latency probes, keeps the completed
download visible during upload, and ignores queued updates after completion.
The compact page retains detailed latency, traffic charts and local reports in
secondary sections. Network fixtures now cover 32 assertions, including delayed
progress, direct/proxied route detection and slow-probe transfer updates. A local
read-only Wi-Fi inspection passed; Internet throughput was not measured during
this repair.

Shared context menus use dark templates without the native icon gutter.
Application-owned WPF dialogs receive dark native captions; the BIOS operation
dialog applies this before showing. Caption APIs follow Microsoft's
[DWM attributes](https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute).
System-owned file/message dialogs continue to use Windows rendering.

Endpoint protocol reference: [Cloudflare speedtest README](https://github.com/cloudflare/speedtest),
checked 2026-09-19. Its documented HTTPS download and upload endpoints provide
purpose-built test traffic. Rion does not copy the JavaScript engine or send a
separate results-logging request. The endpoint necessarily receives the client's
IP and measurement requests. No TURN/UDP-loss result is inferred from ICMP.

[Microsoft NTTTCP](https://github.com/microsoft/ntttcp) is a Windows throughput
tool requiring a configured sender/receiver pair. It is suitable for a controlled
LAN peer, not a substitute for an Internet endpoint. Native HTTPS is the first
integrated transport; NTTTCP execution/peer orchestration remains to be verified.

## BIOS draft provenance and limits

The supplied HTML contains one `BUILTIN_PROFILE`, with 96 entries; its own
description says it is not a validated motherboard preset. The exact original
JSON is archived in `Assets/Profiles/Rion-source-draft.json`. The Intel LAN
entry refers to a network controller, not an Intel CPU profile. Imported draft
risk labels are not compatibility evidence. The app requires a unique exported
field and option for individual staging, never executes `applyToAll`, and blocks
fixed CO, PBO, memory-clock, security-reducing and cooling targets from these
profile actions. Numeric range information not present in an export is shown as
unknown; field width is not presented as a safe operating range.

Original text badges recognize ASUS, ASRock, MSI, Gigabyte, EVGA, Biostar,
Supermicro, Dell, HP, Lenovo, Acer, Fujitsu, Intel, Tyan, Shuttle and NZXT. They
are not official vendor logos. Firmware vendor and CPU detection do not establish
compatibility for automatic optimization.

## September 19 recovery checkpoint

After the reported PC crash, the canonical source, previous self-contained EXE,
installer and matching source ZIP remained on disk. This checkpoint continues
those files; it does not claim to repair Codex's local conversation database.

The GPU interaction increment replaces release-only slider debouncing with a
75 ms coalescing timer, permits only one write per setting, and protects newer
input from stale readback. AMD continuous color settings retain original-state
capture and restoration without opening a modal confirmation for every sample.
Display-mode/scaling/color-format changes retain confirmation. Fan edits snap
to backend increments and preserve detected endpoint temperatures; the graph
shows duty %, temperatures, individual labels, numeric entry and arrow-key edits.
The maximize icon closes correctly and follows every window-state change.

The remaining table entries above are real unfinished work, not completion
claims. In particular, no universal Intel BIOS preset exists in the supplied
HTML; automatic firmware recommendations and runtime PBO/CO writes still need
verified platform mappings. Network comparison exists, but automatic candidate
application/rollback trials do not. Services startup suppression is not the
requested complete SCM/registry service editor. NVIDIA recommendation presets
are not a full per-application profile editor. Installer packaging is implemented;
clean-VM install/upgrade/uninstall and physical GPU-write validation remain open.

## Validation boundaries

### Quality of life checkpoint

General now has one expandable Quality of life card with 18 individual controls,
including hidden taskbar Search/Task View, dark/opaque appearance, minimize and
taskbar animations, Widgets/Search highlights, Start recommendations, persistent
OneDrive sync policy, legacy Copilot and supported Paint AI policies. Its main
action skips unsupported and individual-choice controls; current values refresh
automatically without Inspect buttons. Per-setting restore
uses the existing journals. Recall is explicitly individual because its policy
deletes existing snapshots, which registry restoration cannot recover.

Resume, all animation effects, and build-dependent Start Pinned/All section
visibility open native Windows settings from inside this card. Their automatic
configuration is not implemented. Current standalone Copilot removal remains in
Debloating; no claim is made that a legacy policy disables every AI experience.
Snipping Tool is preserved. Autoruns now reviews all eligible desktop startup
apps across all pages, excluding services/tasks/packaged or unknown entries.
Windows Search has an explicit signed-system-service Manual option with exact
startup-state history; it stays protected from disable batches. Manual does not
mean search-triggered indexing, and it does not stop an already running indexer.


Use loopback servers, fake settings/hardware and read-only host queries.
Never change live registry/services/network/driver/GPU/firmware merely to prove
a test. Hardware/firmware compatibility cannot be certified by a mock or compile.
Before final packaging, coordinate concurrent tasks, run applicable regression
checks, freeze source, record artifact timestamps/hashes and retain the previous
release. Update this record as actual features and tests land.



