# Release preparation

## Current delivery: portable and installer EXEs

The Files release contains `Rion-Win11-Portable.exe` (the self-contained application) and `Rion-Win11-Setup.exe` (the complete offline installer). Legacy ZIPs, bootstrapper payloads and standalone manifest assets are superseded. Release notes hold both SHA-256 hashes and a link to the matching source archive in the repository. The portable app embeds license notices under About; setup also installs loose notices. Web-installer tooling below remains available for compatibility, but is not used for this release.

Compact GPU pages stage edits and complete profiles, verify readback and retain recovery records. BIOS pages add persisted scans, full-snapshot numbered profiles, safe fan mode/preset controls, offline imports and post-import restart prompts. Ambiguous fan curves remain preview-only. Rion profile review detects Intel/AMD and excludes protected or ambiguous settings. Network Benchmark is removed from navigation. AMD package inspection and preparation now share an exact publisher-name policy, including the verified `Advanced Micro Devices` signer used by the 26.8.1 package.

See [workflow details](UI-BIOS-WORKFLOWS.md) and [test coverage](TESTING.md). No live hardware writes are performed by the regression or rendering suites.

## September 19, 2026: GPU responsiveness and controls

NVIDIA setting detection, backup reads and telemetry run away from the UI dispatcher. DRS reads share a session; write verification uses a fresh session. Stalled telemetry clears stale values. Corrected thermal targets and clock/presence decoding; optional NVML adds current clock, utilization, temperature, board-power and fan-percent readings when the single GPU identity matches. Unsupported readings remain unavailable. Physical NVIDIA hardware validation is still required.

Added documented Battery Boost frame-limit presets and External Quiet Mode, gated by driver support, with compact descriptions and driver-support checks. Linux profiler clock-gating masks are not exposed as Windows registry tweaks. AMD TDC is a validated read-only percentage; its historical persisted identifier is retained. Win32 Separation Control offers five individually selected presets with exact restore support and restart guidance.

Fake-provider tests cover dispatcher responsiveness, stalled samples, native units, DRS batching/verification, GPU setting routing and recovery. The test suite makes no live GPU or registry changes.

## Reproducible entry points

- `tools/Build.ps1`: solution build, one MSBuild worker to avoid shared WPF generated-file races.
- `tools/Test.ps1`: selected fake-state and child-process regression suites; see [TESTING.md](TESTING.md). CI requires these to pass before packaging.
- `tools/Publish.ps1`: self-contained Windows x64 single-file EXE, checksums, source/artifact manifest and preserved licensing notices under `dist/win-x64`.
- `tools/Build-Installer.ps1 -CompilerPath <makensis.exe>`: NSIS 3.12 single-EXE setup containing that exact published core, with uninstaller and start-menu shortcut. Validates package/source hashes before building; no optional utility payload is embedded. Install/upgrade/uninstall have not been exercised on a clean test VM.
- `tools/Build-Web-Installer.ps1 -CompilerPath <makensis.exe>`: tiny online setup in `dist/web-installer`, built after the offline installer. It downloads a hash-named copy of that installer over HTTPS, enforces expected size and SHA-256, then installs silently into the selected folder. Upload the generated payload unchanged to the URL in `HOSTING.txt` before distributing online setup. `-DownloadBaseUrl` selects another public HTTPS hosting directory. Compilation does not establish that hosting is live.
- `tools/Export-Source.ps1`: source-only ZIP with public build tools and an explicit documentation allowlist; excludes workspace history, research snapshots, generated output and local credentials.
- .NET SDK used for the initial reorganization check: 8.0.424.

Unsigned downloads are published in the [GitHub Files release](https://github.com/riontweaks/rion-win-11/releases/tag/Files). Do not claim SmartScreen reputation, zero antivirus detections, or hardware-test coverage from these builds.

Installer compiler source: [NSIS official download](https://nsis.sourceforge.io/Download).
Both setup variants and the uninstaller use the application's `ApplicationIcon`
from its project file. Offline setup uses solid LZMA with a 64 MiB dictionary;
online setup embeds only its downloader and release identity. The full runtime
and license notices remain in the downloaded payload. Download failure, size or
hash mismatch prevents payload execution; no installer payload is executed by
the build/verification scripts.
NSIS 3.12 portable ZIP SHA-256 from the official SourceForge release download:
`56581F90DB321581C5381193D796FFFCF2D24B2F8FED2160A6C6A3BAA67F2C4F`.
Compiler binaries stay outside the source tree. `licenses/NSIS-COPYING.txt`
preserves installer component licensing. The installer deletes explicit managed
file paths, never a recursive wildcard of the install directory or user data.

## Before a public launch

Resolve the Power Settings Explorer upstream license/permission issue described in THIRD_PARTY_NOTICES.md. Finish dependency/license review, preserve corresponding-source obligations, review the public tree for private information, and choose a public repository/release destination. An initial common credential-pattern scan found no matches; that is not a complete secret audit.

Build from a consistent final source snapshot. Package the source corresponding to that exact binary, preserve notices, and record the binary checksum. Keep signing keys outside the source tree.

## Local package verification

Run `tools/Test.ps1` before `tools/Publish.ps1`. Publishing creates a fresh staging directory, compares public source hashes before and after the build, and refuses to promote output if the source changed. `release-manifest.json` records the source inventory, SDK version, packaging options and payload hashes. `SHA256SUMS.txt` covers every package file except itself, including the manifest. Neither file certifies behavior or records test results that were not run by that command.

The ready package contains the EXE, root license/notices, `licenses/`, manifest and checksums. Loose debug symbols stay in `dist/.staging`, outside the distributable. The previous `dist/win-x64` is moved intact to `dist/previous` only after the new package is ready; failed builds retain the previous release. Local staging and previous output are retained for inspection.

Source export uses the same public file inventory as the manifest. Export from the unchanged source snapshot used for publishing, then compare its inventory with `release-manifest.json`. The exporter does not automatically bind a later source ZIP to an earlier binary. Private handoffs and review reports are never included merely because they are Markdown files.

Security hardening, source-license limits and scan procedure: [SECURITY.md](SECURITY.md). Antivirus reports must be recorded against the final release hash.


## September 19, 2026: Autoruns layout update

The Autoruns page uses a compact wrapping toolbar, shorter startup rows, a blue selection highlight, and collapsed entry details. Single-page lists hide pagination. The summary now distinguishes entries on the page from entries visible without scrolling. Startup behavior and recovery remain unchanged.

Follow the corresponding-source link in the release notes for this update. GitHub-generated archives follow the existing Files tag and may describe an older repository snapshot.

