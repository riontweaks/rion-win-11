# NVIDIA DRS mapping and diagnostic boundary

Checked 2026-09-19 against NVIDIA's public Windows SDK and upstream NVIDIA Profile Inspector metadata. This review does not claim hardware validation of every setting or approval to write unknown settings.

## Sources and licensing

- [NVIDIA nvapi.h](https://github.com/NVIDIA/nvapi/blob/main/nvapi.h): `NVDRS_SETTING_V1`, setting types, predefined validity, value location and `NvAPI_DRS_EnumSettings`.
- [NVIDIA interface IDs](https://github.com/NVIDIA/nvapi/blob/main/nvapi_interface.h): enum-settings ID `0xAE3039DA` and restore-default-setting ID `0x53F0381E`.
- [NVIDIA setting definitions](https://github.com/NVIDIA/nvapi/blob/main/NvApiDriverSettings.h): public DRS setting identifiers and named DWORD values. Installed drivers can differ from the latest SDK.
- [NVIDIA Profile Inspector](https://github.com/Orbmu2k/nvidiaProfileInspector), [custom names and descriptions](https://github.com/Orbmu2k/nvidiaProfileInspector/blob/master/nvidiaProfileInspector/CustomSettingNames.xml), and [metadata loader](https://github.com/Orbmu2k/nvidiaProfileInspector/blob/master/nvidiaProfileInspector/AppBootstrapper.cs): useful secondary mapping references. Inspector separates friendly metadata from native numeric identities and permits external metadata overrides. A friendly name or community description does not establish a public driver contract.
- [Inspector MIT license](https://github.com/Orbmu2k/nvidiaProfileInspector/blob/master/LICENSE). No Inspector source, XML, or descriptions are copied into this change. Existing NVIDIA SDK attribution remains in `licenses/NVIDIA-NVAPI.txt`.

## Current routes

| Area | Current evidence and boundary |
| --- | --- |
| Power management | Public `PREFERRED_PSTATE_ID` maps six named choices. This is a scheduling/power preference, not a board-power limit. Read the driver's predefined value instead of treating adaptive or optimal as a universal default. |
| Frame queue | `PRERENDERLIMIT_ID` controls pre-rendered frames. It must not be relabeled as Reflex or Ultra Low Latency. |
| V-Sync | `VSYNCMODE_ID` selects sync behavior. Adaptive tear control is a separate ID; a single DWORD cannot represent both independent settings. |
| Texture filtering | Preserve unsigned raw values: high-quality is `0xFFFFFFF6`. Do not coerce it to an arbitrary signed slider value. |
| Frame limiter | `FRL_FPS_ID` is public. The app's displayed slider and native map currently have different maxima (360 versus 1000); this diagnostic work does not silently expand the UI. |
| Additional graphics | The existing `AdditionalGraphicsSettings` catalog holds public DRS IDs and explicit values for AA, filtering, presentation and DLSS controls. Existence in a new SDK does not ensure applicability to every installed driver, GPU or game. |
| NIS / DSR / Reflex boost | Catalog descriptions are not verified native mappings. They remain unmapped where the app lacks an unambiguous supported implementation. No ID guesses or inspector-only values are enabled here. |
| Display configuration | Color and scaling are display-specific APIs, not generic DRS DWORDs. `ReadDefault` deliberately does not guess defaults for them. |
| Overclocking / board power | Native setters remain unavailable where verified interfaces and recovery are absent. Mock tuning support is not native support. |
| Kernel profiler symbols | NVIDIA's open GPU kernel repository is Linux source. `NVB0CC_CTRL_PROFILER_CG_CONTROL_MASK_BLCG` is a profiler control-mask field, not a Windows registry value or public NVAPI setting. |

## Read-only API

`INvapiProvider.ReadDrsDiagnostics(CancellationToken)` returns a snapshot of the **base profile only**, identified as `NVAPI/base-profile`. It does not enumerate applications, choose a game profile, alter registry keys, call save/set/restore, or automatically run during navigation. Call it on a worker thread: cancellation is checked between driver calls and cannot interrupt a native call already in progress.

The snapshot preserves numeric setting ID, native name, exact type and location, raw predefined/current flags, and current/predefined values. A predefined value is present only when the driver marks it valid. DWORD and QWORD values retain all bits; binary values retain their byte length and payload. Unicode strings retain UTF-16 bytes and display text; narrow strings retain bytes without assuming a code page. Unknown types retain raw union storage and an explicit interpretation error. Invalid binary lengths and unterminated strings are reported, not read outside buffers.

Enumeration uses initialized versioned records and binary capacities, 32 entries per call, a 4096-entry maximum, and a disposable DRS session. Error, cancellation, duplicate ID and safety-limit snapshots are incomplete. No write exports are required for diagnostics.

`DrsDiagnostics.Compare(before, after)` matches numeric setting IDs within equal profile identities. Order does not matter. Type, location, flags, name, current and predefined metadata changes remain visible. Partial snapshots and duplicate IDs cannot establish additions/removals and are rejected. This compares profile contents; it does not establish that two captures came from the same physical GPU, host or driver release. Record those separately when comparing captures across machines. No import or apply operation is offered.

## Driver defaults

`INvapiProvider.ReadDefault(SettingId)` reads valid predefined DWORD values for existing mapped DRS controls, decodes the value through the existing mapping, and marks the result `RestoreNative=true`, `NativePredefined=true`, `NativeDword=<exact predefined DWORD>`. Missing default metadata, unknown values, non-DWORD types, unmapped settings or unavailable exact restoration produce unsupported results. The method makes no changes. Applying such a result through the existing write path restores that one predefined setting and verifies it; it does not reset the entire profile/database. The mock returns its initialized baseline defaults, independent of subsequent changes.

## Validation

Hardware-free `TestDrsDiagnostics` in the GpuWiring suite checks predefined/current separation, absent and unknown defaults, mock baseline stability, binary/QWORD/Unicode decoding, unknown types, identity-based comparisons, cancellation and malformed enumeration counts. The enumeration fixture runs with set/save exports absent and checks session cleanup. No live GPU write is used as a test.
